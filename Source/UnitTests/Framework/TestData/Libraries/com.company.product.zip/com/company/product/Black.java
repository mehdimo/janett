package painting.colors;

public class Black
{
	public java.lang.String getName();
}
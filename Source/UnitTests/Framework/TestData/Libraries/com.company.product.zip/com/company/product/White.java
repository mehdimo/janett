package painting.colors;

public class White
{
	public java.lang.String getName();
}
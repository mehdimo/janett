package org.maya.commons.codeManagement;

public class JavaTransformation
{
	public java.lang.Void translate();
}
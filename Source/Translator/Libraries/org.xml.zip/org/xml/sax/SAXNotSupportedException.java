package org.xml.sax;

abstract class SAXNotSupportedException extends org.xml.sax.SAXException
{
	public SAXNotSupportedException(java.lang.String parameter1) ;
}

package org.xml.sax;

abstract class SAXNotSupportedException extends org.xml.sax.SAXException
{
}

package org.xml.sax;

interface Attributes
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.String getLocalName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getQName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getType(java.lang.Integer parameter1) ;
	public abstract java.lang.String getURI(java.lang.Integer parameter1) ;
	public abstract java.lang.String getValue(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getIndex(java.lang.String parameter1) ;
	public abstract java.lang.String getType(java.lang.String parameter1) ;
	public abstract java.lang.String getValue(java.lang.String parameter1) ;
	public abstract java.lang.Integer getIndex(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.String getType(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.String getValue(java.lang.String parameter1, java.lang.String parameter2) ;
}

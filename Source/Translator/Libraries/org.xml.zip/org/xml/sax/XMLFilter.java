package org.xml.sax;

interface XMLFilter implements org.xml.sax.XMLReader
{
	public abstract org.xml.sax.XMLReader getParent() ;
	public abstract java.lang.Void setParent(org.xml.sax.XMLReader parameter1) ;
}

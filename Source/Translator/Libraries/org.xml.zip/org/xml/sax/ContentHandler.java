package org.xml.sax;

interface ContentHandler
{
	public abstract java.lang.Void endDocument() ;
	public abstract java.lang.Void startDocument() ;
	public abstract java.lang.Void characters(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void ignorableWhitespace(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void endPrefixMapping(java.lang.String parameter1) ;
	public abstract java.lang.Void skippedEntity(java.lang.String parameter1) ;
	public abstract java.lang.Void setDocumentLocator(org.xml.sax.Locator parameter1) ;
	public abstract java.lang.Void processingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void startPrefixMapping(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void endElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void startElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, org.xml.sax.Attributes parameter4) ;
}

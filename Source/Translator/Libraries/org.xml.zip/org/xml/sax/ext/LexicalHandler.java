package org.xml.sax.ext;

interface LexicalHandler
{
	public abstract java.lang.Void endCDATA() ;
	public abstract java.lang.Void endDTD() ;
	public abstract java.lang.Void startCDATA() ;
	public abstract java.lang.Void comment(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void endEntity(java.lang.String parameter1) ;
	public abstract java.lang.Void startEntity(java.lang.String parameter1) ;
	public abstract java.lang.Void startDTD(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
}

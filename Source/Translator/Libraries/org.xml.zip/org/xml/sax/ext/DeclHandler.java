package org.xml.sax.ext;

interface DeclHandler
{
	public abstract java.lang.Void elementDecl(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void internalEntityDecl(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void externalEntityDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void attributeDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5) ;
}

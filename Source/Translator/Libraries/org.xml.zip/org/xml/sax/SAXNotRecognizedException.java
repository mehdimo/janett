package org.xml.sax;

abstract class SAXNotRecognizedException extends org.xml.sax.SAXException
{
	public SAXNotRecognizedException(java.lang.String parameter1) ;
}

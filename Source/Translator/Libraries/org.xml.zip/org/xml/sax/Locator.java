package org.xml.sax;

interface Locator
{
	public abstract java.lang.Integer getColumnNumber() ;
	public abstract java.lang.Integer getLineNumber() ;
	public abstract java.lang.String getPublicId() ;
	public abstract java.lang.String getSystemId() ;
}

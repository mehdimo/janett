package org.xml.sax;

interface XMLReader
{
	public abstract java.lang.Void parse(java.lang.String parameter1) ;
	public abstract java.lang.Boolean getFeature(java.lang.String parameter1) ;
	public abstract java.lang.Void setFeature(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public abstract org.xml.sax.ContentHandler getContentHandler() ;
	public abstract java.lang.Void setContentHandler(org.xml.sax.ContentHandler parameter1) ;
	public abstract org.xml.sax.DTDHandler getDTDHandler() ;
	public abstract java.lang.Void setDTDHandler(org.xml.sax.DTDHandler parameter1) ;
	public abstract org.xml.sax.EntityResolver getEntityResolver() ;
	public abstract java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public abstract org.xml.sax.ErrorHandler getErrorHandler() ;
	public abstract java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public abstract java.lang.Void parse(org.xml.sax.InputSource parameter1) ;
	public abstract java.lang.Object getProperty(java.lang.String parameter1) ;
	public abstract java.lang.Void setProperty(java.lang.String parameter1, java.lang.Object parameter2) ;
}

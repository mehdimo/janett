package org.xml.sax;

interface AttributeList
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.String getName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getType(java.lang.Integer parameter1) ;
	public abstract java.lang.String getValue(java.lang.Integer parameter1) ;
	public abstract java.lang.String getType(java.lang.String parameter1) ;
	public abstract java.lang.String getValue(java.lang.String parameter1) ;
}

package org.xml.sax;

abstract class SAXParseException extends org.xml.sax.SAXException
{
	public java.lang.Integer getColumnNumber() ;
	public java.lang.Integer getLineNumber() ;
	public java.lang.String getPublicId() ;
	public java.lang.String getSystemId() ;
	public SAXParseException(java.lang.String parameter1, org.xml.sax.Locator parameter2) ;
	public SAXParseException(java.lang.String parameter1, org.xml.sax.Locator parameter2, java.lang.Exception parameter3) ;
	public SAXParseException(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public SAXParseException(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Exception parameter6) ;
}

package org.xml.sax;

abstract class SAXParseException extends org.xml.sax.SAXException
{
	public java.lang.Integer getColumnNumber() ;
	public java.lang.Integer getLineNumber() ;
	public java.lang.String getPublicId() ;
	public java.lang.String getSystemId() ;
}

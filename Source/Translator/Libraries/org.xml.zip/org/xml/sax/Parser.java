package org.xml.sax;

interface Parser
{
	public abstract java.lang.Void parse(java.lang.String parameter1) ;
	public abstract java.lang.Void setLocale(java.util.Locale parameter1) ;
	public abstract java.lang.Void setDTDHandler(org.xml.sax.DTDHandler parameter1) ;
	public abstract java.lang.Void setDocumentHandler(org.xml.sax.DocumentHandler parameter1) ;
	public abstract java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public abstract java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public abstract java.lang.Void parse(org.xml.sax.InputSource parameter1) ;
}

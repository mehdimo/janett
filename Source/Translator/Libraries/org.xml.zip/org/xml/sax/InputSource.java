package org.xml.sax;

abstract class InputSource
{
	public java.io.InputStream getByteStream() ;
	public java.lang.Void setByteStream(java.io.InputStream parameter1) ;
	public java.io.Reader getCharacterStream() ;
	public java.lang.Void setCharacterStream(java.io.Reader parameter1) ;
	public java.lang.String getEncoding() ;
	public java.lang.String getPublicId() ;
	public java.lang.String getSystemId() ;
	public java.lang.Void setEncoding(java.lang.String parameter1) ;
	public java.lang.Void setPublicId(java.lang.String parameter1) ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
}

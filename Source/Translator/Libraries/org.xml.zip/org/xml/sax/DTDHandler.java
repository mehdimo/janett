package org.xml.sax;

interface DTDHandler
{
	public abstract java.lang.Void notationDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void unparsedEntityDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
}

package org.xml.sax;

interface ErrorHandler
{
	public abstract java.lang.Void error(org.xml.sax.SAXParseException parameter1) ;
	public abstract java.lang.Void fatalError(org.xml.sax.SAXParseException parameter1) ;
	public abstract java.lang.Void warning(org.xml.sax.SAXParseException parameter1) ;
}

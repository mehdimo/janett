package org.xml.sax;

abstract class SAXException extends java.lang.Exception
{
	public java.lang.Exception getException() ;
	public SAXException(java.lang.Exception parameter1) ;
	public java.lang.String getMessage() ;
	public java.lang.String toString() ;
	public SAXException(java.lang.String parameter1) ;
	public SAXException(java.lang.String parameter1, java.lang.Exception parameter2) ;
}

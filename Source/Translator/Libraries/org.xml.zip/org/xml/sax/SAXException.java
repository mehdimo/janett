package org.xml.sax;

abstract class SAXException extends java.lang.Exception
{
	public java.lang.Exception getException() ;
	public java.lang.String getMessage() ;
	public java.lang.String toString() ;
}

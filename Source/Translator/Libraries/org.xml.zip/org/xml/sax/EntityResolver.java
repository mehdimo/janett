package org.xml.sax;

interface EntityResolver
{
	public abstract org.xml.sax.InputSource resolveEntity(java.lang.String parameter1, java.lang.String parameter2) ;
}

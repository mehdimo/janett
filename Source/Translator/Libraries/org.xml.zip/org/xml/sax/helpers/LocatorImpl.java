package org.xml.sax.helpers;

abstract class LocatorImpl implements org.xml.sax.Locator
{
	public java.lang.Integer getColumnNumber() ;
	public java.lang.Integer getLineNumber() ;
	public LocatorImpl() ;
	public java.lang.Void setColumnNumber(java.lang.Integer parameter1) ;
	public java.lang.Void setLineNumber(java.lang.Integer parameter1) ;
	public java.lang.String getPublicId() ;
	public java.lang.String getSystemId() ;
	public java.lang.Void setPublicId(java.lang.String parameter1) ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
	public LocatorImpl(org.xml.sax.Locator parameter1) ;
}

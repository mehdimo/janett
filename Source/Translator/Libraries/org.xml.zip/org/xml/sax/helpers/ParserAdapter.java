package org.xml.sax.helpers;

abstract class ParserAdapter implements org.xml.sax.XMLReader, org.xml.sax.DocumentHandler
{
	public java.lang.Void endDocument() ;
	public java.lang.Void startDocument() ;
	public java.lang.Void characters(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void ignorableWhitespace(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void endElement(java.lang.String parameter1) ;
	public java.lang.Void parse(java.lang.String parameter1) ;
	public java.lang.Boolean getFeature(java.lang.String parameter1) ;
	public java.lang.Void setFeature(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public org.xml.sax.ContentHandler getContentHandler() ;
	public java.lang.Void setContentHandler(org.xml.sax.ContentHandler parameter1) ;
	public org.xml.sax.DTDHandler getDTDHandler() ;
	public java.lang.Void setDTDHandler(org.xml.sax.DTDHandler parameter1) ;
	public org.xml.sax.EntityResolver getEntityResolver() ;
	public java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public org.xml.sax.ErrorHandler getErrorHandler() ;
	public java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public java.lang.Void parse(org.xml.sax.InputSource parameter1) ;
	public java.lang.Void setDocumentLocator(org.xml.sax.Locator parameter1) ;
	public java.lang.Object getProperty(java.lang.String parameter1) ;
	public java.lang.Void setProperty(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void processingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void startElement(java.lang.String parameter1, org.xml.sax.AttributeList parameter2) ;
}

package org.xml.sax.helpers;

abstract class XMLFilterImpl implements org.xml.sax.XMLFilter, org.xml.sax.EntityResolver, org.xml.sax.DTDHandler, org.xml.sax.ContentHandler, org.xml.sax.ErrorHandler
{
	public java.lang.Void endDocument() ;
	public java.lang.Void startDocument() ;
	public java.lang.Void characters(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void ignorableWhitespace(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void endPrefixMapping(java.lang.String parameter1) ;
	public java.lang.Void parse(java.lang.String parameter1) ;
	public java.lang.Void skippedEntity(java.lang.String parameter1) ;
	public java.lang.Boolean getFeature(java.lang.String parameter1) ;
	public java.lang.Void setFeature(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public org.xml.sax.ContentHandler getContentHandler() ;
	public java.lang.Void setContentHandler(org.xml.sax.ContentHandler parameter1) ;
	public org.xml.sax.DTDHandler getDTDHandler() ;
	public java.lang.Void setDTDHandler(org.xml.sax.DTDHandler parameter1) ;
	public org.xml.sax.EntityResolver getEntityResolver() ;
	public java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public org.xml.sax.ErrorHandler getErrorHandler() ;
	public java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public java.lang.Void parse(org.xml.sax.InputSource parameter1) ;
	public java.lang.Void setDocumentLocator(org.xml.sax.Locator parameter1) ;
	public java.lang.Void error(org.xml.sax.SAXParseException parameter1) ;
	public java.lang.Void fatalError(org.xml.sax.SAXParseException parameter1) ;
	public java.lang.Void warning(org.xml.sax.SAXParseException parameter1) ;
	public org.xml.sax.XMLReader getParent() ;
	public java.lang.Void setParent(org.xml.sax.XMLReader parameter1) ;
	public java.lang.Object getProperty(java.lang.String parameter1) ;
	public java.lang.Void setProperty(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void processingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void startPrefixMapping(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void endElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.Void notationDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public org.xml.sax.InputSource resolveEntity(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void unparsedEntityDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
	public java.lang.Void startElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, org.xml.sax.Attributes parameter4) ;
}

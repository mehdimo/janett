package org.xml.sax.helpers;

abstract class ParserFactory
{
	public org.xml.sax.Parser makeParser() ;
	public org.xml.sax.Parser makeParser(java.lang.String parameter1) ;
}

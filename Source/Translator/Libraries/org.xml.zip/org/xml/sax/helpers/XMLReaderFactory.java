package org.xml.sax.helpers;

abstract class XMLReaderFactory
{
	public org.xml.sax.XMLReader createXMLReader() ;
	public org.xml.sax.XMLReader createXMLReader(java.lang.String parameter1) ;
}

package org.xml.sax.helpers;

abstract class XMLReaderAdapter implements org.xml.sax.Parser, org.xml.sax.ContentHandler
{
	public XMLReaderAdapter() ;
	public java.lang.Void endDocument() ;
	public java.lang.Void startDocument() ;
	public java.lang.Void characters(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void ignorableWhitespace(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void endPrefixMapping(java.lang.String parameter1) ;
	public java.lang.Void parse(java.lang.String parameter1) ;
	public java.lang.Void skippedEntity(java.lang.String parameter1) ;
	public java.lang.Void setLocale(java.util.Locale parameter1) ;
	public java.lang.Void setDTDHandler(org.xml.sax.DTDHandler parameter1) ;
	public java.lang.Void setDocumentHandler(org.xml.sax.DocumentHandler parameter1) ;
	public java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public java.lang.Void parse(org.xml.sax.InputSource parameter1) ;
	public java.lang.Void setDocumentLocator(org.xml.sax.Locator parameter1) ;
	public XMLReaderAdapter(org.xml.sax.XMLReader parameter1) ;
	public java.lang.Void processingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void startPrefixMapping(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void endElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.Void startElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, org.xml.sax.Attributes parameter4) ;
}

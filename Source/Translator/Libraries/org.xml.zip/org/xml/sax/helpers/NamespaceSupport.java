package org.xml.sax.helpers;

abstract class NamespaceSupport
{
	public NamespaceSupport() ;
	public java.lang.Void popContext() ;
	public java.lang.Void pushContext() ;
	public java.lang.Void reset() ;
	public java.util.Enumeration getDeclaredPrefixes() ;
	public java.util.Enumeration getPrefixes() ;
	public java.lang.String getPrefix(java.lang.String parameter1) ;
	public java.lang.String getURI(java.lang.String parameter1) ;
	public java.lang.Boolean declarePrefix(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.util.Enumeration getPrefixes(java.lang.String parameter1) ;
	public java.lang.String[] processName(java.lang.String parameter1, java.lang.String[] parameter2, java.lang.Boolean parameter3) ;
	java.lang.String XMLNS;
}

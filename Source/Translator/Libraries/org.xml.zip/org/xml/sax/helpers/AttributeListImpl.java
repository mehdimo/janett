package org.xml.sax.helpers;

abstract class AttributeListImpl implements org.xml.sax.AttributeList
{
	public java.lang.Integer getLength() ;
	public java.lang.Void clear() ;
	public java.lang.String getName(java.lang.Integer parameter1) ;
	public java.lang.String getType(java.lang.Integer parameter1) ;
	public java.lang.String getValue(java.lang.Integer parameter1) ;
	public java.lang.Void removeAttribute(java.lang.String parameter1) ;
	public java.lang.Void setAttributeList(org.xml.sax.AttributeList parameter1) ;
	public java.lang.String getType(java.lang.String parameter1) ;
	public java.lang.String getValue(java.lang.String parameter1) ;
	public java.lang.Void addAttribute(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
}

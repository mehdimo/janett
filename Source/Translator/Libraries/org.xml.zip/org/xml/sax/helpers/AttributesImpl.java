package org.xml.sax.helpers;

abstract class AttributesImpl implements org.xml.sax.Attributes
{
	public java.lang.Integer getLength() ;
	public AttributesImpl() ;
	public java.lang.Void clear() ;
	public java.lang.Void removeAttribute(java.lang.Integer parameter1) ;
	public java.lang.String getLocalName(java.lang.Integer parameter1) ;
	public java.lang.String getQName(java.lang.Integer parameter1) ;
	public java.lang.String getType(java.lang.Integer parameter1) ;
	public java.lang.String getURI(java.lang.Integer parameter1) ;
	public java.lang.String getValue(java.lang.Integer parameter1) ;
	public java.lang.Void setLocalName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.Void setQName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.Void setType(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.Void setURI(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.Void setValue(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.Integer getIndex(java.lang.String parameter1) ;
	public AttributesImpl(org.xml.sax.Attributes parameter1) ;
	public java.lang.Void setAttributes(org.xml.sax.Attributes parameter1) ;
	public java.lang.String getType(java.lang.String parameter1) ;
	public java.lang.String getValue(java.lang.String parameter1) ;
	public java.lang.Integer getIndex(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.String getType(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.String getValue(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void setAttribute(java.lang.Integer parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5, java.lang.String parameter6) ;
	public java.lang.Void addAttribute(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5) ;
}

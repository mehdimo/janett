package org.xml.sax.helpers;

abstract class DefaultHandler implements org.xml.sax.EntityResolver, org.xml.sax.DTDHandler, org.xml.sax.ContentHandler, org.xml.sax.ErrorHandler
{
	public java.lang.Void endDocument() ;
	public java.lang.Void startDocument() ;
	public java.lang.Void characters(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void ignorableWhitespace(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void endPrefixMapping(java.lang.String parameter1) ;
	public java.lang.Void skippedEntity(java.lang.String parameter1) ;
	public java.lang.Void setDocumentLocator(org.xml.sax.Locator parameter1) ;
	public java.lang.Void error(org.xml.sax.SAXParseException parameter1) ;
	public java.lang.Void fatalError(org.xml.sax.SAXParseException parameter1) ;
	public java.lang.Void warning(org.xml.sax.SAXParseException parameter1) ;
	public java.lang.Void processingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void startPrefixMapping(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void endElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.Void notationDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public org.xml.sax.InputSource resolveEntity(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void unparsedEntityDecl(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
	public java.lang.Void startElement(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, org.xml.sax.Attributes parameter4) ;
}

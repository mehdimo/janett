package javax.sql;

interface PooledConnection
{
	public abstract java.lang.Void close() ;
	public abstract java.sql.Connection getConnection() ;
	public abstract java.lang.Void addConnectionEventListener(javax.sql.ConnectionEventListener parameter1) ;
	public abstract java.lang.Void removeConnectionEventListener(javax.sql.ConnectionEventListener parameter1) ;
}

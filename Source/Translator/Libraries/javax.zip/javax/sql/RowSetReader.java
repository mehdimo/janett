package javax.sql;

interface RowSetReader
{
	public abstract java.lang.Void readData(javax.sql.RowSetInternal parameter1) ;
}

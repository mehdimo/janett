package javax.sql;

interface RowSetMetaData implements java.sql.ResultSetMetaData
{
	public abstract java.lang.Void setColumnCount(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setColumnDisplaySize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setColumnType(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setNullable(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setPrecision(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setScale(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setAutoIncrement(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setCaseSensitive(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setCurrency(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setSearchable(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setSigned(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setCatalogName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setColumnLabel(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setColumnName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setColumnTypeName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setSchemaName(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setTableName(java.lang.Integer parameter1, java.lang.String parameter2) ;
}

package javax.sql;

abstract class RowSetEvent extends java.util.EventObject
{
}

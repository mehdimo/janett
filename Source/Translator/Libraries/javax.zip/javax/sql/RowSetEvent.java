package javax.sql;

abstract class RowSetEvent extends java.util.EventObject
{
	public RowSetEvent(javax.sql.RowSet parameter1) ;
}

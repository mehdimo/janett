package javax.sql;

interface XADataSource
{
	public abstract java.lang.Integer getLoginTimeout() ;
	public abstract java.lang.Void setLoginTimeout(java.lang.Integer parameter1) ;
	public abstract java.io.PrintWriter getLogWriter() ;
	public abstract java.lang.Void setLogWriter(java.io.PrintWriter parameter1) ;
	public abstract javax.sql.XAConnection getXAConnection() ;
	public abstract javax.sql.XAConnection getXAConnection(java.lang.String parameter1, java.lang.String parameter2) ;
}

package javax.sql;

interface RowSetListener implements java.util.EventListener
{
	public abstract java.lang.Void cursorMoved(javax.sql.RowSetEvent parameter1) ;
	public abstract java.lang.Void rowChanged(javax.sql.RowSetEvent parameter1) ;
	public abstract java.lang.Void rowSetChanged(javax.sql.RowSetEvent parameter1) ;
}

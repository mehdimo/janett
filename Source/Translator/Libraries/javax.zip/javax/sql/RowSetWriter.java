package javax.sql;

interface RowSetWriter
{
	public abstract java.lang.Boolean writeData(javax.sql.RowSetInternal parameter1) ;
}

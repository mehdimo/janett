package javax.sql;

abstract class ConnectionEvent extends java.util.EventObject
{
	public java.sql.SQLException getSQLException() ;
	public ConnectionEvent(javax.sql.PooledConnection parameter1) ;
	public ConnectionEvent(javax.sql.PooledConnection parameter1, java.sql.SQLException parameter2) ;
}

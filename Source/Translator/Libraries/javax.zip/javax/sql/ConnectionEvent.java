package javax.sql;

abstract class ConnectionEvent extends java.util.EventObject
{
	public java.sql.SQLException getSQLException() ;
}

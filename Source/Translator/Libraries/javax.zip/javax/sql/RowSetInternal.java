package javax.sql;

interface RowSetInternal
{
	public abstract java.lang.Object[] getParams() ;
	public abstract java.sql.Connection getConnection() ;
	public abstract java.sql.ResultSet getOriginal() ;
	public abstract java.sql.ResultSet getOriginalRow() ;
	public abstract java.lang.Void setMetaData(javax.sql.RowSetMetaData parameter1) ;
}

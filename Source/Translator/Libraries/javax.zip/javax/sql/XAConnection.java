package javax.sql;

interface XAConnection implements javax.sql.PooledConnection
{
	public abstract javax.transaction.xa.XAResource getXAResource() ;
}

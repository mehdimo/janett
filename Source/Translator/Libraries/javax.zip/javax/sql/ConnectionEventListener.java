package javax.sql;

interface ConnectionEventListener implements java.util.EventListener
{
	public abstract java.lang.Void connectionClosed(javax.sql.ConnectionEvent parameter1) ;
	public abstract java.lang.Void connectionErrorOccurred(javax.sql.ConnectionEvent parameter1) ;
}

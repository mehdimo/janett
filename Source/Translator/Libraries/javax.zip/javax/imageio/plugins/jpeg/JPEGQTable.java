package javax.imageio.plugins.jpeg;

abstract class JPEGQTable
{
	public java.lang.Integer[] getTable() ;
	public java.lang.String toString() ;
	public javax.imageio.plugins.jpeg.JPEGQTable getScaledInstance(java.lang.Float parameter1, java.lang.Boolean parameter2) ;
	javax.imageio.plugins.jpeg.JPEGQTable K1Luminance;
	javax.imageio.plugins.jpeg.JPEGQTable K1Div2Luminance;
	javax.imageio.plugins.jpeg.JPEGQTable K2Chrominance;
	javax.imageio.plugins.jpeg.JPEGQTable K2Div2Chrominance;
}

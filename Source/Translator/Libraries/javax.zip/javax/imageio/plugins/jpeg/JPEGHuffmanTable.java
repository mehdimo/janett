package javax.imageio.plugins.jpeg;

abstract class JPEGHuffmanTable
{
	public java.lang.Short[] getLengths() ;
	public java.lang.Short[] getValues() ;
	public JPEGHuffmanTable(java.lang.Short[] parameter1, java.lang.Short[] parameter2) ;
	public java.lang.String toString() ;
	javax.imageio.plugins.jpeg.JPEGHuffmanTable StdDCLuminance;
	javax.imageio.plugins.jpeg.JPEGHuffmanTable StdDCChrominance;
	javax.imageio.plugins.jpeg.JPEGHuffmanTable StdACLuminance;
	javax.imageio.plugins.jpeg.JPEGHuffmanTable StdACChrominance;
}

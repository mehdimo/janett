package javax.imageio.plugins.jpeg;

abstract class JPEGImageReadParam extends javax.imageio.ImageReadParam
{
	public java.lang.Void unsetDecodeTables() ;
	public java.lang.Boolean areTablesSet() ;
	public javax.imageio.plugins.jpeg.JPEGHuffmanTable[] getACHuffmanTables() ;
	public javax.imageio.plugins.jpeg.JPEGHuffmanTable[] getDCHuffmanTables() ;
	public javax.imageio.plugins.jpeg.JPEGQTable[] getQTables() ;
	public java.lang.Void setDecodeTables(javax.imageio.plugins.jpeg.JPEGQTable[] parameter1, javax.imageio.plugins.jpeg.JPEGHuffmanTable[] parameter2, javax.imageio.plugins.jpeg.JPEGHuffmanTable[] parameter3) ;
}

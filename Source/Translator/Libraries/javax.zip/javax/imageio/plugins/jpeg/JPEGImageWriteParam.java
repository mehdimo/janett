package javax.imageio.plugins.jpeg;

abstract class JPEGImageWriteParam extends javax.imageio.ImageWriteParam
{
	public java.lang.Void unsetCompression() ;
	public java.lang.Void unsetEncodeTables() ;
	public java.lang.Boolean areTablesSet() ;
	public java.lang.Boolean getOptimizeHuffmanTables() ;
	public java.lang.Boolean isCompressionLossless() ;
	public java.lang.Float[] getCompressionQualityValues() ;
	public java.lang.Void setOptimizeHuffmanTables(java.lang.Boolean parameter1) ;
	public java.lang.String[] getCompressionQualityDescriptions() ;
	public JPEGImageWriteParam(java.util.Locale parameter1) ;
	public javax.imageio.plugins.jpeg.JPEGHuffmanTable[] getACHuffmanTables() ;
	public javax.imageio.plugins.jpeg.JPEGHuffmanTable[] getDCHuffmanTables() ;
	public javax.imageio.plugins.jpeg.JPEGQTable[] getQTables() ;
	public java.lang.Void setEncodeTables(javax.imageio.plugins.jpeg.JPEGQTable[] parameter1, javax.imageio.plugins.jpeg.JPEGHuffmanTable[] parameter2, javax.imageio.plugins.jpeg.JPEGHuffmanTable[] parameter3) ;
}

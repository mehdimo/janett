package javax.imageio;

abstract class IIOImage
{
	public java.lang.Integer getNumThumbnails() ;
	public java.lang.Boolean hasRaster() ;
	public java.awt.image.BufferedImage getThumbnail(java.lang.Integer parameter1) ;
	public java.awt.image.Raster getRaster() ;
	public java.lang.Void setRaster(java.awt.image.Raster parameter1) ;
	public java.awt.image.RenderedImage getRenderedImage() ;
	public java.lang.Void setRenderedImage(java.awt.image.RenderedImage parameter1) ;
	public java.util.List getThumbnails() ;
	public java.lang.Void setThumbnails(java.util.List parameter1) ;
	public javax.imageio.metadata.IIOMetadata getMetadata() ;
	public java.lang.Void setMetadata(javax.imageio.metadata.IIOMetadata parameter1) ;
	public IIOImage(java.awt.image.Raster parameter1, java.util.List parameter2, javax.imageio.metadata.IIOMetadata parameter3) ;
	public IIOImage(java.awt.image.RenderedImage parameter1, java.util.List parameter2, javax.imageio.metadata.IIOMetadata parameter3) ;
}

package javax.imageio;

abstract class ImageIO
{
	public java.lang.Void scanForPlugins() ;
	public java.lang.Boolean getUseCache() ;
	public java.lang.Void setUseCache(java.lang.Boolean parameter1) ;
	public java.io.File getCacheDirectory() ;
	public java.lang.Void setCacheDirectory(java.io.File parameter1) ;
	public java.lang.String[] getReaderFormatNames() ;
	public java.lang.String[] getReaderMIMETypes() ;
	public java.lang.String[] getWriterFormatNames() ;
	public java.lang.String[] getWriterMIMETypes() ;
	public java.awt.image.BufferedImage read(java.io.File parameter1) ;
	public java.awt.image.BufferedImage read(java.io.InputStream parameter1) ;
	public java.awt.image.BufferedImage read(java.net.URL parameter1) ;
	public java.awt.image.BufferedImage read(javax.imageio.stream.ImageInputStream parameter1) ;
	public java.util.Iterator getImageReaders(java.lang.Object parameter1) ;
	public java.util.Iterator getImageReadersByFormatName(java.lang.String parameter1) ;
	public java.util.Iterator getImageReadersByMIMEType(java.lang.String parameter1) ;
	public java.util.Iterator getImageReadersBySuffix(java.lang.String parameter1) ;
	public java.util.Iterator getImageWritersByFormatName(java.lang.String parameter1) ;
	public java.util.Iterator getImageWritersByMIMEType(java.lang.String parameter1) ;
	public java.util.Iterator getImageWritersBySuffix(java.lang.String parameter1) ;
	public javax.imageio.ImageReader getImageReader(javax.imageio.ImageWriter parameter1) ;
	public javax.imageio.ImageWriter getImageWriter(javax.imageio.ImageReader parameter1) ;
	public javax.imageio.stream.ImageInputStream createImageInputStream(java.lang.Object parameter1) ;
	public javax.imageio.stream.ImageOutputStream createImageOutputStream(java.lang.Object parameter1) ;
	public java.lang.Boolean write(java.awt.image.RenderedImage parameter1, java.lang.String parameter2, java.io.File parameter3) ;
	public java.lang.Boolean write(java.awt.image.RenderedImage parameter1, java.lang.String parameter2, java.io.OutputStream parameter3) ;
	public java.util.Iterator getImageWriters(javax.imageio.ImageTypeSpecifier parameter1, java.lang.String parameter2) ;
	public java.util.Iterator getImageTranscoders(javax.imageio.ImageReader parameter1, javax.imageio.ImageWriter parameter2) ;
	public java.lang.Boolean write(java.awt.image.RenderedImage parameter1, java.lang.String parameter2, javax.imageio.stream.ImageOutputStream parameter3) ;
}

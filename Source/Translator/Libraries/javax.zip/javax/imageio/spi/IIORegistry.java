package javax.imageio.spi;

abstract class IIORegistry extends javax.imageio.spi.ServiceRegistry
{
	public java.lang.Void registerApplicationClasspathSpis() ;
	public javax.imageio.spi.IIORegistry getDefaultInstance() ;
}

package javax.imageio.spi;

abstract class ImageReaderSpi extends javax.imageio.spi.ImageReaderWriterSpi
{
	public java.lang.Class[] getInputTypes() ;
	public abstract java.lang.Boolean canDecodeInput(java.lang.Object parameter1) ;
	public java.lang.String[] getImageWriterSpiNames() ;
	public javax.imageio.ImageReader createReaderInstance() ;
	public java.lang.Boolean isOwnReader(javax.imageio.ImageReader parameter1) ;
	public abstract javax.imageio.ImageReader createReaderInstance(java.lang.Object parameter1) ;
	java.lang.Class[] STANDARD_INPUT_TYPE;
}

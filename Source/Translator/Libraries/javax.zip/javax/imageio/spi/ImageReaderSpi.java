package javax.imageio.spi;

abstract class ImageReaderSpi extends javax.imageio.spi.ImageReaderWriterSpi
{
	public ImageReaderSpi() ;
	public java.lang.Class[] getInputTypes() ;
	public abstract java.lang.Boolean canDecodeInput(java.lang.Object parameter1) ;
	public java.lang.String[] getImageWriterSpiNames() ;
	public javax.imageio.ImageReader createReaderInstance() ;
	public java.lang.Boolean isOwnReader(javax.imageio.ImageReader parameter1) ;
	public abstract javax.imageio.ImageReader createReaderInstance(java.lang.Object parameter1) ;
	public ImageReaderSpi(java.lang.String parameter1, java.lang.String parameter2, java.lang.String[] parameter3, java.lang.String[] parameter4, java.lang.String[] parameter5, java.lang.String parameter6, java.lang.Class[] parameter7, java.lang.String[] parameter8, java.lang.Boolean parameter9, java.lang.String parameter10, 
	java.lang.String parameter11, java.lang.String[] parameter12, java.lang.String[] parameter13, java.lang.Boolean parameter14, java.lang.String parameter15, java.lang.String parameter16, java.lang.String[] parameter17, java.lang.String[] parameter18) ;
	java.lang.Class[] STANDARD_INPUT_TYPE;
}

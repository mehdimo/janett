package javax.imageio.spi;

abstract class ImageOutputStreamSpi extends javax.imageio.spi.IIOServiceProvider
{
	public ImageOutputStreamSpi() ;
	public java.lang.Boolean canUseCacheFile() ;
	public java.lang.Boolean needsCacheFile() ;
	public java.lang.Class getOutputClass() ;
	public javax.imageio.stream.ImageOutputStream createOutputStreamInstance(java.lang.Object parameter1) ;
	public ImageOutputStreamSpi(java.lang.String parameter1, java.lang.String parameter2, java.lang.Class parameter3) ;
	public abstract javax.imageio.stream.ImageOutputStream createOutputStreamInstance(java.lang.Object parameter1, java.lang.Boolean parameter2, java.io.File parameter3) ;
}

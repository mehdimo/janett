package javax.imageio.spi;

abstract class ImageOutputStreamSpi extends javax.imageio.spi.IIOServiceProvider
{
	public java.lang.Boolean canUseCacheFile() ;
	public java.lang.Boolean needsCacheFile() ;
	public java.lang.Class getOutputClass() ;
	public javax.imageio.stream.ImageOutputStream createOutputStreamInstance(java.lang.Object parameter1) ;
	public abstract javax.imageio.stream.ImageOutputStream createOutputStreamInstance(java.lang.Object parameter1, java.lang.Boolean parameter2, java.io.File parameter3) ;
}

package javax.imageio.spi;

abstract class IIOServiceProvider implements javax.imageio.spi.RegisterableService
{
	public IIOServiceProvider() ;
	public java.lang.String getVendorName() ;
	public java.lang.String getVersion() ;
	public java.lang.Void onDeregistration(javax.imageio.spi.ServiceRegistry parameter1, java.lang.Class parameter2) ;
	public java.lang.Void onRegistration(javax.imageio.spi.ServiceRegistry parameter1, java.lang.Class parameter2) ;
	public IIOServiceProvider(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.String getDescription(java.util.Locale parameter1) ;
}

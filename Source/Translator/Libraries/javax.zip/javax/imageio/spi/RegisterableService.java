package javax.imageio.spi;

interface RegisterableService
{
	public abstract java.lang.Void onDeregistration(javax.imageio.spi.ServiceRegistry parameter1, java.lang.Class parameter2) ;
	public abstract java.lang.Void onRegistration(javax.imageio.spi.ServiceRegistry parameter1, java.lang.Class parameter2) ;
}

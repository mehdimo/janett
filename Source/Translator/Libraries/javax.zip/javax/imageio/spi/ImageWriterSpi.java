package javax.imageio.spi;

abstract class ImageWriterSpi extends javax.imageio.spi.ImageReaderWriterSpi
{
	public java.lang.Boolean isFormatLossless() ;
	public java.lang.Boolean canEncodeImage(java.awt.image.RenderedImage parameter1) ;
	public java.lang.Class[] getOutputTypes() ;
	public java.lang.String[] getImageReaderSpiNames() ;
	public abstract java.lang.Boolean canEncodeImage(javax.imageio.ImageTypeSpecifier parameter1) ;
	public javax.imageio.ImageWriter createWriterInstance() ;
	public java.lang.Boolean isOwnWriter(javax.imageio.ImageWriter parameter1) ;
	public abstract javax.imageio.ImageWriter createWriterInstance(java.lang.Object parameter1) ;
	java.lang.Class[] STANDARD_OUTPUT_TYPE;
}

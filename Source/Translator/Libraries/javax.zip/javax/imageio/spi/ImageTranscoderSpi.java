package javax.imageio.spi;

abstract class ImageTranscoderSpi extends javax.imageio.spi.IIOServiceProvider
{
	public ImageTranscoderSpi() ;
	public abstract java.lang.String getReaderServiceProviderName() ;
	public abstract java.lang.String getWriterServiceProviderName() ;
	public abstract javax.imageio.ImageTranscoder createTranscoderInstance() ;
	public ImageTranscoderSpi(java.lang.String parameter1, java.lang.String parameter2) ;
}

package javax.imageio.spi;

abstract class ImageTranscoderSpi extends javax.imageio.spi.IIOServiceProvider
{
	public abstract java.lang.String getReaderServiceProviderName() ;
	public abstract java.lang.String getWriterServiceProviderName() ;
	public abstract javax.imageio.ImageTranscoder createTranscoderInstance() ;
}

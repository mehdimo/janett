package javax.imageio.spi;

abstract class ServiceRegistry
{
	public java.lang.Void deregisterAll() ;
	public java.lang.Void finalize() ;
	public java.lang.Void deregisterAll(java.lang.Class parameter1) ;
	public java.lang.Void deregisterServiceProvider(java.lang.Object parameter1) ;
	public java.lang.Void registerServiceProvider(java.lang.Object parameter1) ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.util.Iterator getCategories() ;
	public java.lang.Void registerServiceProviders(java.util.Iterator parameter1) ;
	public java.lang.Boolean deregisterServiceProvider(java.lang.Object parameter1, java.lang.Class parameter2) ;
	public java.lang.Boolean registerServiceProvider(java.lang.Object parameter1, java.lang.Class parameter2) ;
	public java.lang.Object getServiceProviderByClass(java.lang.Class parameter1) ;
	public java.util.Iterator lookupProviders(java.lang.Class parameter1) ;
	public java.util.Iterator getServiceProviders(java.lang.Class parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Boolean setOrdering(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Boolean unsetOrdering(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.util.Iterator lookupProviders(java.lang.Class parameter1, java.lang.ClassLoader parameter2) ;
	public java.util.Iterator getServiceProviders(java.lang.Class parameter1, javax.imageio.spi.ServiceRegistry.Filter parameter2, java.lang.Boolean parameter3) ;
	interface Filter
	{
		public abstract java.lang.Boolean filter(java.lang.Object parameter1) ;
	}
}

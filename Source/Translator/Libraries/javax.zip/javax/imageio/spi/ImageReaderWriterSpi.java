package javax.imageio.spi;

abstract class ImageReaderWriterSpi extends javax.imageio.spi.IIOServiceProvider
{
	public ImageReaderWriterSpi() ;
	public java.lang.Boolean isStandardImageMetadataFormatSupported() ;
	public java.lang.Boolean isStandardStreamMetadataFormatSupported() ;
	public java.lang.String getNativeImageMetadataFormatName() ;
	public java.lang.String getNativeStreamMetadataFormatName() ;
	public java.lang.String getPluginClassName() ;
	public java.lang.String[] getExtraImageMetadataFormatNames() ;
	public java.lang.String[] getExtraStreamMetadataFormatNames() ;
	public java.lang.String[] getFileSuffixes() ;
	public java.lang.String[] getFormatNames() ;
	public java.lang.String[] getMIMETypes() ;
	public javax.imageio.metadata.IIOMetadataFormat getImageMetadataFormat(java.lang.String parameter1) ;
	public javax.imageio.metadata.IIOMetadataFormat getStreamMetadataFormat(java.lang.String parameter1) ;
	public ImageReaderWriterSpi(java.lang.String parameter1, java.lang.String parameter2, java.lang.String[] parameter3, java.lang.String[] parameter4, java.lang.String[] parameter5, java.lang.String parameter6, java.lang.Boolean parameter7, java.lang.String parameter8, java.lang.String parameter9, java.lang.String[] parameter10, 
	java.lang.String[] parameter11, java.lang.Boolean parameter12, java.lang.String parameter13, java.lang.String parameter14, java.lang.String[] parameter15, java.lang.String[] parameter16) ;
}

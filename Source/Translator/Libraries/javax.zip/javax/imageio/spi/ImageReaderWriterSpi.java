package javax.imageio.spi;

abstract class ImageReaderWriterSpi extends javax.imageio.spi.IIOServiceProvider
{
	public java.lang.Boolean isStandardImageMetadataFormatSupported() ;
	public java.lang.Boolean isStandardStreamMetadataFormatSupported() ;
	public java.lang.String getNativeImageMetadataFormatName() ;
	public java.lang.String getNativeStreamMetadataFormatName() ;
	public java.lang.String getPluginClassName() ;
	public java.lang.String[] getExtraImageMetadataFormatNames() ;
	public java.lang.String[] getExtraStreamMetadataFormatNames() ;
	public java.lang.String[] getFileSuffixes() ;
	public java.lang.String[] getFormatNames() ;
	public java.lang.String[] getMIMETypes() ;
	public javax.imageio.metadata.IIOMetadataFormat getImageMetadataFormat(java.lang.String parameter1) ;
	public javax.imageio.metadata.IIOMetadataFormat getStreamMetadataFormat(java.lang.String parameter1) ;
}

package javax.imageio.spi;

abstract class ImageInputStreamSpi extends javax.imageio.spi.IIOServiceProvider
{
	public java.lang.Boolean canUseCacheFile() ;
	public java.lang.Boolean needsCacheFile() ;
	public java.lang.Class getInputClass() ;
	public javax.imageio.stream.ImageInputStream createInputStreamInstance(java.lang.Object parameter1) ;
	public abstract javax.imageio.stream.ImageInputStream createInputStreamInstance(java.lang.Object parameter1, java.lang.Boolean parameter2, java.io.File parameter3) ;
}

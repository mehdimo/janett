package javax.imageio;

abstract class ImageTypeSpecifier
{
	public java.lang.Integer getBufferedImageType() ;
	public java.lang.Integer getNumBands() ;
	public java.lang.Integer getNumComponents() ;
	public java.lang.Integer getBitsPerBand(java.lang.Integer parameter1) ;
	public java.awt.image.BufferedImage createBufferedImage(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.ColorModel getColorModel() ;
	public java.awt.image.SampleModel getSampleModel() ;
	public java.awt.image.SampleModel getSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public javax.imageio.ImageTypeSpecifier createFromBufferedImageType(java.lang.Integer parameter1) ;
	public javax.imageio.ImageTypeSpecifier createGrayscale(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public javax.imageio.ImageTypeSpecifier createGrayscale(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3, java.lang.Boolean parameter4) ;
	public javax.imageio.ImageTypeSpecifier createIndexed(java.lang.Byte[] parameter1, java.lang.Byte[] parameter2, java.lang.Byte[] parameter3, java.lang.Byte[] parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public javax.imageio.ImageTypeSpecifier createPacked(java.awt.color.ColorSpace parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Boolean parameter7) ;
	public javax.imageio.ImageTypeSpecifier createInterleaved(java.awt.color.ColorSpace parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4, java.lang.Boolean parameter5) ;
	public javax.imageio.ImageTypeSpecifier createBanded(java.awt.color.ColorSpace parameter1, java.lang.Integer[] parameter2, java.lang.Integer[] parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5, java.lang.Boolean parameter6) ;
	public javax.imageio.ImageTypeSpecifier createFromRenderedImage(java.awt.image.RenderedImage parameter1) ;
}

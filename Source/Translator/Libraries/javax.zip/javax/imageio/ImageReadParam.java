package javax.imageio;

abstract class ImageReadParam extends javax.imageio.IIOParam
{
	public java.lang.Integer getSourceMaxProgressivePass() ;
	public java.lang.Integer getSourceMinProgressivePass() ;
	public java.lang.Integer getSourceNumProgressivePasses() ;
	public ImageReadParam() ;
	public java.lang.Boolean canSetSourceRenderSize() ;
	public java.lang.Integer[] getDestinationBands() ;
	public java.lang.Void setSourceProgressivePasses(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setDestinationBands(java.lang.Integer[] parameter1) ;
	public java.awt.Dimension getSourceRenderSize() ;
	public java.lang.Void setSourceRenderSize(java.awt.Dimension parameter1) ;
	public java.awt.image.BufferedImage getDestination() ;
	public java.lang.Void setDestination(java.awt.image.BufferedImage parameter1) ;
	public java.lang.Void setDestinationType(javax.imageio.ImageTypeSpecifier parameter1) ;
}

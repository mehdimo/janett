package javax.imageio;

abstract class IIOException extends java.io.IOException
{
	public IIOException(java.lang.String parameter1) ;
	public IIOException(java.lang.String parameter1, java.lang.Throwable parameter2) ;
}

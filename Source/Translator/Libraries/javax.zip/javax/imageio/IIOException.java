package javax.imageio;

abstract class IIOException extends java.io.IOException
{
}

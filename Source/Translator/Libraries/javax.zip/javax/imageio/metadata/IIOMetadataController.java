package javax.imageio.metadata;

interface IIOMetadataController
{
	public abstract java.lang.Boolean activate(javax.imageio.metadata.IIOMetadata parameter1) ;
}

package javax.imageio.metadata;

abstract class IIOInvalidTreeException extends javax.imageio.IIOException
{
	public org.w3c.dom.Node getOffendingNode() ;
	public IIOInvalidTreeException(java.lang.String parameter1, org.w3c.dom.Node parameter2) ;
	public IIOInvalidTreeException(java.lang.String parameter1, java.lang.Throwable parameter2, org.w3c.dom.Node parameter3) ;
}

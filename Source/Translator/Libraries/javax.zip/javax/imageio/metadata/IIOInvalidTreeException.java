package javax.imageio.metadata;

abstract class IIOInvalidTreeException extends javax.imageio.IIOException
{
	public org.w3c.dom.Node getOffendingNode() ;
}

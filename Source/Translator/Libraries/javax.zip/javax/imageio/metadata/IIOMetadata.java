package javax.imageio.metadata;

abstract class IIOMetadata
{
	public IIOMetadata() ;
	public abstract java.lang.Void reset() ;
	public java.lang.Boolean activateController() ;
	public java.lang.Boolean hasController() ;
	public abstract java.lang.Boolean isReadOnly() ;
	public java.lang.Boolean isStandardMetadataFormatSupported() ;
	public java.lang.String getNativeMetadataFormatName() ;
	public java.lang.String[] getExtraMetadataFormatNames() ;
	public java.lang.String[] getMetadataFormatNames() ;
	public javax.imageio.metadata.IIOMetadataController getController() ;
	public javax.imageio.metadata.IIOMetadataController getDefaultController() ;
	public java.lang.Void setController(javax.imageio.metadata.IIOMetadataController parameter1) ;
	public javax.imageio.metadata.IIOMetadataNode getStandardChromaNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardCompressionNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardDataNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardDimensionNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardDocumentNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardTextNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardTileNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardTransparencyNode() ;
	public javax.imageio.metadata.IIOMetadataNode getStandardTree() ;
	public javax.imageio.metadata.IIOMetadataFormat getMetadataFormat(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Node getAsTree(java.lang.String parameter1) ;
	public abstract java.lang.Void mergeTree(java.lang.String parameter1, org.w3c.dom.Node parameter2) ;
	public java.lang.Void setFromTree(java.lang.String parameter1, org.w3c.dom.Node parameter2) ;
	public IIOMetadata(java.lang.Boolean parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String[] parameter4, java.lang.String[] parameter5) ;
}

package javax.imageio;

abstract class IIOParam
{
	public java.lang.Integer getSourceXSubsampling() ;
	public java.lang.Integer getSourceYSubsampling() ;
	public java.lang.Integer getSubsamplingXOffset() ;
	public java.lang.Integer getSubsamplingYOffset() ;
	public IIOParam() ;
	public java.lang.Boolean activateController() ;
	public java.lang.Boolean hasController() ;
	public java.lang.Integer[] getSourceBands() ;
	public java.lang.Void setSourceSubsampling(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void setSourceBands(java.lang.Integer[] parameter1) ;
	public java.awt.Point getDestinationOffset() ;
	public java.lang.Void setDestinationOffset(java.awt.Point parameter1) ;
	public java.awt.Rectangle getSourceRegion() ;
	public java.lang.Void setSourceRegion(java.awt.Rectangle parameter1) ;
	public javax.imageio.IIOParamController getController() ;
	public javax.imageio.IIOParamController getDefaultController() ;
	public java.lang.Void setController(javax.imageio.IIOParamController parameter1) ;
	public javax.imageio.ImageTypeSpecifier getDestinationType() ;
	public java.lang.Void setDestinationType(javax.imageio.ImageTypeSpecifier parameter1) ;
}

package javax.imageio.stream;

abstract class MemoryCacheImageOutputStream extends javax.imageio.stream.ImageOutputStreamImpl
{
	public java.lang.Integer read() ;
	public java.lang.Long length() ;
	public java.lang.Void close() ;
	public java.lang.Boolean isCached() ;
	public java.lang.Boolean isCachedFile() ;
	public java.lang.Boolean isCachedMemory() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void flushBefore(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package javax.imageio.stream;

interface ImageOutputStream implements javax.imageio.stream.ImageInputStream, java.io.DataOutput
{
	public abstract java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public abstract java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public abstract java.lang.Void write(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeBit(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public abstract java.lang.Void flushBefore(java.lang.Long parameter1) ;
	public abstract java.lang.Void writeLong(java.lang.Long parameter1) ;
	public abstract java.lang.Void writeBits(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeChars(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeDoubles(java.lang.Double[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeFloats(java.lang.Float[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeInts(java.lang.Integer[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeLongs(java.lang.Long[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeShorts(java.lang.Short[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeBytes(java.lang.String parameter1) ;
	public abstract java.lang.Void writeChars(java.lang.String parameter1) ;
	public abstract java.lang.Void writeUTF(java.lang.String parameter1) ;
}

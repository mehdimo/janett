package javax.imageio.stream;

abstract class FileImageInputStream extends javax.imageio.stream.ImageInputStreamImpl
{
	public java.lang.Integer read() ;
	public java.lang.Long length() ;
	public java.lang.Void close() ;
	public java.lang.Void seek(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

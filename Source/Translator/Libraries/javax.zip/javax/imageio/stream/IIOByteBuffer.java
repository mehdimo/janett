package javax.imageio.stream;

abstract class IIOByteBuffer
{
	public java.lang.Integer getLength() ;
	public java.lang.Integer getOffset() ;
	public java.lang.Byte[] getData() ;
	public java.lang.Void setLength(java.lang.Integer parameter1) ;
	public java.lang.Void setOffset(java.lang.Integer parameter1) ;
	public java.lang.Void setData(java.lang.Byte[] parameter1) ;
	public IIOByteBuffer(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package javax.imageio.stream;

abstract class ImageOutputStreamImpl extends javax.imageio.stream.ImageInputStreamImpl implements javax.imageio.stream.ImageOutputStream
{
	public java.lang.Void flushBits() ;
	public java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public abstract java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void writeBit(java.lang.Integer parameter1) ;
	public java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public java.lang.Void writeLong(java.lang.Long parameter1) ;
	public java.lang.Void writeBits(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeChars(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeDoubles(java.lang.Double[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeFloats(java.lang.Float[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeInts(java.lang.Integer[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeLongs(java.lang.Long[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeShorts(java.lang.Short[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeBytes(java.lang.String parameter1) ;
	public java.lang.Void writeChars(java.lang.String parameter1) ;
	public java.lang.Void writeUTF(java.lang.String parameter1) ;
}

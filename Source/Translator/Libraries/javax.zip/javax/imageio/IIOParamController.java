package javax.imageio;

interface IIOParamController
{
	public abstract java.lang.Boolean activate(javax.imageio.IIOParam parameter1) ;
}

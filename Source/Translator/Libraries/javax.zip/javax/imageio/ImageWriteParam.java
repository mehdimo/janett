package javax.imageio;

abstract class ImageWriteParam extends javax.imageio.IIOParam
{
	public java.lang.Float getCompressionQuality() ;
	public java.lang.Integer getCompressionMode() ;
	public java.lang.Integer getProgressiveMode() ;
	public java.lang.Integer getTileGridXOffset() ;
	public java.lang.Integer getTileGridYOffset() ;
	public java.lang.Integer getTileHeight() ;
	public java.lang.Integer getTileWidth() ;
	public java.lang.Integer getTilingMode() ;
	public java.lang.Void unsetCompression() ;
	public java.lang.Void unsetTiling() ;
	public java.lang.Boolean canOffsetTiles() ;
	public java.lang.Boolean canWriteCompressed() ;
	public java.lang.Boolean canWriteProgressive() ;
	public java.lang.Boolean canWriteTiles() ;
	public java.lang.Boolean isCompressionLossless() ;
	public java.lang.Float[] getCompressionQualityValues() ;
	public java.lang.Float getBitRate(java.lang.Float parameter1) ;
	public java.lang.Void setCompressionQuality(java.lang.Float parameter1) ;
	public java.lang.Void setCompressionMode(java.lang.Integer parameter1) ;
	public java.lang.Void setProgressiveMode(java.lang.Integer parameter1) ;
	public java.lang.Void setTilingMode(java.lang.Integer parameter1) ;
	public java.lang.Void setTiling(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.awt.Dimension[] getPreferredTileSizes() ;
	public java.lang.String getCompressionType() ;
	public java.lang.String getLocalizedCompressionTypeName() ;
	public java.lang.String[] getCompressionQualityDescriptions() ;
	public java.lang.String[] getCompressionTypes() ;
	public java.lang.Void setCompressionType(java.lang.String parameter1) ;
	public java.util.Locale getLocale() ;
	java.lang.Integer MODE_DISABLED;
	java.lang.Integer MODE_DEFAULT;
	java.lang.Integer MODE_EXPLICIT;
	java.lang.Integer MODE_COPY_FROM_METADATA;
}

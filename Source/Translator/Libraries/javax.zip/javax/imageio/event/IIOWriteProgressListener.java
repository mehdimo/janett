package javax.imageio.event;

interface IIOWriteProgressListener implements java.util.EventListener
{
	public abstract java.lang.Void imageComplete(javax.imageio.ImageWriter parameter1) ;
	public abstract java.lang.Void thumbnailComplete(javax.imageio.ImageWriter parameter1) ;
	public abstract java.lang.Void writeAborted(javax.imageio.ImageWriter parameter1) ;
	public abstract java.lang.Void imageProgress(javax.imageio.ImageWriter parameter1, java.lang.Float parameter2) ;
	public abstract java.lang.Void thumbnailProgress(javax.imageio.ImageWriter parameter1, java.lang.Float parameter2) ;
	public abstract java.lang.Void imageStarted(javax.imageio.ImageWriter parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void thumbnailStarted(javax.imageio.ImageWriter parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

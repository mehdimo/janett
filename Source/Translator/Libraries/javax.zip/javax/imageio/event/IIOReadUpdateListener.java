package javax.imageio.event;

interface IIOReadUpdateListener implements java.util.EventListener
{
	public abstract java.lang.Void passComplete(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2) ;
	public abstract java.lang.Void thumbnailPassComplete(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2) ;
	public abstract java.lang.Void passStarted(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9, java.lang.Integer[] parameter10
	) ;
	public abstract java.lang.Void thumbnailPassStarted(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9, java.lang.Integer[] parameter10
	) ;
	public abstract java.lang.Void imageUpdate(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer[] parameter9) ;
	public abstract java.lang.Void thumbnailUpdate(javax.imageio.ImageReader parameter1, java.awt.image.BufferedImage parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer[] parameter9) ;
}

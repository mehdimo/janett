package javax.imageio.event;

interface IIOWriteWarningListener implements java.util.EventListener
{
	public abstract java.lang.Void warningOccurred(javax.imageio.ImageWriter parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
}

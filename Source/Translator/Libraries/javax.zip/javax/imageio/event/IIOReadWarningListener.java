package javax.imageio.event;

interface IIOReadWarningListener implements java.util.EventListener
{
	public abstract java.lang.Void warningOccurred(javax.imageio.ImageReader parameter1, java.lang.String parameter2) ;
}

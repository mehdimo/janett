package javax.imageio;

interface ImageTranscoder
{
	public abstract javax.imageio.metadata.IIOMetadata convertStreamMetadata(javax.imageio.metadata.IIOMetadata parameter1, javax.imageio.ImageWriteParam parameter2) ;
	public abstract javax.imageio.metadata.IIOMetadata convertImageMetadata(javax.imageio.metadata.IIOMetadata parameter1, javax.imageio.ImageTypeSpecifier parameter2, javax.imageio.ImageWriteParam parameter3) ;
}

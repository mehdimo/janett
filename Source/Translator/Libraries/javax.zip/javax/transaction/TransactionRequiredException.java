package javax.transaction;

abstract class TransactionRequiredException extends java.rmi.RemoteException
{
}

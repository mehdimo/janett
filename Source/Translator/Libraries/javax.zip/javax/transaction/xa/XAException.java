package javax.transaction.xa;

abstract class XAException extends java.lang.Exception
{
	java.lang.Integer errorCode;
	java.lang.Integer XA_RBBASE;
	java.lang.Integer XA_RBROLLBACK;
	java.lang.Integer XA_RBCOMMFAIL;
	java.lang.Integer XA_RBDEADLOCK;
	java.lang.Integer XA_RBINTEGRITY;
	java.lang.Integer XA_RBOTHER;
	java.lang.Integer XA_RBPROTO;
	java.lang.Integer XA_RBTIMEOUT;
	java.lang.Integer XA_RBTRANSIENT;
	java.lang.Integer XA_RBEND;
	java.lang.Integer XA_NOMIGRATE;
	java.lang.Integer XA_HEURHAZ;
	java.lang.Integer XA_HEURCOM;
	java.lang.Integer XA_HEURRB;
	java.lang.Integer XA_HEURMIX;
	java.lang.Integer XA_RETRY;
	java.lang.Integer XA_RDONLY;
	java.lang.Integer XAER_ASYNC;
	java.lang.Integer XAER_RMERR;
	java.lang.Integer XAER_NOTA;
	java.lang.Integer XAER_INVAL;
	java.lang.Integer XAER_PROTO;
	java.lang.Integer XAER_RMFAIL;
	java.lang.Integer XAER_DUPID;
	java.lang.Integer XAER_OUTSIDE;
}

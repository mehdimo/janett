package javax.transaction.xa;

interface XAResource
{
	public abstract java.lang.Integer getTransactionTimeout() ;
	public abstract java.lang.Boolean setTransactionTimeout(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isSameRM(javax.transaction.xa.XAResource parameter1) ;
	public abstract javax.transaction.xa.Xid[] recover(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer prepare(javax.transaction.xa.Xid parameter1) ;
	public abstract java.lang.Void forget(javax.transaction.xa.Xid parameter1) ;
	public abstract java.lang.Void rollback(javax.transaction.xa.Xid parameter1) ;
	public abstract java.lang.Void end(javax.transaction.xa.Xid parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void start(javax.transaction.xa.Xid parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void commit(javax.transaction.xa.Xid parameter1, java.lang.Boolean parameter2) ;
	java.lang.Integer TMENDRSCAN;
	java.lang.Integer TMFAIL;
	java.lang.Integer TMJOIN;
	java.lang.Integer TMNOFLAGS;
	java.lang.Integer TMONEPHASE;
	java.lang.Integer TMRESUME;
	java.lang.Integer TMSTARTRSCAN;
	java.lang.Integer TMSUCCESS;
	java.lang.Integer TMSUSPEND;
	java.lang.Integer XA_RDONLY;
	java.lang.Integer XA_OK;
}

package javax.transaction.xa;

interface Xid
{
	public abstract java.lang.Integer getFormatId() ;
	public abstract java.lang.Byte[] getBranchQualifier() ;
	public abstract java.lang.Byte[] getGlobalTransactionId() ;
	java.lang.Integer MAXGTRIDSIZE;
	java.lang.Integer MAXBQUALSIZE;
}

package javax.transaction;

abstract class TransactionRolledbackException extends java.rmi.RemoteException
{
}

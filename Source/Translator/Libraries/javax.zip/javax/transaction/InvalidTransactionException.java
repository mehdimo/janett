package javax.transaction;

abstract class InvalidTransactionException extends java.rmi.RemoteException
{
}

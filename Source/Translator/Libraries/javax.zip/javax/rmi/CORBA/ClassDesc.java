package javax.rmi.CORBA;

abstract class ClassDesc implements java.io.Serializable
{
	public ClassDesc() ;
}

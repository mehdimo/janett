package javax.rmi.CORBA;

abstract class Util
{
	public java.lang.Void unexportObject(java.rmi.Remote parameter1) ;
	public java.lang.Boolean isLocal(javax.rmi.CORBA.Stub parameter1) ;
	public javax.rmi.CORBA.ValueHandler createValueHandler() ;
	public java.lang.Object readAny(org.omg.CORBA.portable.InputStream parameter1) ;
	public java.lang.Void writeAbstractObject(org.omg.CORBA.portable.OutputStream parameter1, java.lang.Object parameter2) ;
	public java.lang.Void writeAny(org.omg.CORBA.portable.OutputStream parameter1, java.lang.Object parameter2) ;
	public java.lang.Void writeRemoteObject(org.omg.CORBA.portable.OutputStream parameter1, java.lang.Object parameter2) ;
	public java.lang.String getCodebase(java.lang.Class parameter1) ;
	public java.lang.Void registerTarget(javax.rmi.CORBA.Tie parameter1, java.rmi.Remote parameter2) ;
	public java.rmi.RemoteException wrapException(java.lang.Throwable parameter1) ;
	public java.rmi.RemoteException mapSystemException(org.omg.CORBA.SystemException parameter1) ;
	public javax.rmi.CORBA.Tie getTie(java.rmi.Remote parameter1) ;
	public java.lang.Object copyObject(java.lang.Object parameter1, org.omg.CORBA.ORB parameter2) ;
	public java.lang.Object[] copyObjects(java.lang.Object[] parameter1, org.omg.CORBA.ORB parameter2) ;
	public java.lang.Class loadClass(java.lang.String parameter1, java.lang.String parameter2, java.lang.ClassLoader parameter3) ;
}

package javax.rmi.CORBA;

interface ValueHandler
{
	public abstract java.lang.Boolean isCustomMarshaled(java.lang.Class parameter1) ;
	public abstract org.omg.SendingContext.RunTime getRunTimeCodeBase() ;
	public abstract java.io.Serializable writeReplace(java.io.Serializable parameter1) ;
	public abstract java.lang.Void writeValue(org.omg.CORBA.portable.OutputStream parameter1, java.io.Serializable parameter2) ;
	public abstract java.lang.String getRMIRepositoryID(java.lang.Class parameter1) ;
	public abstract java.io.Serializable readValue(org.omg.CORBA.portable.InputStream parameter1, java.lang.Integer parameter2, java.lang.Class parameter3, java.lang.String parameter4, org.omg.SendingContext.RunTime parameter5) ;
}

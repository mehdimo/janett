package javax.rmi.CORBA;

interface StubDelegate
{
	public abstract java.lang.Integer hashCode(javax.rmi.CORBA.Stub parameter1) ;
	public abstract java.lang.Void readObject(javax.rmi.CORBA.Stub parameter1, java.io.ObjectInputStream parameter2) ;
	public abstract java.lang.Void writeObject(javax.rmi.CORBA.Stub parameter1, java.io.ObjectOutputStream parameter2) ;
	public abstract java.lang.Boolean equals(javax.rmi.CORBA.Stub parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.String toString(javax.rmi.CORBA.Stub parameter1) ;
	public abstract java.lang.Void connect(javax.rmi.CORBA.Stub parameter1, org.omg.CORBA.ORB parameter2) ;
}

package javax.rmi.CORBA;

interface Tie implements org.omg.CORBA.portable.InvokeHandler
{
	public abstract java.lang.Void deactivate() ;
	public abstract java.rmi.Remote getTarget() ;
	public abstract java.lang.Void setTarget(java.rmi.Remote parameter1) ;
	public abstract org.omg.CORBA.ORB orb() ;
	public abstract java.lang.Void orb(org.omg.CORBA.ORB parameter1) ;
	public abstract org.omg.CORBA.Object thisObject() ;
}

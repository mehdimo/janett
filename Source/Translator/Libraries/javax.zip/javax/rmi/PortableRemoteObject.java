package javax.rmi;

abstract class PortableRemoteObject
{
	public java.lang.Void exportObject(java.rmi.Remote parameter1) ;
	public java.lang.Void unexportObject(java.rmi.Remote parameter1) ;
	public java.rmi.Remote toStub(java.rmi.Remote parameter1) ;
	public java.lang.Void connect(java.rmi.Remote parameter1, java.rmi.Remote parameter2) ;
	public java.lang.Object narrow(java.lang.Object parameter1, java.lang.Class parameter2) ;
}

package javax.security.auth.callback;

abstract class LanguageCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public LanguageCallback() ;
	public java.util.Locale getLocale() ;
	public java.lang.Void setLocale(java.util.Locale parameter1) ;
}

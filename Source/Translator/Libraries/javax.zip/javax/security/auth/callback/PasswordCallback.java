package javax.security.auth.callback;

abstract class PasswordCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.Void clearPassword() ;
	public java.lang.Boolean isEchoOn() ;
	public java.lang.Character[] getPassword() ;
	public java.lang.Void setPassword(java.lang.Character[] parameter1) ;
	public java.lang.String getPrompt() ;
	public PasswordCallback(java.lang.String parameter1, java.lang.Boolean parameter2) ;
}

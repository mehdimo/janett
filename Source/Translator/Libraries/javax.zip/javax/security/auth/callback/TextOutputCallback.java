package javax.security.auth.callback;

abstract class TextOutputCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.Integer getMessageType() ;
	public java.lang.String getMessage() ;
	java.lang.Integer INFORMATION;
	java.lang.Integer WARNING;
	java.lang.Integer ERROR;
}

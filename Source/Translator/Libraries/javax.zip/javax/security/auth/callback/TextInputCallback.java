package javax.security.auth.callback;

abstract class TextInputCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.String getDefaultText() ;
	public java.lang.String getPrompt() ;
	public java.lang.String getText() ;
	public java.lang.Void setText(java.lang.String parameter1) ;
}

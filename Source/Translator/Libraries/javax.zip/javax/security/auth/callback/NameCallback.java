package javax.security.auth.callback;

abstract class NameCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.String getDefaultName() ;
	public java.lang.String getName() ;
	public java.lang.String getPrompt() ;
	public java.lang.Void setName(java.lang.String parameter1) ;
}

package javax.security.auth.callback;

abstract class NameCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.String getDefaultName() ;
	public java.lang.String getName() ;
	public java.lang.String getPrompt() ;
	public NameCallback(java.lang.String parameter1) ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public NameCallback(java.lang.String parameter1, java.lang.String parameter2) ;
}

package javax.security.auth.callback;

abstract class ChoiceCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.Integer getDefaultChoice() ;
	public java.lang.Boolean allowMultipleSelections() ;
	public java.lang.Integer[] getSelectedIndexes() ;
	public java.lang.Void setSelectedIndex(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectedIndexes(java.lang.Integer[] parameter1) ;
	public java.lang.String getPrompt() ;
	public java.lang.String[] getChoices() ;
}

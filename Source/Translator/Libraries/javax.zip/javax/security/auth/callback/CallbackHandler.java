package javax.security.auth.callback;

interface CallbackHandler
{
	public abstract java.lang.Void handle(javax.security.auth.callback.Callback[] parameter1) ;
}

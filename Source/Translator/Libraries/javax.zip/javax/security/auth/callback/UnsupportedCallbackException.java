package javax.security.auth.callback;

abstract class UnsupportedCallbackException extends java.lang.Exception
{
	public javax.security.auth.callback.Callback getCallback() ;
}

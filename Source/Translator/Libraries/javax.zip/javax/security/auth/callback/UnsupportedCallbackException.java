package javax.security.auth.callback;

abstract class UnsupportedCallbackException extends java.lang.Exception
{
	public javax.security.auth.callback.Callback getCallback() ;
	public UnsupportedCallbackException(javax.security.auth.callback.Callback parameter1) ;
	public UnsupportedCallbackException(javax.security.auth.callback.Callback parameter1, java.lang.String parameter2) ;
}

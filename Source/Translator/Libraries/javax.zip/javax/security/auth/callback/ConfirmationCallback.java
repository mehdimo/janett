package javax.security.auth.callback;

abstract class ConfirmationCallback implements javax.security.auth.callback.Callback, java.io.Serializable
{
	public java.lang.Integer getDefaultOption() ;
	public java.lang.Integer getMessageType() ;
	public java.lang.Integer getOptionType() ;
	public java.lang.Integer getSelectedIndex() ;
	public java.lang.Void setSelectedIndex(java.lang.Integer parameter1) ;
	public ConfirmationCallback(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.String getPrompt() ;
	public java.lang.String[] getOptions() ;
	public ConfirmationCallback(java.lang.Integer parameter1, java.lang.String[] parameter2, java.lang.Integer parameter3) ;
	public ConfirmationCallback(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public ConfirmationCallback(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.String[] parameter3, java.lang.Integer parameter4) ;
	java.lang.Integer UNSPECIFIED_OPTION;
	java.lang.Integer YES_NO_OPTION;
	java.lang.Integer YES_NO_CANCEL_OPTION;
	java.lang.Integer OK_CANCEL_OPTION;
	java.lang.Integer YES;
	java.lang.Integer NO;
	java.lang.Integer CANCEL;
	java.lang.Integer OK;
	java.lang.Integer INFORMATION;
	java.lang.Integer WARNING;
	java.lang.Integer ERROR;
}

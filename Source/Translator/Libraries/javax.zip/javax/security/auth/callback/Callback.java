package javax.security.auth.callback;

interface Callback
{
}

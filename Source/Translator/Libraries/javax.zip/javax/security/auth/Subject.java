package javax.security.auth;

abstract class Subject implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public Subject() ;
	public java.lang.Void setReadOnly() ;
	public java.lang.Boolean isReadOnly() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.util.Set getPrincipals() ;
	public java.util.Set getPrivateCredentials() ;
	public java.util.Set getPublicCredentials() ;
	public java.util.Set getPrincipals(java.lang.Class parameter1) ;
	public java.util.Set getPrivateCredentials(java.lang.Class parameter1) ;
	public java.util.Set getPublicCredentials(java.lang.Class parameter1) ;
	public javax.security.auth.Subject getSubject(java.security.AccessControlContext parameter1) ;
	public java.lang.Object doAs(javax.security.auth.Subject parameter1, java.security.PrivilegedAction parameter2) ;
	public java.lang.Object doAs(javax.security.auth.Subject parameter1, java.security.PrivilegedExceptionAction parameter2) ;
	public Subject(java.lang.Boolean parameter1, java.util.Set parameter2, java.util.Set parameter3, java.util.Set parameter4) ;
	public java.lang.Object doAsPrivileged(javax.security.auth.Subject parameter1, java.security.PrivilegedAction parameter2, java.security.AccessControlContext parameter3) ;
	public java.lang.Object doAsPrivileged(javax.security.auth.Subject parameter1, java.security.PrivilegedExceptionAction parameter2, java.security.AccessControlContext parameter3) ;
}

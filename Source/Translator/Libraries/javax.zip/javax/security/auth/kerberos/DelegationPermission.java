package javax.security.auth.kerberos;

abstract class DelegationPermission extends java.security.BasicPermission implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public DelegationPermission(java.lang.String parameter1) ;
	public java.lang.Boolean implies(java.security.Permission parameter1) ;
	public java.security.PermissionCollection newPermissionCollection() ;
	public DelegationPermission(java.lang.String parameter1, java.lang.String parameter2) ;
}

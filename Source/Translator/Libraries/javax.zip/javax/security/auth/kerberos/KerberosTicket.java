package javax.security.auth.kerberos;

abstract class KerberosTicket implements javax.security.auth.Destroyable, javax.security.auth.Refreshable, java.io.Serializable
{
	public java.lang.Integer getSessionKeyType() ;
	public java.lang.Void destroy() ;
	public java.lang.Void refresh() ;
	public java.lang.Boolean isCurrent() ;
	public java.lang.Boolean isDestroyed() ;
	public java.lang.Boolean isForwardable() ;
	public java.lang.Boolean isForwarded() ;
	public java.lang.Boolean isInitial() ;
	public java.lang.Boolean isPostdated() ;
	public java.lang.Boolean isProxiable() ;
	public java.lang.Boolean isProxy() ;
	public java.lang.Boolean isRenewable() ;
	public java.lang.Byte[] getEncoded() ;
	public java.lang.Boolean[] getFlags() ;
	public java.lang.String toString() ;
	public java.net.InetAddress[] getClientAddresses() ;
	public java.util.Date getAuthTime() ;
	public java.util.Date getEndTime() ;
	public java.util.Date getRenewTill() ;
	public java.util.Date getStartTime() ;
	public javax.crypto.SecretKey getSessionKey() ;
	public javax.security.auth.kerberos.KerberosPrincipal getClient() ;
	public javax.security.auth.kerberos.KerberosPrincipal getServer() ;
	public KerberosTicket(java.lang.Byte[] parameter1, javax.security.auth.kerberos.KerberosPrincipal parameter2, javax.security.auth.kerberos.KerberosPrincipal parameter3, java.lang.Byte[] parameter4, java.lang.Integer parameter5, java.lang.Boolean[] parameter6, java.util.Date parameter7, java.util.Date parameter8, java.util.Date parameter9, java.util.Date parameter10, 
	java.net.InetAddress[] parameter11) ;
}

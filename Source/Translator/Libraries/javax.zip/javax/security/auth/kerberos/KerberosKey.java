package javax.security.auth.kerberos;

abstract class KerberosKey implements javax.crypto.SecretKey, javax.security.auth.Destroyable
{
	public java.lang.Integer getKeyType() ;
	public java.lang.Integer getVersionNumber() ;
	public java.lang.Void destroy() ;
	public java.lang.Boolean isDestroyed() ;
	public java.lang.Byte[] getEncoded() ;
	public java.lang.String getAlgorithm() ;
	public java.lang.String getFormat() ;
	public java.lang.String toString() ;
	public javax.security.auth.kerberos.KerberosPrincipal getPrincipal() ;
}

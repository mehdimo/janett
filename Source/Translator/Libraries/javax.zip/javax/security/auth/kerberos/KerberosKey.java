package javax.security.auth.kerberos;

abstract class KerberosKey implements javax.crypto.SecretKey, javax.security.auth.Destroyable
{
	public java.lang.Integer getKeyType() ;
	public java.lang.Integer getVersionNumber() ;
	public java.lang.Void destroy() ;
	public java.lang.Boolean isDestroyed() ;
	public java.lang.Byte[] getEncoded() ;
	public java.lang.String getAlgorithm() ;
	public java.lang.String getFormat() ;
	public java.lang.String toString() ;
	public javax.security.auth.kerberos.KerberosPrincipal getPrincipal() ;
	public KerberosKey(javax.security.auth.kerberos.KerberosPrincipal parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public KerberosKey(javax.security.auth.kerberos.KerberosPrincipal parameter1, java.lang.Character[] parameter2, java.lang.String parameter3) ;
}

package javax.security.auth.kerberos;

abstract class KerberosPrincipal implements java.security.Principal, java.io.Serializable
{
	public java.lang.Integer getNameType() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String getRealm() ;
	public java.lang.String toString() ;
	java.lang.Integer KRB_NT_UNKNOWN;
	java.lang.Integer KRB_NT_PRINCIPAL;
	java.lang.Integer KRB_NT_SRV_INST;
	java.lang.Integer KRB_NT_SRV_HST;
	java.lang.Integer KRB_NT_SRV_XHST;
	java.lang.Integer KRB_NT_UID;
}

package javax.security.auth.login;

abstract class LoginContext
{
	public java.lang.Void login() ;
	public java.lang.Void logout() ;
	public javax.security.auth.Subject getSubject() ;
}

package javax.security.auth.login;

abstract class LoginContext
{
	public java.lang.Void login() ;
	public java.lang.Void logout() ;
	public LoginContext(java.lang.String parameter1) ;
	public javax.security.auth.Subject getSubject() ;
	public LoginContext(java.lang.String parameter1, javax.security.auth.Subject parameter2) ;
	public LoginContext(java.lang.String parameter1, javax.security.auth.callback.CallbackHandler parameter2) ;
	public LoginContext(java.lang.String parameter1, javax.security.auth.Subject parameter2, javax.security.auth.callback.CallbackHandler parameter3) ;
}

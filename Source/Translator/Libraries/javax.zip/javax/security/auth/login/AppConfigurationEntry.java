package javax.security.auth.login;

abstract class AppConfigurationEntry
{
	public java.lang.String getLoginModuleName() ;
	public java.util.Map getOptions() ;
	public javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag getControlFlag() ;
	public AppConfigurationEntry(java.lang.String parameter1, javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag parameter2, java.util.Map parameter3) ;
	abstract class LoginModuleControlFlag
	{
		public java.lang.String toString() ;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag REQUIRED;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag REQUISITE;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag SUFFICIENT;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag OPTIONAL;
	}
}

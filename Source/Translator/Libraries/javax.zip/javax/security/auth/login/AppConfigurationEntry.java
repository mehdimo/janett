package javax.security.auth.login;

abstract class AppConfigurationEntry
{
	public java.lang.String getLoginModuleName() ;
	public java.util.Map getOptions() ;
	public javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag getControlFlag() ;
	abstract class LoginModuleControlFlag
	{
		public java.lang.String toString() ;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag REQUIRED;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag REQUISITE;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag SUFFICIENT;
		javax.security.auth.login.AppConfigurationEntry.LoginModuleControlFlag OPTIONAL;
	}
}

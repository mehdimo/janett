package javax.security.auth.login;

abstract class FailedLoginException extends javax.security.auth.login.LoginException
{
}

package javax.security.auth.login;

abstract class FailedLoginException extends javax.security.auth.login.LoginException
{
	public FailedLoginException() ;
	public FailedLoginException(java.lang.String parameter1) ;
}

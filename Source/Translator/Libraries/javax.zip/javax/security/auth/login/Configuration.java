package javax.security.auth.login;

abstract class Configuration
{
	public Configuration() ;
	public abstract java.lang.Void refresh() ;
	public javax.security.auth.login.Configuration getConfiguration() ;
	public java.lang.Void setConfiguration(javax.security.auth.login.Configuration parameter1) ;
	public abstract javax.security.auth.login.AppConfigurationEntry[] getAppConfigurationEntry(java.lang.String parameter1) ;
}

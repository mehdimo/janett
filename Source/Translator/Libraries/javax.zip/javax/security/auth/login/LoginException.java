package javax.security.auth.login;

abstract class LoginException extends java.security.GeneralSecurityException
{
	public LoginException() ;
	public LoginException(java.lang.String parameter1) ;
}

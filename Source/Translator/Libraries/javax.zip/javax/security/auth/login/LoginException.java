package javax.security.auth.login;

abstract class LoginException extends java.security.GeneralSecurityException
{
}

package javax.security.auth.login;

abstract class AccountExpiredException extends javax.security.auth.login.LoginException
{
}

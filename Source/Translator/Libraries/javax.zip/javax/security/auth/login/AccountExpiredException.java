package javax.security.auth.login;

abstract class AccountExpiredException extends javax.security.auth.login.LoginException
{
	public AccountExpiredException() ;
	public AccountExpiredException(java.lang.String parameter1) ;
}

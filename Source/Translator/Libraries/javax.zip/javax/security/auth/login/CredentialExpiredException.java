package javax.security.auth.login;

abstract class CredentialExpiredException extends javax.security.auth.login.LoginException
{
	public CredentialExpiredException() ;
	public CredentialExpiredException(java.lang.String parameter1) ;
}

package javax.security.auth.login;

abstract class CredentialExpiredException extends javax.security.auth.login.LoginException
{
}

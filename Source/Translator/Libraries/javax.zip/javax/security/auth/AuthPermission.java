package javax.security.auth;

abstract class AuthPermission extends java.security.BasicPermission
{
}

package javax.security.auth;

abstract class AuthPermission extends java.security.BasicPermission
{
	public AuthPermission(java.lang.String parameter1) ;
	public AuthPermission(java.lang.String parameter1, java.lang.String parameter2) ;
}

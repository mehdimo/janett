package javax.security.auth;

interface Destroyable
{
	public abstract java.lang.Void destroy() ;
	public abstract java.lang.Boolean isDestroyed() ;
}

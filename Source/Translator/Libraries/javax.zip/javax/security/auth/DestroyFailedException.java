package javax.security.auth;

abstract class DestroyFailedException extends java.lang.Exception
{
	public DestroyFailedException() ;
	public DestroyFailedException(java.lang.String parameter1) ;
}

package javax.security.auth;

abstract class SubjectDomainCombiner implements java.security.DomainCombiner
{
	public javax.security.auth.Subject getSubject() ;
	public java.security.ProtectionDomain[] combine(java.security.ProtectionDomain[] parameter1, java.security.ProtectionDomain[] parameter2) ;
}

package javax.security.auth.spi;

interface LoginModule
{
	public abstract java.lang.Boolean abort() ;
	public abstract java.lang.Boolean commit() ;
	public abstract java.lang.Boolean login() ;
	public abstract java.lang.Boolean logout() ;
	public abstract java.lang.Void initialize(javax.security.auth.Subject parameter1, javax.security.auth.callback.CallbackHandler parameter2, java.util.Map parameter3, java.util.Map parameter4) ;
}

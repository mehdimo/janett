package javax.security.auth;

abstract class RefreshFailedException extends java.lang.Exception
{
}

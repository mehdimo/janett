package javax.security.auth;

abstract class RefreshFailedException extends java.lang.Exception
{
	public RefreshFailedException() ;
	public RefreshFailedException(java.lang.String parameter1) ;
}

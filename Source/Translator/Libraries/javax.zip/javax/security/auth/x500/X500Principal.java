package javax.security.auth.x500;

abstract class X500Principal implements java.security.Principal, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Byte[] getEncoded() ;
	public X500Principal(java.lang.Byte[] parameter1) ;
	public X500Principal(java.io.InputStream parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public X500Principal(java.lang.String parameter1) ;
	public java.lang.String getName(java.lang.String parameter1) ;
	java.lang.String RFC1779;
	java.lang.String RFC2253;
	java.lang.String CANONICAL;
}

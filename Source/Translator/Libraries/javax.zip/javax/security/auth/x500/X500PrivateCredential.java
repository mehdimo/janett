package javax.security.auth.x500;

abstract class X500PrivateCredential implements javax.security.auth.Destroyable
{
	public java.lang.Void destroy() ;
	public java.lang.Boolean isDestroyed() ;
	public java.lang.String getAlias() ;
	public java.security.PrivateKey getPrivateKey() ;
	public java.security.cert.X509Certificate getCertificate() ;
	public X500PrivateCredential(java.security.cert.X509Certificate parameter1, java.security.PrivateKey parameter2) ;
	public X500PrivateCredential(java.security.cert.X509Certificate parameter1, java.security.PrivateKey parameter2, java.lang.String parameter3) ;
}

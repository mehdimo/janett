package javax.security.auth;

abstract class Policy
{
	public Policy() ;
	public abstract java.lang.Void refresh() ;
	public javax.security.auth.Policy getPolicy() ;
	public java.lang.Void setPolicy(javax.security.auth.Policy parameter1) ;
	public abstract java.security.PermissionCollection getPermissions(javax.security.auth.Subject parameter1, java.security.CodeSource parameter2) ;
}

package javax.security.auth;

interface Refreshable
{
	public abstract java.lang.Void refresh() ;
	public abstract java.lang.Boolean isCurrent() ;
}

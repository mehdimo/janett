package javax.swing;

abstract class JDesktopPane extends javax.swing.JLayeredPane implements javax.accessibility.Accessible
{
	public java.lang.Integer getDragMode() ;
	public JDesktopPane() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isOpaque() ;
	public java.lang.Void setDragMode(java.lang.Integer parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public javax.swing.DesktopManager getDesktopManager() ;
	public java.lang.Void setDesktopManager(javax.swing.DesktopManager parameter1) ;
	public javax.swing.JInternalFrame getSelectedFrame() ;
	public javax.swing.JInternalFrame[] getAllFrames() ;
	public javax.swing.JInternalFrame[] getAllFramesInLayer(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectedFrame(javax.swing.JInternalFrame parameter1) ;
	public javax.swing.plaf.DesktopPaneUI getUI() ;
	public java.lang.Void setUI(javax.swing.plaf.DesktopPaneUI parameter1) ;
	java.lang.Integer LIVE_DRAG_MODE;
	java.lang.Integer OUTLINE_DRAG_MODE;
	abstract class AccessibleJDesktopPane extends javax.swing.JComponent.AccessibleJComponent
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public AccessibleJDesktopPane(javax.swing.JDesktopPane parameter1) ;
	}
}

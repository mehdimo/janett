package javax.swing;

abstract class JColorChooser extends javax.swing.JComponent implements javax.accessibility.Accessible
{
	public JColorChooser() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean getDragEnabled() ;
	public java.lang.Void setColor(java.lang.Integer parameter1) ;
	public java.lang.Void setColor(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void setDragEnabled(java.lang.Boolean parameter1) ;
	public java.awt.Color getColor() ;
	public JColorChooser(java.awt.Color parameter1) ;
	public java.lang.Void setColor(java.awt.Color parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public javax.swing.JComponent getPreviewPanel() ;
	public java.lang.Void setPreviewPanel(javax.swing.JComponent parameter1) ;
	public javax.swing.colorchooser.AbstractColorChooserPanel[] getChooserPanels() ;
	public java.lang.Void addChooserPanel(javax.swing.colorchooser.AbstractColorChooserPanel parameter1) ;
	public java.lang.Void setChooserPanels(javax.swing.colorchooser.AbstractColorChooserPanel[] parameter1) ;
	public javax.swing.colorchooser.ColorSelectionModel getSelectionModel() ;
	public JColorChooser(javax.swing.colorchooser.ColorSelectionModel parameter1) ;
	public java.lang.Void setSelectionModel(javax.swing.colorchooser.ColorSelectionModel parameter1) ;
	public javax.swing.plaf.ColorChooserUI getUI() ;
	public java.lang.Void setUI(javax.swing.plaf.ColorChooserUI parameter1) ;
	public javax.swing.colorchooser.AbstractColorChooserPanel removeChooserPanel(javax.swing.colorchooser.AbstractColorChooserPanel parameter1) ;
	public java.awt.Color showDialog(java.awt.Component parameter1, java.lang.String parameter2, java.awt.Color parameter3) ;
	public javax.swing.JDialog createDialog(java.awt.Component parameter1, java.lang.String parameter2, java.lang.Boolean parameter3, javax.swing.JColorChooser parameter4, java.awt.event.ActionListener parameter5, java.awt.event.ActionListener parameter6) ;
	java.lang.String SELECTION_MODEL_PROPERTY;
	java.lang.String PREVIEW_PANEL_PROPERTY;
	java.lang.String CHOOSER_PANELS_PROPERTY;
	abstract class AccessibleJColorChooser extends javax.swing.JComponent.AccessibleJComponent
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public AccessibleJColorChooser(javax.swing.JColorChooser parameter1) ;
	}
}

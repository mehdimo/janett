package javax.swing.event;

interface TableColumnModelListener implements java.util.EventListener
{
	public abstract java.lang.Void columnMarginChanged(javax.swing.event.ChangeEvent parameter1) ;
	public abstract java.lang.Void columnSelectionChanged(javax.swing.event.ListSelectionEvent parameter1) ;
	public abstract java.lang.Void columnAdded(javax.swing.event.TableColumnModelEvent parameter1) ;
	public abstract java.lang.Void columnMoved(javax.swing.event.TableColumnModelEvent parameter1) ;
	public abstract java.lang.Void columnRemoved(javax.swing.event.TableColumnModelEvent parameter1) ;
}

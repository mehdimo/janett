package javax.swing.event;

interface MenuKeyListener implements java.util.EventListener
{
	public abstract java.lang.Void menuKeyPressed(javax.swing.event.MenuKeyEvent parameter1) ;
	public abstract java.lang.Void menuKeyReleased(javax.swing.event.MenuKeyEvent parameter1) ;
	public abstract java.lang.Void menuKeyTyped(javax.swing.event.MenuKeyEvent parameter1) ;
}

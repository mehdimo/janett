package javax.swing.event;

abstract class TableModelEvent extends java.util.EventObject
{
	public java.lang.Integer getColumn() ;
	public java.lang.Integer getFirstRow() ;
	public java.lang.Integer getLastRow() ;
	public java.lang.Integer getType() ;
	java.lang.Integer INSERT;
	java.lang.Integer UPDATE;
	java.lang.Integer DELETE;
	java.lang.Integer HEADER_ROW;
	java.lang.Integer ALL_COLUMNS;
}

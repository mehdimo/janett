package javax.swing.event;

abstract class TableModelEvent extends java.util.EventObject
{
	public java.lang.Integer getColumn() ;
	public java.lang.Integer getFirstRow() ;
	public java.lang.Integer getLastRow() ;
	public java.lang.Integer getType() ;
	public TableModelEvent(javax.swing.table.TableModel parameter1) ;
	public TableModelEvent(javax.swing.table.TableModel parameter1, java.lang.Integer parameter2) ;
	public TableModelEvent(javax.swing.table.TableModel parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public TableModelEvent(javax.swing.table.TableModel parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public TableModelEvent(javax.swing.table.TableModel parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	java.lang.Integer INSERT;
	java.lang.Integer UPDATE;
	java.lang.Integer DELETE;
	java.lang.Integer HEADER_ROW;
	java.lang.Integer ALL_COLUMNS;
}

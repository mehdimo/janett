package javax.swing.event;

interface MouseInputListener implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener
{
}

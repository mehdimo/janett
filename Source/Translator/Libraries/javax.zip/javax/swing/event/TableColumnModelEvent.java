package javax.swing.event;

abstract class TableColumnModelEvent extends java.util.EventObject
{
	public java.lang.Integer getFromIndex() ;
	public java.lang.Integer getToIndex() ;
	public TableColumnModelEvent(javax.swing.table.TableColumnModel parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

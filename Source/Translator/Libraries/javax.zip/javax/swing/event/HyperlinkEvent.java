package javax.swing.event;

abstract class HyperlinkEvent extends java.util.EventObject
{
	public java.lang.String getDescription() ;
	public java.net.URL getURL() ;
	public javax.swing.event.HyperlinkEvent.EventType getEventType() ;
	public javax.swing.text.Element getSourceElement() ;
	public HyperlinkEvent(java.lang.Object parameter1, javax.swing.event.HyperlinkEvent.EventType parameter2, java.net.URL parameter3) ;
	public HyperlinkEvent(java.lang.Object parameter1, javax.swing.event.HyperlinkEvent.EventType parameter2, java.net.URL parameter3, java.lang.String parameter4) ;
	public HyperlinkEvent(java.lang.Object parameter1, javax.swing.event.HyperlinkEvent.EventType parameter2, java.net.URL parameter3, java.lang.String parameter4, javax.swing.text.Element parameter5) ;
	abstract class EventType
	{
		public java.lang.String toString() ;
		javax.swing.event.HyperlinkEvent.EventType ENTERED;
		javax.swing.event.HyperlinkEvent.EventType EXITED;
		javax.swing.event.HyperlinkEvent.EventType ACTIVATED;
	}
}

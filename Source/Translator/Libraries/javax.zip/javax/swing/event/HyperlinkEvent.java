package javax.swing.event;

abstract class HyperlinkEvent extends java.util.EventObject
{
	public java.lang.String getDescription() ;
	public java.net.URL getURL() ;
	public javax.swing.event.HyperlinkEvent.EventType getEventType() ;
	public javax.swing.text.Element getSourceElement() ;
	abstract class EventType
	{
		public java.lang.String toString() ;
		javax.swing.event.HyperlinkEvent.EventType ENTERED;
		javax.swing.event.HyperlinkEvent.EventType EXITED;
		javax.swing.event.HyperlinkEvent.EventType ACTIVATED;
	}
}

package javax.swing.event;

interface MenuDragMouseListener implements java.util.EventListener
{
	public abstract java.lang.Void menuDragMouseDragged(javax.swing.event.MenuDragMouseEvent parameter1) ;
	public abstract java.lang.Void menuDragMouseEntered(javax.swing.event.MenuDragMouseEvent parameter1) ;
	public abstract java.lang.Void menuDragMouseExited(javax.swing.event.MenuDragMouseEvent parameter1) ;
	public abstract java.lang.Void menuDragMouseReleased(javax.swing.event.MenuDragMouseEvent parameter1) ;
}

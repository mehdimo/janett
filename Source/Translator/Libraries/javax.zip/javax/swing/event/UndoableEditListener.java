package javax.swing.event;

interface UndoableEditListener implements java.util.EventListener
{
	public abstract java.lang.Void undoableEditHappened(javax.swing.event.UndoableEditEvent parameter1) ;
}

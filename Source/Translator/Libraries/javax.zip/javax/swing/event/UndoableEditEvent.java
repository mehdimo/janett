package javax.swing.event;

abstract class UndoableEditEvent extends java.util.EventObject
{
	public javax.swing.undo.UndoableEdit getEdit() ;
}

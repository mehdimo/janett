package javax.swing.event;

abstract class UndoableEditEvent extends java.util.EventObject
{
	public javax.swing.undo.UndoableEdit getEdit() ;
	public UndoableEditEvent(java.lang.Object parameter1, javax.swing.undo.UndoableEdit parameter2) ;
}

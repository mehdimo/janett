package javax.swing.event;

interface CellEditorListener implements java.util.EventListener
{
	public abstract java.lang.Void editingCanceled(javax.swing.event.ChangeEvent parameter1) ;
	public abstract java.lang.Void editingStopped(javax.swing.event.ChangeEvent parameter1) ;
}

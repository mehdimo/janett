package javax.swing.event;

abstract class SwingPropertyChangeSupport extends java.beans.PropertyChangeSupport
{
	public java.lang.Void firePropertyChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public SwingPropertyChangeSupport(java.lang.Object parameter1) ;
	public java.lang.Boolean hasListeners(java.lang.String parameter1) ;
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String parameter1) ;
	public java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void removePropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
}

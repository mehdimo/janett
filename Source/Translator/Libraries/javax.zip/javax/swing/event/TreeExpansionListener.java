package javax.swing.event;

interface TreeExpansionListener implements java.util.EventListener
{
	public abstract java.lang.Void treeCollapsed(javax.swing.event.TreeExpansionEvent parameter1) ;
	public abstract java.lang.Void treeExpanded(javax.swing.event.TreeExpansionEvent parameter1) ;
}

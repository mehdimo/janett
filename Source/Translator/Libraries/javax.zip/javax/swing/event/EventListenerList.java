package javax.swing.event;

abstract class EventListenerList implements java.io.Serializable
{
	public java.lang.Integer getListenerCount() ;
	public java.lang.Integer getListenerCount(java.lang.Class parameter1) ;
	public java.lang.Object[] getListenerList() ;
	public java.lang.String toString() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	public java.lang.Void add(java.lang.Class parameter1, java.util.EventListener parameter2) ;
	public java.lang.Void remove(java.lang.Class parameter1, java.util.EventListener parameter2) ;
}

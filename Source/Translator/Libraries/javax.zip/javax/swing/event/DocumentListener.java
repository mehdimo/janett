package javax.swing.event;

interface DocumentListener implements java.util.EventListener
{
	public abstract java.lang.Void changedUpdate(javax.swing.event.DocumentEvent parameter1) ;
	public abstract java.lang.Void insertUpdate(javax.swing.event.DocumentEvent parameter1) ;
	public abstract java.lang.Void removeUpdate(javax.swing.event.DocumentEvent parameter1) ;
}

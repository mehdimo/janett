package javax.swing.event;

abstract class InternalFrameAdapter implements javax.swing.event.InternalFrameListener
{
	public java.lang.Void internalFrameActivated(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameClosed(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameClosing(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameDeactivated(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameDeiconified(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameIconified(javax.swing.event.InternalFrameEvent parameter1) ;
	public java.lang.Void internalFrameOpened(javax.swing.event.InternalFrameEvent parameter1) ;
}

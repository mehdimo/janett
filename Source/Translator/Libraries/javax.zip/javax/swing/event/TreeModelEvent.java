package javax.swing.event;

abstract class TreeModelEvent extends java.util.EventObject
{
	public java.lang.Integer[] getChildIndices() ;
	public java.lang.Object[] getChildren() ;
	public java.lang.Object[] getPath() ;
	public java.lang.String toString() ;
	public javax.swing.tree.TreePath getTreePath() ;
	public TreeModelEvent(java.lang.Object parameter1, java.lang.Object[] parameter2) ;
	public TreeModelEvent(java.lang.Object parameter1, javax.swing.tree.TreePath parameter2) ;
	public TreeModelEvent(java.lang.Object parameter1, java.lang.Object[] parameter2, java.lang.Integer[] parameter3, java.lang.Object[] parameter4) ;
	public TreeModelEvent(java.lang.Object parameter1, javax.swing.tree.TreePath parameter2, java.lang.Integer[] parameter3, java.lang.Object[] parameter4) ;
}

package javax.swing.event;

abstract class TreeModelEvent extends java.util.EventObject
{
	public java.lang.Integer[] getChildIndices() ;
	public java.lang.Object[] getChildren() ;
	public java.lang.Object[] getPath() ;
	public java.lang.String toString() ;
	public javax.swing.tree.TreePath getTreePath() ;
}

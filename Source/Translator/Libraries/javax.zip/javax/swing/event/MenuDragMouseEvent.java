package javax.swing.event;

abstract class MenuDragMouseEvent extends java.awt.event.MouseEvent
{
	public javax.swing.MenuElement[] getPath() ;
	public javax.swing.MenuSelectionManager getMenuSelectionManager() ;
}

package javax.swing.event;

abstract class MenuDragMouseEvent extends java.awt.event.MouseEvent
{
	public javax.swing.MenuElement[] getPath() ;
	public javax.swing.MenuSelectionManager getMenuSelectionManager() ;
	public MenuDragMouseEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Boolean parameter8, javax.swing.MenuElement[] parameter9, javax.swing.MenuSelectionManager parameter10
	) ;
}

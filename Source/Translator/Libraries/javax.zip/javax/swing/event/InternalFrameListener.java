package javax.swing.event;

interface InternalFrameListener implements java.util.EventListener
{
	public abstract java.lang.Void internalFrameActivated(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameClosed(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameClosing(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameDeactivated(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameDeiconified(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameIconified(javax.swing.event.InternalFrameEvent parameter1) ;
	public abstract java.lang.Void internalFrameOpened(javax.swing.event.InternalFrameEvent parameter1) ;
}

package javax.swing.event;

interface ListSelectionListener implements java.util.EventListener
{
	public abstract java.lang.Void valueChanged(javax.swing.event.ListSelectionEvent parameter1) ;
}

package javax.swing.event;

abstract class ListDataEvent extends java.util.EventObject
{
	public java.lang.Integer getIndex0() ;
	public java.lang.Integer getIndex1() ;
	public java.lang.Integer getType() ;
	public java.lang.String toString() ;
	java.lang.Integer CONTENTS_CHANGED;
	java.lang.Integer INTERVAL_ADDED;
	java.lang.Integer INTERVAL_REMOVED;
}

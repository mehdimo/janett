package javax.swing.event;

abstract class ListDataEvent extends java.util.EventObject
{
	public java.lang.Integer getIndex0() ;
	public java.lang.Integer getIndex1() ;
	public java.lang.Integer getType() ;
	public ListDataEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.String toString() ;
	java.lang.Integer CONTENTS_CHANGED;
	java.lang.Integer INTERVAL_ADDED;
	java.lang.Integer INTERVAL_REMOVED;
}

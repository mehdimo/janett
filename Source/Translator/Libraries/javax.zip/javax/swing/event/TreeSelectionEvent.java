package javax.swing.event;

abstract class TreeSelectionEvent extends java.util.EventObject
{
	public java.lang.Boolean isAddedPath() ;
	public java.lang.Boolean isAddedPath(java.lang.Integer parameter1) ;
	public javax.swing.tree.TreePath getNewLeadSelectionPath() ;
	public javax.swing.tree.TreePath getOldLeadSelectionPath() ;
	public javax.swing.tree.TreePath getPath() ;
	public javax.swing.tree.TreePath[] getPaths() ;
	public java.lang.Boolean isAddedPath(javax.swing.tree.TreePath parameter1) ;
	public java.lang.Object cloneWithSource(java.lang.Object parameter1) ;
	public TreeSelectionEvent(java.lang.Object parameter1, javax.swing.tree.TreePath parameter2, java.lang.Boolean parameter3, javax.swing.tree.TreePath parameter4, javax.swing.tree.TreePath parameter5) ;
	public TreeSelectionEvent(java.lang.Object parameter1, javax.swing.tree.TreePath[] parameter2, java.lang.Boolean[] parameter3, javax.swing.tree.TreePath parameter4, javax.swing.tree.TreePath parameter5) ;
}

package javax.swing.event;

abstract class TreeExpansionEvent extends java.util.EventObject
{
	public javax.swing.tree.TreePath getPath() ;
}

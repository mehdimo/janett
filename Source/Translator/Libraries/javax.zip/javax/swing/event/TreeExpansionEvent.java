package javax.swing.event;

abstract class TreeExpansionEvent extends java.util.EventObject
{
	public javax.swing.tree.TreePath getPath() ;
	public TreeExpansionEvent(java.lang.Object parameter1, javax.swing.tree.TreePath parameter2) ;
}

package javax.swing.event;

interface ListDataListener implements java.util.EventListener
{
	public abstract java.lang.Void contentsChanged(javax.swing.event.ListDataEvent parameter1) ;
	public abstract java.lang.Void intervalAdded(javax.swing.event.ListDataEvent parameter1) ;
	public abstract java.lang.Void intervalRemoved(javax.swing.event.ListDataEvent parameter1) ;
}

package javax.swing.event;

interface TableModelListener implements java.util.EventListener
{
	public abstract java.lang.Void tableChanged(javax.swing.event.TableModelEvent parameter1) ;
}

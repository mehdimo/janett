package javax.swing.event;

interface MenuListener implements java.util.EventListener
{
	public abstract java.lang.Void menuCanceled(javax.swing.event.MenuEvent parameter1) ;
	public abstract java.lang.Void menuDeselected(javax.swing.event.MenuEvent parameter1) ;
	public abstract java.lang.Void menuSelected(javax.swing.event.MenuEvent parameter1) ;
}

package javax.swing.event;

interface TreeWillExpandListener implements java.util.EventListener
{
	public abstract java.lang.Void treeWillCollapse(javax.swing.event.TreeExpansionEvent parameter1) ;
	public abstract java.lang.Void treeWillExpand(javax.swing.event.TreeExpansionEvent parameter1) ;
}

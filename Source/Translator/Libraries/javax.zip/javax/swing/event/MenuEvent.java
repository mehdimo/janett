package javax.swing.event;

abstract class MenuEvent extends java.util.EventObject
{
	public MenuEvent(java.lang.Object parameter1) ;
}

package javax.swing.event;

interface PopupMenuListener implements java.util.EventListener
{
	public abstract java.lang.Void popupMenuCanceled(javax.swing.event.PopupMenuEvent parameter1) ;
	public abstract java.lang.Void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent parameter1) ;
	public abstract java.lang.Void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent parameter1) ;
}

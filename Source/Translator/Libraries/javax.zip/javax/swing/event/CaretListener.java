package javax.swing.event;

interface CaretListener implements java.util.EventListener
{
	public abstract java.lang.Void caretUpdate(javax.swing.event.CaretEvent parameter1) ;
}

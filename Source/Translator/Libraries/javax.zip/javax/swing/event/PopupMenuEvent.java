package javax.swing.event;

abstract class PopupMenuEvent extends java.util.EventObject
{
}

package javax.swing.event;

abstract class PopupMenuEvent extends java.util.EventObject
{
	public PopupMenuEvent(java.lang.Object parameter1) ;
}

package javax.swing.event;

abstract class MouseInputAdapter implements javax.swing.event.MouseInputListener
{
	public MouseInputAdapter() ;
	public java.lang.Void mouseClicked(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseDragged(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseEntered(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseExited(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseMoved(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mousePressed(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseReleased(java.awt.event.MouseEvent parameter1) ;
}

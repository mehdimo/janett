package javax.swing.event;

abstract class ChangeEvent extends java.util.EventObject
{
}

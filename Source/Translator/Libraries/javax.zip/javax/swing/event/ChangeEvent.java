package javax.swing.event;

abstract class ChangeEvent extends java.util.EventObject
{
	public ChangeEvent(java.lang.Object parameter1) ;
}

package javax.swing.event;

interface TreeSelectionListener implements java.util.EventListener
{
	public abstract java.lang.Void valueChanged(javax.swing.event.TreeSelectionEvent parameter1) ;
}

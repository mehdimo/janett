package javax.swing.event;

interface HyperlinkListener implements java.util.EventListener
{
	public abstract java.lang.Void hyperlinkUpdate(javax.swing.event.HyperlinkEvent parameter1) ;
}

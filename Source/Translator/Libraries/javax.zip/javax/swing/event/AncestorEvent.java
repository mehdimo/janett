package javax.swing.event;

abstract class AncestorEvent extends java.awt.AWTEvent
{
	public java.awt.Container getAncestor() ;
	public java.awt.Container getAncestorParent() ;
	public javax.swing.JComponent getComponent() ;
	public AncestorEvent(javax.swing.JComponent parameter1, java.lang.Integer parameter2, java.awt.Container parameter3, java.awt.Container parameter4) ;
	java.lang.Integer ANCESTOR_ADDED;
	java.lang.Integer ANCESTOR_REMOVED;
	java.lang.Integer ANCESTOR_MOVED;
}

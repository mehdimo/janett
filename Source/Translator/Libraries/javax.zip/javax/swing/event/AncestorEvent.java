package javax.swing.event;

abstract class AncestorEvent extends java.awt.AWTEvent
{
	public java.awt.Container getAncestor() ;
	public java.awt.Container getAncestorParent() ;
	public javax.swing.JComponent getComponent() ;
	java.lang.Integer ANCESTOR_ADDED;
	java.lang.Integer ANCESTOR_REMOVED;
	java.lang.Integer ANCESTOR_MOVED;
}

package javax.swing.event;

abstract class MenuKeyEvent extends java.awt.event.KeyEvent
{
	public javax.swing.MenuElement[] getPath() ;
	public javax.swing.MenuSelectionManager getMenuSelectionManager() ;
	public MenuKeyEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Character parameter6, javax.swing.MenuElement[] parameter7, javax.swing.MenuSelectionManager parameter8) ;
}

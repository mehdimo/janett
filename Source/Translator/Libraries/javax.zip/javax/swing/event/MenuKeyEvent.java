package javax.swing.event;

abstract class MenuKeyEvent extends java.awt.event.KeyEvent
{
	public javax.swing.MenuElement[] getPath() ;
	public javax.swing.MenuSelectionManager getMenuSelectionManager() ;
}

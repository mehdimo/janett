package javax.swing.event;

interface AncestorListener implements java.util.EventListener
{
	public abstract java.lang.Void ancestorAdded(javax.swing.event.AncestorEvent parameter1) ;
	public abstract java.lang.Void ancestorMoved(javax.swing.event.AncestorEvent parameter1) ;
	public abstract java.lang.Void ancestorRemoved(javax.swing.event.AncestorEvent parameter1) ;
}

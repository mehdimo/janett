package javax.swing.event;

abstract class InternalFrameEvent extends java.awt.AWTEvent
{
	public java.lang.String paramString() ;
	public javax.swing.JInternalFrame getInternalFrame() ;
	java.lang.Integer INTERNAL_FRAME_FIRST;
	java.lang.Integer INTERNAL_FRAME_LAST;
	java.lang.Integer INTERNAL_FRAME_OPENED;
	java.lang.Integer INTERNAL_FRAME_CLOSING;
	java.lang.Integer INTERNAL_FRAME_CLOSED;
	java.lang.Integer INTERNAL_FRAME_ICONIFIED;
	java.lang.Integer INTERNAL_FRAME_DEICONIFIED;
	java.lang.Integer INTERNAL_FRAME_ACTIVATED;
	java.lang.Integer INTERNAL_FRAME_DEACTIVATED;
}

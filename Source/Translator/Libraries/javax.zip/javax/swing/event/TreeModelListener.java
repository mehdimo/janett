package javax.swing.event;

interface TreeModelListener implements java.util.EventListener
{
	public abstract java.lang.Void treeNodesChanged(javax.swing.event.TreeModelEvent parameter1) ;
	public abstract java.lang.Void treeNodesInserted(javax.swing.event.TreeModelEvent parameter1) ;
	public abstract java.lang.Void treeNodesRemoved(javax.swing.event.TreeModelEvent parameter1) ;
	public abstract java.lang.Void treeStructureChanged(javax.swing.event.TreeModelEvent parameter1) ;
}

package javax.swing.event;

interface ChangeListener implements java.util.EventListener
{
	public abstract java.lang.Void stateChanged(javax.swing.event.ChangeEvent parameter1) ;
}

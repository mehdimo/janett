package javax.swing.event;

interface DocumentEvent
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.Integer getOffset() ;
	public abstract javax.swing.event.DocumentEvent.EventType getType() ;
	public abstract javax.swing.text.Document getDocument() ;
	public abstract javax.swing.event.DocumentEvent.ElementChange getChange(javax.swing.text.Element parameter1) ;
	abstract class EventType
	{
		public java.lang.String toString() ;
		javax.swing.event.DocumentEvent.EventType INSERT;
		javax.swing.event.DocumentEvent.EventType REMOVE;
		javax.swing.event.DocumentEvent.EventType CHANGE;
	}
	interface ElementChange
	{
		public abstract java.lang.Integer getIndex() ;
		public abstract javax.swing.text.Element getElement() ;
		public abstract javax.swing.text.Element[] getChildrenAdded() ;
		public abstract javax.swing.text.Element[] getChildrenRemoved() ;
	}
}

package javax.swing.event;

abstract class ListSelectionEvent extends java.util.EventObject
{
	public java.lang.Integer getFirstIndex() ;
	public java.lang.Integer getLastIndex() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public java.lang.String toString() ;
}

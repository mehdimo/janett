package javax.swing.event;

abstract class ListSelectionEvent extends java.util.EventObject
{
	public java.lang.Integer getFirstIndex() ;
	public java.lang.Integer getLastIndex() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public ListSelectionEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4) ;
	public java.lang.String toString() ;
}

package javax.swing.event;

abstract class CaretEvent extends java.util.EventObject
{
	public abstract java.lang.Integer getDot() ;
	public abstract java.lang.Integer getMark() ;
}

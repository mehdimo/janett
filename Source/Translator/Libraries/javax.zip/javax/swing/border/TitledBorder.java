package javax.swing.border;

abstract class TitledBorder extends javax.swing.border.AbstractBorder
{
	public java.lang.Integer getTitleJustification() ;
	public java.lang.Integer getTitlePosition() ;
	public java.lang.Boolean isBorderOpaque() ;
	public java.lang.Void setTitleJustification(java.lang.Integer parameter1) ;
	public java.lang.Void setTitlePosition(java.lang.Integer parameter1) ;
	public java.awt.Color getTitleColor() ;
	public java.lang.Void setTitleColor(java.awt.Color parameter1) ;
	public java.awt.Font getTitleFont() ;
	public java.lang.Void setTitleFont(java.awt.Font parameter1) ;
	public java.lang.String getTitle() ;
	public TitledBorder(java.lang.String parameter1) ;
	public java.lang.Void setTitle(java.lang.String parameter1) ;
	public javax.swing.border.Border getBorder() ;
	public TitledBorder(javax.swing.border.Border parameter1) ;
	public java.lang.Void setBorder(javax.swing.border.Border parameter1) ;
	public java.awt.Dimension getMinimumSize(java.awt.Component parameter1) ;
	public java.awt.Font getFont(java.awt.Component parameter1) ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public TitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2) ;
	public TitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public TitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Font parameter5) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
	public TitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Font parameter5, java.awt.Color parameter6) ;
	java.lang.Integer DEFAULT_POSITION;
	java.lang.Integer ABOVE_TOP;
	java.lang.Integer TOP;
	java.lang.Integer BELOW_TOP;
	java.lang.Integer ABOVE_BOTTOM;
	java.lang.Integer BOTTOM;
	java.lang.Integer BELOW_BOTTOM;
	java.lang.Integer DEFAULT_JUSTIFICATION;
	java.lang.Integer LEFT;
	java.lang.Integer CENTER;
	java.lang.Integer RIGHT;
	java.lang.Integer LEADING;
	java.lang.Integer TRAILING;
}

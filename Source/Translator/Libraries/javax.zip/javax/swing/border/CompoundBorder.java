package javax.swing.border;

abstract class CompoundBorder extends javax.swing.border.AbstractBorder
{
	public CompoundBorder() ;
	public java.lang.Boolean isBorderOpaque() ;
	public javax.swing.border.Border getInsideBorder() ;
	public javax.swing.border.Border getOutsideBorder() ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public CompoundBorder(javax.swing.border.Border parameter1, javax.swing.border.Border parameter2) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
}

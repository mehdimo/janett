package javax.swing.border;

interface Border
{
	public abstract java.lang.Boolean isBorderOpaque() ;
	public abstract java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public abstract java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
}

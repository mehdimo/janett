package javax.swing.border;

abstract class EtchedBorder extends javax.swing.border.AbstractBorder
{
	public java.lang.Integer getEtchType() ;
	public java.lang.Boolean isBorderOpaque() ;
	public java.awt.Color getHighlightColor() ;
	public java.awt.Color getShadowColor() ;
	public java.awt.Color getHighlightColor(java.awt.Component parameter1) ;
	public java.awt.Color getShadowColor(java.awt.Component parameter1) ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
	java.lang.Integer RAISED;
	java.lang.Integer LOWERED;
}

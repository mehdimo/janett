package javax.swing.border;

abstract class MatteBorder extends javax.swing.border.EmptyBorder
{
	public java.lang.Boolean isBorderOpaque() ;
	public java.awt.Color getMatteColor() ;
	public MatteBorder(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Color parameter5) ;
	public java.awt.Insets getBorderInsets() ;
	public javax.swing.Icon getTileIcon() ;
	public MatteBorder(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, javax.swing.Icon parameter5) ;
	public MatteBorder(javax.swing.Icon parameter1) ;
	public MatteBorder(java.awt.Insets parameter1, java.awt.Color parameter2) ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public MatteBorder(java.awt.Insets parameter1, javax.swing.Icon parameter2) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
}

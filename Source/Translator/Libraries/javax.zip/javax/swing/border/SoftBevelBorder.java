package javax.swing.border;

abstract class SoftBevelBorder extends javax.swing.border.BevelBorder
{
	public java.lang.Boolean isBorderOpaque() ;
	public SoftBevelBorder(java.lang.Integer parameter1) ;
	public SoftBevelBorder(java.lang.Integer parameter1, java.awt.Color parameter2, java.awt.Color parameter3) ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
	public SoftBevelBorder(java.lang.Integer parameter1, java.awt.Color parameter2, java.awt.Color parameter3, java.awt.Color parameter4, java.awt.Color parameter5) ;
}

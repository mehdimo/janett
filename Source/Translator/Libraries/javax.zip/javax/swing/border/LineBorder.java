package javax.swing.border;

abstract class LineBorder extends javax.swing.border.AbstractBorder
{
	public java.lang.Integer getThickness() ;
	public java.lang.Boolean getRoundedCorners() ;
	public java.lang.Boolean isBorderOpaque() ;
	public java.awt.Color getLineColor() ;
	public javax.swing.border.Border createBlackLineBorder() ;
	public javax.swing.border.Border createGrayLineBorder() ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
}

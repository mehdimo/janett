package javax.swing.border;

abstract class AbstractBorder implements javax.swing.border.Border, java.io.Serializable
{
	public java.lang.Boolean isBorderOpaque() ;
	public java.lang.Void paintBorder(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1) ;
	public java.awt.Rectangle getInteriorRectangle(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.awt.Insets getBorderInsets(java.awt.Component parameter1, java.awt.Insets parameter2) ;
	public java.awt.Rectangle getInteriorRectangle(java.awt.Component parameter1, javax.swing.border.Border parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
}

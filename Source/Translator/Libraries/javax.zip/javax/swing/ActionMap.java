package javax.swing;

abstract class ActionMap implements java.io.Serializable
{
	public java.lang.Integer size() ;
	public ActionMap() ;
	public java.lang.Void clear() ;
	public java.lang.Object[] allKeys() ;
	public java.lang.Object[] keys() ;
	public java.lang.Void remove(java.lang.Object parameter1) ;
	public javax.swing.ActionMap getParent() ;
	public java.lang.Void setParent(javax.swing.ActionMap parameter1) ;
	public javax.swing.Action get(java.lang.Object parameter1) ;
	public java.lang.Void put(java.lang.Object parameter1, javax.swing.Action parameter2) ;
}

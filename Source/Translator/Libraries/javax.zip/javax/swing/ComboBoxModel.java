package javax.swing;

interface ComboBoxModel implements javax.swing.ListModel
{
	public abstract java.lang.Object getSelectedItem() ;
	public abstract java.lang.Void setSelectedItem(java.lang.Object parameter1) ;
}

package javax.swing;

interface Icon
{
	public abstract java.lang.Integer getIconHeight() ;
	public abstract java.lang.Integer getIconWidth() ;
	public abstract java.lang.Void paintIcon(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

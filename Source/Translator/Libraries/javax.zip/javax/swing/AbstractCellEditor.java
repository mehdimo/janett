package javax.swing;

abstract class AbstractCellEditor implements javax.swing.CellEditor, java.io.Serializable
{
	public AbstractCellEditor() ;
	public java.lang.Void cancelCellEditing() ;
	public java.lang.Void fireEditingCanceled() ;
	public java.lang.Void fireEditingStopped() ;
	public java.lang.Boolean stopCellEditing() ;
	public java.lang.Boolean isCellEditable(java.util.EventObject parameter1) ;
	public java.lang.Boolean shouldSelectCell(java.util.EventObject parameter1) ;
	public javax.swing.event.CellEditorListener[] getCellEditorListeners() ;
	public java.lang.Void addCellEditorListener(javax.swing.event.CellEditorListener parameter1) ;
	public java.lang.Void removeCellEditorListener(javax.swing.event.CellEditorListener parameter1) ;
}

package javax.swing;

abstract class CellRendererPane extends java.awt.Container implements javax.accessibility.Accessible
{
	public java.lang.Void invalidate() ;
	public java.lang.Void paint(java.awt.Graphics parameter1) ;
	public java.lang.Void update(java.awt.Graphics parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void addImpl(java.awt.Component parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void paintComponent(java.awt.Graphics parameter1, java.awt.Component parameter2, java.awt.Container parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7) ;
	public java.lang.Void paintComponent(java.awt.Graphics parameter1, java.awt.Component parameter2, java.awt.Container parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Boolean parameter8) ;
	public java.lang.Void paintComponent(java.awt.Graphics parameter1, java.awt.Component parameter2, java.awt.Container parameter3, java.awt.Rectangle parameter4) ;
	abstract class AccessibleCellRendererPane extends java.awt.Container.AccessibleAWTContainer
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

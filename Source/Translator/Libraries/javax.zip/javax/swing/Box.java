package javax.swing;

abstract class Box extends javax.swing.JComponent implements javax.accessibility.Accessible
{
	public java.awt.Component createGlue() ;
	public java.awt.Component createHorizontalGlue() ;
	public java.awt.Component createVerticalGlue() ;
	public java.awt.Component createHorizontalStrut(java.lang.Integer parameter1) ;
	public java.awt.Component createVerticalStrut(java.lang.Integer parameter1) ;
	public java.lang.Void setLayout(java.awt.LayoutManager parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public javax.swing.Box createHorizontalBox() ;
	public javax.swing.Box createVerticalBox() ;
	public java.awt.Component createRigidArea(java.awt.Dimension parameter1) ;
	abstract class Filler$AccessibleBoxFiller extends java.awt.Component.AccessibleAWTComponent
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
	abstract class Filler extends javax.swing.JComponent implements javax.accessibility.Accessible
	{
		public java.awt.Dimension getMaximumSize() ;
		public java.awt.Dimension getMinimumSize() ;
		public java.awt.Dimension getPreferredSize() ;
		public javax.accessibility.AccessibleContext getAccessibleContext() ;
		public java.lang.Void changeShape(java.awt.Dimension parameter1, java.awt.Dimension parameter2, java.awt.Dimension parameter3) ;
	}
	abstract class AccessibleBox extends java.awt.Container.AccessibleAWTContainer
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

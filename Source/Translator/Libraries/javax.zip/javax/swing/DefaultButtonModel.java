package javax.swing;

abstract class DefaultButtonModel implements javax.swing.ButtonModel, java.io.Serializable
{
	public java.lang.Integer getMnemonic() ;
	public DefaultButtonModel() ;
	public java.lang.Void fireStateChanged() ;
	public java.lang.Boolean isArmed() ;
	public java.lang.Boolean isEnabled() ;
	public java.lang.Boolean isPressed() ;
	public java.lang.Boolean isRollover() ;
	public java.lang.Boolean isSelected() ;
	public java.lang.Void setMnemonic(java.lang.Integer parameter1) ;
	public java.lang.Void setArmed(java.lang.Boolean parameter1) ;
	public java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void setPressed(java.lang.Boolean parameter1) ;
	public java.lang.Void setRollover(java.lang.Boolean parameter1) ;
	public java.lang.Void setSelected(java.lang.Boolean parameter1) ;
	public java.lang.Void fireActionPerformed(java.awt.event.ActionEvent parameter1) ;
	public java.awt.event.ActionListener[] getActionListeners() ;
	public java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void fireItemStateChanged(java.awt.event.ItemEvent parameter1) ;
	public java.awt.event.ItemListener[] getItemListeners() ;
	public java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String getActionCommand() ;
	public java.lang.Void setActionCommand(java.lang.String parameter1) ;
	public javax.swing.ButtonGroup getGroup() ;
	public java.lang.Void setGroup(javax.swing.ButtonGroup parameter1) ;
	public javax.swing.event.ChangeListener[] getChangeListeners() ;
	public java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	java.lang.Integer ARMED;
	java.lang.Integer SELECTED;
	java.lang.Integer PRESSED;
	java.lang.Integer ENABLED;
	java.lang.Integer ROLLOVER;
}

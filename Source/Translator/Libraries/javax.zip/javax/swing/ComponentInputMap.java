package javax.swing;

abstract class ComponentInputMap extends javax.swing.InputMap
{
	public java.lang.Void clear() ;
	public java.lang.Void setParent(javax.swing.InputMap parameter1) ;
	public javax.swing.JComponent getComponent() ;
	public ComponentInputMap(javax.swing.JComponent parameter1) ;
	public java.lang.Void remove(javax.swing.KeyStroke parameter1) ;
	public java.lang.Void put(javax.swing.KeyStroke parameter1, java.lang.Object parameter2) ;
}

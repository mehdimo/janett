package javax.swing;

abstract class InputVerifier
{
	public java.lang.Boolean shouldYieldFocus(javax.swing.JComponent parameter1) ;
	public abstract java.lang.Boolean verify(javax.swing.JComponent parameter1) ;
}

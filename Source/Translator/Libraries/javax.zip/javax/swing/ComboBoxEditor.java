package javax.swing;

interface ComboBoxEditor
{
	public abstract java.lang.Void selectAll() ;
	public abstract java.awt.Component getEditorComponent() ;
	public abstract java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public abstract java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public abstract java.lang.Object getItem() ;
	public abstract java.lang.Void setItem(java.lang.Object parameter1) ;
}

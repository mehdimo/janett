package javax.swing;

abstract class JComboBox extends javax.swing.JComponent implements java.awt.ItemSelectable, javax.swing.event.ListDataListener, java.awt.event.ActionListener, javax.accessibility.Accessible
{
	public java.lang.Integer getItemCount() ;
	public java.lang.Integer getMaximumRowCount() ;
	public java.lang.Integer getSelectedIndex() ;
	public java.lang.Void fireActionEvent() ;
	public java.lang.Void firePopupMenuCanceled() ;
	public java.lang.Void firePopupMenuWillBecomeInvisible() ;
	public java.lang.Void firePopupMenuWillBecomeVisible() ;
	public java.lang.Void hidePopup() ;
	public java.lang.Void installAncestorListener() ;
	public java.lang.Void removeAllItems() ;
	public java.lang.Void selectedItemChanged() ;
	public java.lang.Void showPopup() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isEditable() ;
	public java.lang.Boolean isLightWeightPopupEnabled() ;
	public java.lang.Boolean isPopupVisible() ;
	public java.lang.Boolean selectWithKeyChar(java.lang.Character parameter1) ;
	public java.lang.Void removeItemAt(java.lang.Integer parameter1) ;
	public java.lang.Void setMaximumRowCount(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectedIndex(java.lang.Integer parameter1) ;
	public java.lang.Void setEditable(java.lang.Boolean parameter1) ;
	public java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void setLightWeightPopupEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void setPopupVisible(java.lang.Boolean parameter1) ;
	public java.lang.Void actionPerformed(java.awt.event.ActionEvent parameter1) ;
	public java.awt.event.ActionListener[] getActionListeners() ;
	public java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void fireItemStateChanged(java.awt.event.ItemEvent parameter1) ;
	public java.awt.event.ItemListener[] getItemListeners() ;
	public java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void processKeyEvent(java.awt.event.KeyEvent parameter1) ;
	public java.lang.Object getPrototypeDisplayValue() ;
	public java.lang.Object getSelectedItem() ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.Object getItemAt(java.lang.Integer parameter1) ;
	public java.lang.Void addItem(java.lang.Object parameter1) ;
	public java.lang.Void removeItem(java.lang.Object parameter1) ;
	public java.lang.Void setPrototypeDisplayValue(java.lang.Object parameter1) ;
	public java.lang.Void setSelectedItem(java.lang.Object parameter1) ;
	public java.lang.Void insertItemAt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.String getActionCommand() ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public java.lang.Void setActionCommand(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public javax.swing.Action getAction() ;
	public java.lang.Void configurePropertiesFromAction(javax.swing.Action parameter1) ;
	public java.lang.Void setAction(javax.swing.Action parameter1) ;
	public javax.swing.ComboBoxEditor getEditor() ;
	public java.lang.Void setEditor(javax.swing.ComboBoxEditor parameter1) ;
	public javax.swing.ComboBoxModel getModel() ;
	public java.lang.Void setModel(javax.swing.ComboBoxModel parameter1) ;
	public javax.swing.JComboBox.KeySelectionManager createDefaultKeySelectionManager() ;
	public javax.swing.JComboBox.KeySelectionManager getKeySelectionManager() ;
	public java.lang.Void setKeySelectionManager(javax.swing.JComboBox.KeySelectionManager parameter1) ;
	public javax.swing.ListCellRenderer getRenderer() ;
	public java.lang.Void setRenderer(javax.swing.ListCellRenderer parameter1) ;
	public java.lang.Void contentsChanged(javax.swing.event.ListDataEvent parameter1) ;
	public java.lang.Void intervalAdded(javax.swing.event.ListDataEvent parameter1) ;
	public java.lang.Void intervalRemoved(javax.swing.event.ListDataEvent parameter1) ;
	public javax.swing.event.PopupMenuListener[] getPopupMenuListeners() ;
	public java.lang.Void addPopupMenuListener(javax.swing.event.PopupMenuListener parameter1) ;
	public java.lang.Void removePopupMenuListener(javax.swing.event.PopupMenuListener parameter1) ;
	public javax.swing.plaf.ComboBoxUI getUI() ;
	public java.lang.Void setUI(javax.swing.plaf.ComboBoxUI parameter1) ;
	public java.beans.PropertyChangeListener createActionPropertyChangeListener(javax.swing.Action parameter1) ;
	public java.lang.Void configureEditor(javax.swing.ComboBoxEditor parameter1, java.lang.Object parameter2) ;
	interface KeySelectionManager
	{
		public abstract java.lang.Integer selectionForKey(java.lang.Character parameter1, javax.swing.ComboBoxModel parameter2) ;
	}
	abstract class AccessibleJComboBox extends javax.swing.JComponent.AccessibleJComponent implements javax.accessibility.AccessibleAction, javax.accessibility.AccessibleSelection
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Integer getAccessibleChildrenCount() ;
		public java.lang.Integer getAccessibleSelectionCount() ;
		public java.lang.Void clearAccessibleSelection() ;
		public java.lang.Void selectAllAccessibleSelection() ;
		public java.lang.Void addAccessibleSelection(java.lang.Integer parameter1) ;
		public java.lang.Void removeAccessibleSelection(java.lang.Integer parameter1) ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public java.lang.Boolean isAccessibleChildSelected(java.lang.Integer parameter1) ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
		public javax.accessibility.Accessible getAccessibleSelection(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleAction getAccessibleAction() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleSelection getAccessibleSelection() ;
	}
}

package javax.swing;

abstract class JCheckBoxMenuItem extends javax.swing.JMenuItem implements javax.swing.SwingConstants, javax.accessibility.Accessible
{
	public JCheckBoxMenuItem() ;
	public java.lang.Boolean getState() ;
	public java.lang.Void setState(java.lang.Boolean parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public JCheckBoxMenuItem(java.lang.String parameter1) ;
	public JCheckBoxMenuItem(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public JCheckBoxMenuItem(javax.swing.Action parameter1) ;
	public JCheckBoxMenuItem(javax.swing.Icon parameter1) ;
	public JCheckBoxMenuItem(java.lang.String parameter1, javax.swing.Icon parameter2) ;
	public JCheckBoxMenuItem(java.lang.String parameter1, javax.swing.Icon parameter2, java.lang.Boolean parameter3) ;
	abstract class AccessibleJCheckBoxMenuItem extends javax.swing.JMenuItem.AccessibleJMenuItem
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public AccessibleJCheckBoxMenuItem(javax.swing.JCheckBoxMenuItem parameter1) ;
	}
}

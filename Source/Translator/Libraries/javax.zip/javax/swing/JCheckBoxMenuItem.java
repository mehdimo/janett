package javax.swing;

abstract class JCheckBoxMenuItem extends javax.swing.JMenuItem implements javax.swing.SwingConstants, javax.accessibility.Accessible
{
	public java.lang.Boolean getState() ;
	public java.lang.Void setState(java.lang.Boolean parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleJCheckBoxMenuItem extends javax.swing.JMenuItem.AccessibleJMenuItem
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

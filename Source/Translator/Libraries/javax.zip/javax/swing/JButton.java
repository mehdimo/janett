package javax.swing;

abstract class JButton extends javax.swing.AbstractButton implements javax.accessibility.Accessible
{
	public JButton() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isDefaultButton() ;
	public java.lang.Boolean isDefaultCapable() ;
	public java.lang.Void setDefaultCapable(java.lang.Boolean parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public JButton(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public JButton(javax.swing.Action parameter1) ;
	public java.lang.Void configurePropertiesFromAction(javax.swing.Action parameter1) ;
	public JButton(javax.swing.Icon parameter1) ;
	public JButton(java.lang.String parameter1, javax.swing.Icon parameter2) ;
	abstract class AccessibleJButton extends javax.swing.AbstractButton.AccessibleAbstractButton
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public AccessibleJButton(javax.swing.JButton parameter1) ;
	}
}

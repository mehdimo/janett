package javax.swing;

abstract class JButton extends javax.swing.AbstractButton implements javax.accessibility.Accessible
{
	public java.lang.Void removeNotify() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isDefaultButton() ;
	public java.lang.Boolean isDefaultCapable() ;
	public java.lang.Void setDefaultCapable(java.lang.Boolean parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void configurePropertiesFromAction(javax.swing.Action parameter1) ;
	abstract class AccessibleJButton extends javax.swing.AbstractButton.AccessibleAbstractButton
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

package javax.swing;

abstract class DefaultListCellRenderer extends javax.swing.JLabel implements javax.swing.ListCellRenderer, java.io.Serializable
{
	public DefaultListCellRenderer() ;
	public java.lang.Void revalidate() ;
	public java.lang.Void validate() ;
	public java.lang.Void repaint(java.lang.Long parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void repaint(java.awt.Rectangle parameter1) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Byte parameter2, java.lang.Byte parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Character parameter2, java.lang.Character parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Double parameter2, java.lang.Double parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Long parameter2, java.lang.Long parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Short parameter2, java.lang.Short parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public java.awt.Component getListCellRendererComponent(javax.swing.JList parameter1, java.lang.Object parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4, java.lang.Boolean parameter5) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	abstract class UIResource extends javax.swing.DefaultListCellRenderer implements javax.swing.plaf.UIResource
	{
		public UIResource() ;
	}
}

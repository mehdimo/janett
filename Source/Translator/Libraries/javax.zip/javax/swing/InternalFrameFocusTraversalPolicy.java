package javax.swing;

abstract class InternalFrameFocusTraversalPolicy extends java.awt.FocusTraversalPolicy
{
	public InternalFrameFocusTraversalPolicy() ;
	public java.awt.Component getInitialComponent(javax.swing.JInternalFrame parameter1) ;
}

package javax.swing;

abstract class InternalFrameFocusTraversalPolicy extends java.awt.FocusTraversalPolicy
{
	public java.awt.Component getInitialComponent(javax.swing.JInternalFrame parameter1) ;
}

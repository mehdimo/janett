package javax.swing;

abstract class DefaultDesktopManager implements javax.swing.DesktopManager, java.io.Serializable
{
	public java.lang.Void beginDraggingFrame(javax.swing.JComponent parameter1) ;
	public java.lang.Void endDraggingFrame(javax.swing.JComponent parameter1) ;
	public java.lang.Void endResizingFrame(javax.swing.JComponent parameter1) ;
	public java.lang.Void beginResizingFrame(javax.swing.JComponent parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void dragFrame(javax.swing.JComponent parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void resizeFrame(javax.swing.JComponent parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void setBoundsForFrame(javax.swing.JComponent parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void activateFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void closeFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void deactivateFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void deiconifyFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void iconifyFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void maximizeFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void minimizeFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void openFrame(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void removeIconFor(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Boolean wasIcon(javax.swing.JInternalFrame parameter1) ;
	public java.awt.Rectangle getBoundsForIconOf(javax.swing.JInternalFrame parameter1) ;
	public java.awt.Rectangle getPreviousBounds(javax.swing.JInternalFrame parameter1) ;
	public java.lang.Void setPreviousBounds(javax.swing.JInternalFrame parameter1, java.awt.Rectangle parameter2) ;
	public java.lang.Void setWasIcon(javax.swing.JInternalFrame parameter1, java.lang.Boolean parameter2) ;
}

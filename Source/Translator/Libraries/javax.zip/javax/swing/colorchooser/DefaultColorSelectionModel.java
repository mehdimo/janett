package javax.swing.colorchooser;

abstract class DefaultColorSelectionModel implements javax.swing.colorchooser.ColorSelectionModel, java.io.Serializable
{
	public DefaultColorSelectionModel() ;
	public java.lang.Void fireStateChanged() ;
	public java.awt.Color getSelectedColor() ;
	public DefaultColorSelectionModel(java.awt.Color parameter1) ;
	public java.lang.Void setSelectedColor(java.awt.Color parameter1) ;
	public javax.swing.event.ChangeListener[] getChangeListeners() ;
	public java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
}

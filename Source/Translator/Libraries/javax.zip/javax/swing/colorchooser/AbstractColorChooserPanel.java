package javax.swing.colorchooser;

abstract class AbstractColorChooserPanel extends javax.swing.JPanel
{
	public java.lang.Integer getDisplayedMnemonicIndex() ;
	public java.lang.Integer getMnemonic() ;
	public abstract java.lang.Void buildChooser() ;
	public abstract java.lang.Void updateChooser() ;
	public java.awt.Color getColorFromModel() ;
	public java.lang.Void paint(java.awt.Graphics parameter1) ;
	public abstract java.lang.String getDisplayName() ;
	public abstract javax.swing.Icon getLargeDisplayIcon() ;
	public abstract javax.swing.Icon getSmallDisplayIcon() ;
	public java.lang.Void installChooserPanel(javax.swing.JColorChooser parameter1) ;
	public java.lang.Void uninstallChooserPanel(javax.swing.JColorChooser parameter1) ;
	public javax.swing.colorchooser.ColorSelectionModel getColorSelectionModel() ;
}

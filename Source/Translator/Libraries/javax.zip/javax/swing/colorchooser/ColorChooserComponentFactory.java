package javax.swing.colorchooser;

abstract class ColorChooserComponentFactory
{
	public javax.swing.JComponent getPreviewPanel() ;
	public javax.swing.colorchooser.AbstractColorChooserPanel[] getDefaultChooserPanels() ;
}

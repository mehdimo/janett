package javax.swing.colorchooser;

interface ColorSelectionModel
{
	public abstract java.awt.Color getSelectedColor() ;
	public abstract java.lang.Void setSelectedColor(java.awt.Color parameter1) ;
	public abstract java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public abstract java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
}

package javax.swing;

abstract class DefaultSingleSelectionModel implements javax.swing.SingleSelectionModel, java.io.Serializable
{
	public java.lang.Integer getSelectedIndex() ;
	public java.lang.Void clearSelection() ;
	public java.lang.Void fireStateChanged() ;
	public java.lang.Boolean isSelected() ;
	public java.lang.Void setSelectedIndex(java.lang.Integer parameter1) ;
	public javax.swing.event.ChangeListener[] getChangeListeners() ;
	public java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
}

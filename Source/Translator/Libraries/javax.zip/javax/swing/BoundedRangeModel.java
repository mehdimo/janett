package javax.swing;

interface BoundedRangeModel
{
	public abstract java.lang.Integer getExtent() ;
	public abstract java.lang.Integer getMaximum() ;
	public abstract java.lang.Integer getMinimum() ;
	public abstract java.lang.Integer getValue() ;
	public abstract java.lang.Boolean getValueIsAdjusting() ;
	public abstract java.lang.Void setExtent(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setMaximum(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setMinimum(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setValue(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setRangeProperties(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public abstract java.lang.Void setValueIsAdjusting(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public abstract java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
}

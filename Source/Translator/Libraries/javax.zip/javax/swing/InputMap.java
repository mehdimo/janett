package javax.swing;

abstract class InputMap implements java.io.Serializable
{
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public javax.swing.InputMap getParent() ;
	public java.lang.Void setParent(javax.swing.InputMap parameter1) ;
	public javax.swing.KeyStroke[] allKeys() ;
	public javax.swing.KeyStroke[] keys() ;
	public java.lang.Void remove(javax.swing.KeyStroke parameter1) ;
	public java.lang.Object get(javax.swing.KeyStroke parameter1) ;
	public java.lang.Void put(javax.swing.KeyStroke parameter1, java.lang.Object parameter2) ;
}

package javax.swing;

interface Action implements java.awt.event.ActionListener
{
	public abstract java.lang.Boolean isEnabled() ;
	public abstract java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Object getValue(java.lang.String parameter1) ;
	public abstract java.lang.Void putValue(java.lang.String parameter1, java.lang.Object parameter2) ;
	java.lang.String DEFAULT;
	java.lang.String NAME;
	java.lang.String SHORT_DESCRIPTION;
	java.lang.String LONG_DESCRIPTION;
	java.lang.String SMALL_ICON;
	java.lang.String ACTION_COMMAND_KEY;
	java.lang.String ACCELERATOR_KEY;
	java.lang.String MNEMONIC_KEY;
}

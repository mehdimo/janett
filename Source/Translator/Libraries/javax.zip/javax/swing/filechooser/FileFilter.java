package javax.swing.filechooser;

abstract class FileFilter
{
	public abstract java.lang.Boolean accept(java.io.File parameter1) ;
	public abstract java.lang.String getDescription() ;
}

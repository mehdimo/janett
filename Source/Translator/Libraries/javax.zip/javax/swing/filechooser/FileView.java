package javax.swing.filechooser;

abstract class FileView
{
	public FileView() ;
	public java.lang.Boolean isTraversable(java.io.File parameter1) ;
	public java.lang.String getDescription(java.io.File parameter1) ;
	public java.lang.String getName(java.io.File parameter1) ;
	public java.lang.String getTypeDescription(java.io.File parameter1) ;
	public javax.swing.Icon getIcon(java.io.File parameter1) ;
}

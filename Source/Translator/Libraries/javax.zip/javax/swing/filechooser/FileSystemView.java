package javax.swing.filechooser;

abstract class FileSystemView
{
	public java.io.File getDefaultDirectory() ;
	public java.io.File getHomeDirectory() ;
	public java.io.File[] getRoots() ;
	public java.lang.Boolean isComputerNode(java.io.File parameter1) ;
	public java.lang.Boolean isDrive(java.io.File parameter1) ;
	public java.lang.Boolean isFileSystem(java.io.File parameter1) ;
	public java.lang.Boolean isFileSystemRoot(java.io.File parameter1) ;
	public java.lang.Boolean isFloppyDrive(java.io.File parameter1) ;
	public java.lang.Boolean isHiddenFile(java.io.File parameter1) ;
	public java.lang.Boolean isRoot(java.io.File parameter1) ;
	public javax.swing.filechooser.FileSystemView getFileSystemView() ;
	public java.io.File createFileSystemRoot(java.io.File parameter1) ;
	public abstract java.io.File createNewFolder(java.io.File parameter1) ;
	public java.io.File getParentDirectory(java.io.File parameter1) ;
	public java.lang.Boolean isParent(java.io.File parameter1, java.io.File parameter2) ;
	public java.io.File[] getFiles(java.io.File parameter1, java.lang.Boolean parameter2) ;
	public java.io.File createFileObject(java.lang.String parameter1) ;
	public java.lang.Boolean isTraversable(java.io.File parameter1) ;
	public java.lang.String getSystemDisplayName(java.io.File parameter1) ;
	public java.lang.String getSystemTypeDescription(java.io.File parameter1) ;
	public javax.swing.Icon getSystemIcon(java.io.File parameter1) ;
	public java.io.File createFileObject(java.io.File parameter1, java.lang.String parameter2) ;
	public java.io.File getChild(java.io.File parameter1, java.lang.String parameter2) ;
}

package javax.swing;

abstract class ButtonGroup implements java.io.Serializable
{
	public java.lang.Integer getButtonCount() ;
	public java.util.Enumeration getElements() ;
	public java.lang.Void add(javax.swing.AbstractButton parameter1) ;
	public java.lang.Void remove(javax.swing.AbstractButton parameter1) ;
	public javax.swing.ButtonModel getSelection() ;
	public java.lang.Boolean isSelected(javax.swing.ButtonModel parameter1) ;
	public java.lang.Void setSelected(javax.swing.ButtonModel parameter1, java.lang.Boolean parameter2) ;
}

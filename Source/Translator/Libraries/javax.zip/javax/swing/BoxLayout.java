package javax.swing;

abstract class BoxLayout implements java.awt.LayoutManager2, java.io.Serializable
{
	public java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public java.lang.Float getLayoutAlignmentX(java.awt.Container parameter1) ;
	public java.lang.Float getLayoutAlignmentY(java.awt.Container parameter1) ;
	public java.lang.Void invalidateLayout(java.awt.Container parameter1) ;
	public java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public java.awt.Dimension maximumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
	public java.lang.Void addLayoutComponent(java.awt.Component parameter1, java.lang.Object parameter2) ;
	java.lang.Integer X_AXIS;
	java.lang.Integer Y_AXIS;
	java.lang.Integer LINE_AXIS;
	java.lang.Integer PAGE_AXIS;
}

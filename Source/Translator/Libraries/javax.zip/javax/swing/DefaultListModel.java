package javax.swing;

abstract class DefaultListModel extends javax.swing.AbstractListModel
{
	public java.lang.Integer capacity() ;
	public java.lang.Integer getSize() ;
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.Void removeAllElements() ;
	public java.lang.Void trimToSize() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Void ensureCapacity(java.lang.Integer parameter1) ;
	public java.lang.Void removeElementAt(java.lang.Integer parameter1) ;
	public java.lang.Void setSize(java.lang.Integer parameter1) ;
	public java.lang.Void removeRange(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Object firstElement() ;
	public java.lang.Object lastElement() ;
	public java.lang.Object[] toArray() ;
	public java.lang.Object elementAt(java.lang.Integer parameter1) ;
	public java.lang.Object get(java.lang.Integer parameter1) ;
	public java.lang.Object getElementAt(java.lang.Integer parameter1) ;
	public java.lang.Object remove(java.lang.Integer parameter1) ;
	public java.lang.Void add(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public java.lang.Integer indexOf(java.lang.Object parameter1) ;
	public java.lang.Integer lastIndexOf(java.lang.Object parameter1) ;
	public java.lang.Void addElement(java.lang.Object parameter1) ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.lang.Boolean removeElement(java.lang.Object parameter1) ;
	public java.lang.Integer indexOf(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer lastIndexOf(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void insertElementAt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElementAt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void copyInto(java.lang.Object[] parameter1) ;
	public java.lang.String toString() ;
	public java.util.Enumeration elements() ;
	public java.lang.Object set(java.lang.Integer parameter1, java.lang.Object parameter2) ;
}

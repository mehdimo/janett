package javax.swing;

abstract class ImageIcon implements javax.swing.Icon, java.io.Serializable, javax.accessibility.Accessible
{
	public java.lang.Integer getIconHeight() ;
	public java.lang.Integer getIconWidth() ;
	public java.lang.Integer getImageLoadStatus() ;
	public java.awt.Image getImage() ;
	public java.lang.Void loadImage(java.awt.Image parameter1) ;
	public java.lang.Void setImage(java.awt.Image parameter1) ;
	public java.awt.image.ImageObserver getImageObserver() ;
	public java.lang.Void setImageObserver(java.awt.image.ImageObserver parameter1) ;
	public java.lang.String getDescription() ;
	public java.lang.String toString() ;
	public java.lang.Void setDescription(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void paintIcon(java.awt.Component parameter1, java.awt.Graphics parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	abstract class AccessibleImageIcon extends javax.accessibility.AccessibleContext implements javax.accessibility.AccessibleIcon, java.io.Serializable
	{
		public java.lang.Integer getAccessibleChildrenCount() ;
		public java.lang.Integer getAccessibleIconHeight() ;
		public java.lang.Integer getAccessibleIconWidth() ;
		public java.lang.Integer getAccessibleIndexInParent() ;
		public java.lang.String getAccessibleIconDescription() ;
		public java.lang.Void setAccessibleIconDescription(java.lang.String parameter1) ;
		public java.util.Locale getLocale() ;
		public javax.accessibility.Accessible getAccessibleParent() ;
		public javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

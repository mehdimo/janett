package javax.swing;

interface CellEditor
{
	public abstract java.lang.Void cancelCellEditing() ;
	public abstract java.lang.Boolean stopCellEditing() ;
	public abstract java.lang.Object getCellEditorValue() ;
	public abstract java.lang.Boolean isCellEditable(java.util.EventObject parameter1) ;
	public abstract java.lang.Boolean shouldSelectCell(java.util.EventObject parameter1) ;
	public abstract java.lang.Void addCellEditorListener(javax.swing.event.CellEditorListener parameter1) ;
	public abstract java.lang.Void removeCellEditorListener(javax.swing.event.CellEditorListener parameter1) ;
}

package javax.swing;

interface ButtonModel implements java.awt.ItemSelectable
{
	public abstract java.lang.Integer getMnemonic() ;
	public abstract java.lang.Boolean isArmed() ;
	public abstract java.lang.Boolean isEnabled() ;
	public abstract java.lang.Boolean isPressed() ;
	public abstract java.lang.Boolean isRollover() ;
	public abstract java.lang.Boolean isSelected() ;
	public abstract java.lang.Void setMnemonic(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setArmed(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setPressed(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setRollover(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setSelected(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public abstract java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public abstract java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public abstract java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public abstract java.lang.String getActionCommand() ;
	public abstract java.lang.Void setActionCommand(java.lang.String parameter1) ;
	public abstract java.lang.Void setGroup(javax.swing.ButtonGroup parameter1) ;
	public abstract java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public abstract java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
}

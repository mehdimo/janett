package javax.swing;

abstract class AbstractAction implements javax.swing.Action, java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Boolean isEnabled() ;
	public java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Object[] getKeys() ;
	public java.lang.Object getValue(java.lang.String parameter1) ;
	public java.lang.Void putValue(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
}

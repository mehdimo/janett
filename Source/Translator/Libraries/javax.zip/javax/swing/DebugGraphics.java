package javax.swing;

abstract class DebugGraphics extends java.awt.Graphics
{
	public java.lang.Integer flashCount() ;
	public java.lang.Integer flashTime() ;
	public java.lang.Integer getDebugOptions() ;
	public java.lang.Void dispose() ;
	public java.lang.Void setPaintMode() ;
	public java.lang.Boolean isDrawingBuffer() ;
	public java.lang.Void setDebugOptions(java.lang.Integer parameter1) ;
	public java.lang.Void setFlashCount(java.lang.Integer parameter1) ;
	public java.lang.Void setFlashTime(java.lang.Integer parameter1) ;
	public java.lang.Void translate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void clearRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void clipRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void drawLine(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void drawOval(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void drawRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void fillOval(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void fillRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void setClip(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void copyArea(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void drawArc(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void drawRoundRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void fillArc(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void fillRoundRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void draw3DRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public java.lang.Void fill3DRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public java.lang.Void drawBytes(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void drawChars(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void drawPolygon(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void drawPolyline(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void fillPolygon(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.awt.Color flashColor() ;
	public java.awt.Color getColor() ;
	public java.lang.Void setColor(java.awt.Color parameter1) ;
	public java.lang.Void setFlashColor(java.awt.Color parameter1) ;
	public java.lang.Void setXORMode(java.awt.Color parameter1) ;
	public java.awt.Font getFont() ;
	public java.lang.Void setFont(java.awt.Font parameter1) ;
	public java.awt.FontMetrics getFontMetrics() ;
	public java.awt.Graphics create() ;
	public java.awt.Graphics create(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.awt.Rectangle getClipBounds() ;
	public java.awt.Shape getClip() ;
	public java.lang.Void setClip(java.awt.Shape parameter1) ;
	public java.io.PrintStream logStream() ;
	public java.lang.Void setLogStream(java.io.PrintStream parameter1) ;
	public java.lang.Void drawString(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void drawString(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.awt.FontMetrics getFontMetrics(java.awt.Font parameter1) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9, java.awt.image.ImageObserver parameter10
	) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.awt.image.ImageObserver parameter6) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.ImageObserver parameter4) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9, java.awt.Color parameter10, 
	java.awt.image.ImageObserver parameter11) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.awt.Color parameter6, java.awt.image.ImageObserver parameter7) ;
	public java.lang.Boolean drawImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Color parameter4, java.awt.image.ImageObserver parameter5) ;
	java.lang.Integer LOG_OPTION;
	java.lang.Integer FLASH_OPTION;
	java.lang.Integer BUFFERED_OPTION;
	java.lang.Integer NONE_OPTION;
}

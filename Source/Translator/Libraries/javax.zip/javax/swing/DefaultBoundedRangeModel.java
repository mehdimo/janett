package javax.swing;

abstract class DefaultBoundedRangeModel implements javax.swing.BoundedRangeModel, java.io.Serializable
{
	public java.lang.Integer getExtent() ;
	public java.lang.Integer getMaximum() ;
	public java.lang.Integer getMinimum() ;
	public java.lang.Integer getValue() ;
	public java.lang.Void fireStateChanged() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public java.lang.Void setExtent(java.lang.Integer parameter1) ;
	public java.lang.Void setMaximum(java.lang.Integer parameter1) ;
	public java.lang.Void setMinimum(java.lang.Integer parameter1) ;
	public java.lang.Void setValue(java.lang.Integer parameter1) ;
	public java.lang.Void setRangeProperties(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public java.lang.Void setValueIsAdjusting(java.lang.Boolean parameter1) ;
	public java.lang.String toString() ;
	public javax.swing.event.ChangeListener[] getChangeListeners() ;
	public java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
}

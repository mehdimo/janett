package javax.swing;

abstract class DefaultComboBoxModel extends javax.swing.AbstractListModel implements javax.swing.MutableComboBoxModel, java.io.Serializable
{
	public java.lang.Integer getSize() ;
	public DefaultComboBoxModel() ;
	public java.lang.Void removeAllElements() ;
	public java.lang.Void removeElementAt(java.lang.Integer parameter1) ;
	public java.lang.Object getSelectedItem() ;
	public java.lang.Object getElementAt(java.lang.Integer parameter1) ;
	public java.lang.Integer getIndexOf(java.lang.Object parameter1) ;
	public java.lang.Void addElement(java.lang.Object parameter1) ;
	public java.lang.Void removeElement(java.lang.Object parameter1) ;
	public java.lang.Void setSelectedItem(java.lang.Object parameter1) ;
	public java.lang.Void insertElementAt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public DefaultComboBoxModel(java.lang.Object[] parameter1) ;
	public DefaultComboBoxModel(java.util.Vector parameter1) ;
}

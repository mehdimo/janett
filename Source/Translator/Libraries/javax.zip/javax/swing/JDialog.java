package javax.swing;

abstract class JDialog extends java.awt.Dialog implements javax.swing.WindowConstants, javax.accessibility.Accessible, javax.swing.RootPaneContainer
{
	public java.lang.Integer getDefaultCloseOperation() ;
	public java.lang.Void dialogInit() ;
	public java.lang.Boolean isDefaultLookAndFeelDecorated() ;
	public java.lang.Boolean isRootPaneCheckingEnabled() ;
	public java.lang.Void setDefaultCloseOperation(java.lang.Integer parameter1) ;
	public java.lang.Void setDefaultLookAndFeelDecorated(java.lang.Boolean parameter1) ;
	public java.lang.Void setRootPaneCheckingEnabled(java.lang.Boolean parameter1) ;
	public java.awt.Component getGlassPane() ;
	public java.lang.Void remove(java.awt.Component parameter1) ;
	public java.lang.Void setGlassPane(java.awt.Component parameter1) ;
	public java.awt.Container getContentPane() ;
	public java.lang.Void setContentPane(java.awt.Container parameter1) ;
	public java.lang.Void update(java.awt.Graphics parameter1) ;
	public java.lang.Void setLayout(java.awt.LayoutManager parameter1) ;
	public java.lang.Void processWindowEvent(java.awt.event.WindowEvent parameter1) ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public javax.swing.JLayeredPane getLayeredPane() ;
	public java.lang.Void setLayeredPane(javax.swing.JLayeredPane parameter1) ;
	public javax.swing.JMenuBar getJMenuBar() ;
	public java.lang.Void setJMenuBar(javax.swing.JMenuBar parameter1) ;
	public javax.swing.JRootPane createRootPane() ;
	public javax.swing.JRootPane getRootPane() ;
	public java.lang.Void setRootPane(javax.swing.JRootPane parameter1) ;
	public java.lang.Void addImpl(java.awt.Component parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	abstract class AccessibleJDialog extends java.awt.Dialog.AccessibleAWTDialog
	{
		public java.lang.String getAccessibleName() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

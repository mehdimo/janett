package javax.swing;

abstract class DefaultListSelectionModel implements javax.swing.ListSelectionModel, java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Integer getAnchorSelectionIndex() ;
	public java.lang.Integer getLeadSelectionIndex() ;
	public java.lang.Integer getMaxSelectionIndex() ;
	public java.lang.Integer getMinSelectionIndex() ;
	public java.lang.Integer getSelectionMode() ;
	public DefaultListSelectionModel() ;
	public java.lang.Void clearSelection() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public java.lang.Boolean isLeadAnchorNotificationEnabled() ;
	public java.lang.Boolean isSelectionEmpty() ;
	public java.lang.Void setAnchorSelectionIndex(java.lang.Integer parameter1) ;
	public java.lang.Void setLeadSelectionIndex(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectionMode(java.lang.Integer parameter1) ;
	public java.lang.Boolean isSelectedIndex(java.lang.Integer parameter1) ;
	public java.lang.Void addSelectionInterval(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void fireValueChanged(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void removeIndexInterval(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void removeSelectionInterval(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setSelectionInterval(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void fireValueChanged(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void insertIndexInterval(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void fireValueChanged(java.lang.Boolean parameter1) ;
	public java.lang.Void setLeadAnchorNotificationEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void setValueIsAdjusting(java.lang.Boolean parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.String toString() ;
	public javax.swing.event.ListSelectionListener[] getListSelectionListeners() ;
	public java.lang.Void addListSelectionListener(javax.swing.event.ListSelectionListener parameter1) ;
	public java.lang.Void removeListSelectionListener(javax.swing.event.ListSelectionListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
}

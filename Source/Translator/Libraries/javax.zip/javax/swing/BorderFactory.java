package javax.swing;

abstract class BorderFactory
{
	public javax.swing.border.Border createEmptyBorder() ;
	public javax.swing.border.Border createEtchedBorder() ;
	public javax.swing.border.Border createLoweredBevelBorder() ;
	public javax.swing.border.Border createRaisedBevelBorder() ;
	public javax.swing.border.Border createBevelBorder(java.lang.Integer parameter1) ;
	public javax.swing.border.Border createEtchedBorder(java.lang.Integer parameter1) ;
	public javax.swing.border.Border createEmptyBorder(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public javax.swing.border.CompoundBorder createCompoundBorder() ;
	public javax.swing.border.Border createLineBorder(java.awt.Color parameter1) ;
	public javax.swing.border.Border createLineBorder(java.awt.Color parameter1, java.lang.Integer parameter2) ;
	public javax.swing.border.MatteBorder createMatteBorder(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Color parameter5) ;
	public javax.swing.border.MatteBorder createMatteBorder(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, javax.swing.Icon parameter5) ;
	public javax.swing.border.TitledBorder createTitledBorder(java.lang.String parameter1) ;
	public javax.swing.border.TitledBorder createTitledBorder(javax.swing.border.Border parameter1) ;
	public javax.swing.border.Border createBevelBorder(java.lang.Integer parameter1, java.awt.Color parameter2, java.awt.Color parameter3) ;
	public javax.swing.border.Border createEtchedBorder(java.lang.Integer parameter1, java.awt.Color parameter2, java.awt.Color parameter3) ;
	public javax.swing.border.Border createEtchedBorder(java.awt.Color parameter1, java.awt.Color parameter2) ;
	public javax.swing.border.CompoundBorder createCompoundBorder(javax.swing.border.Border parameter1, javax.swing.border.Border parameter2) ;
	public javax.swing.border.TitledBorder createTitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2) ;
	public javax.swing.border.TitledBorder createTitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public javax.swing.border.TitledBorder createTitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Font parameter5) ;
	public javax.swing.border.Border createBevelBorder(java.lang.Integer parameter1, java.awt.Color parameter2, java.awt.Color parameter3, java.awt.Color parameter4, java.awt.Color parameter5) ;
	public javax.swing.border.TitledBorder createTitledBorder(javax.swing.border.Border parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.Font parameter5, java.awt.Color parameter6) ;
}

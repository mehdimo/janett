package javax.swing;

abstract class AbstractSpinnerModel implements javax.swing.SpinnerModel
{
	public AbstractSpinnerModel() ;
	public java.lang.Void fireStateChanged() ;
	public javax.swing.event.ChangeListener[] getChangeListeners() ;
	public java.lang.Void addChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.lang.Void removeChangeListener(javax.swing.event.ChangeListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
}

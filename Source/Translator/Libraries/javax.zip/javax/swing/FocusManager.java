package javax.swing;

abstract class FocusManager extends java.awt.DefaultKeyboardFocusManager
{
	public FocusManager() ;
	public java.lang.Void disableSwingFocusManager() ;
	public java.lang.Boolean isFocusManagerEnabled() ;
	public javax.swing.FocusManager getCurrentManager() ;
	public java.lang.Void setCurrentManager(javax.swing.FocusManager parameter1) ;
	java.lang.String FOCUS_MANAGER_CLASS_PROPERTY;
}

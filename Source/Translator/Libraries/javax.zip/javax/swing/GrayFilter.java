package javax.swing;

abstract class GrayFilter extends java.awt.image.RGBImageFilter
{
	public java.lang.Integer filterRGB(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.awt.Image createDisabledImage(java.awt.Image parameter1) ;
}

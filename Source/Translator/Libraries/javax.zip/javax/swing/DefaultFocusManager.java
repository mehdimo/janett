package javax.swing;

abstract class DefaultFocusManager extends javax.swing.FocusManager
{
	public java.lang.Boolean compareTabOrder(java.awt.Component parameter1, java.awt.Component parameter2) ;
	public java.awt.Component getFirstComponent(java.awt.Container parameter1) ;
	public java.awt.Component getLastComponent(java.awt.Container parameter1) ;
	public java.awt.Component getComponentAfter(java.awt.Container parameter1, java.awt.Component parameter2) ;
	public java.awt.Component getComponentBefore(java.awt.Container parameter1, java.awt.Component parameter2) ;
}

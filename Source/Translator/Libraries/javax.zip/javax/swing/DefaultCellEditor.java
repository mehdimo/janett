package javax.swing;

abstract class DefaultCellEditor extends javax.swing.AbstractCellEditor implements javax.swing.table.TableCellEditor, javax.swing.tree.TreeCellEditor
{
	public java.lang.Integer getClickCountToStart() ;
	public java.lang.Void cancelCellEditing() ;
	public java.lang.Boolean stopCellEditing() ;
	public java.lang.Void setClickCountToStart(java.lang.Integer parameter1) ;
	public java.awt.Component getComponent() ;
	public java.lang.Object getCellEditorValue() ;
	public java.lang.Boolean isCellEditable(java.util.EventObject parameter1) ;
	public java.lang.Boolean shouldSelectCell(java.util.EventObject parameter1) ;
	public DefaultCellEditor(javax.swing.JCheckBox parameter1) ;
	public DefaultCellEditor(javax.swing.JComboBox parameter1) ;
	public DefaultCellEditor(javax.swing.JTextField parameter1) ;
	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable parameter1, java.lang.Object parameter2, java.lang.Boolean parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.awt.Component getTreeCellEditorComponent(javax.swing.JTree parameter1, java.lang.Object parameter2, java.lang.Boolean parameter3, java.lang.Boolean parameter4, java.lang.Boolean parameter5, java.lang.Integer parameter6) ;
	abstract class EditorDelegate implements java.awt.event.ActionListener, java.awt.event.ItemListener, java.io.Serializable
	{
		public java.lang.Void cancelCellEditing() ;
		public java.lang.Boolean stopCellEditing() ;
		public java.lang.Void actionPerformed(java.awt.event.ActionEvent parameter1) ;
		public java.lang.Void itemStateChanged(java.awt.event.ItemEvent parameter1) ;
		public java.lang.Object getCellEditorValue() ;
		public java.lang.Void setValue(java.lang.Object parameter1) ;
		public java.lang.Boolean isCellEditable(java.util.EventObject parameter1) ;
		public java.lang.Boolean shouldSelectCell(java.util.EventObject parameter1) ;
		public java.lang.Boolean startCellEditing(java.util.EventObject parameter1) ;
		public EditorDelegate(javax.swing.DefaultCellEditor parameter1) ;
	}
}

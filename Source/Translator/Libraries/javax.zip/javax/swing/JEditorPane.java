package javax.swing;

abstract class JEditorPane extends javax.swing.text.JTextComponent
{
	public JEditorPane() ;
	public java.lang.Boolean getScrollableTracksViewportHeight() ;
	public java.lang.Boolean getScrollableTracksViewportWidth() ;
	public java.awt.Dimension getPreferredSize() ;
	public java.lang.String getContentType() ;
	public java.lang.String getText() ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public JEditorPane(java.lang.String parameter1) ;
	public java.lang.Void replaceSelection(java.lang.String parameter1) ;
	public java.lang.Void scrollToReference(java.lang.String parameter1) ;
	public java.lang.Void setContentType(java.lang.String parameter1) ;
	public java.lang.Void setPage(java.lang.String parameter1) ;
	public java.lang.Void setText(java.lang.String parameter1) ;
	public java.net.URL getPage() ;
	public JEditorPane(java.net.URL parameter1) ;
	public java.lang.Void setPage(java.net.URL parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void fireHyperlinkUpdate(javax.swing.event.HyperlinkEvent parameter1) ;
	public javax.swing.event.HyperlinkListener[] getHyperlinkListeners() ;
	public java.lang.Void addHyperlinkListener(javax.swing.event.HyperlinkListener parameter1) ;
	public java.lang.Void removeHyperlinkListener(javax.swing.event.HyperlinkListener parameter1) ;
	public javax.swing.text.EditorKit createDefaultEditorKit() ;
	public javax.swing.text.EditorKit getEditorKit() ;
	public java.lang.Void setEditorKit(javax.swing.text.EditorKit parameter1) ;
	public java.io.InputStream getStream(java.net.URL parameter1) ;
	public java.lang.Void read(java.io.InputStream parameter1, java.lang.Object parameter2) ;
	public java.lang.String getEditorKitClassNameForContentType(java.lang.String parameter1) ;
	public JEditorPane(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void registerEditorKitForContentType(java.lang.String parameter1, java.lang.String parameter2) ;
	public javax.swing.text.EditorKit createEditorKitForContentType(java.lang.String parameter1) ;
	public javax.swing.text.EditorKit getEditorKitForContentType(java.lang.String parameter1) ;
	public java.lang.Void setEditorKitForContentType(java.lang.String parameter1, javax.swing.text.EditorKit parameter2) ;
	public java.lang.Void registerEditorKitForContentType(java.lang.String parameter1, java.lang.String parameter2, java.lang.ClassLoader parameter3) ;
	abstract class JEditorPaneAccessibleHypertextSupport$HTMLLink extends javax.accessibility.AccessibleHyperlink
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Integer getEndIndex() ;
		public java.lang.Integer getStartIndex() ;
		public java.lang.Boolean isValid() ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public java.lang.Object getAccessibleActionAnchor(java.lang.Integer parameter1) ;
		public java.lang.Object getAccessibleActionObject(java.lang.Integer parameter1) ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public JEditorPaneAccessibleHypertextSupport$HTMLLink(javax.swing.JEditorPane.JEditorPaneAccessibleHypertextSupport parameter1, javax.swing.text.Element parameter2) ;
	}
	abstract class AccessibleJEditorPane extends javax.swing.text.JTextComponent.AccessibleJTextComponent
	{
		public java.lang.String getAccessibleDescription() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
		public AccessibleJEditorPane(javax.swing.JEditorPane parameter1) ;
	}
	abstract class JEditorPaneAccessibleHypertextSupport extends javax.swing.JEditorPane.AccessibleJEditorPane implements javax.accessibility.AccessibleHypertext
	{
		public java.lang.Integer getLinkCount() ;
		public java.lang.Integer getLinkIndex(java.lang.Integer parameter1) ;
		public java.lang.String getLinkText(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleHyperlink getLink(java.lang.Integer parameter1) ;
		public JEditorPaneAccessibleHypertextSupport(javax.swing.JEditorPane parameter1) ;
	}
	abstract class AccessibleJEditorPaneHTML extends javax.swing.JEditorPane.AccessibleJEditorPane
	{
		public java.lang.Integer getAccessibleChildrenCount() ;
		public javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleText getAccessibleText() ;
		public AccessibleJEditorPaneHTML(javax.swing.JEditorPane parameter1) ;
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point parameter1) ;
	}
}

package javax.swing;

abstract class AbstractListModel implements javax.swing.ListModel, java.io.Serializable
{
	public java.lang.Void fireContentsChanged(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void fireIntervalAdded(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void fireIntervalRemoved(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public javax.swing.event.ListDataListener[] getListDataListeners() ;
	public java.lang.Void addListDataListener(javax.swing.event.ListDataListener parameter1) ;
	public java.lang.Void removeListDataListener(javax.swing.event.ListDataListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
}

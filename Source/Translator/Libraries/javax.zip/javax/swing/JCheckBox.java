package javax.swing;

abstract class JCheckBox extends javax.swing.JToggleButton implements javax.accessibility.Accessible
{
	public JCheckBox() ;
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isBorderPaintedFlat() ;
	public java.lang.Void setBorderPaintedFlat(java.lang.Boolean parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public JCheckBox(java.lang.String parameter1) ;
	public JCheckBox(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public JCheckBox(javax.swing.Action parameter1) ;
	public java.lang.Void configurePropertiesFromAction(javax.swing.Action parameter1) ;
	public JCheckBox(javax.swing.Icon parameter1) ;
	public JCheckBox(javax.swing.Icon parameter1, java.lang.Boolean parameter2) ;
	public java.beans.PropertyChangeListener createActionPropertyChangeListener(javax.swing.Action parameter1) ;
	public JCheckBox(java.lang.String parameter1, javax.swing.Icon parameter2) ;
	public JCheckBox(java.lang.String parameter1, javax.swing.Icon parameter2, java.lang.Boolean parameter3) ;
	java.lang.String BORDER_PAINTED_FLAT_CHANGED_PROPERTY;
	abstract class AccessibleJCheckBox extends javax.swing.JToggleButton.AccessibleJToggleButton
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public AccessibleJCheckBox(javax.swing.JCheckBox parameter1) ;
	}
}

package javax.swing;

abstract class JCheckBox extends javax.swing.JToggleButton implements javax.accessibility.Accessible
{
	public java.lang.Void updateUI() ;
	public java.lang.Boolean isBorderPaintedFlat() ;
	public java.lang.Void setBorderPaintedFlat(java.lang.Boolean parameter1) ;
	public java.lang.String getUIClassID() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void configurePropertiesFromAction(javax.swing.Action parameter1) ;
	public java.beans.PropertyChangeListener createActionPropertyChangeListener(javax.swing.Action parameter1) ;
	java.lang.String BORDER_PAINTED_FLAT_CHANGED_PROPERTY;
	abstract class AccessibleJCheckBox extends javax.swing.JToggleButton.AccessibleJToggleButton
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

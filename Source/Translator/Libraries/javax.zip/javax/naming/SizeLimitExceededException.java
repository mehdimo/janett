package javax.naming;

abstract class SizeLimitExceededException extends javax.naming.LimitExceededException
{
	public SizeLimitExceededException() ;
	public SizeLimitExceededException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class SizeLimitExceededException extends javax.naming.LimitExceededException
{
}

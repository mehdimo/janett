package javax.naming;

abstract class NameNotFoundException extends javax.naming.NamingException
{
	public NameNotFoundException() ;
	public NameNotFoundException(java.lang.String parameter1) ;
}

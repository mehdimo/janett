package javax.naming;

abstract class NameNotFoundException extends javax.naming.NamingException
{
}

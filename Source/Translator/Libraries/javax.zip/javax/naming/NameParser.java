package javax.naming;

interface NameParser
{
	public abstract javax.naming.Name parse(java.lang.String parameter1) ;
}

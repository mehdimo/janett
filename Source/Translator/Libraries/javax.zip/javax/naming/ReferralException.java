package javax.naming;

abstract class ReferralException extends javax.naming.NamingException
{
	public ReferralException() ;
	public abstract java.lang.Void retryReferral() ;
	public abstract java.lang.Boolean skipReferral() ;
	public abstract java.lang.Object getReferralInfo() ;
	public ReferralException(java.lang.String parameter1) ;
	public abstract javax.naming.Context getReferralContext() ;
	public abstract javax.naming.Context getReferralContext(java.util.Hashtable parameter1) ;
}

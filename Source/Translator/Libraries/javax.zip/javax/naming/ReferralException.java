package javax.naming;

abstract class ReferralException extends javax.naming.NamingException
{
	public abstract java.lang.Void retryReferral() ;
	public abstract java.lang.Boolean skipReferral() ;
	public abstract java.lang.Object getReferralInfo() ;
	public abstract javax.naming.Context getReferralContext() ;
	public abstract javax.naming.Context getReferralContext(java.util.Hashtable parameter1) ;
}

package javax.naming;

interface Name implements java.lang.Cloneable, java.io.Serializable
{
	public abstract java.lang.Integer size() ;
	public abstract java.lang.Boolean isEmpty() ;
	public abstract java.lang.Object clone() ;
	public abstract java.lang.Object remove(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public abstract java.lang.String get(java.lang.Integer parameter1) ;
	public abstract java.util.Enumeration getAll() ;
	public abstract javax.naming.Name getPrefix(java.lang.Integer parameter1) ;
	public abstract javax.naming.Name getSuffix(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean endsWith(javax.naming.Name parameter1) ;
	public abstract java.lang.Boolean startsWith(javax.naming.Name parameter1) ;
	public abstract javax.naming.Name add(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract javax.naming.Name add(java.lang.String parameter1) ;
	public abstract javax.naming.Name addAll(java.lang.Integer parameter1, javax.naming.Name parameter2) ;
	public abstract javax.naming.Name addAll(javax.naming.Name parameter1) ;
}

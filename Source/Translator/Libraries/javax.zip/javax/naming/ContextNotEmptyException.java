package javax.naming;

abstract class ContextNotEmptyException extends javax.naming.NamingException
{
	public ContextNotEmptyException() ;
	public ContextNotEmptyException(java.lang.String parameter1) ;
}

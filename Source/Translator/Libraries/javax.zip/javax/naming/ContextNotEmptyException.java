package javax.naming;

abstract class ContextNotEmptyException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class NotContextException extends javax.naming.NamingException
{
	public NotContextException() ;
	public NotContextException(java.lang.String parameter1) ;
}

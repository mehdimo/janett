package javax.naming;

abstract class NotContextException extends javax.naming.NamingException
{
}

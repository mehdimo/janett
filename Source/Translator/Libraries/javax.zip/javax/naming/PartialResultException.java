package javax.naming;

abstract class PartialResultException extends javax.naming.NamingException
{
}

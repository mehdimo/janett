package javax.naming;

abstract class PartialResultException extends javax.naming.NamingException
{
	public PartialResultException() ;
	public PartialResultException(java.lang.String parameter1) ;
}

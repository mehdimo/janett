package javax.naming.event;

interface NamespaceChangeListener implements javax.naming.event.NamingListener
{
	public abstract java.lang.Void objectAdded(javax.naming.event.NamingEvent parameter1) ;
	public abstract java.lang.Void objectRemoved(javax.naming.event.NamingEvent parameter1) ;
	public abstract java.lang.Void objectRenamed(javax.naming.event.NamingEvent parameter1) ;
}

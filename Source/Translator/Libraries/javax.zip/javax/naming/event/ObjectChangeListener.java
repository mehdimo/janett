package javax.naming.event;

interface ObjectChangeListener implements javax.naming.event.NamingListener
{
	public abstract java.lang.Void objectChanged(javax.naming.event.NamingEvent parameter1) ;
}

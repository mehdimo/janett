package javax.naming.event;

interface NamingListener implements java.util.EventListener
{
	public abstract java.lang.Void namingExceptionThrown(javax.naming.event.NamingExceptionEvent parameter1) ;
}

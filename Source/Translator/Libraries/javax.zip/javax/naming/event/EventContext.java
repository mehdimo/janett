package javax.naming.event;

interface EventContext implements javax.naming.Context
{
	public abstract java.lang.Boolean targetMustExist() ;
	public abstract java.lang.Void removeNamingListener(javax.naming.event.NamingListener parameter1) ;
	public abstract java.lang.Void addNamingListener(java.lang.String parameter1, java.lang.Integer parameter2, javax.naming.event.NamingListener parameter3) ;
	public abstract java.lang.Void addNamingListener(javax.naming.Name parameter1, java.lang.Integer parameter2, javax.naming.event.NamingListener parameter3) ;
	java.lang.Integer OBJECT_SCOPE;
	java.lang.Integer ONELEVEL_SCOPE;
	java.lang.Integer SUBTREE_SCOPE;
}

package javax.naming.event;

abstract class NamingEvent extends java.util.EventObject
{
	public java.lang.Integer getType() ;
	public java.lang.Object getChangeInfo() ;
	public javax.naming.Binding getNewBinding() ;
	public javax.naming.Binding getOldBinding() ;
	public javax.naming.event.EventContext getEventContext() ;
	public java.lang.Void dispatch(javax.naming.event.NamingListener parameter1) ;
	java.lang.Integer OBJECT_ADDED;
	java.lang.Integer OBJECT_REMOVED;
	java.lang.Integer OBJECT_RENAMED;
	java.lang.Integer OBJECT_CHANGED;
}

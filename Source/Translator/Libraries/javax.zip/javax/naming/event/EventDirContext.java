package javax.naming.event;

interface EventDirContext implements javax.naming.event.EventContext, javax.naming.directory.DirContext
{
	public abstract java.lang.Void addNamingListener(java.lang.String parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3, javax.naming.event.NamingListener parameter4) ;
	public abstract java.lang.Void addNamingListener(javax.naming.Name parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3, javax.naming.event.NamingListener parameter4) ;
	public abstract java.lang.Void addNamingListener(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4, javax.naming.event.NamingListener parameter5) ;
	public abstract java.lang.Void addNamingListener(javax.naming.Name parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4, javax.naming.event.NamingListener parameter5) ;
}

package javax.naming.event;

abstract class NamingExceptionEvent extends java.util.EventObject
{
	public javax.naming.NamingException getException() ;
	public javax.naming.event.EventContext getEventContext() ;
	public java.lang.Void dispatch(javax.naming.event.NamingListener parameter1) ;
	public NamingExceptionEvent(javax.naming.event.EventContext parameter1, javax.naming.NamingException parameter2) ;
}

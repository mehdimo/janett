package javax.naming;

abstract class AuthenticationException extends javax.naming.NamingSecurityException
{
}

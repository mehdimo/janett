package javax.naming;

abstract class AuthenticationException extends javax.naming.NamingSecurityException
{
	public AuthenticationException() ;
	public AuthenticationException(java.lang.String parameter1) ;
}

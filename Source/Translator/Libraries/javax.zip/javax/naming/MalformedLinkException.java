package javax.naming;

abstract class MalformedLinkException extends javax.naming.LinkException
{
	public MalformedLinkException() ;
	public MalformedLinkException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class MalformedLinkException extends javax.naming.LinkException
{
}

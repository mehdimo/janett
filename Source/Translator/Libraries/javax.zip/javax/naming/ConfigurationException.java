package javax.naming;

abstract class ConfigurationException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class ConfigurationException extends javax.naming.NamingException
{
	public ConfigurationException() ;
	public ConfigurationException(java.lang.String parameter1) ;
}

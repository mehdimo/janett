package javax.naming.ldap;

interface LdapContext implements javax.naming.directory.DirContext
{
	public abstract javax.naming.ldap.Control[] getConnectControls() ;
	public abstract javax.naming.ldap.Control[] getRequestControls() ;
	public abstract javax.naming.ldap.Control[] getResponseControls() ;
	public abstract java.lang.Void reconnect(javax.naming.ldap.Control[] parameter1) ;
	public abstract java.lang.Void setRequestControls(javax.naming.ldap.Control[] parameter1) ;
	public abstract javax.naming.ldap.ExtendedResponse extendedOperation(javax.naming.ldap.ExtendedRequest parameter1) ;
	public abstract javax.naming.ldap.LdapContext newInstance(javax.naming.ldap.Control[] parameter1) ;
	java.lang.String CONTROL_FACTORIES;
}

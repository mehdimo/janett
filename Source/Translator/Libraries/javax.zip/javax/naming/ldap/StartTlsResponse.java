package javax.naming.ldap;

abstract class StartTlsResponse implements javax.naming.ldap.ExtendedResponse
{
	public StartTlsResponse() ;
	public abstract java.lang.Void close() ;
	public java.lang.Byte[] getEncodedValue() ;
	public java.lang.String getID() ;
	public abstract java.lang.Void setEnabledCipherSuites(java.lang.String[] parameter1) ;
	public abstract java.lang.Void setHostnameVerifier(javax.net.ssl.HostnameVerifier parameter1) ;
	public abstract javax.net.ssl.SSLSession negotiate() ;
	public abstract javax.net.ssl.SSLSession negotiate(javax.net.ssl.SSLSocketFactory parameter1) ;
	java.lang.String OID;
}

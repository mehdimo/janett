package javax.naming.ldap;

abstract class InitialLdapContext extends javax.naming.directory.InitialDirContext implements javax.naming.ldap.LdapContext
{
	public InitialLdapContext() ;
	public javax.naming.ldap.Control[] getConnectControls() ;
	public javax.naming.ldap.Control[] getRequestControls() ;
	public javax.naming.ldap.Control[] getResponseControls() ;
	public java.lang.Void reconnect(javax.naming.ldap.Control[] parameter1) ;
	public java.lang.Void setRequestControls(javax.naming.ldap.Control[] parameter1) ;
	public InitialLdapContext(java.util.Hashtable parameter1, javax.naming.ldap.Control[] parameter2) ;
	public javax.naming.ldap.ExtendedResponse extendedOperation(javax.naming.ldap.ExtendedRequest parameter1) ;
	public javax.naming.ldap.LdapContext newInstance(javax.naming.ldap.Control[] parameter1) ;
}

package javax.naming.ldap;

interface HasControls
{
	public abstract javax.naming.ldap.Control[] getControls() ;
}

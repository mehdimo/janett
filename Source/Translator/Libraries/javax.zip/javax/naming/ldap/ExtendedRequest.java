package javax.naming.ldap;

interface ExtendedRequest implements java.io.Serializable
{
	public abstract java.lang.Byte[] getEncodedValue() ;
	public abstract java.lang.String getID() ;
	public abstract javax.naming.ldap.ExtendedResponse createExtendedResponse(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

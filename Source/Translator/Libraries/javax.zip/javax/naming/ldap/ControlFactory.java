package javax.naming.ldap;

abstract class ControlFactory
{
	public abstract javax.naming.ldap.Control getControlInstance(javax.naming.ldap.Control parameter1) ;
	public javax.naming.ldap.Control getControlInstance(javax.naming.ldap.Control parameter1, javax.naming.Context parameter2, java.util.Hashtable parameter3) ;
}

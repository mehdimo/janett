package javax.naming.ldap;

abstract class StartTlsRequest implements javax.naming.ldap.ExtendedRequest
{
	public StartTlsRequest() ;
	public java.lang.Byte[] getEncodedValue() ;
	public java.lang.String getID() ;
	public javax.naming.ldap.ExtendedResponse createExtendedResponse(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	java.lang.String OID;
}

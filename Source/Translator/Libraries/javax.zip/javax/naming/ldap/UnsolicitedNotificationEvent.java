package javax.naming.ldap;

abstract class UnsolicitedNotificationEvent extends java.util.EventObject
{
	public javax.naming.ldap.UnsolicitedNotification getNotification() ;
	public java.lang.Void dispatch(javax.naming.ldap.UnsolicitedNotificationListener parameter1) ;
	public UnsolicitedNotificationEvent(java.lang.Object parameter1, javax.naming.ldap.UnsolicitedNotification parameter2) ;
}

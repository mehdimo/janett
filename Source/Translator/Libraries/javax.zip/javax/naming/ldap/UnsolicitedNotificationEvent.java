package javax.naming.ldap;

abstract class UnsolicitedNotificationEvent extends java.util.EventObject
{
	public javax.naming.ldap.UnsolicitedNotification getNotification() ;
	public java.lang.Void dispatch(javax.naming.ldap.UnsolicitedNotificationListener parameter1) ;
}

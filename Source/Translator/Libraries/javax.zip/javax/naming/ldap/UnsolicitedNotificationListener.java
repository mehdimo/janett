package javax.naming.ldap;

interface UnsolicitedNotificationListener implements javax.naming.event.NamingListener
{
	public abstract java.lang.Void notificationReceived(javax.naming.ldap.UnsolicitedNotificationEvent parameter1) ;
}

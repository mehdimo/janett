package javax.naming.ldap;

interface UnsolicitedNotification implements javax.naming.ldap.ExtendedResponse, javax.naming.ldap.HasControls
{
	public abstract java.lang.String[] getReferrals() ;
	public abstract javax.naming.NamingException getException() ;
}

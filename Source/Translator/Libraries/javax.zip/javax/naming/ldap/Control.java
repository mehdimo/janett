package javax.naming.ldap;

interface Control implements java.io.Serializable
{
	public abstract java.lang.Boolean isCritical() ;
	public abstract java.lang.Byte[] getEncodedValue() ;
	public abstract java.lang.String getID() ;
	java.lang.Boolean CRITICAL;
	java.lang.Boolean NONCRITICAL;
}

package javax.naming.ldap;

interface ExtendedResponse implements java.io.Serializable
{
	public abstract java.lang.Byte[] getEncodedValue() ;
	public abstract java.lang.String getID() ;
}

package javax.naming.ldap;

abstract class LdapReferralException extends javax.naming.ReferralException
{
	public LdapReferralException() ;
	public LdapReferralException(java.lang.String parameter1) ;
	public abstract javax.naming.Context getReferralContext() ;
	public abstract javax.naming.Context getReferralContext(java.util.Hashtable parameter1) ;
	public abstract javax.naming.Context getReferralContext(java.util.Hashtable parameter1, javax.naming.ldap.Control[] parameter2) ;
}

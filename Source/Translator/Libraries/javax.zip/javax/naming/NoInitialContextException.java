package javax.naming;

abstract class NoInitialContextException extends javax.naming.NamingException
{
	public NoInitialContextException() ;
	public NoInitialContextException(java.lang.String parameter1) ;
}

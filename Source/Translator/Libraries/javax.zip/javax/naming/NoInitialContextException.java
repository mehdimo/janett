package javax.naming;

abstract class NoInitialContextException extends javax.naming.NamingException
{
}

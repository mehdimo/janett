package javax.naming;

abstract class InvalidNameException extends javax.naming.NamingException
{
}

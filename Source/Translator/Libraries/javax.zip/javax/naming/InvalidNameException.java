package javax.naming;

abstract class InvalidNameException extends javax.naming.NamingException
{
	public InvalidNameException() ;
	public InvalidNameException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class AuthenticationNotSupportedException extends javax.naming.NamingSecurityException
{
	public AuthenticationNotSupportedException() ;
	public AuthenticationNotSupportedException(java.lang.String parameter1) ;
}

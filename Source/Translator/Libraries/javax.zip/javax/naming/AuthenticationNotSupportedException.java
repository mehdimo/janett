package javax.naming;

abstract class AuthenticationNotSupportedException extends javax.naming.NamingSecurityException
{
}

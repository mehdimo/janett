package javax.naming;

interface Referenceable
{
	public abstract javax.naming.Reference getReference() ;
}

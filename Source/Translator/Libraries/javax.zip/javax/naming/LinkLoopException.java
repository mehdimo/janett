package javax.naming;

abstract class LinkLoopException extends javax.naming.LinkException
{
	public LinkLoopException() ;
	public LinkLoopException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class LinkLoopException extends javax.naming.LinkException
{
}

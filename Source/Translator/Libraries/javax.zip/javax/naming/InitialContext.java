package javax.naming;

abstract class InitialContext implements javax.naming.Context
{
	public java.lang.Void close() ;
	public java.lang.String getNameInNamespace() ;
	public java.lang.Void destroySubcontext(java.lang.String parameter1) ;
	public java.lang.Void unbind(java.lang.String parameter1) ;
	public java.util.Hashtable getEnvironment() ;
	public java.lang.Void init(java.util.Hashtable parameter1) ;
	public javax.naming.Context getDefaultInitCtx() ;
	public java.lang.Void destroySubcontext(javax.naming.Name parameter1) ;
	public java.lang.Void unbind(javax.naming.Name parameter1) ;
	public java.lang.Object lookup(java.lang.String parameter1) ;
	public java.lang.Object lookupLink(java.lang.String parameter1) ;
	public java.lang.Object removeFromEnvironment(java.lang.String parameter1) ;
	public java.lang.Void bind(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void rebind(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Object lookup(javax.naming.Name parameter1) ;
	public java.lang.Object lookupLink(javax.naming.Name parameter1) ;
	public java.lang.Void bind(javax.naming.Name parameter1, java.lang.Object parameter2) ;
	public java.lang.Void rebind(javax.naming.Name parameter1, java.lang.Object parameter2) ;
	public java.lang.Void rename(java.lang.String parameter1, java.lang.String parameter2) ;
	public javax.naming.Context createSubcontext(java.lang.String parameter1) ;
	public javax.naming.Context getURLOrDefaultInitCtx(java.lang.String parameter1) ;
	public javax.naming.Context createSubcontext(javax.naming.Name parameter1) ;
	public javax.naming.Context getURLOrDefaultInitCtx(javax.naming.Name parameter1) ;
	public java.lang.Void rename(javax.naming.Name parameter1, javax.naming.Name parameter2) ;
	public javax.naming.NameParser getNameParser(java.lang.String parameter1) ;
	public javax.naming.NameParser getNameParser(javax.naming.Name parameter1) ;
	public javax.naming.NamingEnumeration list(java.lang.String parameter1) ;
	public javax.naming.NamingEnumeration listBindings(java.lang.String parameter1) ;
	public javax.naming.NamingEnumeration list(javax.naming.Name parameter1) ;
	public javax.naming.NamingEnumeration listBindings(javax.naming.Name parameter1) ;
	public java.lang.Object addToEnvironment(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.String composeName(java.lang.String parameter1, java.lang.String parameter2) ;
	public javax.naming.Name composeName(javax.naming.Name parameter1, javax.naming.Name parameter2) ;
}

package javax.naming;

abstract class CompositeName implements javax.naming.Name
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public CompositeName() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Object clone() ;
	public java.lang.Object remove(java.lang.Integer parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String get(java.lang.Integer parameter1) ;
	public CompositeName(java.lang.String parameter1) ;
	public java.util.Enumeration getAll() ;
	public CompositeName(java.util.Enumeration parameter1) ;
	public javax.naming.Name getPrefix(java.lang.Integer parameter1) ;
	public javax.naming.Name getSuffix(java.lang.Integer parameter1) ;
	public java.lang.Boolean endsWith(javax.naming.Name parameter1) ;
	public java.lang.Boolean startsWith(javax.naming.Name parameter1) ;
	public javax.naming.Name add(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public javax.naming.Name add(java.lang.String parameter1) ;
	public javax.naming.Name addAll(java.lang.Integer parameter1, javax.naming.Name parameter2) ;
	public javax.naming.Name addAll(javax.naming.Name parameter1) ;
}

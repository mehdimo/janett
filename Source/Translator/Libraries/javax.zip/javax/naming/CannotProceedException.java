package javax.naming;

abstract class CannotProceedException extends javax.naming.NamingException
{
	public CannotProceedException() ;
	public CannotProceedException(java.lang.String parameter1) ;
	public java.util.Hashtable getEnvironment() ;
	public java.lang.Void setEnvironment(java.util.Hashtable parameter1) ;
	public javax.naming.Context getAltNameCtx() ;
	public java.lang.Void setAltNameCtx(javax.naming.Context parameter1) ;
	public javax.naming.Name getAltName() ;
	public javax.naming.Name getRemainingNewName() ;
	public java.lang.Void setAltName(javax.naming.Name parameter1) ;
	public java.lang.Void setRemainingNewName(javax.naming.Name parameter1) ;
}

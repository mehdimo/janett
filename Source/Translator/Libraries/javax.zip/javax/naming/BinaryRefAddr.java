package javax.naming;

abstract class BinaryRefAddr extends javax.naming.RefAddr
{
	public java.lang.Integer hashCode() ;
	public java.lang.Object getContent() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

package javax.naming;

abstract class BinaryRefAddr extends javax.naming.RefAddr
{
	public java.lang.Integer hashCode() ;
	public java.lang.Object getContent() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public BinaryRefAddr(java.lang.String parameter1, java.lang.Byte[] parameter2) ;
	public BinaryRefAddr(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

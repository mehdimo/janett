package javax.naming;

abstract class RefAddr implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public abstract java.lang.Object getContent() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getType() ;
	public java.lang.String toString() ;
	public RefAddr(java.lang.String parameter1) ;
}

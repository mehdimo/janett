package javax.naming.directory;

abstract class NoSuchAttributeException extends javax.naming.NamingException
{
	public NoSuchAttributeException() ;
	public NoSuchAttributeException(java.lang.String parameter1) ;
}

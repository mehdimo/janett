package javax.naming.directory;

abstract class NoSuchAttributeException extends javax.naming.NamingException
{
}

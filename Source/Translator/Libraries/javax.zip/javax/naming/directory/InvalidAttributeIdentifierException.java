package javax.naming.directory;

abstract class InvalidAttributeIdentifierException extends javax.naming.NamingException
{
}

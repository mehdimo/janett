package javax.naming.directory;

abstract class InvalidAttributeIdentifierException extends javax.naming.NamingException
{
	public InvalidAttributeIdentifierException() ;
	public InvalidAttributeIdentifierException(java.lang.String parameter1) ;
}

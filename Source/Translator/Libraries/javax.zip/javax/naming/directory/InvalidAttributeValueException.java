package javax.naming.directory;

abstract class InvalidAttributeValueException extends javax.naming.NamingException
{
	public InvalidAttributeValueException() ;
	public InvalidAttributeValueException(java.lang.String parameter1) ;
}

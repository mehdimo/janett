package javax.naming.directory;

abstract class InvalidAttributeValueException extends javax.naming.NamingException
{
}

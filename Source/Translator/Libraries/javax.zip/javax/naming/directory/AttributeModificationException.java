package javax.naming.directory;

abstract class AttributeModificationException extends javax.naming.NamingException
{
	public AttributeModificationException() ;
	public java.lang.String toString() ;
	public AttributeModificationException(java.lang.String parameter1) ;
	public javax.naming.directory.ModificationItem[] getUnexecutedModifications() ;
	public java.lang.Void setUnexecutedModifications(javax.naming.directory.ModificationItem[] parameter1) ;
}

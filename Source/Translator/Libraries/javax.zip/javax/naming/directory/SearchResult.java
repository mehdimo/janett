package javax.naming.directory;

abstract class SearchResult extends javax.naming.Binding
{
	public java.lang.String toString() ;
	public javax.naming.directory.Attributes getAttributes() ;
	public java.lang.Void setAttributes(javax.naming.directory.Attributes parameter1) ;
}

package javax.naming.directory;

abstract class SearchResult extends javax.naming.Binding
{
	public java.lang.String toString() ;
	public javax.naming.directory.Attributes getAttributes() ;
	public java.lang.Void setAttributes(javax.naming.directory.Attributes parameter1) ;
	public SearchResult(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public SearchResult(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3, java.lang.Boolean parameter4) ;
	public SearchResult(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object parameter3, javax.naming.directory.Attributes parameter4) ;
	public SearchResult(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object parameter3, javax.naming.directory.Attributes parameter4, java.lang.Boolean parameter5) ;
}

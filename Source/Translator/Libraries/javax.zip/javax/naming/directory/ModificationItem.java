package javax.naming.directory;

abstract class ModificationItem implements java.io.Serializable
{
	public java.lang.Integer getModificationOp() ;
	public java.lang.String toString() ;
	public javax.naming.directory.Attribute getAttribute() ;
}

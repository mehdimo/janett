package javax.naming.directory;

abstract class ModificationItem implements java.io.Serializable
{
	public java.lang.Integer getModificationOp() ;
	public java.lang.String toString() ;
	public javax.naming.directory.Attribute getAttribute() ;
	public ModificationItem(java.lang.Integer parameter1, javax.naming.directory.Attribute parameter2) ;
}

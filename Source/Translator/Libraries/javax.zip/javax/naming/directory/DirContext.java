package javax.naming.directory;

interface DirContext implements javax.naming.Context
{
	public abstract javax.naming.directory.Attributes getAttributes(java.lang.String parameter1) ;
	public abstract java.lang.Void modifyAttributes(java.lang.String parameter1, java.lang.Integer parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract javax.naming.directory.Attributes getAttributes(javax.naming.Name parameter1) ;
	public abstract java.lang.Void modifyAttributes(javax.naming.Name parameter1, java.lang.Integer parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract javax.naming.directory.DirContext getSchema(java.lang.String parameter1) ;
	public abstract javax.naming.directory.DirContext getSchemaClassDefinition(java.lang.String parameter1) ;
	public abstract javax.naming.directory.DirContext getSchema(javax.naming.Name parameter1) ;
	public abstract javax.naming.directory.DirContext getSchemaClassDefinition(javax.naming.Name parameter1) ;
	public abstract java.lang.Void modifyAttributes(java.lang.String parameter1, javax.naming.directory.ModificationItem[] parameter2) ;
	public abstract java.lang.Void modifyAttributes(javax.naming.Name parameter1, javax.naming.directory.ModificationItem[] parameter2) ;
	public abstract javax.naming.NamingEnumeration search(java.lang.String parameter1, javax.naming.directory.Attributes parameter2) ;
	public abstract javax.naming.NamingEnumeration search(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2) ;
	public abstract java.lang.Void bind(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract java.lang.Void rebind(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract java.lang.Void bind(javax.naming.Name parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract java.lang.Void rebind(javax.naming.Name parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public abstract javax.naming.directory.Attributes getAttributes(java.lang.String parameter1, java.lang.String[] parameter2) ;
	public abstract javax.naming.directory.Attributes getAttributes(javax.naming.Name parameter1, java.lang.String[] parameter2) ;
	public abstract javax.naming.directory.DirContext createSubcontext(java.lang.String parameter1, javax.naming.directory.Attributes parameter2) ;
	public abstract javax.naming.directory.DirContext createSubcontext(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2) ;
	public abstract javax.naming.NamingEnumeration search(java.lang.String parameter1, javax.naming.directory.Attributes parameter2, java.lang.String[] parameter3) ;
	public abstract javax.naming.NamingEnumeration search(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2, java.lang.String[] parameter3) ;
	public abstract javax.naming.NamingEnumeration search(java.lang.String parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3) ;
	public abstract javax.naming.NamingEnumeration search(javax.naming.Name parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3) ;
	public abstract javax.naming.NamingEnumeration search(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4) ;
	public abstract javax.naming.NamingEnumeration search(javax.naming.Name parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4) ;
	java.lang.Integer ADD_ATTRIBUTE;
	java.lang.Integer REPLACE_ATTRIBUTE;
	java.lang.Integer REMOVE_ATTRIBUTE;
}

package javax.naming.directory;

interface Attribute implements java.lang.Cloneable, java.io.Serializable
{
	public abstract java.lang.Integer size() ;
	public abstract java.lang.Void clear() ;
	public abstract java.lang.Boolean isOrdered() ;
	public abstract java.lang.Object clone() ;
	public abstract java.lang.Object get() ;
	public abstract java.lang.Object get(java.lang.Integer parameter1) ;
	public abstract java.lang.Object remove(java.lang.Integer parameter1) ;
	public abstract java.lang.Void add(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Boolean add(java.lang.Object parameter1) ;
	public abstract java.lang.Boolean contains(java.lang.Object parameter1) ;
	public abstract java.lang.Boolean remove(java.lang.Object parameter1) ;
	public abstract java.lang.String getID() ;
	public abstract javax.naming.NamingEnumeration getAll() ;
	public abstract javax.naming.directory.DirContext getAttributeDefinition() ;
	public abstract javax.naming.directory.DirContext getAttributeSyntaxDefinition() ;
	public abstract java.lang.Object set(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	java.lang.Long serialVersionUID;
}

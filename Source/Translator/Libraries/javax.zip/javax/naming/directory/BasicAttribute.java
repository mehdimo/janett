package javax.naming.directory;

abstract class BasicAttribute implements javax.naming.directory.Attribute
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.Boolean isOrdered() ;
	public java.lang.Object clone() ;
	public java.lang.Object get() ;
	public java.lang.Object get(java.lang.Integer parameter1) ;
	public java.lang.Object remove(java.lang.Integer parameter1) ;
	public java.lang.Void add(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public java.lang.Boolean add(java.lang.Object parameter1) ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.Boolean remove(java.lang.Object parameter1) ;
	public java.lang.String getID() ;
	public java.lang.String toString() ;
	public javax.naming.NamingEnumeration getAll() ;
	public javax.naming.directory.DirContext getAttributeDefinition() ;
	public javax.naming.directory.DirContext getAttributeSyntaxDefinition() ;
	public java.lang.Object set(java.lang.Integer parameter1, java.lang.Object parameter2) ;
}

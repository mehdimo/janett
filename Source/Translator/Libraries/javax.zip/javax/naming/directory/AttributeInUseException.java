package javax.naming.directory;

abstract class AttributeInUseException extends javax.naming.NamingException
{
	public AttributeInUseException() ;
	public AttributeInUseException(java.lang.String parameter1) ;
}

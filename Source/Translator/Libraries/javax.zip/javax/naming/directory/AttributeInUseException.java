package javax.naming.directory;

abstract class AttributeInUseException extends javax.naming.NamingException
{
}

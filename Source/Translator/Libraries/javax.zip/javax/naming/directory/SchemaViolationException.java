package javax.naming.directory;

abstract class SchemaViolationException extends javax.naming.NamingException
{
	public SchemaViolationException() ;
	public SchemaViolationException(java.lang.String parameter1) ;
}

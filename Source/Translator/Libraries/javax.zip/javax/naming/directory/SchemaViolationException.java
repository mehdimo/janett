package javax.naming.directory;

abstract class SchemaViolationException extends javax.naming.NamingException
{
}

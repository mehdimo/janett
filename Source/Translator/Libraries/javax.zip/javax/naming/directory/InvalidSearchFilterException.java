package javax.naming.directory;

abstract class InvalidSearchFilterException extends javax.naming.NamingException
{
}

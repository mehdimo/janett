package javax.naming.directory;

abstract class InvalidSearchFilterException extends javax.naming.NamingException
{
	public InvalidSearchFilterException() ;
	public InvalidSearchFilterException(java.lang.String parameter1) ;
}

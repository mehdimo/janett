package javax.naming.directory;

abstract class InvalidSearchControlsException extends javax.naming.NamingException
{
	public InvalidSearchControlsException() ;
	public InvalidSearchControlsException(java.lang.String parameter1) ;
}

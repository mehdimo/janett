package javax.naming.directory;

abstract class InvalidSearchControlsException extends javax.naming.NamingException
{
}

package javax.naming.directory;

abstract class SearchControls implements java.io.Serializable
{
	public java.lang.Integer getSearchScope() ;
	public java.lang.Integer getTimeLimit() ;
	public java.lang.Long getCountLimit() ;
	public java.lang.Boolean getDerefLinkFlag() ;
	public java.lang.Boolean getReturningObjFlag() ;
	public java.lang.Void setSearchScope(java.lang.Integer parameter1) ;
	public java.lang.Void setTimeLimit(java.lang.Integer parameter1) ;
	public java.lang.Void setCountLimit(java.lang.Long parameter1) ;
	public java.lang.Void setDerefLinkFlag(java.lang.Boolean parameter1) ;
	public java.lang.Void setReturningObjFlag(java.lang.Boolean parameter1) ;
	public java.lang.String[] getReturningAttributes() ;
	public java.lang.Void setReturningAttributes(java.lang.String[] parameter1) ;
	java.lang.Integer OBJECT_SCOPE;
	java.lang.Integer ONELEVEL_SCOPE;
	java.lang.Integer SUBTREE_SCOPE;
}

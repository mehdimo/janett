package javax.naming.directory;

abstract class InvalidAttributesException extends javax.naming.NamingException
{
	public InvalidAttributesException() ;
	public InvalidAttributesException(java.lang.String parameter1) ;
}

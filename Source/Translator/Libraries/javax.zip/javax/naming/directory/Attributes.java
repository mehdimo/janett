package javax.naming.directory;

interface Attributes implements java.lang.Cloneable, java.io.Serializable
{
	public abstract java.lang.Integer size() ;
	public abstract java.lang.Boolean isCaseIgnored() ;
	public abstract java.lang.Object clone() ;
	public abstract javax.naming.NamingEnumeration getAll() ;
	public abstract javax.naming.NamingEnumeration getIDs() ;
	public abstract javax.naming.directory.Attribute get(java.lang.String parameter1) ;
	public abstract javax.naming.directory.Attribute remove(java.lang.String parameter1) ;
	public abstract javax.naming.directory.Attribute put(javax.naming.directory.Attribute parameter1) ;
	public abstract javax.naming.directory.Attribute put(java.lang.String parameter1, java.lang.Object parameter2) ;
}

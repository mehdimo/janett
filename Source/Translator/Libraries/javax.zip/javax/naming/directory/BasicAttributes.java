package javax.naming.directory;

abstract class BasicAttributes implements javax.naming.directory.Attributes
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public BasicAttributes() ;
	public java.lang.Boolean isCaseIgnored() ;
	public BasicAttributes(java.lang.Boolean parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public javax.naming.NamingEnumeration getAll() ;
	public javax.naming.NamingEnumeration getIDs() ;
	public BasicAttributes(java.lang.String parameter1, java.lang.Object parameter2) ;
	public BasicAttributes(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Boolean parameter3) ;
	public javax.naming.directory.Attribute get(java.lang.String parameter1) ;
	public javax.naming.directory.Attribute remove(java.lang.String parameter1) ;
	public javax.naming.directory.Attribute put(javax.naming.directory.Attribute parameter1) ;
	public javax.naming.directory.Attribute put(java.lang.String parameter1, java.lang.Object parameter2) ;
}

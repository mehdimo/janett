package javax.naming.directory;

abstract class InitialDirContext extends javax.naming.InitialContext implements javax.naming.directory.DirContext
{
	public InitialDirContext() ;
	public InitialDirContext(java.lang.Boolean parameter1) ;
	public InitialDirContext(java.util.Hashtable parameter1) ;
	public javax.naming.directory.Attributes getAttributes(java.lang.String parameter1) ;
	public java.lang.Void modifyAttributes(java.lang.String parameter1, java.lang.Integer parameter2, javax.naming.directory.Attributes parameter3) ;
	public javax.naming.directory.Attributes getAttributes(javax.naming.Name parameter1) ;
	public java.lang.Void modifyAttributes(javax.naming.Name parameter1, java.lang.Integer parameter2, javax.naming.directory.Attributes parameter3) ;
	public javax.naming.directory.DirContext getSchema(java.lang.String parameter1) ;
	public javax.naming.directory.DirContext getSchemaClassDefinition(java.lang.String parameter1) ;
	public javax.naming.directory.DirContext getSchema(javax.naming.Name parameter1) ;
	public javax.naming.directory.DirContext getSchemaClassDefinition(javax.naming.Name parameter1) ;
	public java.lang.Void modifyAttributes(java.lang.String parameter1, javax.naming.directory.ModificationItem[] parameter2) ;
	public java.lang.Void modifyAttributes(javax.naming.Name parameter1, javax.naming.directory.ModificationItem[] parameter2) ;
	public javax.naming.NamingEnumeration search(java.lang.String parameter1, javax.naming.directory.Attributes parameter2) ;
	public javax.naming.NamingEnumeration search(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2) ;
	public java.lang.Void bind(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public java.lang.Void rebind(java.lang.String parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public java.lang.Void bind(javax.naming.Name parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public java.lang.Void rebind(javax.naming.Name parameter1, java.lang.Object parameter2, javax.naming.directory.Attributes parameter3) ;
	public javax.naming.directory.Attributes getAttributes(java.lang.String parameter1, java.lang.String[] parameter2) ;
	public javax.naming.directory.Attributes getAttributes(javax.naming.Name parameter1, java.lang.String[] parameter2) ;
	public javax.naming.directory.DirContext createSubcontext(java.lang.String parameter1, javax.naming.directory.Attributes parameter2) ;
	public javax.naming.directory.DirContext createSubcontext(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2) ;
	public javax.naming.NamingEnumeration search(java.lang.String parameter1, javax.naming.directory.Attributes parameter2, java.lang.String[] parameter3) ;
	public javax.naming.NamingEnumeration search(javax.naming.Name parameter1, javax.naming.directory.Attributes parameter2, java.lang.String[] parameter3) ;
	public javax.naming.NamingEnumeration search(java.lang.String parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3) ;
	public javax.naming.NamingEnumeration search(javax.naming.Name parameter1, java.lang.String parameter2, javax.naming.directory.SearchControls parameter3) ;
	public javax.naming.NamingEnumeration search(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4) ;
	public javax.naming.NamingEnumeration search(javax.naming.Name parameter1, java.lang.String parameter2, java.lang.Object[] parameter3, javax.naming.directory.SearchControls parameter4) ;
}

package javax.naming;

abstract class LinkException extends javax.naming.NamingException
{
	public java.lang.Object getLinkResolvedObj() ;
	public java.lang.Void setLinkResolvedObj(java.lang.Object parameter1) ;
	public java.lang.String getLinkExplanation() ;
	public java.lang.String toString() ;
	public java.lang.Void setLinkExplanation(java.lang.String parameter1) ;
	public java.lang.String toString(java.lang.Boolean parameter1) ;
	public javax.naming.Name getLinkRemainingName() ;
	public javax.naming.Name getLinkResolvedName() ;
	public java.lang.Void setLinkRemainingName(javax.naming.Name parameter1) ;
	public java.lang.Void setLinkResolvedName(javax.naming.Name parameter1) ;
}

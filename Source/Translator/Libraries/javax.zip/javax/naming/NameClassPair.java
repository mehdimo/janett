package javax.naming;

abstract class NameClassPair implements java.io.Serializable
{
	public java.lang.Boolean isRelative() ;
	public java.lang.Void setRelative(java.lang.Boolean parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Void setClassName(java.lang.String parameter1) ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public NameClassPair(java.lang.String parameter1, java.lang.String parameter2) ;
	public NameClassPair(java.lang.String parameter1, java.lang.String parameter2, java.lang.Boolean parameter3) ;
}

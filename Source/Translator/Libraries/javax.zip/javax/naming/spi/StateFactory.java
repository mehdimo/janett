package javax.naming.spi;

interface StateFactory
{
	public abstract java.lang.Object getStateToBind(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4) ;
}

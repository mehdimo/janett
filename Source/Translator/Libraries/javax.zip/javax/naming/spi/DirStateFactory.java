package javax.naming.spi;

interface DirStateFactory implements javax.naming.spi.StateFactory
{
	public abstract javax.naming.spi.DirStateFactory.Result getStateToBind(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4, javax.naming.directory.Attributes parameter5) ;
	abstract class Result
	{
		public java.lang.Object getObject() ;
		public javax.naming.directory.Attributes getAttributes() ;
	}
}

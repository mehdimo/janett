package javax.naming.spi;

interface ObjectFactoryBuilder
{
	public abstract javax.naming.spi.ObjectFactory createObjectFactory(java.lang.Object parameter1, java.util.Hashtable parameter2) ;
}

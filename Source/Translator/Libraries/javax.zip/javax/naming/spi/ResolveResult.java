package javax.naming.spi;

abstract class ResolveResult implements java.io.Serializable
{
	public java.lang.Object getResolvedObj() ;
	public java.lang.Void setResolvedObj(java.lang.Object parameter1) ;
	public java.lang.Void appendRemainingComponent(java.lang.String parameter1) ;
	public javax.naming.Name getRemainingName() ;
	public java.lang.Void appendRemainingName(javax.naming.Name parameter1) ;
	public java.lang.Void setRemainingName(javax.naming.Name parameter1) ;
}

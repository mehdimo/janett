package javax.naming.spi;

interface InitialContextFactory
{
	public abstract javax.naming.Context getInitialContext(java.util.Hashtable parameter1) ;
}

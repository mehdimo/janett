package javax.naming.spi;

abstract class DirectoryManager extends javax.naming.spi.NamingManager
{
	public javax.naming.directory.DirContext getContinuationDirContext(javax.naming.CannotProceedException parameter1) ;
	public java.lang.Object getObjectInstance(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4, javax.naming.directory.Attributes parameter5) ;
	public javax.naming.spi.DirStateFactory.Result getStateToBind(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4, javax.naming.directory.Attributes parameter5) ;
}

package javax.naming.spi;

interface Resolver
{
	public abstract javax.naming.spi.ResolveResult resolveToClass(java.lang.String parameter1, java.lang.Class parameter2) ;
	public abstract javax.naming.spi.ResolveResult resolveToClass(javax.naming.Name parameter1, java.lang.Class parameter2) ;
}

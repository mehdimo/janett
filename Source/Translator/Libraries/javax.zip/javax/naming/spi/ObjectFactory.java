package javax.naming.spi;

interface ObjectFactory
{
	public abstract java.lang.Object getObjectInstance(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4) ;
}

package javax.naming.spi;

interface InitialContextFactoryBuilder
{
	public abstract javax.naming.spi.InitialContextFactory createInitialContextFactory(java.util.Hashtable parameter1) ;
}

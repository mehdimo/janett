package javax.naming.spi;

abstract class NamingManager
{
	public java.lang.Boolean hasInitialContextFactoryBuilder() ;
	public java.lang.Void setInitialContextFactoryBuilder(javax.naming.spi.InitialContextFactoryBuilder parameter1) ;
	public java.lang.Void setObjectFactoryBuilder(javax.naming.spi.ObjectFactoryBuilder parameter1) ;
	public javax.naming.Context getInitialContext(java.util.Hashtable parameter1) ;
	public javax.naming.Context getContinuationContext(javax.naming.CannotProceedException parameter1) ;
	public javax.naming.Context getURLContext(java.lang.String parameter1, java.util.Hashtable parameter2) ;
	public java.lang.Object getObjectInstance(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4) ;
	public java.lang.Object getStateToBind(java.lang.Object parameter1, javax.naming.Name parameter2, javax.naming.Context parameter3, java.util.Hashtable parameter4) ;
	java.lang.String CPE;
}

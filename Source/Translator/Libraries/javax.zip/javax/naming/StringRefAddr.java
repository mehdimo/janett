package javax.naming;

abstract class StringRefAddr extends javax.naming.RefAddr
{
	public java.lang.Object getContent() ;
}

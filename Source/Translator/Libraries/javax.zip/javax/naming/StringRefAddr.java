package javax.naming;

abstract class StringRefAddr extends javax.naming.RefAddr
{
	public java.lang.Object getContent() ;
	public StringRefAddr(java.lang.String parameter1, java.lang.String parameter2) ;
}

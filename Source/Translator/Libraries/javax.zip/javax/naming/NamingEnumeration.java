package javax.naming;

interface NamingEnumeration implements java.util.Enumeration
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.Boolean hasMore() ;
	public abstract java.lang.Object next() ;
}

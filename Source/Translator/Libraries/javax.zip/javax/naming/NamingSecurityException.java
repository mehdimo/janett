package javax.naming;

abstract class NamingSecurityException extends javax.naming.NamingException
{
	public NamingSecurityException() ;
	public NamingSecurityException(java.lang.String parameter1) ;
}

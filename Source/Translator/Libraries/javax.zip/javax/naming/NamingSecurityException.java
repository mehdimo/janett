package javax.naming;

abstract class NamingSecurityException extends javax.naming.NamingException
{
}

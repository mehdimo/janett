package javax.naming;

interface Context
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.String getNameInNamespace() ;
	public abstract java.lang.Void destroySubcontext(java.lang.String parameter1) ;
	public abstract java.lang.Void unbind(java.lang.String parameter1) ;
	public abstract java.util.Hashtable getEnvironment() ;
	public abstract java.lang.Void destroySubcontext(javax.naming.Name parameter1) ;
	public abstract java.lang.Void unbind(javax.naming.Name parameter1) ;
	public abstract java.lang.Object lookup(java.lang.String parameter1) ;
	public abstract java.lang.Object lookupLink(java.lang.String parameter1) ;
	public abstract java.lang.Object removeFromEnvironment(java.lang.String parameter1) ;
	public abstract java.lang.Void bind(java.lang.String parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Void rebind(java.lang.String parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Object lookup(javax.naming.Name parameter1) ;
	public abstract java.lang.Object lookupLink(javax.naming.Name parameter1) ;
	public abstract java.lang.Void bind(javax.naming.Name parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Void rebind(javax.naming.Name parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Void rename(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract javax.naming.Context createSubcontext(java.lang.String parameter1) ;
	public abstract javax.naming.Context createSubcontext(javax.naming.Name parameter1) ;
	public abstract java.lang.Void rename(javax.naming.Name parameter1, javax.naming.Name parameter2) ;
	public abstract javax.naming.NameParser getNameParser(java.lang.String parameter1) ;
	public abstract javax.naming.NameParser getNameParser(javax.naming.Name parameter1) ;
	public abstract javax.naming.NamingEnumeration list(java.lang.String parameter1) ;
	public abstract javax.naming.NamingEnumeration listBindings(java.lang.String parameter1) ;
	public abstract javax.naming.NamingEnumeration list(javax.naming.Name parameter1) ;
	public abstract javax.naming.NamingEnumeration listBindings(javax.naming.Name parameter1) ;
	public abstract java.lang.Object addToEnvironment(java.lang.String parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.String composeName(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract javax.naming.Name composeName(javax.naming.Name parameter1, javax.naming.Name parameter2) ;
	java.lang.String INITIAL_CONTEXT_FACTORY;
	java.lang.String OBJECT_FACTORIES;
	java.lang.String STATE_FACTORIES;
	java.lang.String URL_PKG_PREFIXES;
	java.lang.String PROVIDER_URL;
	java.lang.String DNS_URL;
	java.lang.String AUTHORITATIVE;
	java.lang.String BATCHSIZE;
	java.lang.String REFERRAL;
	java.lang.String SECURITY_PROTOCOL;
	java.lang.String SECURITY_AUTHENTICATION;
	java.lang.String SECURITY_PRINCIPAL;
	java.lang.String SECURITY_CREDENTIALS;
	java.lang.String LANGUAGE;
	java.lang.String APPLET;
}

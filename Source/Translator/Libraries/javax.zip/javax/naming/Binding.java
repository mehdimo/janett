package javax.naming;

abstract class Binding extends javax.naming.NameClassPair
{
	public java.lang.Object getObject() ;
	public java.lang.Void setObject(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String toString() ;
	public Binding(java.lang.String parameter1, java.lang.Object parameter2) ;
	public Binding(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Boolean parameter3) ;
	public Binding(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object parameter3) ;
	public Binding(java.lang.String parameter1, java.lang.String parameter2, java.lang.Object parameter3, java.lang.Boolean parameter4) ;
}

package javax.naming;

abstract class Binding extends javax.naming.NameClassPair
{
	public java.lang.Object getObject() ;
	public java.lang.Void setObject(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String toString() ;
}

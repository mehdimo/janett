package javax.naming;

abstract class NameAlreadyBoundException extends javax.naming.NamingException
{
	public NameAlreadyBoundException() ;
	public NameAlreadyBoundException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class NameAlreadyBoundException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class NoPermissionException extends javax.naming.NamingSecurityException
{
}

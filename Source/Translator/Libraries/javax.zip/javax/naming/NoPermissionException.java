package javax.naming;

abstract class NoPermissionException extends javax.naming.NamingSecurityException
{
	public NoPermissionException() ;
	public NoPermissionException(java.lang.String parameter1) ;
}

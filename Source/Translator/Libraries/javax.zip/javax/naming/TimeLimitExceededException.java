package javax.naming;

abstract class TimeLimitExceededException extends javax.naming.LimitExceededException
{
	public TimeLimitExceededException() ;
	public TimeLimitExceededException(java.lang.String parameter1) ;
}

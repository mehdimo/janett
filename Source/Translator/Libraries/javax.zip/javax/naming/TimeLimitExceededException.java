package javax.naming;

abstract class TimeLimitExceededException extends javax.naming.LimitExceededException
{
}

package javax.naming;

abstract class CommunicationException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class CommunicationException extends javax.naming.NamingException
{
	public CommunicationException() ;
	public CommunicationException(java.lang.String parameter1) ;
}

package javax.naming;

abstract class LinkRef extends javax.naming.Reference
{
	public java.lang.String getLinkName() ;
}

package javax.naming;

abstract class LinkRef extends javax.naming.Reference
{
	public java.lang.String getLinkName() ;
	public LinkRef(java.lang.String parameter1) ;
	public LinkRef(javax.naming.Name parameter1) ;
}

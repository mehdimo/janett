package javax.naming;

abstract class InsufficientResourcesException extends javax.naming.NamingException
{
	public InsufficientResourcesException() ;
	public InsufficientResourcesException(java.lang.String parameter1) ;
}

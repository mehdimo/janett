package javax.naming;

abstract class InsufficientResourcesException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class NamingException extends java.lang.Exception
{
	public NamingException() ;
	public java.lang.Object getResolvedObj() ;
	public java.lang.Void setResolvedObj(java.lang.Object parameter1) ;
	public java.lang.String getExplanation() ;
	public java.lang.String toString() ;
	public NamingException(java.lang.String parameter1) ;
	public java.lang.Void appendRemainingComponent(java.lang.String parameter1) ;
	public java.lang.String toString(java.lang.Boolean parameter1) ;
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getRootCause() ;
	public java.lang.Void setRootCause(java.lang.Throwable parameter1) ;
	public javax.naming.Name getRemainingName() ;
	public javax.naming.Name getResolvedName() ;
	public java.lang.Void appendRemainingName(javax.naming.Name parameter1) ;
	public java.lang.Void setRemainingName(javax.naming.Name parameter1) ;
	public java.lang.Void setResolvedName(javax.naming.Name parameter1) ;
	public java.lang.Throwable initCause(java.lang.Throwable parameter1) ;
}

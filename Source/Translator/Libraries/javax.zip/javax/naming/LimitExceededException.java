package javax.naming;

abstract class LimitExceededException extends javax.naming.NamingException
{
}

package javax.naming;

abstract class LimitExceededException extends javax.naming.NamingException
{
	public LimitExceededException() ;
	public LimitExceededException(java.lang.String parameter1) ;
}

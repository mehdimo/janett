package javax.naming;

abstract class InterruptedNamingException extends javax.naming.NamingException
{
	public InterruptedNamingException() ;
	public InterruptedNamingException(java.lang.String parameter1) ;
}

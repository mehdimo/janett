package javax.naming;

abstract class InterruptedNamingException extends javax.naming.NamingException
{
}

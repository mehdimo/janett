package javax.naming;

abstract class ServiceUnavailableException extends javax.naming.NamingException
{
	public ServiceUnavailableException() ;
	public ServiceUnavailableException(java.lang.String parameter1) ;
}

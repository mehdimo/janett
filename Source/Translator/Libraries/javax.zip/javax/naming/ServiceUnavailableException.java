package javax.naming;

abstract class ServiceUnavailableException extends javax.naming.NamingException
{
}

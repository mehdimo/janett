package javax.naming;

abstract class Reference implements java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.Object clone() ;
	public java.lang.Object remove(java.lang.Integer parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String getFactoryClassLocation() ;
	public java.lang.String getFactoryClassName() ;
	public java.lang.String toString() ;
	public java.util.Enumeration getAll() ;
	public javax.naming.RefAddr get(java.lang.Integer parameter1) ;
	public java.lang.Void add(java.lang.Integer parameter1, javax.naming.RefAddr parameter2) ;
	public java.lang.Void add(javax.naming.RefAddr parameter1) ;
	public javax.naming.RefAddr get(java.lang.String parameter1) ;
}

package javax.naming;

abstract class OperationNotSupportedException extends javax.naming.NamingException
{
	public OperationNotSupportedException() ;
	public OperationNotSupportedException(java.lang.String parameter1) ;
}

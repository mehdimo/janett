package javax.naming;

abstract class OperationNotSupportedException extends javax.naming.NamingException
{
}

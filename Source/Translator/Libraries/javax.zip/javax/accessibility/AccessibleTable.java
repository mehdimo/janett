package javax.accessibility;

interface AccessibleTable
{
	public abstract java.lang.Integer getAccessibleColumnCount() ;
	public abstract java.lang.Integer getAccessibleRowCount() ;
	public abstract java.lang.Integer[] getSelectedAccessibleColumns() ;
	public abstract java.lang.Integer[] getSelectedAccessibleRows() ;
	public abstract java.lang.Boolean isAccessibleColumnSelected(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isAccessibleRowSelected(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getAccessibleColumnExtentAt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer getAccessibleRowExtentAt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Boolean isAccessibleSelected(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract javax.accessibility.Accessible getAccessibleCaption() ;
	public abstract javax.accessibility.Accessible getAccessibleSummary() ;
	public abstract javax.accessibility.Accessible getAccessibleColumnDescription(java.lang.Integer parameter1) ;
	public abstract javax.accessibility.Accessible getAccessibleRowDescription(java.lang.Integer parameter1) ;
	public abstract javax.accessibility.Accessible getAccessibleAt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setAccessibleColumnDescription(java.lang.Integer parameter1, javax.accessibility.Accessible parameter2) ;
	public abstract java.lang.Void setAccessibleRowDescription(java.lang.Integer parameter1, javax.accessibility.Accessible parameter2) ;
	public abstract java.lang.Void setAccessibleCaption(javax.accessibility.Accessible parameter1) ;
	public abstract java.lang.Void setAccessibleSummary(javax.accessibility.Accessible parameter1) ;
	public abstract javax.accessibility.AccessibleTable getAccessibleColumnHeader() ;
	public abstract javax.accessibility.AccessibleTable getAccessibleRowHeader() ;
	public abstract java.lang.Void setAccessibleColumnHeader(javax.accessibility.AccessibleTable parameter1) ;
	public abstract java.lang.Void setAccessibleRowHeader(javax.accessibility.AccessibleTable parameter1) ;
}

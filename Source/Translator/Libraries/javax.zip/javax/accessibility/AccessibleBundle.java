package javax.accessibility;

abstract class AccessibleBundle
{
	public java.lang.String toDisplayString() ;
	public java.lang.String toString() ;
	public java.lang.String toDisplayString(java.util.Locale parameter1) ;
	public java.lang.String toDisplayString(java.lang.String parameter1, java.util.Locale parameter2) ;
}

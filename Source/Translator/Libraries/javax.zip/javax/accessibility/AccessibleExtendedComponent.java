package javax.accessibility;

interface AccessibleExtendedComponent implements javax.accessibility.AccessibleComponent
{
	public abstract java.lang.String getTitledBorderText() ;
	public abstract java.lang.String getToolTipText() ;
	public abstract javax.accessibility.AccessibleKeyBinding getAccessibleKeyBinding() ;
}

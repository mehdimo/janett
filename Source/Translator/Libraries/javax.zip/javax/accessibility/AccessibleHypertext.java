package javax.accessibility;

interface AccessibleHypertext implements javax.accessibility.AccessibleText
{
	public abstract java.lang.Integer getLinkCount() ;
	public abstract java.lang.Integer getLinkIndex(java.lang.Integer parameter1) ;
	public abstract javax.accessibility.AccessibleHyperlink getLink(java.lang.Integer parameter1) ;
}

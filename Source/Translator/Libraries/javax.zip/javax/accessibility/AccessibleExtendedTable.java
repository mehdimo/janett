package javax.accessibility;

interface AccessibleExtendedTable implements javax.accessibility.AccessibleTable
{
	public abstract java.lang.Integer getAccessibleColumn(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getAccessibleRow(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getAccessibleIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
}

package javax.accessibility;

interface AccessibleAction
{
	public abstract java.lang.Integer getAccessibleActionCount() ;
	public abstract java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
}

package javax.accessibility;

abstract class AccessibleRelation extends javax.accessibility.AccessibleBundle
{
	public java.lang.Object[] getTarget() ;
	public java.lang.Void setTarget(java.lang.Object parameter1) ;
	public java.lang.Void setTarget(java.lang.Object[] parameter1) ;
	public java.lang.String getKey() ;
	java.lang.String LABEL_FOR;
	java.lang.String LABELED_BY;
	java.lang.String MEMBER_OF;
	java.lang.String CONTROLLER_FOR;
	java.lang.String CONTROLLED_BY;
	java.lang.String LABEL_FOR_PROPERTY;
	java.lang.String LABELED_BY_PROPERTY;
	java.lang.String MEMBER_OF_PROPERTY;
	java.lang.String CONTROLLER_FOR_PROPERTY;
	java.lang.String CONTROLLED_BY_PROPERTY;
}

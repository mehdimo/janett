package javax.accessibility;

interface AccessibleEditableText implements javax.accessibility.AccessibleText
{
	public abstract java.lang.Void paste(java.lang.Integer parameter1) ;
	public abstract java.lang.Void cut(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void delete(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void selectText(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String getTextRange(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void replaceText(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void insertTextAtIndex(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setTextContents(java.lang.String parameter1) ;
	public abstract java.lang.Void setAttributes(java.lang.Integer parameter1, java.lang.Integer parameter2, javax.swing.text.AttributeSet parameter3) ;
}

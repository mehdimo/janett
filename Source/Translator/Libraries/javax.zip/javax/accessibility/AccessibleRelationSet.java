package javax.accessibility;

abstract class AccessibleRelationSet
{
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.String toString() ;
	public java.lang.Boolean contains(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleRelation[] toArray() ;
	public java.lang.Boolean add(javax.accessibility.AccessibleRelation parameter1) ;
	public java.lang.Boolean remove(javax.accessibility.AccessibleRelation parameter1) ;
	public java.lang.Void addAll(javax.accessibility.AccessibleRelation[] parameter1) ;
	public javax.accessibility.AccessibleRelation get(java.lang.String parameter1) ;
}

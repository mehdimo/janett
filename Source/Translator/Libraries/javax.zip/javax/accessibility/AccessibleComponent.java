package javax.accessibility;

interface AccessibleComponent
{
	public abstract java.lang.Void requestFocus() ;
	public abstract java.lang.Boolean isEnabled() ;
	public abstract java.lang.Boolean isFocusTraversable() ;
	public abstract java.lang.Boolean isShowing() ;
	public abstract java.lang.Boolean isVisible() ;
	public abstract java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setVisible(java.lang.Boolean parameter1) ;
	public abstract java.awt.Color getBackground() ;
	public abstract java.awt.Color getForeground() ;
	public abstract java.lang.Void setBackground(java.awt.Color parameter1) ;
	public abstract java.lang.Void setForeground(java.awt.Color parameter1) ;
	public abstract java.awt.Cursor getCursor() ;
	public abstract java.lang.Void setCursor(java.awt.Cursor parameter1) ;
	public abstract java.awt.Dimension getSize() ;
	public abstract java.lang.Void setSize(java.awt.Dimension parameter1) ;
	public abstract java.awt.Font getFont() ;
	public abstract java.lang.Void setFont(java.awt.Font parameter1) ;
	public abstract java.awt.Point getLocation() ;
	public abstract java.awt.Point getLocationOnScreen() ;
	public abstract java.lang.Void setLocation(java.awt.Point parameter1) ;
	public abstract java.lang.Boolean contains(java.awt.Point parameter1) ;
	public abstract java.awt.Rectangle getBounds() ;
	public abstract java.lang.Void setBounds(java.awt.Rectangle parameter1) ;
	public abstract java.lang.Void addFocusListener(java.awt.event.FocusListener parameter1) ;
	public abstract java.lang.Void removeFocusListener(java.awt.event.FocusListener parameter1) ;
	public abstract java.awt.FontMetrics getFontMetrics(java.awt.Font parameter1) ;
	public abstract javax.accessibility.Accessible getAccessibleAt(java.awt.Point parameter1) ;
}

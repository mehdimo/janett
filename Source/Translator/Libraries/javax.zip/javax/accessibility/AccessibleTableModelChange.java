package javax.accessibility;

interface AccessibleTableModelChange
{
	public abstract java.lang.Integer getFirstColumn() ;
	public abstract java.lang.Integer getFirstRow() ;
	public abstract java.lang.Integer getLastColumn() ;
	public abstract java.lang.Integer getLastRow() ;
	public abstract java.lang.Integer getType() ;
	java.lang.Integer INSERT;
	java.lang.Integer UPDATE;
	java.lang.Integer DELETE;
}

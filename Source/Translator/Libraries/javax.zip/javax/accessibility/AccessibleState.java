package javax.accessibility;

abstract class AccessibleState extends javax.accessibility.AccessibleBundle
{
	public AccessibleState(java.lang.String parameter1) ;
	javax.accessibility.AccessibleState ACTIVE;
	javax.accessibility.AccessibleState PRESSED;
	javax.accessibility.AccessibleState ARMED;
	javax.accessibility.AccessibleState BUSY;
	javax.accessibility.AccessibleState CHECKED;
	javax.accessibility.AccessibleState EDITABLE;
	javax.accessibility.AccessibleState EXPANDABLE;
	javax.accessibility.AccessibleState COLLAPSED;
	javax.accessibility.AccessibleState EXPANDED;
	javax.accessibility.AccessibleState ENABLED;
	javax.accessibility.AccessibleState FOCUSABLE;
	javax.accessibility.AccessibleState FOCUSED;
	javax.accessibility.AccessibleState ICONIFIED;
	javax.accessibility.AccessibleState MODAL;
	javax.accessibility.AccessibleState OPAQUE;
	javax.accessibility.AccessibleState RESIZABLE;
	javax.accessibility.AccessibleState MULTISELECTABLE;
	javax.accessibility.AccessibleState SELECTABLE;
	javax.accessibility.AccessibleState SELECTED;
	javax.accessibility.AccessibleState SHOWING;
	javax.accessibility.AccessibleState VISIBLE;
	javax.accessibility.AccessibleState VERTICAL;
	javax.accessibility.AccessibleState HORIZONTAL;
	javax.accessibility.AccessibleState SINGLE_LINE;
	javax.accessibility.AccessibleState MULTI_LINE;
	javax.accessibility.AccessibleState TRANSIENT;
}

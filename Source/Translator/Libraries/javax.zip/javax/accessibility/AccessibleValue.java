package javax.accessibility;

interface AccessibleValue
{
	public abstract java.lang.Number getCurrentAccessibleValue() ;
	public abstract java.lang.Number getMaximumAccessibleValue() ;
	public abstract java.lang.Number getMinimumAccessibleValue() ;
	public abstract java.lang.Boolean setCurrentAccessibleValue(java.lang.Number parameter1) ;
}

package javax.accessibility;

abstract class AccessibleResourceBundle extends java.util.ListResourceBundle
{
	public AccessibleResourceBundle() ;
	public void getContents() ;
}

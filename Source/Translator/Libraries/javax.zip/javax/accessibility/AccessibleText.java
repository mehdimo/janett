package javax.accessibility;

interface AccessibleText
{
	public abstract java.lang.Integer getCaretPosition() ;
	public abstract java.lang.Integer getCharCount() ;
	public abstract java.lang.Integer getSelectionEnd() ;
	public abstract java.lang.Integer getSelectionStart() ;
	public abstract java.lang.Integer getIndexAtPoint(java.awt.Point parameter1) ;
	public abstract java.awt.Rectangle getCharacterBounds(java.lang.Integer parameter1) ;
	public abstract java.lang.String getSelectedText() ;
	public abstract java.lang.String getAfterIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String getAtIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String getBeforeIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract javax.swing.text.AttributeSet getCharacterAttribute(java.lang.Integer parameter1) ;
	java.lang.Integer CHARACTER;
	java.lang.Integer WORD;
	java.lang.Integer SENTENCE;
}

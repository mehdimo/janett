package javax.accessibility;

abstract class AccessibleContext
{
	public abstract java.lang.Integer getAccessibleChildrenCount() ;
	public abstract java.lang.Integer getAccessibleIndexInParent() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.String getAccessibleDescription() ;
	public java.lang.String getAccessibleName() ;
	public java.lang.Void setAccessibleDescription(java.lang.String parameter1) ;
	public java.lang.Void setAccessibleName(java.lang.String parameter1) ;
	public abstract java.util.Locale getLocale() ;
	public javax.accessibility.Accessible getAccessibleParent() ;
	public abstract javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
	public java.lang.Void setAccessibleParent(javax.accessibility.Accessible parameter1) ;
	public javax.accessibility.AccessibleAction getAccessibleAction() ;
	public javax.accessibility.AccessibleComponent getAccessibleComponent() ;
	public javax.accessibility.AccessibleEditableText getAccessibleEditableText() ;
	public javax.accessibility.AccessibleIcon[] getAccessibleIcon() ;
	public javax.accessibility.AccessibleRelationSet getAccessibleRelationSet() ;
	public abstract javax.accessibility.AccessibleRole getAccessibleRole() ;
	public javax.accessibility.AccessibleSelection getAccessibleSelection() ;
	public abstract javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	public javax.accessibility.AccessibleTable getAccessibleTable() ;
	public javax.accessibility.AccessibleText getAccessibleText() ;
	public javax.accessibility.AccessibleValue getAccessibleValue() ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	java.lang.String ACCESSIBLE_NAME_PROPERTY;
	java.lang.String ACCESSIBLE_DESCRIPTION_PROPERTY;
	java.lang.String ACCESSIBLE_STATE_PROPERTY;
	java.lang.String ACCESSIBLE_VALUE_PROPERTY;
	java.lang.String ACCESSIBLE_SELECTION_PROPERTY;
	java.lang.String ACCESSIBLE_TEXT_PROPERTY;
	java.lang.String ACCESSIBLE_CARET_PROPERTY;
	java.lang.String ACCESSIBLE_VISIBLE_DATA_PROPERTY;
	java.lang.String ACCESSIBLE_CHILD_PROPERTY;
	java.lang.String ACCESSIBLE_ACTIVE_DESCENDANT_PROPERTY;
	java.lang.String ACCESSIBLE_TABLE_CAPTION_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_SUMMARY_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_MODEL_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_ROW_HEADER_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_ROW_DESCRIPTION_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_COLUMN_HEADER_CHANGED;
	java.lang.String ACCESSIBLE_TABLE_COLUMN_DESCRIPTION_CHANGED;
	java.lang.String ACCESSIBLE_ACTION_PROPERTY;
	java.lang.String ACCESSIBLE_HYPERTEXT_OFFSET;
}

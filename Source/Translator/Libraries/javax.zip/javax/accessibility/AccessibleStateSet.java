package javax.accessibility;

abstract class AccessibleStateSet
{
	public AccessibleStateSet() ;
	public java.lang.Void clear() ;
	public java.lang.String toString() ;
	public javax.accessibility.AccessibleState[] toArray() ;
	public java.lang.Boolean add(javax.accessibility.AccessibleState parameter1) ;
	public java.lang.Boolean contains(javax.accessibility.AccessibleState parameter1) ;
	public java.lang.Boolean remove(javax.accessibility.AccessibleState parameter1) ;
	public AccessibleStateSet(javax.accessibility.AccessibleState[] parameter1) ;
	public java.lang.Void addAll(javax.accessibility.AccessibleState[] parameter1) ;
}

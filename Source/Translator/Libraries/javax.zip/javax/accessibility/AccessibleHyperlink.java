package javax.accessibility;

abstract class AccessibleHyperlink implements javax.accessibility.AccessibleAction
{
	public abstract java.lang.Integer getAccessibleActionCount() ;
	public abstract java.lang.Integer getEndIndex() ;
	public abstract java.lang.Integer getStartIndex() ;
	public abstract java.lang.Boolean isValid() ;
	public abstract java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
	public abstract java.lang.Object getAccessibleActionAnchor(java.lang.Integer parameter1) ;
	public abstract java.lang.Object getAccessibleActionObject(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
}

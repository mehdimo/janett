package javax.accessibility;

interface AccessibleSelection
{
	public abstract java.lang.Integer getAccessibleSelectionCount() ;
	public abstract java.lang.Void clearAccessibleSelection() ;
	public abstract java.lang.Void selectAllAccessibleSelection() ;
	public abstract java.lang.Void addAccessibleSelection(java.lang.Integer parameter1) ;
	public abstract java.lang.Void removeAccessibleSelection(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isAccessibleChildSelected(java.lang.Integer parameter1) ;
	public abstract javax.accessibility.Accessible getAccessibleSelection(java.lang.Integer parameter1) ;
}

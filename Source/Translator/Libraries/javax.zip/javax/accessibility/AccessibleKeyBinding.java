package javax.accessibility;

interface AccessibleKeyBinding
{
	public abstract java.lang.Integer getAccessibleKeyBindingCount() ;
	public abstract java.lang.Object getAccessibleKeyBinding(java.lang.Integer parameter1) ;
}

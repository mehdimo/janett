package javax.accessibility;

interface AccessibleIcon
{
	public abstract java.lang.Integer getAccessibleIconHeight() ;
	public abstract java.lang.Integer getAccessibleIconWidth() ;
	public abstract java.lang.String getAccessibleIconDescription() ;
	public abstract java.lang.Void setAccessibleIconDescription(java.lang.String parameter1) ;
}

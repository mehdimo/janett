package javax.accessibility;

interface Accessible
{
	public abstract javax.accessibility.AccessibleContext getAccessibleContext() ;
}

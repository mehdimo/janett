package javax.xml.transform;

abstract class TransformerFactory
{
	public abstract java.lang.Boolean getFeature(java.lang.String parameter1) ;
	public abstract javax.xml.transform.ErrorListener getErrorListener() ;
	public abstract java.lang.Void setErrorListener(javax.xml.transform.ErrorListener parameter1) ;
	public abstract javax.xml.transform.Transformer newTransformer() ;
	public javax.xml.transform.TransformerFactory newInstance() ;
	public abstract javax.xml.transform.URIResolver getURIResolver() ;
	public abstract java.lang.Void setURIResolver(javax.xml.transform.URIResolver parameter1) ;
	public abstract java.lang.Object getAttribute(java.lang.String parameter1) ;
	public abstract java.lang.Void setAttribute(java.lang.String parameter1, java.lang.Object parameter2) ;
	public abstract javax.xml.transform.Templates newTemplates(javax.xml.transform.Source parameter1) ;
	public abstract javax.xml.transform.Transformer newTransformer(javax.xml.transform.Source parameter1) ;
	public abstract javax.xml.transform.Source getAssociatedStylesheet(javax.xml.transform.Source parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
}

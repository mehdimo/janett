package javax.xml.transform;

interface Result
{
	public abstract java.lang.String getSystemId() ;
	public abstract java.lang.Void setSystemId(java.lang.String parameter1) ;
	java.lang.String PI_DISABLE_OUTPUT_ESCAPING;
	java.lang.String PI_ENABLE_OUTPUT_ESCAPING;
}

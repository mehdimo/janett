package javax.xml.transform.sax;

interface TemplatesHandler implements org.xml.sax.ContentHandler
{
	public abstract java.lang.String getSystemId() ;
	public abstract java.lang.Void setSystemId(java.lang.String parameter1) ;
	public abstract javax.xml.transform.Templates getTemplates() ;
}

package javax.xml.transform.sax;

abstract class SAXTransformerFactory extends javax.xml.transform.TransformerFactory
{
	public abstract javax.xml.transform.sax.TemplatesHandler newTemplatesHandler() ;
	public abstract javax.xml.transform.sax.TransformerHandler newTransformerHandler() ;
	public abstract javax.xml.transform.sax.TransformerHandler newTransformerHandler(javax.xml.transform.Source parameter1) ;
	public abstract javax.xml.transform.sax.TransformerHandler newTransformerHandler(javax.xml.transform.Templates parameter1) ;
	public abstract org.xml.sax.XMLFilter newXMLFilter(javax.xml.transform.Source parameter1) ;
	public abstract org.xml.sax.XMLFilter newXMLFilter(javax.xml.transform.Templates parameter1) ;
	java.lang.String FEATURE;
	java.lang.String FEATURE_XMLFILTER;
}

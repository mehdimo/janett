package javax.xml.transform.sax;

abstract class SAXResult implements javax.xml.transform.Result
{
	public java.lang.String getSystemId() ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
	public org.xml.sax.ContentHandler getHandler() ;
	public java.lang.Void setHandler(org.xml.sax.ContentHandler parameter1) ;
	public org.xml.sax.ext.LexicalHandler getLexicalHandler() ;
	public java.lang.Void setLexicalHandler(org.xml.sax.ext.LexicalHandler parameter1) ;
	java.lang.String FEATURE;
}

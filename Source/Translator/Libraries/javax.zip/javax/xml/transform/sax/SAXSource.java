package javax.xml.transform.sax;

abstract class SAXSource implements javax.xml.transform.Source
{
	public java.lang.String getSystemId() ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
	public org.xml.sax.InputSource getInputSource() ;
	public java.lang.Void setInputSource(org.xml.sax.InputSource parameter1) ;
	public org.xml.sax.XMLReader getXMLReader() ;
	public java.lang.Void setXMLReader(org.xml.sax.XMLReader parameter1) ;
	public org.xml.sax.InputSource sourceToInputSource(javax.xml.transform.Source parameter1) ;
	java.lang.String FEATURE;
}

package javax.xml.transform.sax;

interface TransformerHandler implements org.xml.sax.ContentHandler, org.xml.sax.ext.LexicalHandler, org.xml.sax.DTDHandler
{
	public abstract java.lang.String getSystemId() ;
	public abstract java.lang.Void setSystemId(java.lang.String parameter1) ;
	public abstract java.lang.Void setResult(javax.xml.transform.Result parameter1) ;
	public abstract javax.xml.transform.Transformer getTransformer() ;
}

package javax.xml.transform;

interface Source
{
	public abstract java.lang.String getSystemId() ;
	public abstract java.lang.Void setSystemId(java.lang.String parameter1) ;
}

package javax.xml.transform;

abstract class Transformer
{
	public abstract java.lang.Void clearParameters() ;
	public abstract java.util.Properties getOutputProperties() ;
	public abstract java.lang.Void setOutputProperties(java.util.Properties parameter1) ;
	public abstract javax.xml.transform.ErrorListener getErrorListener() ;
	public abstract java.lang.Void setErrorListener(javax.xml.transform.ErrorListener parameter1) ;
	public abstract javax.xml.transform.URIResolver getURIResolver() ;
	public abstract java.lang.Void setURIResolver(javax.xml.transform.URIResolver parameter1) ;
	public abstract java.lang.Object getParameter(java.lang.String parameter1) ;
	public abstract java.lang.Void setParameter(java.lang.String parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.String getOutputProperty(java.lang.String parameter1) ;
	public abstract java.lang.Void setOutputProperty(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void transform(javax.xml.transform.Source parameter1, javax.xml.transform.Result parameter2) ;
}

package javax.xml.transform.dom;

interface DOMLocator implements javax.xml.transform.SourceLocator
{
	public abstract org.w3c.dom.Node getOriginatingNode() ;
}

package javax.xml.transform;

interface ErrorListener
{
	public abstract java.lang.Void error(javax.xml.transform.TransformerException parameter1) ;
	public abstract java.lang.Void fatalError(javax.xml.transform.TransformerException parameter1) ;
	public abstract java.lang.Void warning(javax.xml.transform.TransformerException parameter1) ;
}

package javax.xml.transform;

abstract class TransformerException extends java.lang.Exception
{
	public java.lang.Void printStackTrace() ;
	public java.lang.Void printStackTrace(java.io.PrintStream parameter1) ;
	public java.lang.Void printStackTrace(java.io.PrintWriter parameter1) ;
	public java.lang.String getLocationAsString() ;
	public java.lang.String getMessageAndLocation() ;
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getException() ;
	public javax.xml.transform.SourceLocator getLocator() ;
	public java.lang.Void setLocator(javax.xml.transform.SourceLocator parameter1) ;
	public java.lang.Throwable initCause(java.lang.Throwable parameter1) ;
}

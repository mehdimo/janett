package javax.xml.transform.stream;

abstract class StreamSource implements javax.xml.transform.Source
{
	public java.lang.Void setSystemId(java.io.File parameter1) ;
	public java.io.InputStream getInputStream() ;
	public java.lang.Void setInputStream(java.io.InputStream parameter1) ;
	public java.io.Reader getReader() ;
	public java.lang.Void setReader(java.io.Reader parameter1) ;
	public java.lang.String getPublicId() ;
	public java.lang.String getSystemId() ;
	public java.lang.Void setPublicId(java.lang.String parameter1) ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
	java.lang.String FEATURE;
}

package javax.xml.transform.stream;

abstract class StreamResult implements javax.xml.transform.Result
{
	public java.lang.Void setSystemId(java.io.File parameter1) ;
	public java.io.OutputStream getOutputStream() ;
	public java.lang.Void setOutputStream(java.io.OutputStream parameter1) ;
	public java.io.Writer getWriter() ;
	public java.lang.Void setWriter(java.io.Writer parameter1) ;
	public java.lang.String getSystemId() ;
	public java.lang.Void setSystemId(java.lang.String parameter1) ;
	java.lang.String FEATURE;
}

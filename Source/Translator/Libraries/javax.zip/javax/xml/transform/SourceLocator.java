package javax.xml.transform;

interface SourceLocator
{
	public abstract java.lang.Integer getColumnNumber() ;
	public abstract java.lang.Integer getLineNumber() ;
	public abstract java.lang.String getPublicId() ;
	public abstract java.lang.String getSystemId() ;
}

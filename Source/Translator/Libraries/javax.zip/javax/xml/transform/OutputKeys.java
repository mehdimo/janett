package javax.xml.transform;

abstract class OutputKeys
{
	java.lang.String METHOD;
	java.lang.String VERSION;
	java.lang.String ENCODING;
	java.lang.String OMIT_XML_DECLARATION;
	java.lang.String STANDALONE;
	java.lang.String DOCTYPE_PUBLIC;
	java.lang.String DOCTYPE_SYSTEM;
	java.lang.String CDATA_SECTION_ELEMENTS;
	java.lang.String INDENT;
	java.lang.String MEDIA_TYPE;
}

package javax.xml.transform;

abstract class TransformerConfigurationException extends javax.xml.transform.TransformerException
{
}

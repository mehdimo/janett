package javax.xml.transform;

abstract class TransformerFactoryConfigurationError extends java.lang.Error
{
	public java.lang.Exception getException() ;
	public java.lang.String getMessage() ;
}

package javax.xml.transform;

interface Templates
{
	public abstract java.util.Properties getOutputProperties() ;
	public abstract javax.xml.transform.Transformer newTransformer() ;
}

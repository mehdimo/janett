package javax.xml.transform;

interface URIResolver
{
	public abstract javax.xml.transform.Source resolve(java.lang.String parameter1, java.lang.String parameter2) ;
}

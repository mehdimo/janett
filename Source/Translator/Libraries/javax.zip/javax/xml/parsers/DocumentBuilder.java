package javax.xml.parsers;

abstract class DocumentBuilder
{
	public abstract java.lang.Boolean isNamespaceAware() ;
	public abstract java.lang.Boolean isValidating() ;
	public abstract org.w3c.dom.DOMImplementation getDOMImplementation() ;
	public abstract org.w3c.dom.Document newDocument() ;
	public abstract java.lang.Void setEntityResolver(org.xml.sax.EntityResolver parameter1) ;
	public abstract java.lang.Void setErrorHandler(org.xml.sax.ErrorHandler parameter1) ;
	public org.w3c.dom.Document parse(java.io.File parameter1) ;
	public org.w3c.dom.Document parse(java.io.InputStream parameter1) ;
	public org.w3c.dom.Document parse(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Document parse(org.xml.sax.InputSource parameter1) ;
	public org.w3c.dom.Document parse(java.io.InputStream parameter1, java.lang.String parameter2) ;
}

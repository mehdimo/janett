package javax.xml.parsers;

abstract class SAXParser
{
	public abstract java.lang.Boolean isNamespaceAware() ;
	public abstract java.lang.Boolean isValidating() ;
	public abstract org.xml.sax.Parser getParser() ;
	public abstract org.xml.sax.XMLReader getXMLReader() ;
	public abstract java.lang.Object getProperty(java.lang.String parameter1) ;
	public abstract java.lang.Void setProperty(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void parse(java.io.File parameter1, org.xml.sax.HandlerBase parameter2) ;
	public java.lang.Void parse(java.io.InputStream parameter1, org.xml.sax.HandlerBase parameter2) ;
	public java.lang.Void parse(java.lang.String parameter1, org.xml.sax.HandlerBase parameter2) ;
	public java.lang.Void parse(org.xml.sax.InputSource parameter1, org.xml.sax.HandlerBase parameter2) ;
	public java.lang.Void parse(java.io.File parameter1, org.xml.sax.helpers.DefaultHandler parameter2) ;
	public java.lang.Void parse(java.io.InputStream parameter1, org.xml.sax.helpers.DefaultHandler parameter2) ;
	public java.lang.Void parse(java.lang.String parameter1, org.xml.sax.helpers.DefaultHandler parameter2) ;
	public java.lang.Void parse(org.xml.sax.InputSource parameter1, org.xml.sax.helpers.DefaultHandler parameter2) ;
	public java.lang.Void parse(java.io.InputStream parameter1, org.xml.sax.HandlerBase parameter2, java.lang.String parameter3) ;
	public java.lang.Void parse(java.io.InputStream parameter1, org.xml.sax.helpers.DefaultHandler parameter2, java.lang.String parameter3) ;
}

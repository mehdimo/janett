package javax.xml.parsers;

abstract class SAXParserFactory
{
	public java.lang.Boolean isNamespaceAware() ;
	public java.lang.Boolean isValidating() ;
	public java.lang.Void setNamespaceAware(java.lang.Boolean parameter1) ;
	public java.lang.Void setValidating(java.lang.Boolean parameter1) ;
	public abstract java.lang.Boolean getFeature(java.lang.String parameter1) ;
	public abstract java.lang.Void setFeature(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public abstract javax.xml.parsers.SAXParser newSAXParser() ;
	public javax.xml.parsers.SAXParserFactory newInstance() ;
}

package javax.xml.parsers;

abstract class ParserConfigurationException extends java.lang.Exception
{
}

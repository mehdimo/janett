package javax.xml.parsers;

abstract class DocumentBuilderFactory
{
	public java.lang.Boolean isCoalescing() ;
	public java.lang.Boolean isExpandEntityReferences() ;
	public java.lang.Boolean isIgnoringComments() ;
	public java.lang.Boolean isIgnoringElementContentWhitespace() ;
	public java.lang.Boolean isNamespaceAware() ;
	public java.lang.Boolean isValidating() ;
	public java.lang.Void setCoalescing(java.lang.Boolean parameter1) ;
	public java.lang.Void setExpandEntityReferences(java.lang.Boolean parameter1) ;
	public java.lang.Void setIgnoringComments(java.lang.Boolean parameter1) ;
	public java.lang.Void setIgnoringElementContentWhitespace(java.lang.Boolean parameter1) ;
	public java.lang.Void setNamespaceAware(java.lang.Boolean parameter1) ;
	public java.lang.Void setValidating(java.lang.Boolean parameter1) ;
	public abstract javax.xml.parsers.DocumentBuilder newDocumentBuilder() ;
	public javax.xml.parsers.DocumentBuilderFactory newInstance() ;
	public abstract java.lang.Object getAttribute(java.lang.String parameter1) ;
	public abstract java.lang.Void setAttribute(java.lang.String parameter1, java.lang.Object parameter2) ;
}

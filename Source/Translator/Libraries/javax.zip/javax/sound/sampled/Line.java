package javax.sound.sampled;

interface Line
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void open() ;
	public abstract java.lang.Boolean isOpen() ;
	public abstract javax.sound.sampled.Control[] getControls() ;
	public abstract java.lang.Boolean isControlSupported(javax.sound.sampled.Control.Type parameter1) ;
	public abstract javax.sound.sampled.Line.Info getLineInfo() ;
	public abstract java.lang.Void addLineListener(javax.sound.sampled.LineListener parameter1) ;
	public abstract java.lang.Void removeLineListener(javax.sound.sampled.LineListener parameter1) ;
	public abstract javax.sound.sampled.Control getControl(javax.sound.sampled.Control.Type parameter1) ;
	abstract class Info
	{
		public java.lang.Class getLineClass() ;
		public java.lang.String toString() ;
		public java.lang.Boolean matches(javax.sound.sampled.Line.Info parameter1) ;
	}
}

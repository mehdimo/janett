package javax.sound.sampled.spi;

abstract class AudioFileReader
{
	public AudioFileReader() ;
	public abstract javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.io.File parameter1) ;
	public abstract javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.io.InputStream parameter1) ;
	public abstract javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.net.URL parameter1) ;
	public abstract javax.sound.sampled.AudioInputStream getAudioInputStream(java.io.File parameter1) ;
	public abstract javax.sound.sampled.AudioInputStream getAudioInputStream(java.io.InputStream parameter1) ;
	public abstract javax.sound.sampled.AudioInputStream getAudioInputStream(java.net.URL parameter1) ;
}

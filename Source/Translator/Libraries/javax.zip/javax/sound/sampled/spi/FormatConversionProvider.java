package javax.sound.sampled.spi;

abstract class FormatConversionProvider
{
	public FormatConversionProvider() ;
	public abstract javax.sound.sampled.AudioFormat.Encoding[] getSourceEncodings() ;
	public abstract javax.sound.sampled.AudioFormat.Encoding[] getTargetEncodings() ;
	public java.lang.Boolean isSourceEncodingSupported(javax.sound.sampled.AudioFormat.Encoding parameter1) ;
	public java.lang.Boolean isTargetEncodingSupported(javax.sound.sampled.AudioFormat.Encoding parameter1) ;
	public java.lang.Boolean isConversionSupported(javax.sound.sampled.AudioFormat parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public java.lang.Boolean isConversionSupported(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public abstract javax.sound.sampled.AudioFormat.Encoding[] getTargetEncodings(javax.sound.sampled.AudioFormat parameter1) ;
	public abstract javax.sound.sampled.AudioFormat[] getTargetFormats(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public abstract javax.sound.sampled.AudioInputStream getAudioInputStream(javax.sound.sampled.AudioFormat parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
	public abstract javax.sound.sampled.AudioInputStream getAudioInputStream(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
}

package javax.sound.sampled.spi;

abstract class AudioFileWriter
{
	public AudioFileWriter() ;
	public abstract javax.sound.sampled.AudioFileFormat.Type[] getAudioFileTypes() ;
	public java.lang.Boolean isFileTypeSupported(javax.sound.sampled.AudioFileFormat.Type parameter1) ;
	public abstract javax.sound.sampled.AudioFileFormat.Type[] getAudioFileTypes(javax.sound.sampled.AudioInputStream parameter1) ;
	public java.lang.Boolean isFileTypeSupported(javax.sound.sampled.AudioFileFormat.Type parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
	public abstract java.lang.Integer write(javax.sound.sampled.AudioInputStream parameter1, javax.sound.sampled.AudioFileFormat.Type parameter2, java.io.File parameter3) ;
	public abstract java.lang.Integer write(javax.sound.sampled.AudioInputStream parameter1, javax.sound.sampled.AudioFileFormat.Type parameter2, java.io.OutputStream parameter3) ;
}

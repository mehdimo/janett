package javax.sound.sampled.spi;

abstract class MixerProvider
{
	public abstract javax.sound.sampled.Mixer.Info[] getMixerInfo() ;
	public java.lang.Boolean isMixerSupported(javax.sound.sampled.Mixer.Info parameter1) ;
	public abstract javax.sound.sampled.Mixer getMixer(javax.sound.sampled.Mixer.Info parameter1) ;
}

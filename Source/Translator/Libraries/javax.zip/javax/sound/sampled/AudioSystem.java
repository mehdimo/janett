package javax.sound.sampled;

abstract class AudioSystem
{
	public javax.sound.sampled.AudioFileFormat.Type[] getAudioFileTypes() ;
	public java.lang.Boolean isFileTypeSupported(javax.sound.sampled.AudioFileFormat.Type parameter1) ;
	public java.lang.Boolean isLineSupported(javax.sound.sampled.Line.Info parameter1) ;
	public javax.sound.sampled.Mixer.Info[] getMixerInfo() ;
	public javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.io.File parameter1) ;
	public javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.io.InputStream parameter1) ;
	public javax.sound.sampled.AudioFileFormat getAudioFileFormat(java.net.URL parameter1) ;
	public javax.sound.sampled.AudioFileFormat.Type[] getAudioFileTypes(javax.sound.sampled.AudioInputStream parameter1) ;
	public java.lang.Boolean isConversionSupported(javax.sound.sampled.AudioFormat parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public java.lang.Boolean isConversionSupported(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public javax.sound.sampled.AudioFormat.Encoding[] getTargetEncodings(javax.sound.sampled.AudioFormat parameter1) ;
	public javax.sound.sampled.AudioFormat.Encoding[] getTargetEncodings(javax.sound.sampled.AudioFormat.Encoding parameter1) ;
	public javax.sound.sampled.AudioInputStream getAudioInputStream(java.io.File parameter1) ;
	public javax.sound.sampled.AudioInputStream getAudioInputStream(java.io.InputStream parameter1) ;
	public javax.sound.sampled.AudioInputStream getAudioInputStream(java.net.URL parameter1) ;
	public java.lang.Boolean isFileTypeSupported(javax.sound.sampled.AudioFileFormat.Type parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
	public javax.sound.sampled.Line getLine(javax.sound.sampled.Line.Info parameter1) ;
	public javax.sound.sampled.Line.Info[] getSourceLineInfo(javax.sound.sampled.Line.Info parameter1) ;
	public javax.sound.sampled.Line.Info[] getTargetLineInfo(javax.sound.sampled.Line.Info parameter1) ;
	public javax.sound.sampled.Mixer getMixer(javax.sound.sampled.Mixer.Info parameter1) ;
	public java.lang.Integer write(javax.sound.sampled.AudioInputStream parameter1, javax.sound.sampled.AudioFileFormat.Type parameter2, java.io.File parameter3) ;
	public java.lang.Integer write(javax.sound.sampled.AudioInputStream parameter1, javax.sound.sampled.AudioFileFormat.Type parameter2, java.io.OutputStream parameter3) ;
	public javax.sound.sampled.AudioFormat[] getTargetFormats(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioFormat parameter2) ;
	public javax.sound.sampled.AudioInputStream getAudioInputStream(javax.sound.sampled.AudioFormat parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
	public javax.sound.sampled.AudioInputStream getAudioInputStream(javax.sound.sampled.AudioFormat.Encoding parameter1, javax.sound.sampled.AudioInputStream parameter2) ;
	java.lang.Integer NOT_SPECIFIED;
}

package javax.sound.sampled;

abstract class UnsupportedAudioFileException extends java.lang.Exception
{
	public UnsupportedAudioFileException() ;
	public UnsupportedAudioFileException(java.lang.String parameter1) ;
}

package javax.sound.sampled;

abstract class UnsupportedAudioFileException extends java.lang.Exception
{
}

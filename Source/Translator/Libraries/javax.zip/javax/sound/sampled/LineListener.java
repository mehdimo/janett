package javax.sound.sampled;

interface LineListener implements java.util.EventListener
{
	public abstract java.lang.Void update(javax.sound.sampled.LineEvent parameter1) ;
}

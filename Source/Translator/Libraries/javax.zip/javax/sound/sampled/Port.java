package javax.sound.sampled;

interface Port implements javax.sound.sampled.Line
{
	abstract class Info extends javax.sound.sampled.Line.Info
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean isSource() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getName() ;
		public java.lang.String toString() ;
		public java.lang.Boolean matches(javax.sound.sampled.Line.Info parameter1) ;
		public Info(java.lang.Class parameter1, java.lang.String parameter2, java.lang.Boolean parameter3) ;
		javax.sound.sampled.Port.Info MICROPHONE;
		javax.sound.sampled.Port.Info LINE_IN;
		javax.sound.sampled.Port.Info COMPACT_DISC;
		javax.sound.sampled.Port.Info SPEAKER;
		javax.sound.sampled.Port.Info HEADPHONE;
		javax.sound.sampled.Port.Info LINE_OUT;
	}
}

package javax.sound.sampled;

abstract class LineEvent extends java.util.EventObject
{
	public java.lang.Long getFramePosition() ;
	public java.lang.String toString() ;
	public javax.sound.sampled.Line getLine() ;
	public javax.sound.sampled.LineEvent.Type getType() ;
	public LineEvent(javax.sound.sampled.Line parameter1, javax.sound.sampled.LineEvent.Type parameter2, java.lang.Long parameter3) ;
	abstract class Type
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String toString() ;
		public Type(java.lang.String parameter1) ;
		javax.sound.sampled.LineEvent.Type OPEN;
		javax.sound.sampled.LineEvent.Type CLOSE;
		javax.sound.sampled.LineEvent.Type START;
		javax.sound.sampled.LineEvent.Type STOP;
	}
}

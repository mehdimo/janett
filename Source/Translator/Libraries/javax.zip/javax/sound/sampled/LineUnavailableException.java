package javax.sound.sampled;

abstract class LineUnavailableException extends java.lang.Exception
{
}

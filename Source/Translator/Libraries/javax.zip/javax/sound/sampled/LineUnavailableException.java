package javax.sound.sampled;

abstract class LineUnavailableException extends java.lang.Exception
{
	public LineUnavailableException() ;
	public LineUnavailableException(java.lang.String parameter1) ;
}

package javax.sound.sampled;

abstract class FloatControl extends javax.sound.sampled.Control
{
	public java.lang.Float getMaximum() ;
	public java.lang.Float getMinimum() ;
	public java.lang.Float getPrecision() ;
	public java.lang.Float getValue() ;
	public java.lang.Integer getUpdatePeriod() ;
	public java.lang.Void setValue(java.lang.Float parameter1) ;
	public java.lang.Void shift(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Integer parameter3) ;
	public java.lang.String getMaxLabel() ;
	public java.lang.String getMidLabel() ;
	public java.lang.String getMinLabel() ;
	public java.lang.String getUnits() ;
	public java.lang.String toString() ;
	public FloatControl(javax.sound.sampled.FloatControl.Type parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Integer parameter5, java.lang.Float parameter6, java.lang.String parameter7) ;
	public FloatControl(javax.sound.sampled.FloatControl.Type parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Integer parameter5, java.lang.Float parameter6, java.lang.String parameter7, java.lang.String parameter8, java.lang.String parameter9, java.lang.String parameter10
	) ;
	abstract class Type extends javax.sound.sampled.Control.Type
	{
		public Type(java.lang.String parameter1) ;
		javax.sound.sampled.FloatControl.Type MASTER_GAIN;
		javax.sound.sampled.FloatControl.Type AUX_SEND;
		javax.sound.sampled.FloatControl.Type AUX_RETURN;
		javax.sound.sampled.FloatControl.Type REVERB_SEND;
		javax.sound.sampled.FloatControl.Type REVERB_RETURN;
		javax.sound.sampled.FloatControl.Type VOLUME;
		javax.sound.sampled.FloatControl.Type PAN;
		javax.sound.sampled.FloatControl.Type BALANCE;
		javax.sound.sampled.FloatControl.Type SAMPLE_RATE;
	}
}

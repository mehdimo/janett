package javax.sound.sampled;

abstract class ReverbType
{
	public java.lang.Float getEarlyReflectionIntensity() ;
	public java.lang.Float getLateReflectionIntensity() ;
	public java.lang.Integer getDecayTime() ;
	public java.lang.Integer getEarlyReflectionDelay() ;
	public java.lang.Integer getLateReflectionDelay() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

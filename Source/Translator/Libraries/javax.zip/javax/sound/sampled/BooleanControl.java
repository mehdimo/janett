package javax.sound.sampled;

abstract class BooleanControl extends javax.sound.sampled.Control
{
	public java.lang.Boolean getValue() ;
	public java.lang.Void setValue(java.lang.Boolean parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String getStateLabel(java.lang.Boolean parameter1) ;
	public BooleanControl(javax.sound.sampled.BooleanControl.Type parameter1, java.lang.Boolean parameter2) ;
	public BooleanControl(javax.sound.sampled.BooleanControl.Type parameter1, java.lang.Boolean parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
	abstract class Type extends javax.sound.sampled.Control.Type
	{
		public Type(java.lang.String parameter1) ;
		javax.sound.sampled.BooleanControl.Type MUTE;
		javax.sound.sampled.BooleanControl.Type APPLY_REVERB;
	}
}

package javax.sound.sampled;

abstract class AudioPermission extends java.security.BasicPermission
{
	public AudioPermission(java.lang.String parameter1) ;
	public AudioPermission(java.lang.String parameter1, java.lang.String parameter2) ;
}

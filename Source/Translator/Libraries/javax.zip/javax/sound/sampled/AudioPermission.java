package javax.sound.sampled;

abstract class AudioPermission extends java.security.BasicPermission
{
}

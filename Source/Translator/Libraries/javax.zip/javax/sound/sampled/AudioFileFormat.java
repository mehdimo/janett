package javax.sound.sampled;

abstract class AudioFileFormat
{
	public java.lang.Integer getByteLength() ;
	public java.lang.Integer getFrameLength() ;
	public java.lang.String toString() ;
	public javax.sound.sampled.AudioFileFormat.Type getType() ;
	public javax.sound.sampled.AudioFormat getFormat() ;
	abstract class Type
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getExtension() ;
		public java.lang.String toString() ;
		javax.sound.sampled.AudioFileFormat.Type WAVE;
		javax.sound.sampled.AudioFileFormat.Type AU;
		javax.sound.sampled.AudioFileFormat.Type AIFF;
		javax.sound.sampled.AudioFileFormat.Type AIFC;
		javax.sound.sampled.AudioFileFormat.Type SND;
	}
}

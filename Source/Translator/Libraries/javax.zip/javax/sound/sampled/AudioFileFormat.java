package javax.sound.sampled;

abstract class AudioFileFormat
{
	public java.lang.Integer getByteLength() ;
	public java.lang.Integer getFrameLength() ;
	public java.lang.String toString() ;
	public javax.sound.sampled.AudioFileFormat.Type getType() ;
	public javax.sound.sampled.AudioFormat getFormat() ;
	public AudioFileFormat(javax.sound.sampled.AudioFileFormat.Type parameter1, java.lang.Integer parameter2, javax.sound.sampled.AudioFormat parameter3, java.lang.Integer parameter4) ;
	public AudioFileFormat(javax.sound.sampled.AudioFileFormat.Type parameter1, javax.sound.sampled.AudioFormat parameter2, java.lang.Integer parameter3) ;
	abstract class Type
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getExtension() ;
		public java.lang.String toString() ;
		public Type(java.lang.String parameter1, java.lang.String parameter2) ;
		javax.sound.sampled.AudioFileFormat.Type WAVE;
		javax.sound.sampled.AudioFileFormat.Type AU;
		javax.sound.sampled.AudioFileFormat.Type AIFF;
		javax.sound.sampled.AudioFileFormat.Type AIFC;
		javax.sound.sampled.AudioFileFormat.Type SND;
	}
}

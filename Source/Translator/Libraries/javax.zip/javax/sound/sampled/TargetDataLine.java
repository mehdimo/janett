package javax.sound.sampled;

interface TargetDataLine implements javax.sound.sampled.DataLine
{
	public abstract java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void open(javax.sound.sampled.AudioFormat parameter1) ;
	public abstract java.lang.Void open(javax.sound.sampled.AudioFormat parameter1, java.lang.Integer parameter2) ;
}

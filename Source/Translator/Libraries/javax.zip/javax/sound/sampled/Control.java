package javax.sound.sampled;

abstract class Control
{
	public java.lang.String toString() ;
	public javax.sound.sampled.Control.Type getType() ;
	abstract class Type
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String toString() ;
	}
}

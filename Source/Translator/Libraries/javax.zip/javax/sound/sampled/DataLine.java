package javax.sound.sampled;

interface DataLine implements javax.sound.sampled.Line
{
	public abstract java.lang.Float getLevel() ;
	public abstract java.lang.Integer available() ;
	public abstract java.lang.Integer getBufferSize() ;
	public abstract java.lang.Integer getFramePosition() ;
	public abstract java.lang.Long getMicrosecondPosition() ;
	public abstract java.lang.Void drain() ;
	public abstract java.lang.Void flush() ;
	public abstract java.lang.Void start() ;
	public abstract java.lang.Void stop() ;
	public abstract java.lang.Boolean isActive() ;
	public abstract java.lang.Boolean isRunning() ;
	public abstract javax.sound.sampled.AudioFormat getFormat() ;
	abstract class Info extends javax.sound.sampled.Line.Info
	{
		public java.lang.Integer getMaxBufferSize() ;
		public java.lang.Integer getMinBufferSize() ;
		public java.lang.String toString() ;
		public javax.sound.sampled.AudioFormat[] getFormats() ;
		public java.lang.Boolean isFormatSupported(javax.sound.sampled.AudioFormat parameter1) ;
		public java.lang.Boolean matches(javax.sound.sampled.Line.Info parameter1) ;
	}
}

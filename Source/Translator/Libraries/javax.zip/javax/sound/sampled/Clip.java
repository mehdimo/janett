package javax.sound.sampled;

interface Clip implements javax.sound.sampled.DataLine
{
	public abstract java.lang.Integer getFrameLength() ;
	public abstract java.lang.Long getMicrosecondLength() ;
	public abstract java.lang.Void loop(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setFramePosition(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setLoopPoints(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setMicrosecondPosition(java.lang.Long parameter1) ;
	public abstract java.lang.Void open(javax.sound.sampled.AudioFormat parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Void open(javax.sound.sampled.AudioInputStream parameter1) ;
	java.lang.Integer LOOP_CONTINUOUSLY;
}

package javax.sound.sampled;

interface Mixer implements javax.sound.sampled.Line
{
	public abstract javax.sound.sampled.Line[] getSourceLines() ;
	public abstract javax.sound.sampled.Line[] getTargetLines() ;
	public abstract java.lang.Void unsynchronize(javax.sound.sampled.Line[] parameter1) ;
	public abstract java.lang.Void synchronize(javax.sound.sampled.Line[] parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Boolean isSynchronizationSupported(javax.sound.sampled.Line[] parameter1, java.lang.Boolean parameter2) ;
	public abstract javax.sound.sampled.Line.Info[] getSourceLineInfo() ;
	public abstract javax.sound.sampled.Line.Info[] getTargetLineInfo() ;
	public abstract java.lang.Integer getMaxLines(javax.sound.sampled.Line.Info parameter1) ;
	public abstract java.lang.Boolean isLineSupported(javax.sound.sampled.Line.Info parameter1) ;
	public abstract javax.sound.sampled.Mixer.Info getMixerInfo() ;
	public abstract javax.sound.sampled.Line getLine(javax.sound.sampled.Line.Info parameter1) ;
	public abstract javax.sound.sampled.Line.Info[] getSourceLineInfo(javax.sound.sampled.Line.Info parameter1) ;
	public abstract javax.sound.sampled.Line.Info[] getTargetLineInfo(javax.sound.sampled.Line.Info parameter1) ;
	abstract class Info
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getDescription() ;
		public java.lang.String getName() ;
		public java.lang.String getVendor() ;
		public java.lang.String getVersion() ;
		public java.lang.String toString() ;
		public Info(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
	}
}

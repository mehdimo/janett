package javax.sound.sampled;

abstract class CompoundControl extends javax.sound.sampled.Control
{
	public java.lang.String toString() ;
	public javax.sound.sampled.Control[] getMemberControls() ;
	abstract class Type extends javax.sound.sampled.Control.Type
	{
	}
}

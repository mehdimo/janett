package javax.sound.sampled;

abstract class CompoundControl extends javax.sound.sampled.Control
{
	public java.lang.String toString() ;
	public javax.sound.sampled.Control[] getMemberControls() ;
	public CompoundControl(javax.sound.sampled.CompoundControl.Type parameter1, javax.sound.sampled.Control[] parameter2) ;
	abstract class Type extends javax.sound.sampled.Control.Type
	{
		public Type(java.lang.String parameter1) ;
	}
}

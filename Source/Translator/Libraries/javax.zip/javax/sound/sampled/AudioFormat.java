package javax.sound.sampled;

abstract class AudioFormat
{
	public java.lang.Float getFrameRate() ;
	public java.lang.Float getSampleRate() ;
	public java.lang.Integer getChannels() ;
	public java.lang.Integer getFrameSize() ;
	public java.lang.Integer getSampleSizeInBits() ;
	public java.lang.Boolean isBigEndian() ;
	public AudioFormat(java.lang.Float parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4, java.lang.Boolean parameter5) ;
	public java.lang.String toString() ;
	public java.lang.Boolean matches(javax.sound.sampled.AudioFormat parameter1) ;
	public javax.sound.sampled.AudioFormat.Encoding getEncoding() ;
	public AudioFormat(javax.sound.sampled.AudioFormat.Encoding parameter1, java.lang.Float parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Float parameter6, java.lang.Boolean parameter7) ;
	abstract class Encoding
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String toString() ;
		public Encoding(java.lang.String parameter1) ;
		javax.sound.sampled.AudioFormat.Encoding PCM_SIGNED;
		javax.sound.sampled.AudioFormat.Encoding PCM_UNSIGNED;
		javax.sound.sampled.AudioFormat.Encoding ULAW;
		javax.sound.sampled.AudioFormat.Encoding ALAW;
	}
}

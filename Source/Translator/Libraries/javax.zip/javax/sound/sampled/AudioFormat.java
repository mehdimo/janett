package javax.sound.sampled;

abstract class AudioFormat
{
	public java.lang.Float getFrameRate() ;
	public java.lang.Float getSampleRate() ;
	public java.lang.Integer getChannels() ;
	public java.lang.Integer getFrameSize() ;
	public java.lang.Integer getSampleSizeInBits() ;
	public java.lang.Boolean isBigEndian() ;
	public java.lang.String toString() ;
	public java.lang.Boolean matches(javax.sound.sampled.AudioFormat parameter1) ;
	public javax.sound.sampled.AudioFormat.Encoding getEncoding() ;
	abstract class Encoding
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String toString() ;
		javax.sound.sampled.AudioFormat.Encoding PCM_SIGNED;
		javax.sound.sampled.AudioFormat.Encoding PCM_UNSIGNED;
		javax.sound.sampled.AudioFormat.Encoding ULAW;
		javax.sound.sampled.AudioFormat.Encoding ALAW;
	}
}

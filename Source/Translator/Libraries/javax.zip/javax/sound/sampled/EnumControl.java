package javax.sound.sampled;

abstract class EnumControl extends javax.sound.sampled.Control
{
	public java.lang.Object getValue() ;
	public java.lang.Object[] getValues() ;
	public java.lang.Void setValue(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	abstract class Type extends javax.sound.sampled.Control.Type
	{
		javax.sound.sampled.EnumControl.Type REVERB;
	}
}

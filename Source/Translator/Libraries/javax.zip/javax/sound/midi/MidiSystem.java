package javax.sound.midi;

abstract class MidiSystem
{
	public java.lang.Integer[] getMidiFileTypes() ;
	public java.lang.Boolean isFileTypeSupported(java.lang.Integer parameter1) ;
	public javax.sound.midi.MidiDevice.Info[] getMidiDeviceInfo() ;
	public javax.sound.midi.Receiver getReceiver() ;
	public java.lang.Boolean isFileTypeSupported(java.lang.Integer parameter1, javax.sound.midi.Sequence parameter2) ;
	public java.lang.Integer[] getMidiFileTypes(javax.sound.midi.Sequence parameter1) ;
	public javax.sound.midi.Sequencer getSequencer() ;
	public javax.sound.midi.Synthesizer getSynthesizer() ;
	public javax.sound.midi.Transmitter getTransmitter() ;
	public java.lang.Integer write(javax.sound.midi.Sequence parameter1, java.lang.Integer parameter2, java.io.File parameter3) ;
	public java.lang.Integer write(javax.sound.midi.Sequence parameter1, java.lang.Integer parameter2, java.io.OutputStream parameter3) ;
	public javax.sound.midi.MidiDevice getMidiDevice(javax.sound.midi.MidiDevice.Info parameter1) ;
	public javax.sound.midi.MidiFileFormat getMidiFileFormat(java.io.File parameter1) ;
	public javax.sound.midi.MidiFileFormat getMidiFileFormat(java.io.InputStream parameter1) ;
	public javax.sound.midi.MidiFileFormat getMidiFileFormat(java.net.URL parameter1) ;
	public javax.sound.midi.Sequence getSequence(java.io.File parameter1) ;
	public javax.sound.midi.Sequence getSequence(java.io.InputStream parameter1) ;
	public javax.sound.midi.Sequence getSequence(java.net.URL parameter1) ;
	public javax.sound.midi.Soundbank getSoundbank(java.io.File parameter1) ;
	public javax.sound.midi.Soundbank getSoundbank(java.io.InputStream parameter1) ;
	public javax.sound.midi.Soundbank getSoundbank(java.net.URL parameter1) ;
}

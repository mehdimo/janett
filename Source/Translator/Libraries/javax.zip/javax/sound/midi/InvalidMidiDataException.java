package javax.sound.midi;

abstract class InvalidMidiDataException extends java.lang.Exception
{
	public InvalidMidiDataException() ;
	public InvalidMidiDataException(java.lang.String parameter1) ;
}

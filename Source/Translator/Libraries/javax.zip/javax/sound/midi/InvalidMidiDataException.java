package javax.sound.midi;

abstract class InvalidMidiDataException extends java.lang.Exception
{
}

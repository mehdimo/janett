package javax.sound.midi.spi;

abstract class MidiFileReader
{
	public MidiFileReader() ;
	public abstract javax.sound.midi.MidiFileFormat getMidiFileFormat(java.io.File parameter1) ;
	public abstract javax.sound.midi.MidiFileFormat getMidiFileFormat(java.io.InputStream parameter1) ;
	public abstract javax.sound.midi.MidiFileFormat getMidiFileFormat(java.net.URL parameter1) ;
	public abstract javax.sound.midi.Sequence getSequence(java.io.File parameter1) ;
	public abstract javax.sound.midi.Sequence getSequence(java.io.InputStream parameter1) ;
	public abstract javax.sound.midi.Sequence getSequence(java.net.URL parameter1) ;
}

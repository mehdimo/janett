package javax.sound.midi.spi;

abstract class MidiFileWriter
{
	public abstract java.lang.Integer[] getMidiFileTypes() ;
	public java.lang.Boolean isFileTypeSupported(java.lang.Integer parameter1) ;
	public java.lang.Boolean isFileTypeSupported(java.lang.Integer parameter1, javax.sound.midi.Sequence parameter2) ;
	public abstract java.lang.Integer[] getMidiFileTypes(javax.sound.midi.Sequence parameter1) ;
	public abstract java.lang.Integer write(javax.sound.midi.Sequence parameter1, java.lang.Integer parameter2, java.io.File parameter3) ;
	public abstract java.lang.Integer write(javax.sound.midi.Sequence parameter1, java.lang.Integer parameter2, java.io.OutputStream parameter3) ;
}

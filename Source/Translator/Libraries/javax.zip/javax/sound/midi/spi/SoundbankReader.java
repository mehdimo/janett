package javax.sound.midi.spi;

abstract class SoundbankReader
{
	public SoundbankReader() ;
	public abstract javax.sound.midi.Soundbank getSoundbank(java.io.File parameter1) ;
	public abstract javax.sound.midi.Soundbank getSoundbank(java.io.InputStream parameter1) ;
	public abstract javax.sound.midi.Soundbank getSoundbank(java.net.URL parameter1) ;
}

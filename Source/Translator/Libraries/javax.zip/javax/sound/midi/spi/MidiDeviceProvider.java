package javax.sound.midi.spi;

abstract class MidiDeviceProvider
{
	public abstract javax.sound.midi.MidiDevice.Info[] getDeviceInfo() ;
	public java.lang.Boolean isDeviceSupported(javax.sound.midi.MidiDevice.Info parameter1) ;
	public abstract javax.sound.midi.MidiDevice getDevice(javax.sound.midi.MidiDevice.Info parameter1) ;
}

package javax.sound.midi;

abstract class Sequence
{
	public java.lang.Float getDivisionType() ;
	public java.lang.Integer getResolution() ;
	public java.lang.Long getMicrosecondLength() ;
	public java.lang.Long getTickLength() ;
	public javax.sound.midi.Patch[] getPatchList() ;
	public javax.sound.midi.Track createTrack() ;
	public javax.sound.midi.Track[] getTracks() ;
	public java.lang.Boolean deleteTrack(javax.sound.midi.Track parameter1) ;
	java.lang.Float PPQ;
	java.lang.Float SMPTE_24;
	java.lang.Float SMPTE_25;
	java.lang.Float SMPTE_30DROP;
	java.lang.Float SMPTE_30;
}

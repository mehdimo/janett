package javax.sound.midi;

abstract class Sequence
{
	public java.lang.Float getDivisionType() ;
	public java.lang.Integer getResolution() ;
	public java.lang.Long getMicrosecondLength() ;
	public java.lang.Long getTickLength() ;
	public Sequence(java.lang.Float parameter1, java.lang.Integer parameter2) ;
	public Sequence(java.lang.Float parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public javax.sound.midi.Patch[] getPatchList() ;
	public javax.sound.midi.Track createTrack() ;
	public javax.sound.midi.Track[] getTracks() ;
	public java.lang.Boolean deleteTrack(javax.sound.midi.Track parameter1) ;
	java.lang.Float PPQ;
	java.lang.Float SMPTE_24;
	java.lang.Float SMPTE_25;
	java.lang.Float SMPTE_30DROP;
	java.lang.Float SMPTE_30;
}

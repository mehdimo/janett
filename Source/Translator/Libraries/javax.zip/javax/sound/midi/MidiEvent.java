package javax.sound.midi;

abstract class MidiEvent
{
	public java.lang.Long getTick() ;
	public java.lang.Void setTick(java.lang.Long parameter1) ;
	public javax.sound.midi.MidiMessage getMessage() ;
	public MidiEvent(javax.sound.midi.MidiMessage parameter1, java.lang.Long parameter2) ;
}

package javax.sound.midi;

abstract class Instrument extends javax.sound.midi.SoundbankResource
{
	public javax.sound.midi.Patch getPatch() ;
	public Instrument(javax.sound.midi.Soundbank parameter1, javax.sound.midi.Patch parameter2, java.lang.String parameter3, java.lang.Class parameter4) ;
}

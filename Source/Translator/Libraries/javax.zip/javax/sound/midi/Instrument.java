package javax.sound.midi;

abstract class Instrument extends javax.sound.midi.SoundbankResource
{
	public javax.sound.midi.Patch getPatch() ;
}

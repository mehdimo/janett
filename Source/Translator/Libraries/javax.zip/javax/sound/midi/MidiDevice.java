package javax.sound.midi;

interface MidiDevice
{
	public abstract java.lang.Integer getMaxReceivers() ;
	public abstract java.lang.Integer getMaxTransmitters() ;
	public abstract java.lang.Long getMicrosecondPosition() ;
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void open() ;
	public abstract java.lang.Boolean isOpen() ;
	public abstract javax.sound.midi.MidiDevice.Info getDeviceInfo() ;
	public abstract javax.sound.midi.Receiver getReceiver() ;
	public abstract javax.sound.midi.Transmitter getTransmitter() ;
	abstract class Info
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getDescription() ;
		public java.lang.String getName() ;
		public java.lang.String getVendor() ;
		public java.lang.String getVersion() ;
		public java.lang.String toString() ;
	}
}

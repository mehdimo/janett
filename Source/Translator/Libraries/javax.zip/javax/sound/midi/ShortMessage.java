package javax.sound.midi;

abstract class ShortMessage extends javax.sound.midi.MidiMessage
{
	public java.lang.Integer getChannel() ;
	public java.lang.Integer getCommand() ;
	public java.lang.Integer getData1() ;
	public java.lang.Integer getData2() ;
	public java.lang.Integer getDataLength(java.lang.Integer parameter1) ;
	public java.lang.Void setMessage(java.lang.Integer parameter1) ;
	public java.lang.Void setMessage(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void setMessage(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Object clone() ;
	java.lang.Integer MIDI_TIME_CODE;
	java.lang.Integer SONG_POSITION_POINTER;
	java.lang.Integer SONG_SELECT;
	java.lang.Integer TUNE_REQUEST;
	java.lang.Integer END_OF_EXCLUSIVE;
	java.lang.Integer TIMING_CLOCK;
	java.lang.Integer START;
	java.lang.Integer CONTINUE;
	java.lang.Integer STOP;
	java.lang.Integer ACTIVE_SENSING;
	java.lang.Integer SYSTEM_RESET;
	java.lang.Integer NOTE_OFF;
	java.lang.Integer NOTE_ON;
	java.lang.Integer POLY_PRESSURE;
	java.lang.Integer CONTROL_CHANGE;
	java.lang.Integer PROGRAM_CHANGE;
	java.lang.Integer CHANNEL_PRESSURE;
	java.lang.Integer PITCH_BEND;
}

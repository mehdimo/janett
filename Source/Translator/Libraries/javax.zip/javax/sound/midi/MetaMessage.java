package javax.sound.midi;

abstract class MetaMessage extends javax.sound.midi.MidiMessage
{
	public java.lang.Integer getType() ;
	public MetaMessage() ;
	public java.lang.Byte[] getData() ;
	public java.lang.Void setMessage(java.lang.Integer parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3) ;
	public MetaMessage(java.lang.Byte[] parameter1) ;
	public java.lang.Object clone() ;
	java.lang.Integer META;
}

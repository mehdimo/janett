package javax.sound.midi;

abstract class MidiMessage implements java.lang.Cloneable
{
	public java.lang.Integer getLength() ;
	public java.lang.Integer getStatus() ;
	public java.lang.Byte[] getMessage() ;
	public MidiMessage(java.lang.Byte[] parameter1) ;
	public java.lang.Void setMessage(java.lang.Byte[] parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Object clone() ;
}

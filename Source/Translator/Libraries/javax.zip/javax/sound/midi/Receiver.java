package javax.sound.midi;

interface Receiver
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void send(javax.sound.midi.MidiMessage parameter1, java.lang.Long parameter2) ;
}

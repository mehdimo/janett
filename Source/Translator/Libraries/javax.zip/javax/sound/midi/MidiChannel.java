package javax.sound.midi;

interface MidiChannel
{
	public abstract java.lang.Integer getChannelPressure() ;
	public abstract java.lang.Integer getPitchBend() ;
	public abstract java.lang.Integer getProgram() ;
	public abstract java.lang.Void allNotesOff() ;
	public abstract java.lang.Void allSoundOff() ;
	public abstract java.lang.Void resetAllControllers() ;
	public abstract java.lang.Boolean getMono() ;
	public abstract java.lang.Boolean getMute() ;
	public abstract java.lang.Boolean getOmni() ;
	public abstract java.lang.Boolean getSolo() ;
	public abstract java.lang.Integer getController(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getPolyPressure(java.lang.Integer parameter1) ;
	public abstract java.lang.Void noteOff(java.lang.Integer parameter1) ;
	public abstract java.lang.Void programChange(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setChannelPressure(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setPitchBend(java.lang.Integer parameter1) ;
	public abstract java.lang.Void controlChange(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void noteOff(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void noteOn(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void programChange(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setPolyPressure(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setMono(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setMute(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setOmni(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setSolo(java.lang.Boolean parameter1) ;
	public abstract java.lang.Boolean localControl(java.lang.Boolean parameter1) ;
}

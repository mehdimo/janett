package javax.sound.midi;

abstract class MidiUnavailableException extends java.lang.Exception
{
	public MidiUnavailableException() ;
	public MidiUnavailableException(java.lang.String parameter1) ;
}

package javax.sound.midi;

abstract class MidiUnavailableException extends java.lang.Exception
{
}

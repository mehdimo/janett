package javax.sound.midi;

abstract class SoundbankResource
{
	public java.lang.Class getDataClass() ;
	public abstract java.lang.Object getData() ;
	public java.lang.String getName() ;
	public javax.sound.midi.Soundbank getSoundbank() ;
}

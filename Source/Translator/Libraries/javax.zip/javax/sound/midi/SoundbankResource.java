package javax.sound.midi;

abstract class SoundbankResource
{
	public java.lang.Class getDataClass() ;
	public abstract java.lang.Object getData() ;
	public java.lang.String getName() ;
	public javax.sound.midi.Soundbank getSoundbank() ;
	public SoundbankResource(javax.sound.midi.Soundbank parameter1, java.lang.String parameter2, java.lang.Class parameter3) ;
}

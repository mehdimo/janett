package javax.sound.midi;

abstract class Track
{
	public java.lang.Integer size() ;
	public java.lang.Long ticks() ;
	public javax.sound.midi.MidiEvent get(java.lang.Integer parameter1) ;
	public java.lang.Boolean add(javax.sound.midi.MidiEvent parameter1) ;
	public java.lang.Boolean remove(javax.sound.midi.MidiEvent parameter1) ;
}

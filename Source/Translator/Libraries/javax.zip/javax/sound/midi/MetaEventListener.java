package javax.sound.midi;

interface MetaEventListener implements java.util.EventListener
{
	public abstract java.lang.Void meta(javax.sound.midi.MetaMessage parameter1) ;
}

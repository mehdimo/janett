package javax.sound.midi;

abstract class Patch
{
	public java.lang.Integer getBank() ;
	public java.lang.Integer getProgram() ;
	public Patch(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
}

package javax.sound.midi;

abstract class Patch
{
	public java.lang.Integer getBank() ;
	public java.lang.Integer getProgram() ;
}

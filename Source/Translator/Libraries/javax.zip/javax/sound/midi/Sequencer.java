package javax.sound.midi;

interface Sequencer implements javax.sound.midi.MidiDevice
{
	public abstract java.lang.Float getTempoFactor() ;
	public abstract java.lang.Float getTempoInBPM() ;
	public abstract java.lang.Float getTempoInMPQ() ;
	public abstract java.lang.Long getMicrosecondLength() ;
	public abstract java.lang.Long getMicrosecondPosition() ;
	public abstract java.lang.Long getTickLength() ;
	public abstract java.lang.Long getTickPosition() ;
	public abstract java.lang.Void start() ;
	public abstract java.lang.Void startRecording() ;
	public abstract java.lang.Void stop() ;
	public abstract java.lang.Void stopRecording() ;
	public abstract java.lang.Boolean isRecording() ;
	public abstract java.lang.Boolean isRunning() ;
	public abstract java.lang.Void setTempoFactor(java.lang.Float parameter1) ;
	public abstract java.lang.Void setTempoInBPM(java.lang.Float parameter1) ;
	public abstract java.lang.Void setTempoInMPQ(java.lang.Float parameter1) ;
	public abstract java.lang.Boolean getTrackMute(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean getTrackSolo(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setTrackMute(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setTrackSolo(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setMicrosecondPosition(java.lang.Long parameter1) ;
	public abstract java.lang.Void setTickPosition(java.lang.Long parameter1) ;
	public abstract java.lang.Void setSequence(java.io.InputStream parameter1) ;
	public abstract java.lang.Integer[] addControllerEventListener(javax.sound.midi.ControllerEventListener parameter1, java.lang.Integer[] parameter2) ;
	public abstract java.lang.Integer[] removeControllerEventListener(javax.sound.midi.ControllerEventListener parameter1, java.lang.Integer[] parameter2) ;
	public abstract java.lang.Void removeMetaEventListener(javax.sound.midi.MetaEventListener parameter1) ;
	public abstract java.lang.Boolean addMetaEventListener(javax.sound.midi.MetaEventListener parameter1) ;
	public abstract javax.sound.midi.Sequence getSequence() ;
	public abstract java.lang.Void setSequence(javax.sound.midi.Sequence parameter1) ;
	public abstract javax.sound.midi.Sequencer.SyncMode getMasterSyncMode() ;
	public abstract javax.sound.midi.Sequencer.SyncMode getSlaveSyncMode() ;
	public abstract javax.sound.midi.Sequencer.SyncMode[] getMasterSyncModes() ;
	public abstract javax.sound.midi.Sequencer.SyncMode[] getSlaveSyncModes() ;
	public abstract java.lang.Void setMasterSyncMode(javax.sound.midi.Sequencer.SyncMode parameter1) ;
	public abstract java.lang.Void setSlaveSyncMode(javax.sound.midi.Sequencer.SyncMode parameter1) ;
	public abstract java.lang.Void recordDisable(javax.sound.midi.Track parameter1) ;
	public abstract java.lang.Void recordEnable(javax.sound.midi.Track parameter1, java.lang.Integer parameter2) ;
	abstract class SyncMode
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String toString() ;
		public SyncMode(java.lang.String parameter1) ;
		javax.sound.midi.Sequencer.SyncMode INTERNAL_CLOCK;
		javax.sound.midi.Sequencer.SyncMode MIDI_SYNC;
		javax.sound.midi.Sequencer.SyncMode MIDI_TIME_CODE;
		javax.sound.midi.Sequencer.SyncMode NO_SYNC;
	}
}

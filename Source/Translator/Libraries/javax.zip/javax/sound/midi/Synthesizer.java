package javax.sound.midi;

interface Synthesizer implements javax.sound.midi.MidiDevice
{
	public abstract java.lang.Integer getMaxPolyphony() ;
	public abstract java.lang.Long getLatency() ;
	public abstract javax.sound.midi.Instrument[] getAvailableInstruments() ;
	public abstract javax.sound.midi.Instrument[] getLoadedInstruments() ;
	public abstract java.lang.Void unloadInstrument(javax.sound.midi.Instrument parameter1) ;
	public abstract java.lang.Boolean loadInstrument(javax.sound.midi.Instrument parameter1) ;
	public abstract javax.sound.midi.MidiChannel[] getChannels() ;
	public abstract javax.sound.midi.Soundbank getDefaultSoundbank() ;
	public abstract java.lang.Void unloadAllInstruments(javax.sound.midi.Soundbank parameter1) ;
	public abstract java.lang.Boolean isSoundbankSupported(javax.sound.midi.Soundbank parameter1) ;
	public abstract java.lang.Boolean loadAllInstruments(javax.sound.midi.Soundbank parameter1) ;
	public abstract javax.sound.midi.VoiceStatus[] getVoiceStatus() ;
	public abstract java.lang.Boolean remapInstrument(javax.sound.midi.Instrument parameter1, javax.sound.midi.Instrument parameter2) ;
	public abstract java.lang.Void unloadInstruments(javax.sound.midi.Soundbank parameter1, javax.sound.midi.Patch[] parameter2) ;
	public abstract java.lang.Boolean loadInstruments(javax.sound.midi.Soundbank parameter1, javax.sound.midi.Patch[] parameter2) ;
}

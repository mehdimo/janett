package javax.sound.midi;

interface ControllerEventListener implements java.util.EventListener
{
	public abstract java.lang.Void controlChange(javax.sound.midi.ShortMessage parameter1) ;
}

package javax.sound.midi;

interface Transmitter
{
	public abstract java.lang.Void close() ;
	public abstract javax.sound.midi.Receiver getReceiver() ;
	public abstract java.lang.Void setReceiver(javax.sound.midi.Receiver parameter1) ;
}

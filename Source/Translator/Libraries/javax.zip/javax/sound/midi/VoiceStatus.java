package javax.sound.midi;

abstract class VoiceStatus
{
	public VoiceStatus() ;
	java.lang.Boolean active;
	java.lang.Integer channel;
	java.lang.Integer bank;
	java.lang.Integer program;
	java.lang.Integer note;
	java.lang.Integer volume;
}

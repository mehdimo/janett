package javax.sound.midi;

abstract class SysexMessage extends javax.sound.midi.MidiMessage
{
	public java.lang.Byte[] getData() ;
	public java.lang.Void setMessage(java.lang.Integer parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void setMessage(java.lang.Byte[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Object clone() ;
	java.lang.Integer SYSTEM_EXCLUSIVE;
	java.lang.Integer SPECIAL_SYSTEM_EXCLUSIVE;
}

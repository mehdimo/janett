package javax.sound.midi;

abstract class MidiFileFormat
{
	public java.lang.Float getDivisionType() ;
	public java.lang.Integer getByteLength() ;
	public java.lang.Integer getResolution() ;
	public java.lang.Integer getType() ;
	public java.lang.Long getMicrosecondLength() ;
	public MidiFileFormat(java.lang.Integer parameter1, java.lang.Float parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Long parameter5) ;
	java.lang.Integer UNKNOWN_LENGTH;
}

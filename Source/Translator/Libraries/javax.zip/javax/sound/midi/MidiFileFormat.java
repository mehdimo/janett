package javax.sound.midi;

abstract class MidiFileFormat
{
	public java.lang.Float getDivisionType() ;
	public java.lang.Integer getByteLength() ;
	public java.lang.Integer getResolution() ;
	public java.lang.Integer getType() ;
	public java.lang.Long getMicrosecondLength() ;
	java.lang.Integer UNKNOWN_LENGTH;
}

package javax.sound.midi;

interface Soundbank
{
	public abstract java.lang.String getDescription() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getVendor() ;
	public abstract java.lang.String getVersion() ;
	public abstract javax.sound.midi.Instrument[] getInstruments() ;
	public abstract javax.sound.midi.SoundbankResource[] getResources() ;
	public abstract javax.sound.midi.Instrument getInstrument(javax.sound.midi.Patch parameter1) ;
}

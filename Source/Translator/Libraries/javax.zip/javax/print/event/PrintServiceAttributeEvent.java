package javax.print.event;

abstract class PrintServiceAttributeEvent extends javax.print.event.PrintEvent
{
	public javax.print.PrintService getPrintService() ;
	public javax.print.attribute.PrintServiceAttributeSet getAttributes() ;
	public PrintServiceAttributeEvent(javax.print.PrintService parameter1, javax.print.attribute.PrintServiceAttributeSet parameter2) ;
}

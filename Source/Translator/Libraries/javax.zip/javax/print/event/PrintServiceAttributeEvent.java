package javax.print.event;

abstract class PrintServiceAttributeEvent extends javax.print.event.PrintEvent
{
	public javax.print.PrintService getPrintService() ;
	public javax.print.attribute.PrintServiceAttributeSet getAttributes() ;
}

package javax.print.event;

interface PrintServiceAttributeListener
{
	public abstract java.lang.Void attributeUpdate(javax.print.event.PrintServiceAttributeEvent parameter1) ;
}

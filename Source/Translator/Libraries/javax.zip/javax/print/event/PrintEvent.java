package javax.print.event;

abstract class PrintEvent extends java.util.EventObject
{
	public PrintEvent(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

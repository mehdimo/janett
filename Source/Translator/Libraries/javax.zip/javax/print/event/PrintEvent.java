package javax.print.event;

abstract class PrintEvent extends java.util.EventObject
{
	public java.lang.String toString() ;
}

package javax.print.event;

interface PrintJobAttributeListener
{
	public abstract java.lang.Void attributeUpdate(javax.print.event.PrintJobAttributeEvent parameter1) ;
}

package javax.print.event;

abstract class PrintJobEvent extends javax.print.event.PrintEvent
{
	public java.lang.Integer getPrintEventType() ;
	public javax.print.DocPrintJob getPrintJob() ;
	public PrintJobEvent(javax.print.DocPrintJob parameter1, java.lang.Integer parameter2) ;
	java.lang.Integer JOB_CANCELED;
	java.lang.Integer JOB_COMPLETE;
	java.lang.Integer JOB_FAILED;
	java.lang.Integer REQUIRES_ATTENTION;
	java.lang.Integer NO_MORE_EVENTS;
	java.lang.Integer DATA_TRANSFER_COMPLETE;
}

package javax.print.event;

interface PrintJobListener
{
	public abstract java.lang.Void printDataTransferCompleted(javax.print.event.PrintJobEvent parameter1) ;
	public abstract java.lang.Void printJobCanceled(javax.print.event.PrintJobEvent parameter1) ;
	public abstract java.lang.Void printJobCompleted(javax.print.event.PrintJobEvent parameter1) ;
	public abstract java.lang.Void printJobFailed(javax.print.event.PrintJobEvent parameter1) ;
	public abstract java.lang.Void printJobNoMoreEvents(javax.print.event.PrintJobEvent parameter1) ;
	public abstract java.lang.Void printJobRequiresAttention(javax.print.event.PrintJobEvent parameter1) ;
}

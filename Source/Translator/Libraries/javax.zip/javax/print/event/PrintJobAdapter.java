package javax.print.event;

abstract class PrintJobAdapter implements javax.print.event.PrintJobListener
{
	public java.lang.Void printDataTransferCompleted(javax.print.event.PrintJobEvent parameter1) ;
	public java.lang.Void printJobCanceled(javax.print.event.PrintJobEvent parameter1) ;
	public java.lang.Void printJobCompleted(javax.print.event.PrintJobEvent parameter1) ;
	public java.lang.Void printJobFailed(javax.print.event.PrintJobEvent parameter1) ;
	public java.lang.Void printJobNoMoreEvents(javax.print.event.PrintJobEvent parameter1) ;
	public java.lang.Void printJobRequiresAttention(javax.print.event.PrintJobEvent parameter1) ;
}

package javax.print.event;

abstract class PrintJobAttributeEvent extends javax.print.event.PrintEvent
{
	public javax.print.DocPrintJob getPrintJob() ;
	public javax.print.attribute.PrintJobAttributeSet getAttributes() ;
	public PrintJobAttributeEvent(javax.print.DocPrintJob parameter1, javax.print.attribute.PrintJobAttributeSet parameter2) ;
}

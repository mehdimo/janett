package javax.print;

interface MultiDoc
{
	public abstract javax.print.Doc getDoc() ;
	public abstract javax.print.MultiDoc next() ;
}

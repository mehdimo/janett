package javax.print;

interface PrintService
{
	public abstract java.lang.Integer hashCode() ;
	public abstract java.lang.Class[] getSupportedAttributeCategories() ;
	public abstract java.lang.Boolean isAttributeCategorySupported(java.lang.Class parameter1) ;
	public abstract java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String getName() ;
	public abstract javax.print.DocFlavor[] getSupportedDocFlavors() ;
	public abstract java.lang.Boolean isDocFlavorSupported(javax.print.DocFlavor parameter1) ;
	public abstract javax.print.DocPrintJob createPrintJob() ;
	public abstract javax.print.ServiceUIFactory getServiceUIFactory() ;
	public abstract javax.print.attribute.PrintServiceAttributeSet getAttributes() ;
	public abstract java.lang.Void addPrintServiceAttributeListener(javax.print.event.PrintServiceAttributeListener parameter1) ;
	public abstract java.lang.Void removePrintServiceAttributeListener(javax.print.event.PrintServiceAttributeListener parameter1) ;
	public abstract java.lang.Object getDefaultAttributeValue(java.lang.Class parameter1) ;
	public abstract javax.print.attribute.PrintServiceAttribute getAttribute(java.lang.Class parameter1) ;
	public abstract java.lang.Boolean isAttributeValueSupported(javax.print.attribute.Attribute parameter1, javax.print.DocFlavor parameter2, javax.print.attribute.AttributeSet parameter3) ;
	public abstract javax.print.attribute.AttributeSet getUnsupportedAttributes(javax.print.DocFlavor parameter1, javax.print.attribute.AttributeSet parameter2) ;
	public abstract java.lang.Object getSupportedAttributeValues(java.lang.Class parameter1, javax.print.DocFlavor parameter2, javax.print.attribute.AttributeSet parameter3) ;
}

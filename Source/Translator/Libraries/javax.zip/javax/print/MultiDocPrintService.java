package javax.print;

interface MultiDocPrintService implements javax.print.PrintService
{
	public abstract javax.print.MultiDocPrintJob createMultiDocPrintJob() ;
}

package javax.print;

interface FlavorException
{
	public abstract javax.print.DocFlavor[] getUnsupportedFlavors() ;
}

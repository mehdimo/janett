package javax.print.attribute;

abstract class ResolutionSyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer getCrossFeedResolutionDphi() ;
	public java.lang.Integer getFeedResolutionDphi() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer getCrossFeedResolution(java.lang.Integer parameter1) ;
	public java.lang.Integer getFeedResolution(java.lang.Integer parameter1) ;
	public java.lang.Integer[] getResolution(java.lang.Integer parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Boolean lessThanOrEquals(javax.print.attribute.ResolutionSyntax parameter1) ;
	public java.lang.String toString(java.lang.Integer parameter1, java.lang.String parameter2) ;
	java.lang.Integer DPI;
	java.lang.Integer DPCM;
}

package javax.print.attribute;

abstract class SetOfIntegerSyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer hashCode() ;
	public void getMembers() ;
	public java.lang.Integer next(java.lang.Integer parameter1) ;
	public java.lang.Boolean contains(java.lang.Integer parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Boolean contains(javax.print.attribute.IntegerSyntax parameter1) ;
}

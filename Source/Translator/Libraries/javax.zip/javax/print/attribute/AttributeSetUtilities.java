package javax.print.attribute;

abstract class AttributeSetUtilities
{
	public java.lang.Void verifyCategoryForValue(java.lang.Class parameter1, javax.print.attribute.Attribute parameter2) ;
	public javax.print.attribute.AttributeSet synchronizedView(javax.print.attribute.AttributeSet parameter1) ;
	public javax.print.attribute.AttributeSet unmodifiableView(javax.print.attribute.AttributeSet parameter1) ;
	public javax.print.attribute.DocAttributeSet synchronizedView(javax.print.attribute.DocAttributeSet parameter1) ;
	public javax.print.attribute.DocAttributeSet unmodifiableView(javax.print.attribute.DocAttributeSet parameter1) ;
	public javax.print.attribute.PrintJobAttributeSet synchronizedView(javax.print.attribute.PrintJobAttributeSet parameter1) ;
	public javax.print.attribute.PrintJobAttributeSet unmodifiableView(javax.print.attribute.PrintJobAttributeSet parameter1) ;
	public javax.print.attribute.PrintRequestAttributeSet synchronizedView(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
	public javax.print.attribute.PrintRequestAttributeSet unmodifiableView(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
	public javax.print.attribute.PrintServiceAttributeSet synchronizedView(javax.print.attribute.PrintServiceAttributeSet parameter1) ;
	public javax.print.attribute.PrintServiceAttributeSet unmodifiableView(javax.print.attribute.PrintServiceAttributeSet parameter1) ;
	public java.lang.Class verifyAttributeCategory(java.lang.Object parameter1, java.lang.Class parameter2) ;
	public javax.print.attribute.Attribute verifyAttributeValue(java.lang.Object parameter1, java.lang.Class parameter2) ;
}

package javax.print.attribute;

interface SupportedValuesAttribute implements javax.print.attribute.Attribute
{
}

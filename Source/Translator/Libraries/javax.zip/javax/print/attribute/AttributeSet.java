package javax.print.attribute;

interface AttributeSet
{
	public abstract java.lang.Integer hashCode() ;
	public abstract java.lang.Integer size() ;
	public abstract java.lang.Void clear() ;
	public abstract java.lang.Boolean isEmpty() ;
	public abstract java.lang.Boolean containsKey(java.lang.Class parameter1) ;
	public abstract java.lang.Boolean remove(java.lang.Class parameter1) ;
	public abstract java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract javax.print.attribute.Attribute[] toArray() ;
	public abstract java.lang.Boolean add(javax.print.attribute.Attribute parameter1) ;
	public abstract java.lang.Boolean containsValue(javax.print.attribute.Attribute parameter1) ;
	public abstract java.lang.Boolean remove(javax.print.attribute.Attribute parameter1) ;
	public abstract java.lang.Boolean addAll(javax.print.attribute.AttributeSet parameter1) ;
	public abstract javax.print.attribute.Attribute get(java.lang.Class parameter1) ;
}

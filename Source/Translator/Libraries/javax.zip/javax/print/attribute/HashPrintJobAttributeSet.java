package javax.print.attribute;

abstract class HashPrintJobAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.PrintJobAttributeSet, java.io.Serializable
{
}

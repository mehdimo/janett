package javax.print.attribute;

abstract class HashPrintJobAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.PrintJobAttributeSet, java.io.Serializable
{
	public HashPrintJobAttributeSet() ;
	public HashPrintJobAttributeSet(javax.print.attribute.PrintJobAttribute parameter1) ;
	public HashPrintJobAttributeSet(javax.print.attribute.PrintJobAttribute[] parameter1) ;
	public HashPrintJobAttributeSet(javax.print.attribute.PrintJobAttributeSet parameter1) ;
}

package javax.print.attribute;

interface PrintJobAttribute implements javax.print.attribute.Attribute
{
}

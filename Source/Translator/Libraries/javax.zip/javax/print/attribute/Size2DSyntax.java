package javax.print.attribute;

abstract class Size2DSyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer getXMicrometers() ;
	public java.lang.Integer getYMicrometers() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Float getX(java.lang.Integer parameter1) ;
	public java.lang.Float getY(java.lang.Integer parameter1) ;
	public java.lang.Float[] getSize(java.lang.Integer parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Integer parameter1, java.lang.String parameter2) ;
	java.lang.Integer INCH;
	java.lang.Integer MM;
}

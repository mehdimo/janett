package javax.print.attribute;

abstract class HashAttributeSet implements javax.print.attribute.AttributeSet, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Boolean containsKey(java.lang.Class parameter1) ;
	public java.lang.Boolean remove(java.lang.Class parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public javax.print.attribute.Attribute[] toArray() ;
	public java.lang.Boolean add(javax.print.attribute.Attribute parameter1) ;
	public java.lang.Boolean containsValue(javax.print.attribute.Attribute parameter1) ;
	public java.lang.Boolean remove(javax.print.attribute.Attribute parameter1) ;
	public java.lang.Boolean addAll(javax.print.attribute.AttributeSet parameter1) ;
	public javax.print.attribute.Attribute get(java.lang.Class parameter1) ;
}

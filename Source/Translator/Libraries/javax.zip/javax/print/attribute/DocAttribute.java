package javax.print.attribute;

interface DocAttribute implements javax.print.attribute.Attribute
{
}

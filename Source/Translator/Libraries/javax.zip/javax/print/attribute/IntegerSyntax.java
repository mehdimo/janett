package javax.print.attribute;

abstract class IntegerSyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer getValue() ;
	public java.lang.Integer hashCode() ;
	public IntegerSyntax(java.lang.Integer parameter1) ;
	public IntegerSyntax(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

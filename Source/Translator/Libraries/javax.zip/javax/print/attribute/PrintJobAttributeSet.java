package javax.print.attribute;

interface PrintJobAttributeSet implements javax.print.attribute.AttributeSet
{
	public abstract java.lang.Boolean add(javax.print.attribute.Attribute parameter1) ;
	public abstract java.lang.Boolean addAll(javax.print.attribute.AttributeSet parameter1) ;
}

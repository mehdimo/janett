package javax.print.attribute;

interface PrintRequestAttribute implements javax.print.attribute.Attribute
{
}

package javax.print.attribute;

abstract class UnmodifiableSetException extends java.lang.RuntimeException
{
}

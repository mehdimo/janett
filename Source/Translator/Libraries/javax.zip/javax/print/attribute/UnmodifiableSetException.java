package javax.print.attribute;

abstract class UnmodifiableSetException extends java.lang.RuntimeException
{
	public UnmodifiableSetException() ;
	public UnmodifiableSetException(java.lang.String parameter1) ;
}

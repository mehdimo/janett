package javax.print.attribute;

interface PrintServiceAttribute implements javax.print.attribute.Attribute
{
}

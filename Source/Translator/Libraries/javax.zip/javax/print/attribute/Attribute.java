package javax.print.attribute;

interface Attribute implements java.io.Serializable
{
	public abstract java.lang.Class getCategory() ;
	public abstract java.lang.String getName() ;
}

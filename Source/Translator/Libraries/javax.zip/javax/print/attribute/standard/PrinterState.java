package javax.print.attribute.standard;

abstract class PrinterState extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintServiceAttribute
{
	public PrinterState(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PrinterState UNKNOWN;
	javax.print.attribute.standard.PrinterState IDLE;
	javax.print.attribute.standard.PrinterState PROCESSING;
	javax.print.attribute.standard.PrinterState STOPPED;
}

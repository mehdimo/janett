package javax.print.attribute.standard;

abstract class PrinterResolution extends javax.print.attribute.ResolutionSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public PrinterResolution(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

package javax.print.attribute.standard;

abstract class JobSheets extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.JobSheets NONE;
	javax.print.attribute.standard.JobSheets STANDARD;
}

package javax.print.attribute.standard;

abstract class OrientationRequested extends javax.print.attribute.EnumSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public java.lang.Integer getOffset() ;
	public OrientationRequested(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.OrientationRequested PORTRAIT;
	javax.print.attribute.standard.OrientationRequested LANDSCAPE;
	javax.print.attribute.standard.OrientationRequested REVERSE_LANDSCAPE;
	javax.print.attribute.standard.OrientationRequested REVERSE_PORTRAIT;
}

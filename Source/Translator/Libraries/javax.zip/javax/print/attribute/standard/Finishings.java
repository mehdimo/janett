package javax.print.attribute.standard;

abstract class Finishings extends javax.print.attribute.EnumSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public java.lang.Integer getOffset() ;
	public Finishings(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.Finishings NONE;
	javax.print.attribute.standard.Finishings STAPLE;
	javax.print.attribute.standard.Finishings COVER;
	javax.print.attribute.standard.Finishings BIND;
	javax.print.attribute.standard.Finishings SADDLE_STITCH;
	javax.print.attribute.standard.Finishings EDGE_STITCH;
	javax.print.attribute.standard.Finishings STAPLE_TOP_LEFT;
	javax.print.attribute.standard.Finishings STAPLE_BOTTOM_LEFT;
	javax.print.attribute.standard.Finishings STAPLE_TOP_RIGHT;
	javax.print.attribute.standard.Finishings STAPLE_BOTTOM_RIGHT;
	javax.print.attribute.standard.Finishings EDGE_STITCH_LEFT;
	javax.print.attribute.standard.Finishings EDGE_STITCH_TOP;
	javax.print.attribute.standard.Finishings EDGE_STITCH_RIGHT;
	javax.print.attribute.standard.Finishings EDGE_STITCH_BOTTOM;
	javax.print.attribute.standard.Finishings STAPLE_DUAL_LEFT;
	javax.print.attribute.standard.Finishings STAPLE_DUAL_TOP;
	javax.print.attribute.standard.Finishings STAPLE_DUAL_RIGHT;
	javax.print.attribute.standard.Finishings STAPLE_DUAL_BOTTOM;
}

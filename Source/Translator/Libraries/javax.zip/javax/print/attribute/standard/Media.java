package javax.print.attribute.standard;

abstract class Media extends javax.print.attribute.EnumSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public Media(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

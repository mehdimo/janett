package javax.print.attribute.standard;

abstract class ReferenceUriSchemesSupported extends javax.print.attribute.EnumSyntax implements javax.print.attribute.Attribute
{
	public ReferenceUriSchemesSupported(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.ReferenceUriSchemesSupported FTP;
	javax.print.attribute.standard.ReferenceUriSchemesSupported HTTP;
	javax.print.attribute.standard.ReferenceUriSchemesSupported HTTPS;
	javax.print.attribute.standard.ReferenceUriSchemesSupported GOPHER;
	javax.print.attribute.standard.ReferenceUriSchemesSupported NEWS;
	javax.print.attribute.standard.ReferenceUriSchemesSupported NNTP;
	javax.print.attribute.standard.ReferenceUriSchemesSupported WAIS;
	javax.print.attribute.standard.ReferenceUriSchemesSupported FILE;
}

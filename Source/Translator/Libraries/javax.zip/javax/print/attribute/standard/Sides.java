package javax.print.attribute.standard;

abstract class Sides extends javax.print.attribute.EnumSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public Sides(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.Sides ONE_SIDED;
	javax.print.attribute.standard.Sides TWO_SIDED_LONG_EDGE;
	javax.print.attribute.standard.Sides TWO_SIDED_SHORT_EDGE;
	javax.print.attribute.standard.Sides DUPLEX;
	javax.print.attribute.standard.Sides TUMBLE;
}

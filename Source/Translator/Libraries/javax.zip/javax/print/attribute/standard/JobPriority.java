package javax.print.attribute.standard;

abstract class JobPriority extends javax.print.attribute.IntegerSyntax implements javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public JobPriority(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

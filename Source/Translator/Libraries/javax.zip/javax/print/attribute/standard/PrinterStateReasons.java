package javax.print.attribute.standard;

abstract class PrinterStateReasons extends java.util.HashMap implements javax.print.attribute.PrintServiceAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.util.Set printerStateReasonSet(javax.print.attribute.standard.Severity parameter1) ;
	public java.lang.Object put(java.lang.Object parameter1, java.lang.Object parameter2) ;
}

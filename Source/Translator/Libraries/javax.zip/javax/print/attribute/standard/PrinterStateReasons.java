package javax.print.attribute.standard;

abstract class PrinterStateReasons extends java.util.HashMap implements javax.print.attribute.PrintServiceAttribute
{
	public PrinterStateReasons() ;
	public PrinterStateReasons(java.lang.Integer parameter1) ;
	public PrinterStateReasons(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public PrinterStateReasons(java.util.Map parameter1) ;
	public java.util.Set printerStateReasonSet(javax.print.attribute.standard.Severity parameter1) ;
	public java.lang.Object put(java.lang.Object parameter1, java.lang.Object parameter2) ;
}

package javax.print.attribute.standard;

abstract class JobStateReason extends javax.print.attribute.EnumSyntax implements javax.print.attribute.Attribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.JobStateReason JOB_INCOMING;
	javax.print.attribute.standard.JobStateReason JOB_DATA_INSUFFICIENT;
	javax.print.attribute.standard.JobStateReason DOCUMENT_ACCESS_ERROR;
	javax.print.attribute.standard.JobStateReason SUBMISSION_INTERRUPTED;
	javax.print.attribute.standard.JobStateReason JOB_OUTGOING;
	javax.print.attribute.standard.JobStateReason JOB_HOLD_UNTIL_SPECIFIED;
	javax.print.attribute.standard.JobStateReason RESOURCES_ARE_NOT_READY;
	javax.print.attribute.standard.JobStateReason PRINTER_STOPPED_PARTLY;
	javax.print.attribute.standard.JobStateReason PRINTER_STOPPED;
	javax.print.attribute.standard.JobStateReason JOB_INTERPRETING;
	javax.print.attribute.standard.JobStateReason JOB_QUEUED;
	javax.print.attribute.standard.JobStateReason JOB_TRANSFORMING;
	javax.print.attribute.standard.JobStateReason JOB_QUEUED_FOR_MARKER;
	javax.print.attribute.standard.JobStateReason JOB_PRINTING;
	javax.print.attribute.standard.JobStateReason JOB_CANCELED_BY_USER;
	javax.print.attribute.standard.JobStateReason JOB_CANCELED_BY_OPERATOR;
	javax.print.attribute.standard.JobStateReason JOB_CANCELED_AT_DEVICE;
	javax.print.attribute.standard.JobStateReason ABORTED_BY_SYSTEM;
	javax.print.attribute.standard.JobStateReason UNSUPPORTED_COMPRESSION;
	javax.print.attribute.standard.JobStateReason COMPRESSION_ERROR;
	javax.print.attribute.standard.JobStateReason UNSUPPORTED_DOCUMENT_FORMAT;
	javax.print.attribute.standard.JobStateReason DOCUMENT_FORMAT_ERROR;
	javax.print.attribute.standard.JobStateReason PROCESSING_TO_STOP_POINT;
	javax.print.attribute.standard.JobStateReason SERVICE_OFF_LINE;
	javax.print.attribute.standard.JobStateReason JOB_COMPLETED_SUCCESSFULLY;
	javax.print.attribute.standard.JobStateReason JOB_COMPLETED_WITH_WARNINGS;
	javax.print.attribute.standard.JobStateReason JOB_COMPLETED_WITH_ERRORS;
	javax.print.attribute.standard.JobStateReason JOB_RESTARTABLE;
	javax.print.attribute.standard.JobStateReason QUEUED_IN_DEVICE;
}

package javax.print.attribute.standard;

abstract class MediaName extends javax.print.attribute.standard.Media implements javax.print.attribute.Attribute
{
	public MediaName(java.lang.Integer parameter1) ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.MediaName NA_LETTER_WHITE;
	javax.print.attribute.standard.MediaName NA_LETTER_TRANSPARENT;
	javax.print.attribute.standard.MediaName ISO_A4_WHITE;
	javax.print.attribute.standard.MediaName ISO_A4_TRANSPARENT;
}

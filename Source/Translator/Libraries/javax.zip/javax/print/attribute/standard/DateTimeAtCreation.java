package javax.print.attribute.standard;

abstract class DateTimeAtCreation extends javax.print.attribute.DateTimeSyntax implements javax.print.attribute.PrintJobAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public DateTimeAtCreation(java.util.Date parameter1) ;
}

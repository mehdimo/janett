package javax.print.attribute.standard;

abstract class Destination extends javax.print.attribute.URISyntax implements javax.print.attribute.PrintJobAttribute, javax.print.attribute.PrintRequestAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public Destination(java.net.URI parameter1) ;
}

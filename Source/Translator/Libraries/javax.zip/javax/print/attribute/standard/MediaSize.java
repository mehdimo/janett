package javax.print.attribute.standard;

abstract class MediaSize extends javax.print.attribute.Size2DSyntax implements javax.print.attribute.Attribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public javax.print.attribute.standard.MediaSizeName getMediaSizeName() ;
	public javax.print.attribute.standard.MediaSizeName findMedia(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Integer parameter3) ;
	public javax.print.attribute.standard.MediaSize getMediaSizeForName(javax.print.attribute.standard.MediaSizeName parameter1) ;
	abstract class Other
	{
		javax.print.attribute.standard.MediaSize EXECUTIVE;
		javax.print.attribute.standard.MediaSize LEDGER;
		javax.print.attribute.standard.MediaSize INVOICE;
		javax.print.attribute.standard.MediaSize FOLIO;
		javax.print.attribute.standard.MediaSize QUARTO;
		javax.print.attribute.standard.MediaSize ITALY_ENVELOPE;
		javax.print.attribute.standard.MediaSize MONARCH_ENVELOPE;
		javax.print.attribute.standard.MediaSize PERSONAL_ENVELOPE;
		javax.print.attribute.standard.MediaSize JAPANESE_POSTCARD;
		javax.print.attribute.standard.MediaSize JAPANESE_DOUBLE_POSTCARD;
	}
	abstract class JIS
	{
		javax.print.attribute.standard.MediaSize B0;
		javax.print.attribute.standard.MediaSize B1;
		javax.print.attribute.standard.MediaSize B2;
		javax.print.attribute.standard.MediaSize B3;
		javax.print.attribute.standard.MediaSize B4;
		javax.print.attribute.standard.MediaSize B5;
		javax.print.attribute.standard.MediaSize B6;
		javax.print.attribute.standard.MediaSize B7;
		javax.print.attribute.standard.MediaSize B8;
		javax.print.attribute.standard.MediaSize B9;
		javax.print.attribute.standard.MediaSize B10;
		javax.print.attribute.standard.MediaSize CHOU_1;
		javax.print.attribute.standard.MediaSize CHOU_2;
		javax.print.attribute.standard.MediaSize CHOU_3;
		javax.print.attribute.standard.MediaSize CHOU_4;
		javax.print.attribute.standard.MediaSize CHOU_30;
		javax.print.attribute.standard.MediaSize CHOU_40;
		javax.print.attribute.standard.MediaSize KAKU_0;
		javax.print.attribute.standard.MediaSize KAKU_1;
		javax.print.attribute.standard.MediaSize KAKU_2;
		javax.print.attribute.standard.MediaSize KAKU_3;
		javax.print.attribute.standard.MediaSize KAKU_4;
		javax.print.attribute.standard.MediaSize KAKU_5;
		javax.print.attribute.standard.MediaSize KAKU_6;
		javax.print.attribute.standard.MediaSize KAKU_7;
		javax.print.attribute.standard.MediaSize KAKU_8;
		javax.print.attribute.standard.MediaSize KAKU_20;
		javax.print.attribute.standard.MediaSize KAKU_A4;
		javax.print.attribute.standard.MediaSize YOU_1;
		javax.print.attribute.standard.MediaSize YOU_2;
		javax.print.attribute.standard.MediaSize YOU_3;
		javax.print.attribute.standard.MediaSize YOU_4;
		javax.print.attribute.standard.MediaSize YOU_5;
		javax.print.attribute.standard.MediaSize YOU_6;
		javax.print.attribute.standard.MediaSize YOU_7;
	}
	abstract class NA
	{
		javax.print.attribute.standard.MediaSize LETTER;
		javax.print.attribute.standard.MediaSize LEGAL;
		javax.print.attribute.standard.MediaSize NA_5X7;
		javax.print.attribute.standard.MediaSize NA_8X10;
		javax.print.attribute.standard.MediaSize NA_NUMBER_9_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_NUMBER_10_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_NUMBER_11_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_NUMBER_12_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_NUMBER_14_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_6X9_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_7X9_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_9x11_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_9x12_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_10x13_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_10x14_ENVELOPE;
		javax.print.attribute.standard.MediaSize NA_10X15_ENVELOPE;
	}
	abstract class Engineering
	{
		javax.print.attribute.standard.MediaSize A;
		javax.print.attribute.standard.MediaSize B;
		javax.print.attribute.standard.MediaSize C;
		javax.print.attribute.standard.MediaSize D;
		javax.print.attribute.standard.MediaSize E;
	}
	abstract class ISO
	{
		javax.print.attribute.standard.MediaSize A0;
		javax.print.attribute.standard.MediaSize A1;
		javax.print.attribute.standard.MediaSize A2;
		javax.print.attribute.standard.MediaSize A3;
		javax.print.attribute.standard.MediaSize A4;
		javax.print.attribute.standard.MediaSize A5;
		javax.print.attribute.standard.MediaSize A6;
		javax.print.attribute.standard.MediaSize A7;
		javax.print.attribute.standard.MediaSize A8;
		javax.print.attribute.standard.MediaSize A9;
		javax.print.attribute.standard.MediaSize A10;
		javax.print.attribute.standard.MediaSize B0;
		javax.print.attribute.standard.MediaSize B1;
		javax.print.attribute.standard.MediaSize B2;
		javax.print.attribute.standard.MediaSize B3;
		javax.print.attribute.standard.MediaSize B4;
		javax.print.attribute.standard.MediaSize B5;
		javax.print.attribute.standard.MediaSize B6;
		javax.print.attribute.standard.MediaSize B7;
		javax.print.attribute.standard.MediaSize B8;
		javax.print.attribute.standard.MediaSize B9;
		javax.print.attribute.standard.MediaSize B10;
		javax.print.attribute.standard.MediaSize C3;
		javax.print.attribute.standard.MediaSize C4;
		javax.print.attribute.standard.MediaSize C5;
		javax.print.attribute.standard.MediaSize C6;
		javax.print.attribute.standard.MediaSize DESIGNATED_LONG;
	}
}

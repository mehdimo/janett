package javax.print.attribute.standard;

abstract class Fidelity extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintJobAttribute, javax.print.attribute.PrintRequestAttribute
{
	public Fidelity(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.Fidelity FIDELITY_TRUE;
	javax.print.attribute.standard.Fidelity FIDELITY_FALSE;
}

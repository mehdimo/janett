package javax.print.attribute.standard;

abstract class NumberOfDocuments extends javax.print.attribute.IntegerSyntax implements javax.print.attribute.PrintJobAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

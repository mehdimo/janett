package javax.print.attribute.standard;

abstract class PrintQuality extends javax.print.attribute.EnumSyntax implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public java.lang.Integer getOffset() ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PrintQuality DRAFT;
	javax.print.attribute.standard.PrintQuality NORMAL;
	javax.print.attribute.standard.PrintQuality HIGH;
}

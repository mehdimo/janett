package javax.print.attribute.standard;

abstract class MultipleDocumentHandling extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public MultipleDocumentHandling(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.MultipleDocumentHandling SINGLE_DOCUMENT;
	javax.print.attribute.standard.MultipleDocumentHandling SEPARATE_DOCUMENTS_UNCOLLATED_COPIES;
	javax.print.attribute.standard.MultipleDocumentHandling SEPARATE_DOCUMENTS_COLLATED_COPIES;
	javax.print.attribute.standard.MultipleDocumentHandling SINGLE_DOCUMENT_NEW_SHEET;
}

package javax.print.attribute.standard;

abstract class PrinterIsAcceptingJobs extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintServiceAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PrinterIsAcceptingJobs NOT_ACCEPTING_JOBS;
	javax.print.attribute.standard.PrinterIsAcceptingJobs ACCEPTING_JOBS;
}

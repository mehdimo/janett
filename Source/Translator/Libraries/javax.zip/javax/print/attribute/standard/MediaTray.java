package javax.print.attribute.standard;

abstract class MediaTray extends javax.print.attribute.standard.Media implements javax.print.attribute.Attribute
{
	public MediaTray(java.lang.Integer parameter1) ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.MediaTray TOP;
	javax.print.attribute.standard.MediaTray MIDDLE;
	javax.print.attribute.standard.MediaTray BOTTOM;
	javax.print.attribute.standard.MediaTray ENVELOPE;
	javax.print.attribute.standard.MediaTray MANUAL;
	javax.print.attribute.standard.MediaTray LARGE_CAPACITY;
	javax.print.attribute.standard.MediaTray MAIN;
	javax.print.attribute.standard.MediaTray SIDE;
}

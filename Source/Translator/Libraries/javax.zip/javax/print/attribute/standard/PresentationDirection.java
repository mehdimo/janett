package javax.print.attribute.standard;

abstract class PresentationDirection extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintJobAttribute, javax.print.attribute.PrintRequestAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PresentationDirection TOBOTTOM_TORIGHT;
	javax.print.attribute.standard.PresentationDirection TOBOTTOM_TOLEFT;
	javax.print.attribute.standard.PresentationDirection TOTOP_TORIGHT;
	javax.print.attribute.standard.PresentationDirection TOTOP_TOLEFT;
	javax.print.attribute.standard.PresentationDirection TORIGHT_TOBOTTOM;
	javax.print.attribute.standard.PresentationDirection TORIGHT_TOTOP;
	javax.print.attribute.standard.PresentationDirection TOLEFT_TOBOTTOM;
	javax.print.attribute.standard.PresentationDirection TOLEFT_TOTOP;
}

package javax.print.attribute.standard;

abstract class PrinterStateReason extends javax.print.attribute.EnumSyntax implements javax.print.attribute.Attribute
{
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PrinterStateReason OTHER;
	javax.print.attribute.standard.PrinterStateReason MEDIA_NEEDED;
	javax.print.attribute.standard.PrinterStateReason MEDIA_JAM;
	javax.print.attribute.standard.PrinterStateReason MOVING_TO_PAUSED;
	javax.print.attribute.standard.PrinterStateReason PAUSED;
	javax.print.attribute.standard.PrinterStateReason SHUTDOWN;
	javax.print.attribute.standard.PrinterStateReason CONNECTING_TO_DEVICE;
	javax.print.attribute.standard.PrinterStateReason TIMED_OUT;
	javax.print.attribute.standard.PrinterStateReason STOPPING;
	javax.print.attribute.standard.PrinterStateReason STOPPED_PARTLY;
	javax.print.attribute.standard.PrinterStateReason TONER_LOW;
	javax.print.attribute.standard.PrinterStateReason TONER_EMPTY;
	javax.print.attribute.standard.PrinterStateReason SPOOL_AREA_FULL;
	javax.print.attribute.standard.PrinterStateReason COVER_OPEN;
	javax.print.attribute.standard.PrinterStateReason INTERLOCK_OPEN;
	javax.print.attribute.standard.PrinterStateReason DOOR_OPEN;
	javax.print.attribute.standard.PrinterStateReason INPUT_TRAY_MISSING;
	javax.print.attribute.standard.PrinterStateReason MEDIA_LOW;
	javax.print.attribute.standard.PrinterStateReason MEDIA_EMPTY;
	javax.print.attribute.standard.PrinterStateReason OUTPUT_TRAY_MISSING;
	javax.print.attribute.standard.PrinterStateReason OUTPUT_AREA_ALMOST_FULL;
	javax.print.attribute.standard.PrinterStateReason OUTPUT_AREA_FULL;
	javax.print.attribute.standard.PrinterStateReason MARKER_SUPPLY_LOW;
	javax.print.attribute.standard.PrinterStateReason MARKER_SUPPLY_EMPTY;
	javax.print.attribute.standard.PrinterStateReason MARKER_WASTE_ALMOST_FULL;
	javax.print.attribute.standard.PrinterStateReason MARKER_WASTE_FULL;
	javax.print.attribute.standard.PrinterStateReason FUSER_OVER_TEMP;
	javax.print.attribute.standard.PrinterStateReason FUSER_UNDER_TEMP;
	javax.print.attribute.standard.PrinterStateReason OPC_NEAR_EOL;
	javax.print.attribute.standard.PrinterStateReason OPC_LIFE_OVER;
	javax.print.attribute.standard.PrinterStateReason DEVELOPER_LOW;
	javax.print.attribute.standard.PrinterStateReason DEVELOPER_EMPTY;
	javax.print.attribute.standard.PrinterStateReason INTERPRETER_RESOURCE_UNAVAILABLE;
}

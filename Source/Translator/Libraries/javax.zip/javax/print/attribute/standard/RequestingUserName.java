package javax.print.attribute.standard;

abstract class RequestingUserName extends javax.print.attribute.TextSyntax implements javax.print.attribute.PrintRequestAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public RequestingUserName(java.lang.String parameter1, java.util.Locale parameter2) ;
}

package javax.print.attribute.standard;

abstract class PrinterMoreInfo extends javax.print.attribute.URISyntax implements javax.print.attribute.PrintServiceAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public PrinterMoreInfo(java.net.URI parameter1) ;
}

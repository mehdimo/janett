package javax.print.attribute.standard;

abstract class PDLOverrideSupported extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintServiceAttribute
{
	public PDLOverrideSupported(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.PDLOverrideSupported NOT_ATTEMPTED;
	javax.print.attribute.standard.PDLOverrideSupported ATTEMPTED;
}

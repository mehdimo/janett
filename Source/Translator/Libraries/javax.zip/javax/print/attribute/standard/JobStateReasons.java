package javax.print.attribute.standard;

abstract class JobStateReasons extends java.util.HashSet implements javax.print.attribute.PrintJobAttribute
{
	public JobStateReasons() ;
	public JobStateReasons(java.lang.Integer parameter1) ;
	public JobStateReasons(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean add(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public JobStateReasons(java.util.Collection parameter1) ;
}

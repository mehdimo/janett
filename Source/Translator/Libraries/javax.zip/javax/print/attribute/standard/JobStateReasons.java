package javax.print.attribute.standard;

abstract class JobStateReasons extends java.util.HashSet implements javax.print.attribute.PrintJobAttribute
{
	public java.lang.Class getCategory() ;
	public java.lang.Boolean add(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

package javax.print.attribute.standard;

abstract class JobState extends javax.print.attribute.EnumSyntax implements javax.print.attribute.PrintJobAttribute
{
	public JobState(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.String getName() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
	javax.print.attribute.standard.JobState UNKNOWN;
	javax.print.attribute.standard.JobState PENDING;
	javax.print.attribute.standard.JobState PENDING_HELD;
	javax.print.attribute.standard.JobState PROCESSING;
	javax.print.attribute.standard.JobState PROCESSING_STOPPED;
	javax.print.attribute.standard.JobState CANCELED;
	javax.print.attribute.standard.JobState ABORTED;
	javax.print.attribute.standard.JobState COMPLETED;
}

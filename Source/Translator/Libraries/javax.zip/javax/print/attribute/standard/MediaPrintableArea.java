package javax.print.attribute.standard;

abstract class MediaPrintableArea implements javax.print.attribute.DocAttribute, javax.print.attribute.PrintRequestAttribute, javax.print.attribute.PrintJobAttribute
{
	public java.lang.Integer hashCode() ;
	public java.lang.Float getHeight(java.lang.Integer parameter1) ;
	public java.lang.Float getWidth(java.lang.Integer parameter1) ;
	public java.lang.Float getX(java.lang.Integer parameter1) ;
	public java.lang.Float getY(java.lang.Integer parameter1) ;
	public java.lang.Float[] getPrintableArea(java.lang.Integer parameter1) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Integer parameter1, java.lang.String parameter2) ;
	java.lang.Integer INCH;
	java.lang.Integer MM;
}

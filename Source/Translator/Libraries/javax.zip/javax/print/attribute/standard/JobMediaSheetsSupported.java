package javax.print.attribute.standard;

abstract class JobMediaSheetsSupported extends javax.print.attribute.SetOfIntegerSyntax implements javax.print.attribute.SupportedValuesAttribute
{
	public JobMediaSheetsSupported(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Class getCategory() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
}

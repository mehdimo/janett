package javax.print.attribute;

abstract class HashPrintRequestAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.PrintRequestAttributeSet, java.io.Serializable
{
}

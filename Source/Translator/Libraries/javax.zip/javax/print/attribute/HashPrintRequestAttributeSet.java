package javax.print.attribute;

abstract class HashPrintRequestAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.PrintRequestAttributeSet, java.io.Serializable
{
	public HashPrintRequestAttributeSet() ;
	public HashPrintRequestAttributeSet(javax.print.attribute.PrintRequestAttribute parameter1) ;
	public HashPrintRequestAttributeSet(javax.print.attribute.PrintRequestAttribute[] parameter1) ;
	public HashPrintRequestAttributeSet(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
}

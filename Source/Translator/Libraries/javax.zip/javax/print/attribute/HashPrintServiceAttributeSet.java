package javax.print.attribute;

abstract class HashPrintServiceAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.PrintServiceAttributeSet, java.io.Serializable
{
}

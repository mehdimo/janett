package javax.print.attribute;

abstract class EnumSyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer getOffset() ;
	public java.lang.Integer getValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Object clone() ;
	public java.lang.Object readResolve() ;
	public java.lang.String toString() ;
	public java.lang.String[] getStringTable() ;
	public javax.print.attribute.EnumSyntax[] getEnumValueTable() ;
}

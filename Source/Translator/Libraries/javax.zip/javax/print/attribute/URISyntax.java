package javax.print.attribute;

abstract class URISyntax implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.net.URI getURI() ;
	public URISyntax(java.net.URI parameter1) ;
}

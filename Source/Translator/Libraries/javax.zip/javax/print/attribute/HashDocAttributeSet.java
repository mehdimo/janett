package javax.print.attribute;

abstract class HashDocAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.DocAttributeSet, java.io.Serializable
{
	public HashDocAttributeSet() ;
	public HashDocAttributeSet(javax.print.attribute.DocAttribute parameter1) ;
	public HashDocAttributeSet(javax.print.attribute.DocAttribute[] parameter1) ;
	public HashDocAttributeSet(javax.print.attribute.DocAttributeSet parameter1) ;
}

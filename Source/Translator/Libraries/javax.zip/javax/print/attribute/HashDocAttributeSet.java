package javax.print.attribute;

abstract class HashDocAttributeSet extends javax.print.attribute.HashAttributeSet implements javax.print.attribute.DocAttributeSet, java.io.Serializable
{
}

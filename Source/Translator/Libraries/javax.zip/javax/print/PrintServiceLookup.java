package javax.print;

abstract class PrintServiceLookup
{
	public abstract javax.print.PrintService getDefaultPrintService() ;
	public javax.print.PrintService lookupDefaultPrintService() ;
	public abstract javax.print.PrintService[] getPrintServices() ;
	public java.lang.Boolean registerService(javax.print.PrintService parameter1) ;
	public java.lang.Boolean registerServiceProvider(javax.print.PrintServiceLookup parameter1) ;
	public abstract javax.print.MultiDocPrintService[] getMultiDocPrintServices(javax.print.DocFlavor[] parameter1, javax.print.attribute.AttributeSet parameter2) ;
	public javax.print.MultiDocPrintService[] lookupMultiDocPrintServices(javax.print.DocFlavor[] parameter1, javax.print.attribute.AttributeSet parameter2) ;
	public abstract javax.print.PrintService[] getPrintServices(javax.print.DocFlavor parameter1, javax.print.attribute.AttributeSet parameter2) ;
	public javax.print.PrintService[] lookupPrintServices(javax.print.DocFlavor parameter1, javax.print.attribute.AttributeSet parameter2) ;
}

package javax.print;

abstract class StreamPrintService implements javax.print.PrintService
{
	public java.lang.Void dispose() ;
	public java.lang.Boolean isDisposed() ;
	public java.io.OutputStream getOutputStream() ;
	public abstract java.lang.String getOutputFormat() ;
}

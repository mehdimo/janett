package javax.print;

abstract class ServiceUI
{
	public javax.print.PrintService printDialog(java.awt.GraphicsConfiguration parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, javax.print.PrintService[] parameter4, javax.print.PrintService parameter5, javax.print.DocFlavor parameter6, javax.print.attribute.PrintRequestAttributeSet parameter7) ;
}

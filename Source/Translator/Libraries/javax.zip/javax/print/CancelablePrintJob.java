package javax.print;

interface CancelablePrintJob implements javax.print.DocPrintJob
{
	public abstract java.lang.Void cancel() ;
}

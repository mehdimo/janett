package javax.print;

interface MultiDocPrintJob implements javax.print.DocPrintJob
{
	public abstract java.lang.Void print(javax.print.MultiDoc parameter1, javax.print.attribute.PrintRequestAttributeSet parameter2) ;
}

package javax.print;

interface AttributeException
{
	public abstract java.lang.Class[] getUnsupportedAttributes() ;
	public abstract javax.print.attribute.Attribute[] getUnsupportedValues() ;
}

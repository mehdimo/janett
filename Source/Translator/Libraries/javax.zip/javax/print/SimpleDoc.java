package javax.print;

abstract class SimpleDoc implements javax.print.Doc
{
	public java.io.InputStream getStreamForBytes() ;
	public java.io.Reader getReaderForText() ;
	public java.lang.Object getPrintData() ;
	public javax.print.DocFlavor getDocFlavor() ;
	public javax.print.attribute.DocAttributeSet getAttributes() ;
}

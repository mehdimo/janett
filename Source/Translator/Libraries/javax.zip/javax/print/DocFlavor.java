package javax.print;

abstract class DocFlavor implements java.io.Serializable, java.lang.Cloneable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getMediaSubtype() ;
	public java.lang.String getMediaType() ;
	public java.lang.String getMimeType() ;
	public java.lang.String getRepresentationClassName() ;
	public java.lang.String toString() ;
	public java.lang.String getParameter(java.lang.String parameter1) ;
	public DocFlavor(java.lang.String parameter1, java.lang.String parameter2) ;
	java.lang.String hostEncoding;
	abstract class SERVICE_FORMATTED extends javax.print.DocFlavor
	{
		public SERVICE_FORMATTED(java.lang.String parameter1) ;
		javax.print.DocFlavor.SERVICE_FORMATTED RENDERABLE_IMAGE;
		javax.print.DocFlavor.SERVICE_FORMATTED PRINTABLE;
		javax.print.DocFlavor.SERVICE_FORMATTED PAGEABLE;
	}
	abstract class URL extends javax.print.DocFlavor
	{
		public URL(java.lang.String parameter1) ;
		javax.print.DocFlavor.URL TEXT_PLAIN_HOST;
		javax.print.DocFlavor.URL TEXT_PLAIN_UTF_8;
		javax.print.DocFlavor.URL TEXT_PLAIN_UTF_16;
		javax.print.DocFlavor.URL TEXT_PLAIN_UTF_16BE;
		javax.print.DocFlavor.URL TEXT_PLAIN_UTF_16LE;
		javax.print.DocFlavor.URL TEXT_PLAIN_US_ASCII;
		javax.print.DocFlavor.URL TEXT_HTML_HOST;
		javax.print.DocFlavor.URL TEXT_HTML_UTF_8;
		javax.print.DocFlavor.URL TEXT_HTML_UTF_16;
		javax.print.DocFlavor.URL TEXT_HTML_UTF_16BE;
		javax.print.DocFlavor.URL TEXT_HTML_UTF_16LE;
		javax.print.DocFlavor.URL TEXT_HTML_US_ASCII;
		javax.print.DocFlavor.URL PDF;
		javax.print.DocFlavor.URL POSTSCRIPT;
		javax.print.DocFlavor.URL PCL;
		javax.print.DocFlavor.URL GIF;
		javax.print.DocFlavor.URL JPEG;
		javax.print.DocFlavor.URL PNG;
		javax.print.DocFlavor.URL AUTOSENSE;
	}
	abstract class INPUT_STREAM extends javax.print.DocFlavor
	{
		public INPUT_STREAM(java.lang.String parameter1) ;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_HOST;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_UTF_8;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_UTF_16;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_UTF_16BE;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_UTF_16LE;
		javax.print.DocFlavor.INPUT_STREAM TEXT_PLAIN_US_ASCII;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_HOST;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_UTF_8;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_UTF_16;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_UTF_16BE;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_UTF_16LE;
		javax.print.DocFlavor.INPUT_STREAM TEXT_HTML_US_ASCII;
		javax.print.DocFlavor.INPUT_STREAM PDF;
		javax.print.DocFlavor.INPUT_STREAM POSTSCRIPT;
		javax.print.DocFlavor.INPUT_STREAM PCL;
		javax.print.DocFlavor.INPUT_STREAM GIF;
		javax.print.DocFlavor.INPUT_STREAM JPEG;
		javax.print.DocFlavor.INPUT_STREAM PNG;
		javax.print.DocFlavor.INPUT_STREAM AUTOSENSE;
	}
	abstract class READER extends javax.print.DocFlavor
	{
		public READER(java.lang.String parameter1) ;
		javax.print.DocFlavor.READER TEXT_PLAIN;
		javax.print.DocFlavor.READER TEXT_HTML;
	}
	abstract class STRING extends javax.print.DocFlavor
	{
		public STRING(java.lang.String parameter1) ;
		javax.print.DocFlavor.STRING TEXT_PLAIN;
		javax.print.DocFlavor.STRING TEXT_HTML;
	}
	abstract class CHAR_ARRAY extends javax.print.DocFlavor
	{
		public CHAR_ARRAY(java.lang.String parameter1) ;
		javax.print.DocFlavor.CHAR_ARRAY TEXT_PLAIN;
		javax.print.DocFlavor.CHAR_ARRAY TEXT_HTML;
	}
	abstract class BYTE_ARRAY extends javax.print.DocFlavor
	{
		public BYTE_ARRAY(java.lang.String parameter1) ;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_HOST;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_UTF_8;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_UTF_16;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_UTF_16BE;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_UTF_16LE;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_PLAIN_US_ASCII;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_HOST;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_UTF_8;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_UTF_16;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_UTF_16BE;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_UTF_16LE;
		javax.print.DocFlavor.BYTE_ARRAY TEXT_HTML_US_ASCII;
		javax.print.DocFlavor.BYTE_ARRAY PDF;
		javax.print.DocFlavor.BYTE_ARRAY POSTSCRIPT;
		javax.print.DocFlavor.BYTE_ARRAY PCL;
		javax.print.DocFlavor.BYTE_ARRAY GIF;
		javax.print.DocFlavor.BYTE_ARRAY JPEG;
		javax.print.DocFlavor.BYTE_ARRAY PNG;
		javax.print.DocFlavor.BYTE_ARRAY AUTOSENSE;
	}
}

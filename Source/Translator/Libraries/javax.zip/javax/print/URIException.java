package javax.print;

interface URIException
{
	public abstract java.lang.Integer getReason() ;
	public abstract java.net.URI getUnsupportedURI() ;
	java.lang.Integer URIInaccessible;
	java.lang.Integer URISchemeNotSupported;
	java.lang.Integer URIOtherProblem;
}

package javax.print;

abstract class StreamPrintServiceFactory
{
	public abstract java.lang.String getOutputFormat() ;
	public abstract javax.print.DocFlavor[] getSupportedDocFlavors() ;
	public abstract javax.print.StreamPrintService getPrintService(java.io.OutputStream parameter1) ;
	public javax.print.StreamPrintServiceFactory[] lookupStreamPrintServiceFactories(javax.print.DocFlavor parameter1, java.lang.String parameter2) ;
}

package javax.print;

interface Doc
{
	public abstract java.io.InputStream getStreamForBytes() ;
	public abstract java.io.Reader getReaderForText() ;
	public abstract java.lang.Object getPrintData() ;
	public abstract javax.print.DocFlavor getDocFlavor() ;
	public abstract javax.print.attribute.DocAttributeSet getAttributes() ;
}

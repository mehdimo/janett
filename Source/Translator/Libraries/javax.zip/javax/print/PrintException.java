package javax.print;

abstract class PrintException extends java.lang.Exception
{
}

package javax.print;

abstract class PrintException extends java.lang.Exception
{
	public PrintException() ;
	public PrintException(java.lang.Exception parameter1) ;
	public PrintException(java.lang.String parameter1) ;
	public PrintException(java.lang.String parameter1, java.lang.Exception parameter2) ;
}

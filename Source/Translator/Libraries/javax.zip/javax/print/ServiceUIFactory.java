package javax.print;

abstract class ServiceUIFactory
{
	public ServiceUIFactory() ;
	public abstract java.lang.String[] getUIClassNamesForRole(java.lang.Integer parameter1) ;
	public abstract java.lang.Object getUI(java.lang.Integer parameter1, java.lang.String parameter2) ;
	java.lang.String JCOMPONENT_UI;
	java.lang.String PANEL_UI;
	java.lang.String DIALOG_UI;
	java.lang.String JDIALOG_UI;
	java.lang.Integer ABOUT_UIROLE;
	java.lang.Integer ADMIN_UIROLE;
	java.lang.Integer MAIN_UIROLE;
	java.lang.Integer RESERVED_UIROLE;
}

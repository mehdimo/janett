package javax.print;

interface DocPrintJob
{
	public abstract javax.print.PrintService getPrintService() ;
	public abstract javax.print.attribute.PrintJobAttributeSet getAttributes() ;
	public abstract java.lang.Void removePrintJobAttributeListener(javax.print.event.PrintJobAttributeListener parameter1) ;
	public abstract java.lang.Void addPrintJobListener(javax.print.event.PrintJobListener parameter1) ;
	public abstract java.lang.Void removePrintJobListener(javax.print.event.PrintJobListener parameter1) ;
	public abstract java.lang.Void addPrintJobAttributeListener(javax.print.event.PrintJobAttributeListener parameter1, javax.print.attribute.PrintJobAttributeSet parameter2) ;
	public abstract java.lang.Void print(javax.print.Doc parameter1, javax.print.attribute.PrintRequestAttributeSet parameter2) ;
}

package org.apache.commons.logging.impl;

abstract class LogFactoryImpl extends org.apache.commons.logging.LogFactory
{
	public LogFactoryImpl() ;
	public java.lang.Object getAttribute(java.lang.String parameter1) ;
	public java.lang.String[] getAttributeNames() ;
	public org.apache.commons.logging.Log getInstance(java.lang.Class parameter1) ;
	public org.apache.commons.logging.Log getInstance(java.lang.String parameter1) ;
	public java.lang.Void release() ;
	public java.lang.Void removeAttribute(java.lang.String parameter1) ;
	public java.lang.Void setAttribute(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.String getLogClassName() ;
	public java.lang.reflect.Constructor getLogConstructor() ;
	public java.lang.Boolean isJdk13LumberjackAvailable() ;
	public java.lang.Boolean isJdk14Available() ;
	public java.lang.Boolean isLog4JAvailable() ;
	public org.apache.commons.logging.Log newInstance(java.lang.String parameter1) ;
	java.lang.String LOG_PROPERTY;
}

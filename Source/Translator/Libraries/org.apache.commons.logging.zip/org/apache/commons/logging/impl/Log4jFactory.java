package org.apache.commons.logging.impl;

abstract class Log4jFactory extends org.apache.commons.logging.LogFactory
{
	public java.lang.Object getAttribute(java.lang.String parameter1) ;
	public java.lang.String[] getAttributeNames() ;
	public org.apache.commons.logging.Log getInstance(java.lang.Class parameter1) ;
	public org.apache.commons.logging.Log getInstance(java.lang.String parameter1) ;
	public java.lang.Void release() ;
	public java.lang.Void removeAttribute(java.lang.String parameter1) ;
	public java.lang.Void setAttribute(java.lang.String parameter1, java.lang.Object parameter2) ;
}

package org.apache.commons.logging;

abstract class LogSource
{
	public java.lang.Void setLogImplementation(java.lang.String parameter1) ;
	public java.lang.Void setLogImplementation(java.lang.Class parameter1) ;
	public org.apache.commons.logging.Log getInstance(java.lang.String parameter1) ;
	public org.apache.commons.logging.Log getInstance(java.lang.Class parameter1) ;
	public org.apache.commons.logging.Log makeNewLogInstance(java.lang.String parameter1) ;
	public java.lang.String[] getLogNames() ;
}

package org.apache.commons.logging;

interface Log
{
	public abstract java.lang.Boolean isDebugEnabled() ;
	public abstract java.lang.Boolean isErrorEnabled() ;
	public abstract java.lang.Boolean isFatalEnabled() ;
	public abstract java.lang.Boolean isInfoEnabled() ;
	public abstract java.lang.Boolean isTraceEnabled() ;
	public abstract java.lang.Boolean isWarnEnabled() ;
	public abstract java.lang.Void trace(java.lang.Object parameter1) ;
	public abstract java.lang.Void trace(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void debug(java.lang.Object parameter1) ;
	public abstract java.lang.Void debug(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void info(java.lang.Object parameter1) ;
	public abstract java.lang.Void info(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void warn(java.lang.Object parameter1) ;
	public abstract java.lang.Void warn(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void error(java.lang.Object parameter1) ;
	public abstract java.lang.Void error(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void fatal(java.lang.Object parameter1) ;
	public abstract java.lang.Void fatal(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
}

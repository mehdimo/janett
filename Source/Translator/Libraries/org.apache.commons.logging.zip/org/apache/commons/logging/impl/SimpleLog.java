package org.apache.commons.logging.impl;

abstract class SimpleLog implements org.apache.commons.logging.Log, java.io.Serializable
{
	public java.lang.Void setLevel(java.lang.Integer parameter1) ;
	public java.lang.Integer getLevel() ;
	public java.lang.Void log(java.lang.Integer parameter1, java.lang.Object parameter2, java.lang.Throwable parameter3) ;
	public java.lang.Void write(java.lang.StringBuffer parameter1) ;
	public java.lang.Boolean isLevelEnabled(java.lang.Integer parameter1) ;
	public java.lang.Void debug(java.lang.Object parameter1) ;
	public java.lang.Void debug(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void trace(java.lang.Object parameter1) ;
	public java.lang.Void trace(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void info(java.lang.Object parameter1) ;
	public java.lang.Void info(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void warn(java.lang.Object parameter1) ;
	public java.lang.Void warn(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void error(java.lang.Object parameter1) ;
	public java.lang.Void error(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void fatal(java.lang.Object parameter1) ;
	public java.lang.Void fatal(java.lang.Object parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Boolean isDebugEnabled() ;
	public java.lang.Boolean isErrorEnabled() ;
	public java.lang.Boolean isFatalEnabled() ;
	public java.lang.Boolean isInfoEnabled() ;
	public java.lang.Boolean isTraceEnabled() ;
	public java.lang.Boolean isWarnEnabled() ;
	java.lang.Integer LOG_LEVEL_TRACE;
	java.lang.Integer LOG_LEVEL_DEBUG;
	java.lang.Integer LOG_LEVEL_INFO;
	java.lang.Integer LOG_LEVEL_WARN;
	java.lang.Integer LOG_LEVEL_ERROR;
	java.lang.Integer LOG_LEVEL_FATAL;
	java.lang.Integer LOG_LEVEL_ALL;
	java.lang.Integer LOG_LEVEL_OFF;
}

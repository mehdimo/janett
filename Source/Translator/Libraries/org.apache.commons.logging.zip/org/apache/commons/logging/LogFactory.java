package org.apache.commons.logging;

abstract class LogFactory
{
	public LogFactory() ;
	public abstract java.lang.Object getAttribute(java.lang.String parameter1) ;
	public abstract java.lang.String[] getAttributeNames() ;
	public abstract org.apache.commons.logging.Log getInstance(java.lang.Class parameter1) ;
	public abstract org.apache.commons.logging.Log getInstance(java.lang.String parameter1) ;
	public abstract java.lang.Void release() ;
	public abstract java.lang.Void removeAttribute(java.lang.String parameter1) ;
	public abstract java.lang.Void setAttribute(java.lang.String parameter1, java.lang.Object parameter2) ;
	public org.apache.commons.logging.LogFactory getFactory() ;
	public org.apache.commons.logging.Log getLog(java.lang.Class parameter1) ;
	public org.apache.commons.logging.Log getLog(java.lang.String parameter1) ;
	public java.lang.Void release(java.lang.ClassLoader parameter1) ;
	public java.lang.Void releaseAll() ;
	public java.lang.ClassLoader getContextClassLoader() ;
	public org.apache.commons.logging.LogFactory newFactory(java.lang.String parameter1, java.lang.ClassLoader parameter2) ;
	java.lang.String FACTORY_PROPERTY;
	java.lang.String FACTORY_DEFAULT;
	java.lang.String FACTORY_PROPERTIES;
}

package org.apache.commons.logging;

abstract class LogConfigurationException extends java.lang.RuntimeException
{
	public java.lang.Throwable getCause() ;
}

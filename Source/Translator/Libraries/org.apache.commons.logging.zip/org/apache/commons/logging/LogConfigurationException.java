package org.apache.commons.logging;

abstract class LogConfigurationException extends java.lang.RuntimeException
{
	public LogConfigurationException() ;
	public LogConfigurationException(java.lang.String parameter1) ;
	public LogConfigurationException(java.lang.Throwable parameter1) ;
	public LogConfigurationException(java.lang.String parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Throwable getCause() ;
}

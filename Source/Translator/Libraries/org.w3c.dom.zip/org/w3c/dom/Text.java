package org.w3c.dom;

interface Text implements org.w3c.dom.CharacterData
{
	public abstract org.w3c.dom.Text splitText(java.lang.Integer parameter1) ;
}

package org.w3c.dom.views;

interface AbstractView
{
	public abstract org.w3c.dom.views.DocumentView getDocument() ;
}

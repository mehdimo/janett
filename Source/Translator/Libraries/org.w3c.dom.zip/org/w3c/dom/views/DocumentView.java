package org.w3c.dom.views;

interface DocumentView
{
	public abstract org.w3c.dom.views.AbstractView getDefaultView() ;
}

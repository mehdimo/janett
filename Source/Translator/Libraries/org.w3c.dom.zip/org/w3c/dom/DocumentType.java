package org.w3c.dom;

interface DocumentType implements org.w3c.dom.Node
{
	public abstract java.lang.String getInternalSubset() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getPublicId() ;
	public abstract java.lang.String getSystemId() ;
	public abstract org.w3c.dom.NamedNodeMap getEntities() ;
	public abstract org.w3c.dom.NamedNodeMap getNotations() ;
}

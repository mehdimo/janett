package org.w3c.dom;

interface CharacterData implements org.w3c.dom.Node
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.Void deleteData(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String getData() ;
	public abstract java.lang.String substringData(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void replaceData(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void insertData(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void appendData(java.lang.String parameter1) ;
	public abstract java.lang.Void setData(java.lang.String parameter1) ;
}

package org.w3c.dom;

interface NodeList
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.Node item(java.lang.Integer parameter1) ;
}

package org.w3c.dom;

interface ProcessingInstruction implements org.w3c.dom.Node
{
	public abstract java.lang.String getData() ;
	public abstract java.lang.String getTarget() ;
	public abstract java.lang.Void setData(java.lang.String parameter1) ;
}

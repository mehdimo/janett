package org.w3c.dom;

interface EntityReference implements org.w3c.dom.Node
{
}

package org.w3c.dom;

interface Entity implements org.w3c.dom.Node
{
	public abstract java.lang.String getNotationName() ;
	public abstract java.lang.String getPublicId() ;
	public abstract java.lang.String getSystemId() ;
}

package org.w3c.dom;

interface Document implements org.w3c.dom.Node
{
	public abstract org.w3c.dom.DOMImplementation getImplementation() ;
	public abstract org.w3c.dom.DocumentFragment createDocumentFragment() ;
	public abstract org.w3c.dom.DocumentType getDoctype() ;
	public abstract org.w3c.dom.Element getDocumentElement() ;
	public abstract org.w3c.dom.Attr createAttribute(java.lang.String parameter1) ;
	public abstract org.w3c.dom.CDATASection createCDATASection(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Comment createComment(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Element createElement(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Element getElementById(java.lang.String parameter1) ;
	public abstract org.w3c.dom.EntityReference createEntityReference(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Node importNode(org.w3c.dom.Node parameter1, java.lang.Boolean parameter2) ;
	public abstract org.w3c.dom.NodeList getElementsByTagName(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Text createTextNode(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Attr createAttributeNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.Element createElementNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.NodeList getElementsByTagNameNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.ProcessingInstruction createProcessingInstruction(java.lang.String parameter1, java.lang.String parameter2) ;
}

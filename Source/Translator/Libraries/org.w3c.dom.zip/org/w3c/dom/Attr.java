package org.w3c.dom;

interface Attr implements org.w3c.dom.Node
{
	public abstract java.lang.Boolean getSpecified() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Element getOwnerElement() ;
}

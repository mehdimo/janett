package org.w3c.dom;

interface Comment implements org.w3c.dom.CharacterData
{
}

package org.w3c.dom.events;

interface EventTarget
{
	public abstract java.lang.Boolean dispatchEvent(org.w3c.dom.events.Event parameter1) ;
	public abstract java.lang.Void addEventListener(java.lang.String parameter1, org.w3c.dom.events.EventListener parameter2, java.lang.Boolean parameter3) ;
	public abstract java.lang.Void removeEventListener(java.lang.String parameter1, org.w3c.dom.events.EventListener parameter2, java.lang.Boolean parameter3) ;
}

package org.w3c.dom.events;

interface UIEvent implements org.w3c.dom.events.Event
{
	public abstract java.lang.Integer getDetail() ;
	public abstract org.w3c.dom.views.AbstractView getView() ;
	public abstract java.lang.Void initUIEvent(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3, org.w3c.dom.views.AbstractView parameter4, java.lang.Integer parameter5) ;
}

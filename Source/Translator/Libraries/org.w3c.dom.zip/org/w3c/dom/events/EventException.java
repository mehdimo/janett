package org.w3c.dom.events;

abstract class EventException extends java.lang.RuntimeException
{
	java.lang.Short code;
	java.lang.Short UNSPECIFIED_EVENT_TYPE_ERR;
}

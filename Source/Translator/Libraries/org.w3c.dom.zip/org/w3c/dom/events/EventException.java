package org.w3c.dom.events;

abstract class EventException extends java.lang.RuntimeException
{
	public EventException(java.lang.Short parameter1, java.lang.String parameter2) ;
	java.lang.Short code;
	java.lang.Short UNSPECIFIED_EVENT_TYPE_ERR;
}

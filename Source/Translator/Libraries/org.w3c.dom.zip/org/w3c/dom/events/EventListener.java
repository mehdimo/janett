package org.w3c.dom.events;

interface EventListener
{
	public abstract java.lang.Void handleEvent(org.w3c.dom.events.Event parameter1) ;
}

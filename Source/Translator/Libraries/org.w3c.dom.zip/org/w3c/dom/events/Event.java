package org.w3c.dom.events;

interface Event
{
	public abstract java.lang.Long getTimeStamp() ;
	public abstract java.lang.Short getEventPhase() ;
	public abstract java.lang.Void preventDefault() ;
	public abstract java.lang.Void stopPropagation() ;
	public abstract java.lang.Boolean getBubbles() ;
	public abstract java.lang.Boolean getCancelable() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.Void initEvent(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public abstract org.w3c.dom.events.EventTarget getCurrentTarget() ;
	public abstract org.w3c.dom.events.EventTarget getTarget() ;
	java.lang.Short CAPTURING_PHASE;
	java.lang.Short AT_TARGET;
	java.lang.Short BUBBLING_PHASE;
}

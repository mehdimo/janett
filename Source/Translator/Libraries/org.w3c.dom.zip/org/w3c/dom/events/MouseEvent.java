package org.w3c.dom.events;

interface MouseEvent implements org.w3c.dom.events.UIEvent
{
	public abstract java.lang.Integer getClientX() ;
	public abstract java.lang.Integer getClientY() ;
	public abstract java.lang.Integer getScreenX() ;
	public abstract java.lang.Integer getScreenY() ;
	public abstract java.lang.Short getButton() ;
	public abstract java.lang.Boolean getAltKey() ;
	public abstract java.lang.Boolean getCtrlKey() ;
	public abstract java.lang.Boolean getMetaKey() ;
	public abstract java.lang.Boolean getShiftKey() ;
	public abstract org.w3c.dom.events.EventTarget getRelatedTarget() ;
	public abstract java.lang.Void initMouseEvent(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3, org.w3c.dom.views.AbstractView parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9, java.lang.Boolean parameter10, 
	java.lang.Boolean parameter11, java.lang.Boolean parameter12, java.lang.Boolean parameter13, java.lang.Short parameter14, org.w3c.dom.events.EventTarget parameter15) ;
}

package org.w3c.dom.events;

interface DocumentEvent
{
	public abstract org.w3c.dom.events.Event createEvent(java.lang.String parameter1) ;
}

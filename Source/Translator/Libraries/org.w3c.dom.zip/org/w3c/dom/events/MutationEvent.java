package org.w3c.dom.events;

interface MutationEvent implements org.w3c.dom.events.Event
{
	public abstract java.lang.Short getAttrChange() ;
	public abstract java.lang.String getAttrName() ;
	public abstract java.lang.String getNewValue() ;
	public abstract java.lang.String getPrevValue() ;
	public abstract org.w3c.dom.Node getRelatedNode() ;
	public abstract java.lang.Void initMutationEvent(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3, org.w3c.dom.Node parameter4, java.lang.String parameter5, java.lang.String parameter6, java.lang.String parameter7, java.lang.Short parameter8) ;
	java.lang.Short MODIFICATION;
	java.lang.Short ADDITION;
	java.lang.Short REMOVAL;
}

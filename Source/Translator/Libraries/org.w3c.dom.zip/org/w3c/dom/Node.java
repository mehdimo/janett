package org.w3c.dom;

interface Node
{
	public abstract java.lang.Short getNodeType() ;
	public abstract java.lang.Void normalize() ;
	public abstract java.lang.Boolean hasAttributes() ;
	public abstract java.lang.Boolean hasChildNodes() ;
	public abstract java.lang.String getLocalName() ;
	public abstract java.lang.String getNamespaceURI() ;
	public abstract java.lang.String getNodeName() ;
	public abstract java.lang.String getNodeValue() ;
	public abstract java.lang.String getPrefix() ;
	public abstract java.lang.Void setNodeValue(java.lang.String parameter1) ;
	public abstract java.lang.Void setPrefix(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Document getOwnerDocument() ;
	public abstract org.w3c.dom.NamedNodeMap getAttributes() ;
	public abstract org.w3c.dom.Node getFirstChild() ;
	public abstract org.w3c.dom.Node getLastChild() ;
	public abstract org.w3c.dom.Node getNextSibling() ;
	public abstract org.w3c.dom.Node getParentNode() ;
	public abstract org.w3c.dom.Node getPreviousSibling() ;
	public abstract org.w3c.dom.Node cloneNode(java.lang.Boolean parameter1) ;
	public abstract org.w3c.dom.NodeList getChildNodes() ;
	public abstract java.lang.Boolean isSupported(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.Node appendChild(org.w3c.dom.Node parameter1) ;
	public abstract org.w3c.dom.Node removeChild(org.w3c.dom.Node parameter1) ;
	public abstract org.w3c.dom.Node insertBefore(org.w3c.dom.Node parameter1, org.w3c.dom.Node parameter2) ;
	public abstract org.w3c.dom.Node replaceChild(org.w3c.dom.Node parameter1, org.w3c.dom.Node parameter2) ;
	java.lang.Short ELEMENT_NODE;
	java.lang.Short ATTRIBUTE_NODE;
	java.lang.Short TEXT_NODE;
	java.lang.Short CDATA_SECTION_NODE;
	java.lang.Short ENTITY_REFERENCE_NODE;
	java.lang.Short ENTITY_NODE;
	java.lang.Short PROCESSING_INSTRUCTION_NODE;
	java.lang.Short COMMENT_NODE;
	java.lang.Short DOCUMENT_NODE;
	java.lang.Short DOCUMENT_TYPE_NODE;
	java.lang.Short DOCUMENT_FRAGMENT_NODE;
	java.lang.Short NOTATION_NODE;
}

package org.w3c.dom.css;

interface ElementCSSInlineStyle
{
	public abstract org.w3c.dom.css.CSSStyleDeclaration getStyle() ;
}

package org.w3c.dom.css;

interface ViewCSS implements org.w3c.dom.views.AbstractView
{
	public abstract org.w3c.dom.css.CSSStyleDeclaration getComputedStyle(org.w3c.dom.Element parameter1, java.lang.String parameter2) ;
}

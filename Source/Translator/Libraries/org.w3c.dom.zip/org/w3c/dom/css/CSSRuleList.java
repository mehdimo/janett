package org.w3c.dom.css;

interface CSSRuleList
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.css.CSSRule item(java.lang.Integer parameter1) ;
}

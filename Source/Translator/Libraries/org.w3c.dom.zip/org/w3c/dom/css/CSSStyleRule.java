package org.w3c.dom.css;

interface CSSStyleRule implements org.w3c.dom.css.CSSRule
{
	public abstract java.lang.String getSelectorText() ;
	public abstract java.lang.Void setSelectorText(java.lang.String parameter1) ;
	public abstract org.w3c.dom.css.CSSStyleDeclaration getStyle() ;
}

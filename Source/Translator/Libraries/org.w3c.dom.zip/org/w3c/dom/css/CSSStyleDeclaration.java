package org.w3c.dom.css;

interface CSSStyleDeclaration
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.String getCssText() ;
	public abstract java.lang.String item(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setCssText(java.lang.String parameter1) ;
	public abstract org.w3c.dom.css.CSSRule getParentRule() ;
	public abstract java.lang.String getPropertyPriority(java.lang.String parameter1) ;
	public abstract java.lang.String getPropertyValue(java.lang.String parameter1) ;
	public abstract java.lang.String removeProperty(java.lang.String parameter1) ;
	public abstract org.w3c.dom.css.CSSValue getPropertyCSSValue(java.lang.String parameter1) ;
	public abstract java.lang.Void setProperty(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
}

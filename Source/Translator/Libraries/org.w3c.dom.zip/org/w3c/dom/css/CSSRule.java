package org.w3c.dom.css;

interface CSSRule
{
	public abstract java.lang.Short getType() ;
	public abstract java.lang.String getCssText() ;
	public abstract java.lang.Void setCssText(java.lang.String parameter1) ;
	public abstract org.w3c.dom.css.CSSRule getParentRule() ;
	public abstract org.w3c.dom.css.CSSStyleSheet getParentStyleSheet() ;
	java.lang.Short UNKNOWN_RULE;
	java.lang.Short STYLE_RULE;
	java.lang.Short CHARSET_RULE;
	java.lang.Short IMPORT_RULE;
	java.lang.Short MEDIA_RULE;
	java.lang.Short FONT_FACE_RULE;
	java.lang.Short PAGE_RULE;
}

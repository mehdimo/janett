package org.w3c.dom.css;

interface CSSStyleSheet implements org.w3c.dom.stylesheets.StyleSheet
{
	public abstract java.lang.Void deleteRule(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer insertRule(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract org.w3c.dom.css.CSSRule getOwnerRule() ;
	public abstract org.w3c.dom.css.CSSRuleList getCssRules() ;
}

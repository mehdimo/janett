package org.w3c.dom.css;

interface CSSValueList implements org.w3c.dom.css.CSSValue
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.css.CSSValue item(java.lang.Integer parameter1) ;
}

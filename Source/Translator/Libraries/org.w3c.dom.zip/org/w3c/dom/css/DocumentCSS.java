package org.w3c.dom.css;

interface DocumentCSS implements org.w3c.dom.stylesheets.DocumentStyle
{
	public abstract org.w3c.dom.css.CSSStyleDeclaration getOverrideStyle(org.w3c.dom.Element parameter1, java.lang.String parameter2) ;
}

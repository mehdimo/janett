package org.w3c.dom.css;

interface CSSPrimitiveValue implements org.w3c.dom.css.CSSValue
{
	public abstract java.lang.Short getPrimitiveType() ;
	public abstract java.lang.Float getFloatValue(java.lang.Short parameter1) ;
	public abstract java.lang.Void setFloatValue(java.lang.Short parameter1, java.lang.Float parameter2) ;
	public abstract java.lang.String getStringValue() ;
	public abstract java.lang.Void setStringValue(java.lang.Short parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.css.Counter getCounterValue() ;
	public abstract org.w3c.dom.css.RGBColor getRGBColorValue() ;
	public abstract org.w3c.dom.css.Rect getRectValue() ;
	java.lang.Short CSS_UNKNOWN;
	java.lang.Short CSS_NUMBER;
	java.lang.Short CSS_PERCENTAGE;
	java.lang.Short CSS_EMS;
	java.lang.Short CSS_EXS;
	java.lang.Short CSS_PX;
	java.lang.Short CSS_CM;
	java.lang.Short CSS_MM;
	java.lang.Short CSS_IN;
	java.lang.Short CSS_PT;
	java.lang.Short CSS_PC;
	java.lang.Short CSS_DEG;
	java.lang.Short CSS_RAD;
	java.lang.Short CSS_GRAD;
	java.lang.Short CSS_MS;
	java.lang.Short CSS_S;
	java.lang.Short CSS_HZ;
	java.lang.Short CSS_KHZ;
	java.lang.Short CSS_DIMENSION;
	java.lang.Short CSS_STRING;
	java.lang.Short CSS_URI;
	java.lang.Short CSS_IDENT;
	java.lang.Short CSS_ATTR;
	java.lang.Short CSS_COUNTER;
	java.lang.Short CSS_RECT;
	java.lang.Short CSS_RGBCOLOR;
}

package org.w3c.dom.css;

interface RGBColor
{
	public abstract org.w3c.dom.css.CSSPrimitiveValue getBlue() ;
	public abstract org.w3c.dom.css.CSSPrimitiveValue getGreen() ;
	public abstract org.w3c.dom.css.CSSPrimitiveValue getRed() ;
}

package org.w3c.dom.css;

interface DOMImplementationCSS implements org.w3c.dom.DOMImplementation
{
	public abstract org.w3c.dom.css.CSSStyleSheet createCSSStyleSheet(java.lang.String parameter1, java.lang.String parameter2) ;
}

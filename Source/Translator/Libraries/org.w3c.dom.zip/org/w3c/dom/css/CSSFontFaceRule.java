package org.w3c.dom.css;

interface CSSFontFaceRule implements org.w3c.dom.css.CSSRule
{
	public abstract org.w3c.dom.css.CSSStyleDeclaration getStyle() ;
}

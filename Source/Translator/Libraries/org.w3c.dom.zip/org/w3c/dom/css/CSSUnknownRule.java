package org.w3c.dom.css;

interface CSSUnknownRule implements org.w3c.dom.css.CSSRule
{
}

package org.w3c.dom.css;

interface Rect
{
	public abstract org.w3c.dom.css.CSSPrimitiveValue getBottom() ;
	public abstract org.w3c.dom.css.CSSPrimitiveValue getLeft() ;
	public abstract org.w3c.dom.css.CSSPrimitiveValue getRight() ;
	public abstract org.w3c.dom.css.CSSPrimitiveValue getTop() ;
}

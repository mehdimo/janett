package org.w3c.dom.css;

interface CSSCharsetRule implements org.w3c.dom.css.CSSRule
{
	public abstract java.lang.String getEncoding() ;
	public abstract java.lang.Void setEncoding(java.lang.String parameter1) ;
}

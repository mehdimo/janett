package org.w3c.dom.css;

interface CSSImportRule implements org.w3c.dom.css.CSSRule
{
	public abstract java.lang.String getHref() ;
	public abstract org.w3c.dom.css.CSSStyleSheet getStyleSheet() ;
	public abstract org.w3c.dom.stylesheets.MediaList getMedia() ;
}

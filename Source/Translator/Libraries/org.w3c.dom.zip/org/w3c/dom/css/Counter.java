package org.w3c.dom.css;

interface Counter
{
	public abstract java.lang.String getIdentifier() ;
	public abstract java.lang.String getListStyle() ;
	public abstract java.lang.String getSeparator() ;
}

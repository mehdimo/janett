package org.w3c.dom.css;

interface CSSValue
{
	public abstract java.lang.Short getCssValueType() ;
	public abstract java.lang.String getCssText() ;
	public abstract java.lang.Void setCssText(java.lang.String parameter1) ;
	java.lang.Short CSS_INHERIT;
	java.lang.Short CSS_PRIMITIVE_VALUE;
	java.lang.Short CSS_VALUE_LIST;
	java.lang.Short CSS_CUSTOM;
}

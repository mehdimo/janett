package org.w3c.dom.html;

interface HTMLBaseFontElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getColor() ;
	public abstract java.lang.String getFace() ;
	public abstract java.lang.String getSize() ;
	public abstract java.lang.Void setColor(java.lang.String parameter1) ;
	public abstract java.lang.Void setFace(java.lang.String parameter1) ;
	public abstract java.lang.Void setSize(java.lang.String parameter1) ;
}

package org.w3c.dom.html;

interface HTMLAreaElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getTabIndex() ;
	public abstract java.lang.Boolean getNoHref() ;
	public abstract java.lang.Void setTabIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setNoHref(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAccessKey() ;
	public abstract java.lang.String getAlt() ;
	public abstract java.lang.String getCoords() ;
	public abstract java.lang.String getHref() ;
	public abstract java.lang.String getShape() ;
	public abstract java.lang.String getTarget() ;
	public abstract java.lang.Void setAccessKey(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlt(java.lang.String parameter1) ;
	public abstract java.lang.Void setCoords(java.lang.String parameter1) ;
	public abstract java.lang.Void setHref(java.lang.String parameter1) ;
	public abstract java.lang.Void setShape(java.lang.String parameter1) ;
	public abstract java.lang.Void setTarget(java.lang.String parameter1) ;
}

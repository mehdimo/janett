package org.w3c.dom.html;

interface HTMLLabelElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getAccessKey() ;
	public abstract java.lang.String getHtmlFor() ;
	public abstract java.lang.Void setAccessKey(java.lang.String parameter1) ;
	public abstract java.lang.Void setHtmlFor(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

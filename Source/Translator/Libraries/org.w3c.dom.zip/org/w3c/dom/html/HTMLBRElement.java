package org.w3c.dom.html;

interface HTMLBRElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getClear() ;
	public abstract java.lang.Void setClear(java.lang.String parameter1) ;
}

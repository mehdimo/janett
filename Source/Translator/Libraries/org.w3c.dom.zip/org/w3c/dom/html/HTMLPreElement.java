package org.w3c.dom.html;

interface HTMLPreElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getWidth() ;
	public abstract java.lang.Void setWidth(java.lang.Integer parameter1) ;
}

package org.w3c.dom.html;

interface HTMLAppletElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getAlt() ;
	public abstract java.lang.String getArchive() ;
	public abstract java.lang.String getCode() ;
	public abstract java.lang.String getCodeBase() ;
	public abstract java.lang.String getHeight() ;
	public abstract java.lang.String getHspace() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getObject() ;
	public abstract java.lang.String getVspace() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlt(java.lang.String parameter1) ;
	public abstract java.lang.Void setArchive(java.lang.String parameter1) ;
	public abstract java.lang.Void setCode(java.lang.String parameter1) ;
	public abstract java.lang.Void setCodeBase(java.lang.String parameter1) ;
	public abstract java.lang.Void setHeight(java.lang.String parameter1) ;
	public abstract java.lang.Void setHspace(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setObject(java.lang.String parameter1) ;
	public abstract java.lang.Void setVspace(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
}

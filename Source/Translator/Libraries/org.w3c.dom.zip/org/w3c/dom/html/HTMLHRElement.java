package org.w3c.dom.html;

interface HTMLHRElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getNoShade() ;
	public abstract java.lang.Void setNoShade(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getSize() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setSize(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
}

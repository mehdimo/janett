package org.w3c.dom.html;

interface HTMLOptionElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getIndex() ;
	public abstract java.lang.Boolean getDefaultSelected() ;
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Boolean getSelected() ;
	public abstract java.lang.Void setDefaultSelected(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setSelected(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getLabel() ;
	public abstract java.lang.String getText() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.Void setLabel(java.lang.String parameter1) ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

package org.w3c.dom.html;

interface HTMLFieldSetElement implements org.w3c.dom.html.HTMLElement
{
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

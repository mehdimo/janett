package org.w3c.dom.html;

interface HTMLTableSectionElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Void deleteRow(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getCh() ;
	public abstract java.lang.String getChOff() ;
	public abstract java.lang.String getVAlign() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setCh(java.lang.String parameter1) ;
	public abstract java.lang.Void setChOff(java.lang.String parameter1) ;
	public abstract java.lang.Void setVAlign(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getRows() ;
	public abstract org.w3c.dom.html.HTMLElement insertRow(java.lang.Integer parameter1) ;
}

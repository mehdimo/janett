package org.w3c.dom.html;

interface HTMLFrameSetElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getCols() ;
	public abstract java.lang.String getRows() ;
	public abstract java.lang.Void setCols(java.lang.String parameter1) ;
	public abstract java.lang.Void setRows(java.lang.String parameter1) ;
}

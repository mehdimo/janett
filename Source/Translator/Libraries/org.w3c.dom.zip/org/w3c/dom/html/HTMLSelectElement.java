package org.w3c.dom.html;

interface HTMLSelectElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.Integer getSelectedIndex() ;
	public abstract java.lang.Integer getSize() ;
	public abstract java.lang.Integer getTabIndex() ;
	public abstract java.lang.Void blur() ;
	public abstract java.lang.Void focus() ;
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Boolean getMultiple() ;
	public abstract java.lang.Void remove(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setSelectedIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setSize(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setTabIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setMultiple(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getOptions() ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
	public abstract java.lang.Void add(org.w3c.dom.html.HTMLElement parameter1, org.w3c.dom.html.HTMLElement parameter2) ;
}

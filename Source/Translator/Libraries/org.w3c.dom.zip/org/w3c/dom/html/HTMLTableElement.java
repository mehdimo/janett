package org.w3c.dom.html;

interface HTMLTableElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Void deleteCaption() ;
	public abstract java.lang.Void deleteTFoot() ;
	public abstract java.lang.Void deleteTHead() ;
	public abstract java.lang.Void deleteRow(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getBgColor() ;
	public abstract java.lang.String getBorder() ;
	public abstract java.lang.String getCellPadding() ;
	public abstract java.lang.String getCellSpacing() ;
	public abstract java.lang.String getFrame() ;
	public abstract java.lang.String getRules() ;
	public abstract java.lang.String getSummary() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setBgColor(java.lang.String parameter1) ;
	public abstract java.lang.Void setBorder(java.lang.String parameter1) ;
	public abstract java.lang.Void setCellPadding(java.lang.String parameter1) ;
	public abstract java.lang.Void setCellSpacing(java.lang.String parameter1) ;
	public abstract java.lang.Void setFrame(java.lang.String parameter1) ;
	public abstract java.lang.Void setRules(java.lang.String parameter1) ;
	public abstract java.lang.Void setSummary(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getRows() ;
	public abstract org.w3c.dom.html.HTMLCollection getTBodies() ;
	public abstract org.w3c.dom.html.HTMLElement createCaption() ;
	public abstract org.w3c.dom.html.HTMLElement createTFoot() ;
	public abstract org.w3c.dom.html.HTMLElement createTHead() ;
	public abstract org.w3c.dom.html.HTMLElement insertRow(java.lang.Integer parameter1) ;
	public abstract org.w3c.dom.html.HTMLTableCaptionElement getCaption() ;
	public abstract java.lang.Void setCaption(org.w3c.dom.html.HTMLTableCaptionElement parameter1) ;
	public abstract org.w3c.dom.html.HTMLTableSectionElement getTFoot() ;
	public abstract org.w3c.dom.html.HTMLTableSectionElement getTHead() ;
	public abstract java.lang.Void setTFoot(org.w3c.dom.html.HTMLTableSectionElement parameter1) ;
	public abstract java.lang.Void setTHead(org.w3c.dom.html.HTMLTableSectionElement parameter1) ;
}

package org.w3c.dom.html;

interface HTMLParagraphElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
}

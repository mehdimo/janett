package org.w3c.dom.html;

interface HTMLTableColElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getSpan() ;
	public abstract java.lang.Void setSpan(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getCh() ;
	public abstract java.lang.String getChOff() ;
	public abstract java.lang.String getVAlign() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setCh(java.lang.String parameter1) ;
	public abstract java.lang.Void setChOff(java.lang.String parameter1) ;
	public abstract java.lang.Void setVAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
}

package org.w3c.dom.html;

interface HTMLBodyElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getALink() ;
	public abstract java.lang.String getBackground() ;
	public abstract java.lang.String getBgColor() ;
	public abstract java.lang.String getLink() ;
	public abstract java.lang.String getText() ;
	public abstract java.lang.String getVLink() ;
	public abstract java.lang.Void setALink(java.lang.String parameter1) ;
	public abstract java.lang.Void setBackground(java.lang.String parameter1) ;
	public abstract java.lang.Void setBgColor(java.lang.String parameter1) ;
	public abstract java.lang.Void setLink(java.lang.String parameter1) ;
	public abstract java.lang.Void setText(java.lang.String parameter1) ;
	public abstract java.lang.Void setVLink(java.lang.String parameter1) ;
}

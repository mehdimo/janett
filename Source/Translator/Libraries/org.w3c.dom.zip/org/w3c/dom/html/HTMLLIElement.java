package org.w3c.dom.html;

interface HTMLLIElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getValue() ;
	public abstract java.lang.Void setValue(java.lang.Integer parameter1) ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.Void setType(java.lang.String parameter1) ;
}

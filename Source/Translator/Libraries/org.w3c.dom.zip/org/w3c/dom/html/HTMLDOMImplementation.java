package org.w3c.dom.html;

interface HTMLDOMImplementation implements org.w3c.dom.DOMImplementation
{
	public abstract org.w3c.dom.html.HTMLDocument createHTMLDocument(java.lang.String parameter1) ;
}

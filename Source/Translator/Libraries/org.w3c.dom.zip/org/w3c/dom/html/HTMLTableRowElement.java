package org.w3c.dom.html;

interface HTMLTableRowElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getRowIndex() ;
	public abstract java.lang.Integer getSectionRowIndex() ;
	public abstract java.lang.Void deleteCell(java.lang.Integer parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getBgColor() ;
	public abstract java.lang.String getCh() ;
	public abstract java.lang.String getChOff() ;
	public abstract java.lang.String getVAlign() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setBgColor(java.lang.String parameter1) ;
	public abstract java.lang.Void setCh(java.lang.String parameter1) ;
	public abstract java.lang.Void setChOff(java.lang.String parameter1) ;
	public abstract java.lang.Void setVAlign(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getCells() ;
	public abstract org.w3c.dom.html.HTMLElement insertCell(java.lang.Integer parameter1) ;
}

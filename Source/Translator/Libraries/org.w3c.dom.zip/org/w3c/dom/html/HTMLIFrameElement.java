package org.w3c.dom.html;

interface HTMLIFrameElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getFrameBorder() ;
	public abstract java.lang.String getHeight() ;
	public abstract java.lang.String getLongDesc() ;
	public abstract java.lang.String getMarginHeight() ;
	public abstract java.lang.String getMarginWidth() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getScrolling() ;
	public abstract java.lang.String getSrc() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setFrameBorder(java.lang.String parameter1) ;
	public abstract java.lang.Void setHeight(java.lang.String parameter1) ;
	public abstract java.lang.Void setLongDesc(java.lang.String parameter1) ;
	public abstract java.lang.Void setMarginHeight(java.lang.String parameter1) ;
	public abstract java.lang.Void setMarginWidth(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setScrolling(java.lang.String parameter1) ;
	public abstract java.lang.Void setSrc(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Document getContentDocument() ;
}

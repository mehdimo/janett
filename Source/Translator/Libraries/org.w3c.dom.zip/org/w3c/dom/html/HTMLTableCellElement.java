package org.w3c.dom.html;

interface HTMLTableCellElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getCellIndex() ;
	public abstract java.lang.Integer getColSpan() ;
	public abstract java.lang.Integer getRowSpan() ;
	public abstract java.lang.Boolean getNoWrap() ;
	public abstract java.lang.Void setColSpan(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setRowSpan(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setNoWrap(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAbbr() ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getAxis() ;
	public abstract java.lang.String getBgColor() ;
	public abstract java.lang.String getCh() ;
	public abstract java.lang.String getChOff() ;
	public abstract java.lang.String getHeaders() ;
	public abstract java.lang.String getHeight() ;
	public abstract java.lang.String getScope() ;
	public abstract java.lang.String getVAlign() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAbbr(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setAxis(java.lang.String parameter1) ;
	public abstract java.lang.Void setBgColor(java.lang.String parameter1) ;
	public abstract java.lang.Void setCh(java.lang.String parameter1) ;
	public abstract java.lang.Void setChOff(java.lang.String parameter1) ;
	public abstract java.lang.Void setHeaders(java.lang.String parameter1) ;
	public abstract java.lang.Void setHeight(java.lang.String parameter1) ;
	public abstract java.lang.Void setScope(java.lang.String parameter1) ;
	public abstract java.lang.Void setVAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
}

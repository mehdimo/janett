package org.w3c.dom.html;

interface HTMLScriptElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getDefer() ;
	public abstract java.lang.Void setDefer(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getCharset() ;
	public abstract java.lang.String getEvent() ;
	public abstract java.lang.String getHtmlFor() ;
	public abstract java.lang.String getSrc() ;
	public abstract java.lang.String getText() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.Void setCharset(java.lang.String parameter1) ;
	public abstract java.lang.Void setEvent(java.lang.String parameter1) ;
	public abstract java.lang.Void setHtmlFor(java.lang.String parameter1) ;
	public abstract java.lang.Void setSrc(java.lang.String parameter1) ;
	public abstract java.lang.Void setText(java.lang.String parameter1) ;
	public abstract java.lang.Void setType(java.lang.String parameter1) ;
}

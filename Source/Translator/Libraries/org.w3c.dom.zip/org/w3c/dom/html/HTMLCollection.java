package org.w3c.dom.html;

interface HTMLCollection
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.Node item(java.lang.Integer parameter1) ;
	public abstract org.w3c.dom.Node namedItem(java.lang.String parameter1) ;
}

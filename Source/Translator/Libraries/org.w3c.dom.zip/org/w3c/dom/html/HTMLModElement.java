package org.w3c.dom.html;

interface HTMLModElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getCite() ;
	public abstract java.lang.String getDateTime() ;
	public abstract java.lang.Void setCite(java.lang.String parameter1) ;
	public abstract java.lang.Void setDateTime(java.lang.String parameter1) ;
}

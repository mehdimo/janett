package org.w3c.dom.html;

interface HTMLButtonElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getTabIndex() ;
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Void setTabIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAccessKey() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.Void setAccessKey(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

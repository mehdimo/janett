package org.w3c.dom.html;

interface HTMLDirectoryElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getCompact() ;
	public abstract java.lang.Void setCompact(java.lang.Boolean parameter1) ;
}

package org.w3c.dom.html;

interface HTMLDocument implements org.w3c.dom.Document
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void open() ;
	public abstract java.lang.String getCookie() ;
	public abstract java.lang.String getDomain() ;
	public abstract java.lang.String getReferrer() ;
	public abstract java.lang.String getTitle() ;
	public abstract java.lang.String getURL() ;
	public abstract java.lang.Void setCookie(java.lang.String parameter1) ;
	public abstract java.lang.Void setTitle(java.lang.String parameter1) ;
	public abstract java.lang.Void write(java.lang.String parameter1) ;
	public abstract java.lang.Void writeln(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getAnchors() ;
	public abstract org.w3c.dom.html.HTMLCollection getApplets() ;
	public abstract org.w3c.dom.html.HTMLCollection getForms() ;
	public abstract org.w3c.dom.html.HTMLCollection getImages() ;
	public abstract org.w3c.dom.html.HTMLCollection getLinks() ;
	public abstract org.w3c.dom.html.HTMLElement getBody() ;
	public abstract java.lang.Void setBody(org.w3c.dom.html.HTMLElement parameter1) ;
	public abstract org.w3c.dom.NodeList getElementsByName(java.lang.String parameter1) ;
}

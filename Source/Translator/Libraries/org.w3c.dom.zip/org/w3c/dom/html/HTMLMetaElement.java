package org.w3c.dom.html;

interface HTMLMetaElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getContent() ;
	public abstract java.lang.String getHttpEquiv() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getScheme() ;
	public abstract java.lang.Void setContent(java.lang.String parameter1) ;
	public abstract java.lang.Void setHttpEquiv(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setScheme(java.lang.String parameter1) ;
}

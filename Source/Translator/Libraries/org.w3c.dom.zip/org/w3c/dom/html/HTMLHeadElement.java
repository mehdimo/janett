package org.w3c.dom.html;

interface HTMLHeadElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getProfile() ;
	public abstract java.lang.Void setProfile(java.lang.String parameter1) ;
}

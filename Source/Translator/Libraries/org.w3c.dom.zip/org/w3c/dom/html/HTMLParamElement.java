package org.w3c.dom.html;

interface HTMLParamElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.String getValueType() ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setType(java.lang.String parameter1) ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract java.lang.Void setValueType(java.lang.String parameter1) ;
}

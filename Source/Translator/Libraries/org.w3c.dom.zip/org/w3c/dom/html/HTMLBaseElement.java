package org.w3c.dom.html;

interface HTMLBaseElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getHref() ;
	public abstract java.lang.String getTarget() ;
	public abstract java.lang.Void setHref(java.lang.String parameter1) ;
	public abstract java.lang.Void setTarget(java.lang.String parameter1) ;
}

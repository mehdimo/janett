package org.w3c.dom.html;

interface HTMLQuoteElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getCite() ;
	public abstract java.lang.Void setCite(java.lang.String parameter1) ;
}

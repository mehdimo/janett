package org.w3c.dom.html;

interface HTMLFormElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.Void reset() ;
	public abstract java.lang.Void submit() ;
	public abstract java.lang.String getAcceptCharset() ;
	public abstract java.lang.String getAction() ;
	public abstract java.lang.String getEnctype() ;
	public abstract java.lang.String getMethod() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getTarget() ;
	public abstract java.lang.Void setAcceptCharset(java.lang.String parameter1) ;
	public abstract java.lang.Void setAction(java.lang.String parameter1) ;
	public abstract java.lang.Void setEnctype(java.lang.String parameter1) ;
	public abstract java.lang.Void setMethod(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setTarget(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getElements() ;
}

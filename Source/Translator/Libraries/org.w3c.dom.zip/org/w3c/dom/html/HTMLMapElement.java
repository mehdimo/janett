package org.w3c.dom.html;

interface HTMLMapElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getName() ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLCollection getAreas() ;
}

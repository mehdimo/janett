package org.w3c.dom.html;

interface HTMLStyleElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getMedia() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.Void setMedia(java.lang.String parameter1) ;
	public abstract java.lang.Void setType(java.lang.String parameter1) ;
}

package org.w3c.dom.html;

interface HTMLHtmlElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getVersion() ;
	public abstract java.lang.Void setVersion(java.lang.String parameter1) ;
}

package org.w3c.dom.html;

interface HTMLImageElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getIsMap() ;
	public abstract java.lang.Void setIsMap(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getAlt() ;
	public abstract java.lang.String getBorder() ;
	public abstract java.lang.String getHeight() ;
	public abstract java.lang.String getHspace() ;
	public abstract java.lang.String getLongDesc() ;
	public abstract java.lang.String getLowSrc() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getSrc() ;
	public abstract java.lang.String getUseMap() ;
	public abstract java.lang.String getVspace() ;
	public abstract java.lang.String getWidth() ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlt(java.lang.String parameter1) ;
	public abstract java.lang.Void setBorder(java.lang.String parameter1) ;
	public abstract java.lang.Void setHeight(java.lang.String parameter1) ;
	public abstract java.lang.Void setHspace(java.lang.String parameter1) ;
	public abstract java.lang.Void setLongDesc(java.lang.String parameter1) ;
	public abstract java.lang.Void setLowSrc(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setSrc(java.lang.String parameter1) ;
	public abstract java.lang.Void setUseMap(java.lang.String parameter1) ;
	public abstract java.lang.Void setVspace(java.lang.String parameter1) ;
	public abstract java.lang.Void setWidth(java.lang.String parameter1) ;
}

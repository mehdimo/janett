package org.w3c.dom.html;

interface HTMLLinkElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getCharset() ;
	public abstract java.lang.String getHref() ;
	public abstract java.lang.String getHreflang() ;
	public abstract java.lang.String getMedia() ;
	public abstract java.lang.String getRel() ;
	public abstract java.lang.String getRev() ;
	public abstract java.lang.String getTarget() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.Void setCharset(java.lang.String parameter1) ;
	public abstract java.lang.Void setHref(java.lang.String parameter1) ;
	public abstract java.lang.Void setHreflang(java.lang.String parameter1) ;
	public abstract java.lang.Void setMedia(java.lang.String parameter1) ;
	public abstract java.lang.Void setRel(java.lang.String parameter1) ;
	public abstract java.lang.Void setRev(java.lang.String parameter1) ;
	public abstract java.lang.Void setTarget(java.lang.String parameter1) ;
	public abstract java.lang.Void setType(java.lang.String parameter1) ;
}

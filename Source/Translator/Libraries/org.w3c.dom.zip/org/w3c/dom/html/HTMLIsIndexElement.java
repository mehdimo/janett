package org.w3c.dom.html;

interface HTMLIsIndexElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getPrompt() ;
	public abstract java.lang.Void setPrompt(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

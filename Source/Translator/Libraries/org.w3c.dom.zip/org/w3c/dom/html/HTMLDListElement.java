package org.w3c.dom.html;

interface HTMLDListElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Boolean getCompact() ;
	public abstract java.lang.Void setCompact(java.lang.Boolean parameter1) ;
}

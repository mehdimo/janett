package org.w3c.dom.html;

interface HTMLInputElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.Integer getMaxLength() ;
	public abstract java.lang.Integer getTabIndex() ;
	public abstract java.lang.Void blur() ;
	public abstract java.lang.Void click() ;
	public abstract java.lang.Void focus() ;
	public abstract java.lang.Void select() ;
	public abstract java.lang.Boolean getChecked() ;
	public abstract java.lang.Boolean getDefaultChecked() ;
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Boolean getReadOnly() ;
	public abstract java.lang.Void setMaxLength(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setTabIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setChecked(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setDefaultChecked(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setReadOnly(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getAccept() ;
	public abstract java.lang.String getAccessKey() ;
	public abstract java.lang.String getAlign() ;
	public abstract java.lang.String getAlt() ;
	public abstract java.lang.String getDefaultValue() ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String getSize() ;
	public abstract java.lang.String getSrc() ;
	public abstract java.lang.String getType() ;
	public abstract java.lang.String getUseMap() ;
	public abstract java.lang.String getValue() ;
	public abstract java.lang.Void setAccept(java.lang.String parameter1) ;
	public abstract java.lang.Void setAccessKey(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlign(java.lang.String parameter1) ;
	public abstract java.lang.Void setAlt(java.lang.String parameter1) ;
	public abstract java.lang.Void setDefaultValue(java.lang.String parameter1) ;
	public abstract java.lang.Void setName(java.lang.String parameter1) ;
	public abstract java.lang.Void setSize(java.lang.String parameter1) ;
	public abstract java.lang.Void setSrc(java.lang.String parameter1) ;
	public abstract java.lang.Void setUseMap(java.lang.String parameter1) ;
	public abstract java.lang.Void setValue(java.lang.String parameter1) ;
	public abstract org.w3c.dom.html.HTMLFormElement getForm() ;
}

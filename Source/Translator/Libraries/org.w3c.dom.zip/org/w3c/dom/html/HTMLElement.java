package org.w3c.dom.html;

interface HTMLElement implements org.w3c.dom.Element
{
	public abstract java.lang.String getClassName() ;
	public abstract java.lang.String getDir() ;
	public abstract java.lang.String getId() ;
	public abstract java.lang.String getLang() ;
	public abstract java.lang.String getTitle() ;
	public abstract java.lang.Void setClassName(java.lang.String parameter1) ;
	public abstract java.lang.Void setDir(java.lang.String parameter1) ;
	public abstract java.lang.Void setId(java.lang.String parameter1) ;
	public abstract java.lang.Void setLang(java.lang.String parameter1) ;
	public abstract java.lang.Void setTitle(java.lang.String parameter1) ;
}

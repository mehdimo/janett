package org.w3c.dom.html;

interface HTMLTitleElement implements org.w3c.dom.html.HTMLElement
{
	public abstract java.lang.String getText() ;
	public abstract java.lang.Void setText(java.lang.String parameter1) ;
}

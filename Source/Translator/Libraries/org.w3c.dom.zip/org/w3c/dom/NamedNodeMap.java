package org.w3c.dom;

interface NamedNodeMap
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.Node item(java.lang.Integer parameter1) ;
	public abstract org.w3c.dom.Node getNamedItem(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Node removeNamedItem(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Node setNamedItem(org.w3c.dom.Node parameter1) ;
	public abstract org.w3c.dom.Node setNamedItemNS(org.w3c.dom.Node parameter1) ;
	public abstract org.w3c.dom.Node getNamedItemNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.Node removeNamedItemNS(java.lang.String parameter1, java.lang.String parameter2) ;
}

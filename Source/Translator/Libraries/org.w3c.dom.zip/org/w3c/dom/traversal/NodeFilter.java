package org.w3c.dom.traversal;

interface NodeFilter
{
	public abstract java.lang.Short acceptNode(org.w3c.dom.Node parameter1) ;
	java.lang.Short FILTER_ACCEPT;
	java.lang.Short FILTER_REJECT;
	java.lang.Short FILTER_SKIP;
	java.lang.Integer SHOW_ALL;
	java.lang.Integer SHOW_ELEMENT;
	java.lang.Integer SHOW_ATTRIBUTE;
	java.lang.Integer SHOW_TEXT;
	java.lang.Integer SHOW_CDATA_SECTION;
	java.lang.Integer SHOW_ENTITY_REFERENCE;
	java.lang.Integer SHOW_ENTITY;
	java.lang.Integer SHOW_PROCESSING_INSTRUCTION;
	java.lang.Integer SHOW_COMMENT;
	java.lang.Integer SHOW_DOCUMENT;
	java.lang.Integer SHOW_DOCUMENT_TYPE;
	java.lang.Integer SHOW_DOCUMENT_FRAGMENT;
	java.lang.Integer SHOW_NOTATION;
}

package org.w3c.dom.traversal;

interface TreeWalker
{
	public abstract java.lang.Integer getWhatToShow() ;
	public abstract java.lang.Boolean getExpandEntityReferences() ;
	public abstract org.w3c.dom.Node firstChild() ;
	public abstract org.w3c.dom.Node getCurrentNode() ;
	public abstract org.w3c.dom.Node getRoot() ;
	public abstract org.w3c.dom.Node lastChild() ;
	public abstract org.w3c.dom.Node nextNode() ;
	public abstract org.w3c.dom.Node nextSibling() ;
	public abstract org.w3c.dom.Node parentNode() ;
	public abstract org.w3c.dom.Node previousNode() ;
	public abstract org.w3c.dom.Node previousSibling() ;
	public abstract java.lang.Void setCurrentNode(org.w3c.dom.Node parameter1) ;
	public abstract org.w3c.dom.traversal.NodeFilter getFilter() ;
}

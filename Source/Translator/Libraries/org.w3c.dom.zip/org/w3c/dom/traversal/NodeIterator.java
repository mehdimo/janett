package org.w3c.dom.traversal;

interface NodeIterator
{
	public abstract java.lang.Integer getWhatToShow() ;
	public abstract java.lang.Void detach() ;
	public abstract java.lang.Boolean getExpandEntityReferences() ;
	public abstract org.w3c.dom.Node getRoot() ;
	public abstract org.w3c.dom.Node nextNode() ;
	public abstract org.w3c.dom.Node previousNode() ;
	public abstract org.w3c.dom.traversal.NodeFilter getFilter() ;
}

package org.w3c.dom.traversal;

interface DocumentTraversal
{
	public abstract org.w3c.dom.traversal.NodeIterator createNodeIterator(org.w3c.dom.Node parameter1, java.lang.Integer parameter2, org.w3c.dom.traversal.NodeFilter parameter3, java.lang.Boolean parameter4) ;
	public abstract org.w3c.dom.traversal.TreeWalker createTreeWalker(org.w3c.dom.Node parameter1, java.lang.Integer parameter2, org.w3c.dom.traversal.NodeFilter parameter3, java.lang.Boolean parameter4) ;
}

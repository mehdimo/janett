package org.w3c.dom;

interface Notation implements org.w3c.dom.Node
{
	public abstract java.lang.String getPublicId() ;
	public abstract java.lang.String getSystemId() ;
}

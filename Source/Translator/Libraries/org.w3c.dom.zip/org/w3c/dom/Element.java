package org.w3c.dom;

interface Element implements org.w3c.dom.Node
{
	public abstract java.lang.String getTagName() ;
	public abstract java.lang.Void removeAttribute(java.lang.String parameter1) ;
	public abstract java.lang.Boolean hasAttribute(java.lang.String parameter1) ;
	public abstract java.lang.String getAttribute(java.lang.String parameter1) ;
	public abstract java.lang.Void removeAttributeNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setAttribute(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Boolean hasAttributeNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.Attr getAttributeNode(java.lang.String parameter1) ;
	public abstract org.w3c.dom.Attr removeAttributeNode(org.w3c.dom.Attr parameter1) ;
	public abstract org.w3c.dom.Attr setAttributeNode(org.w3c.dom.Attr parameter1) ;
	public abstract org.w3c.dom.Attr setAttributeNodeNS(org.w3c.dom.Attr parameter1) ;
	public abstract org.w3c.dom.NodeList getElementsByTagName(java.lang.String parameter1) ;
	public abstract java.lang.String getAttributeNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setAttributeNS(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public abstract org.w3c.dom.Attr getAttributeNodeNS(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.NodeList getElementsByTagNameNS(java.lang.String parameter1, java.lang.String parameter2) ;
}

package org.w3c.dom.stylesheets;

interface DocumentStyle
{
	public abstract org.w3c.dom.stylesheets.StyleSheetList getStyleSheets() ;
}

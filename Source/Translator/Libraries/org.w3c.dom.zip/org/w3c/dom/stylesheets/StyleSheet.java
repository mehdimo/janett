package org.w3c.dom.stylesheets;

interface StyleSheet
{
	public abstract java.lang.Boolean getDisabled() ;
	public abstract java.lang.Void setDisabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getHref() ;
	public abstract java.lang.String getTitle() ;
	public abstract java.lang.String getType() ;
	public abstract org.w3c.dom.Node getOwnerNode() ;
	public abstract org.w3c.dom.stylesheets.MediaList getMedia() ;
	public abstract org.w3c.dom.stylesheets.StyleSheet getParentStyleSheet() ;
}

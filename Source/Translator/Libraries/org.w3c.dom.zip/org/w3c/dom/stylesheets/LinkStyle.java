package org.w3c.dom.stylesheets;

interface LinkStyle
{
	public abstract org.w3c.dom.stylesheets.StyleSheet getSheet() ;
}

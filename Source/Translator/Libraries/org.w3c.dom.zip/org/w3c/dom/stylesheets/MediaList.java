package org.w3c.dom.stylesheets;

interface MediaList
{
	public abstract java.lang.Integer getLength() ;
	public abstract java.lang.String getMediaText() ;
	public abstract java.lang.String item(java.lang.Integer parameter1) ;
	public abstract java.lang.Void appendMedium(java.lang.String parameter1) ;
	public abstract java.lang.Void deleteMedium(java.lang.String parameter1) ;
	public abstract java.lang.Void setMediaText(java.lang.String parameter1) ;
}

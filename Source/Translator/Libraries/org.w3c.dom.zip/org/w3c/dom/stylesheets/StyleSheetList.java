package org.w3c.dom.stylesheets;

interface StyleSheetList
{
	public abstract java.lang.Integer getLength() ;
	public abstract org.w3c.dom.stylesheets.StyleSheet item(java.lang.Integer parameter1) ;
}

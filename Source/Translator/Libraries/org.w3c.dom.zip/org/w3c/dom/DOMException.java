package org.w3c.dom;

abstract class DOMException extends java.lang.RuntimeException
{
	public DOMException(java.lang.Short parameter1, java.lang.String parameter2) ;
	java.lang.Short code;
	java.lang.Short INDEX_SIZE_ERR;
	java.lang.Short DOMSTRING_SIZE_ERR;
	java.lang.Short HIERARCHY_REQUEST_ERR;
	java.lang.Short WRONG_DOCUMENT_ERR;
	java.lang.Short INVALID_CHARACTER_ERR;
	java.lang.Short NO_DATA_ALLOWED_ERR;
	java.lang.Short NO_MODIFICATION_ALLOWED_ERR;
	java.lang.Short NOT_FOUND_ERR;
	java.lang.Short NOT_SUPPORTED_ERR;
	java.lang.Short INUSE_ATTRIBUTE_ERR;
	java.lang.Short INVALID_STATE_ERR;
	java.lang.Short SYNTAX_ERR;
	java.lang.Short INVALID_MODIFICATION_ERR;
	java.lang.Short NAMESPACE_ERR;
	java.lang.Short INVALID_ACCESS_ERR;
}

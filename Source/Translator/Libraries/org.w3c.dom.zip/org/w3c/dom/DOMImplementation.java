package org.w3c.dom;

interface DOMImplementation
{
	public abstract java.lang.Boolean hasFeature(java.lang.String parameter1, java.lang.String parameter2) ;
	public abstract org.w3c.dom.Document createDocument(java.lang.String parameter1, java.lang.String parameter2, org.w3c.dom.DocumentType parameter3) ;
	public abstract org.w3c.dom.DocumentType createDocumentType(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
}

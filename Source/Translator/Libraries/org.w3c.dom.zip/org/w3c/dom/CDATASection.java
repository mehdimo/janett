package org.w3c.dom;

interface CDATASection implements org.w3c.dom.Text
{
}

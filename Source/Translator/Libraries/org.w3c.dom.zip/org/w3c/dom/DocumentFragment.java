package org.w3c.dom;

interface DocumentFragment implements org.w3c.dom.Node
{
}

package junit.framework;

abstract class ComparisonFailure extends junit.framework.AssertionFailedError
{
	public ComparisonFailure(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.String getMessage() ;
	public java.lang.String getActual() ;
	public java.lang.String getExpected() ;
}

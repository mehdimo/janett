package junit.framework;

abstract class ComparisonFailure extends junit.framework.AssertionFailedError
{
	public java.lang.String getMessage() ;
	public java.lang.String getActual() ;
	public java.lang.String getExpected() ;
}

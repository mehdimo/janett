package junit.framework;

abstract class TestFailure
{
	public junit.framework.Test failedTest() ;
	public java.lang.Throwable thrownException() ;
	public java.lang.String toString() ;
	public java.lang.String trace() ;
	public java.lang.String exceptionMessage() ;
	public java.lang.Boolean isFailure() ;
}

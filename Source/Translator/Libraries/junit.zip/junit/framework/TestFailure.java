package junit.framework;

abstract class TestFailure
{
	public TestFailure(junit.framework.Test parameter1, java.lang.Throwable parameter2) ;
	public junit.framework.Test failedTest() ;
	public java.lang.Throwable thrownException() ;
	public java.lang.String toString() ;
	public java.lang.String trace() ;
	public java.lang.String exceptionMessage() ;
	public java.lang.Boolean isFailure() ;
}

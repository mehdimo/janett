package junit.framework;

abstract class TestCase extends junit.framework.Assert implements junit.framework.Test
{
	public java.lang.Integer countTestCases() ;
	public junit.framework.TestResult createResult() ;
	public junit.framework.TestResult run() ;
	public java.lang.Void run(junit.framework.TestResult parameter1) ;
	public java.lang.Void runBare() ;
	public java.lang.Void runTest() ;
	public java.lang.Void setUp() ;
	public java.lang.Void tearDown() ;
	public java.lang.String toString() ;
	public java.lang.String getName() ;
	public java.lang.Void setName(java.lang.String parameter1) ;
}

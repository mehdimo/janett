package junit.framework;

abstract class AssertionFailedError extends java.lang.Error
{
}

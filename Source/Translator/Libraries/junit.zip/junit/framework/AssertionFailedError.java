package junit.framework;

abstract class AssertionFailedError extends java.lang.Error
{
	public AssertionFailedError() ;
	public AssertionFailedError(java.lang.String parameter1) ;
}

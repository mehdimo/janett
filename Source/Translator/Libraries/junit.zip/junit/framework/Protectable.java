package junit.framework;

interface Protectable
{
	public abstract java.lang.Void protect() ;
}

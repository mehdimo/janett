package junit.framework;

abstract class Assert
{
	public java.lang.Void assertTrue(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void assertTrue(java.lang.Boolean parameter1) ;
	public java.lang.Void assertFalse(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void assertFalse(java.lang.Boolean parameter1) ;
	public java.lang.Void fail(java.lang.String parameter1) ;
	public java.lang.Void fail() ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Void assertEquals(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void assertEquals(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
	public java.lang.Void assertEquals(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Long parameter2, java.lang.Long parameter3) ;
	public java.lang.Void assertEquals(java.lang.Long parameter1, java.lang.Long parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void assertEquals(java.lang.Boolean parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Byte parameter2, java.lang.Byte parameter3) ;
	public java.lang.Void assertEquals(java.lang.Byte parameter1, java.lang.Byte parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Character parameter2, java.lang.Character parameter3) ;
	public java.lang.Void assertEquals(java.lang.Character parameter1, java.lang.Character parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Short parameter2, java.lang.Short parameter3) ;
	public java.lang.Void assertEquals(java.lang.Short parameter1, java.lang.Short parameter2) ;
	public java.lang.Void assertEquals(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void assertEquals(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void assertNotNull(java.lang.Object parameter1) ;
	public java.lang.Void assertNotNull(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void assertNull(java.lang.Object parameter1) ;
	public java.lang.Void assertNull(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void assertSame(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Void assertSame(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.lang.Void assertNotSame(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Void assertNotSame(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.lang.Void failSame(java.lang.String parameter1) ;
	public java.lang.Void failNotSame(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Void failNotEquals(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
}

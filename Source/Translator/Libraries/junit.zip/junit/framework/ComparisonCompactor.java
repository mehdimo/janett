package junit.framework;

abstract class ComparisonCompactor
{
	public java.lang.String compact(java.lang.String parameter1) ;
}

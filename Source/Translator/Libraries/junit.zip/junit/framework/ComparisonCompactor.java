package junit.framework;

abstract class ComparisonCompactor
{
	public ComparisonCompactor(java.lang.Integer parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
	public java.lang.String compact(java.lang.String parameter1) ;
}

package junit.framework;

abstract class TestSuite implements junit.framework.Test
{
	public junit.framework.Test createTest(java.lang.Class parameter1, java.lang.String parameter2) ;
	public java.lang.reflect.Constructor getTestConstructor(java.lang.Class parameter1) ;
	public junit.framework.Test warning(java.lang.String parameter1) ;
	public TestSuite() ;
	public TestSuite(java.lang.Class parameter1) ;
	public TestSuite(java.lang.Class parameter1, java.lang.String parameter2) ;
	public TestSuite(java.lang.String parameter1) ;
	public TestSuite(java.lang.Class[] parameter1) ;
	public TestSuite(java.lang.Class[] parameter1, java.lang.String parameter2) ;
	public java.lang.Void addTest(junit.framework.Test parameter1) ;
	public java.lang.Void addTestSuite(java.lang.Class parameter1) ;
	public java.lang.Integer countTestCases() ;
	public java.lang.String getName() ;
	public java.lang.Void run(junit.framework.TestResult parameter1) ;
	public java.lang.Void runTest(junit.framework.Test parameter1, junit.framework.TestResult parameter2) ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public junit.framework.Test testAt(java.lang.Integer parameter1) ;
	public java.lang.Integer testCount() ;
	public java.util.Enumeration tests() ;
	public java.lang.String toString() ;
}

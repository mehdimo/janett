package junit.framework;

abstract class TestResult
{
	public TestResult() ;
	public java.lang.Void addError(junit.framework.Test parameter1, java.lang.Throwable parameter2) ;
	public java.lang.Void addFailure(junit.framework.Test parameter1, junit.framework.AssertionFailedError parameter2) ;
	public java.lang.Void addListener(junit.framework.TestListener parameter1) ;
	public java.lang.Void removeListener(junit.framework.TestListener parameter1) ;
	public java.lang.Void endTest(junit.framework.Test parameter1) ;
	public java.lang.Integer errorCount() ;
	public java.util.Enumeration errors() ;
	public java.lang.Integer failureCount() ;
	public java.util.Enumeration failures() ;
	public java.lang.Void run(junit.framework.TestCase parameter1) ;
	public java.lang.Integer runCount() ;
	public java.lang.Void runProtected(junit.framework.Test parameter1, junit.framework.Protectable parameter2) ;
	public java.lang.Boolean shouldStop() ;
	public java.lang.Void startTest(junit.framework.Test parameter1) ;
	public java.lang.Void stop() ;
	public java.lang.Boolean wasSuccessful() ;
}

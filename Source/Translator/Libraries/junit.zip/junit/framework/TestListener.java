package junit.framework;

interface TestListener
{
	public abstract java.lang.Void addError(junit.framework.Test parameter1, java.lang.Throwable parameter2) ;
	public abstract java.lang.Void addFailure(junit.framework.Test parameter1, junit.framework.AssertionFailedError parameter2) ;
	public abstract java.lang.Void endTest(junit.framework.Test parameter1) ;
	public abstract java.lang.Void startTest(junit.framework.Test parameter1) ;
}

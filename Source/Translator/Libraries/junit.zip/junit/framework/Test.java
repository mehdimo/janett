package junit.framework;

interface Test
{
	public abstract java.lang.Integer countTestCases() ;
	public abstract java.lang.Void run(junit.framework.TestResult parameter1) ;
}

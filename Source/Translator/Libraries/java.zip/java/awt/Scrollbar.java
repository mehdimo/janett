package java.awt;

abstract class Scrollbar extends java.awt.Component implements java.awt.Adjustable, javax.accessibility.Accessible
{
	public java.lang.Integer getBlockIncrement() ;
	public java.lang.Integer getLineIncrement() ;
	public java.lang.Integer getMaximum() ;
	public java.lang.Integer getMinimum() ;
	public java.lang.Integer getOrientation() ;
	public java.lang.Integer getPageIncrement() ;
	public java.lang.Integer getUnitIncrement() ;
	public java.lang.Integer getValue() ;
	public java.lang.Integer getVisible() ;
	public java.lang.Integer getVisibleAmount() ;
	public Scrollbar() ;
	public java.lang.Void addNotify() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public Scrollbar(java.lang.Integer parameter1) ;
	public java.lang.Void setBlockIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setLineIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setMaximum(java.lang.Integer parameter1) ;
	public java.lang.Void setMinimum(java.lang.Integer parameter1) ;
	public java.lang.Void setOrientation(java.lang.Integer parameter1) ;
	public java.lang.Void setPageIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setUnitIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setValue(java.lang.Integer parameter1) ;
	public java.lang.Void setVisibleAmount(java.lang.Integer parameter1) ;
	public java.lang.Void setValues(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public Scrollbar(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void setValueIsAdjusting(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void processAdjustmentEvent(java.awt.event.AdjustmentEvent parameter1) ;
	public java.awt.event.AdjustmentListener[] getAdjustmentListeners() ;
	public java.lang.Void addAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	public java.lang.Void removeAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	java.lang.Integer HORIZONTAL;
	java.lang.Integer VERTICAL;
	abstract class AccessibleAWTScrollBar extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleValue
	{
		public AccessibleAWTScrollBar(java.awt.Scrollbar parameter1) ;
		public java.lang.Number getCurrentAccessibleValue() ;
		public java.lang.Number getMaximumAccessibleValue() ;
		public java.lang.Number getMinimumAccessibleValue() ;
		public java.lang.Boolean setCurrentAccessibleValue(java.lang.Number parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
		public javax.accessibility.AccessibleValue getAccessibleValue() ;
	}
}

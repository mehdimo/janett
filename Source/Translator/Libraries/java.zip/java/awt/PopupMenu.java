package java.awt;

abstract class PopupMenu extends java.awt.Menu
{
	public PopupMenu() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void show(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public PopupMenu(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTPopupMenu extends java.awt.Menu.AccessibleAWTMenu
	{
		public AccessibleAWTPopupMenu(java.awt.PopupMenu parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

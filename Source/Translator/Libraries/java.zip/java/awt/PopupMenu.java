package java.awt;

abstract class PopupMenu extends java.awt.Menu
{
	public java.lang.Void addNotify() ;
	public java.lang.Void show(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTPopupMenu extends java.awt.Menu.AccessibleAWTMenu
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

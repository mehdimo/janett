package java.awt;

abstract class BorderLayout implements java.awt.LayoutManager2, java.io.Serializable
{
	public java.lang.Integer getHgap() ;
	public java.lang.Integer getVgap() ;
	public java.lang.Void setHgap(java.lang.Integer parameter1) ;
	public java.lang.Void setVgap(java.lang.Integer parameter1) ;
	public java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public java.lang.Float getLayoutAlignmentX(java.awt.Container parameter1) ;
	public java.lang.Float getLayoutAlignmentY(java.awt.Container parameter1) ;
	public java.lang.Void invalidateLayout(java.awt.Container parameter1) ;
	public java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public java.awt.Dimension maximumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
	public java.lang.Void addLayoutComponent(java.awt.Component parameter1, java.lang.Object parameter2) ;
	java.lang.String NORTH;
	java.lang.String SOUTH;
	java.lang.String EAST;
	java.lang.String WEST;
	java.lang.String CENTER;
	java.lang.String BEFORE_FIRST_LINE;
	java.lang.String AFTER_LAST_LINE;
	java.lang.String BEFORE_LINE_BEGINS;
	java.lang.String AFTER_LINE_ENDS;
	java.lang.String PAGE_START;
	java.lang.String PAGE_END;
	java.lang.String LINE_START;
	java.lang.String LINE_END;
}

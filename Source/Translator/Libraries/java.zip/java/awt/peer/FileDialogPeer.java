package java.awt.peer;

interface FileDialogPeer implements java.awt.peer.DialogPeer
{
	public abstract java.lang.Void setFilenameFilter(java.io.FilenameFilter parameter1) ;
	public abstract java.lang.Void setDirectory(java.lang.String parameter1) ;
	public abstract java.lang.Void setFile(java.lang.String parameter1) ;
}

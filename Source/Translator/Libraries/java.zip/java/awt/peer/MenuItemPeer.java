package java.awt.peer;

interface MenuItemPeer implements java.awt.peer.MenuComponentPeer
{
	public abstract java.lang.Void disable() ;
	public abstract java.lang.Void enable() ;
	public abstract java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setLabel(java.lang.String parameter1) ;
}

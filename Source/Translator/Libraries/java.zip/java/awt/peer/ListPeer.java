package java.awt.peer;

interface ListPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void clear() ;
	public abstract java.lang.Void removeAll() ;
	public abstract java.lang.Integer[] getSelectedIndexes() ;
	public abstract java.lang.Void deselect(java.lang.Integer parameter1) ;
	public abstract java.lang.Void makeVisible(java.lang.Integer parameter1) ;
	public abstract java.lang.Void select(java.lang.Integer parameter1) ;
	public abstract java.lang.Void delItems(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setMultipleMode(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setMultipleSelections(java.lang.Boolean parameter1) ;
	public abstract java.awt.Dimension getMinimumSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension getPreferredSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension minimumSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension preferredSize(java.lang.Integer parameter1) ;
	public abstract java.lang.Void add(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void addItem(java.lang.String parameter1, java.lang.Integer parameter2) ;
}

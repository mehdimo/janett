package java.awt.peer;

interface ScrollPanePeer implements java.awt.peer.ContainerPeer
{
	public abstract java.lang.Integer getHScrollbarHeight() ;
	public abstract java.lang.Integer getVScrollbarWidth() ;
	public abstract java.lang.Void childResized(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setScrollPosition(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setUnitIncrement(java.awt.Adjustable parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setValue(java.awt.Adjustable parameter1, java.lang.Integer parameter2) ;
}

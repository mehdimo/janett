package java.awt.peer;

interface TextFieldPeer implements java.awt.peer.TextComponentPeer
{
	public abstract java.lang.Void setEchoChar(java.lang.Character parameter1) ;
	public abstract java.lang.Void setEchoCharacter(java.lang.Character parameter1) ;
	public abstract java.awt.Dimension getMinimumSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension getPreferredSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension minimumSize(java.lang.Integer parameter1) ;
	public abstract java.awt.Dimension preferredSize(java.lang.Integer parameter1) ;
}

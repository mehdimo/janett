package java.awt.peer;

interface CheckboxPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void setState(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setCheckboxGroup(java.awt.CheckboxGroup parameter1) ;
	public abstract java.lang.Void setLabel(java.lang.String parameter1) ;
}

package java.awt.peer;

interface LabelPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void setAlignment(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setText(java.lang.String parameter1) ;
}

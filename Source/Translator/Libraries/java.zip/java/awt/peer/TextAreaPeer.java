package java.awt.peer;

interface TextAreaPeer implements java.awt.peer.TextComponentPeer
{
	public abstract java.awt.Dimension getMinimumSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Dimension getPreferredSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Dimension minimumSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Dimension preferredSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void insert(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void insertText(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void replaceRange(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void replaceText(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package java.awt.peer;

interface PopupMenuPeer implements java.awt.peer.MenuPeer
{
	public abstract java.lang.Void show(java.awt.Event parameter1) ;
}

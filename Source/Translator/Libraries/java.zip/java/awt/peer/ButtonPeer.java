package java.awt.peer;

interface ButtonPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void setLabel(java.lang.String parameter1) ;
}

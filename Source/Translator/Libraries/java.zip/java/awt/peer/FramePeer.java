package java.awt.peer;

interface FramePeer implements java.awt.peer.WindowPeer
{
	public abstract java.lang.Integer getState() ;
	public abstract java.lang.Void setState(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setResizable(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setIconImage(java.awt.Image parameter1) ;
	public abstract java.lang.Void setMenuBar(java.awt.MenuBar parameter1) ;
	public abstract java.lang.Void setMaximizedBounds(java.awt.Rectangle parameter1) ;
	public abstract java.lang.Void setTitle(java.lang.String parameter1) ;
}

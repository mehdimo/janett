package java.awt.peer;

interface RobotPeer
{
	public abstract java.lang.Void keyPress(java.lang.Integer parameter1) ;
	public abstract java.lang.Void keyRelease(java.lang.Integer parameter1) ;
	public abstract java.lang.Void mousePress(java.lang.Integer parameter1) ;
	public abstract java.lang.Void mouseRelease(java.lang.Integer parameter1) ;
	public abstract java.lang.Void mouseWheel(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getRGBPixel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void mouseMove(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer[] getRGBPixels(java.awt.Rectangle parameter1) ;
}

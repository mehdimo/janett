package java.awt.peer;

interface FontPeer
{
}

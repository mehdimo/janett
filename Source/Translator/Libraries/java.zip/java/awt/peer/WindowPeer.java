package java.awt.peer;

interface WindowPeer implements java.awt.peer.ContainerPeer
{
	public abstract java.lang.Void toBack() ;
	public abstract java.lang.Void toFront() ;
}

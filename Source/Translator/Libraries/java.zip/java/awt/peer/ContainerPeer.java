package java.awt.peer;

interface ContainerPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void beginLayout() ;
	public abstract java.lang.Void beginValidate() ;
	public abstract java.lang.Void endLayout() ;
	public abstract java.lang.Void endValidate() ;
	public abstract java.lang.Boolean isPaintPending() ;
	public abstract java.awt.Insets getInsets() ;
	public abstract java.awt.Insets insets() ;
}

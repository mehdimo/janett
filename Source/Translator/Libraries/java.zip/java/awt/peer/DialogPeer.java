package java.awt.peer;

interface DialogPeer implements java.awt.peer.WindowPeer
{
	public abstract java.lang.Void setResizable(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setTitle(java.lang.String parameter1) ;
}

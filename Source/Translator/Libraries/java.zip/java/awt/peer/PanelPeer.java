package java.awt.peer;

interface PanelPeer implements java.awt.peer.ContainerPeer
{
}

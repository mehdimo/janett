package java.awt.peer;

interface TextComponentPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Integer getCaretPosition() ;
	public abstract java.lang.Integer getSelectionEnd() ;
	public abstract java.lang.Integer getSelectionStart() ;
	public abstract java.lang.Void setCaretPosition(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getIndexAtPoint(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void select(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Long filterEvents(java.lang.Long parameter1) ;
	public abstract java.lang.Void setEditable(java.lang.Boolean parameter1) ;
	public abstract java.awt.Rectangle getCharacterBounds(java.lang.Integer parameter1) ;
	public abstract java.lang.String getText() ;
	public abstract java.lang.Void setText(java.lang.String parameter1) ;
}

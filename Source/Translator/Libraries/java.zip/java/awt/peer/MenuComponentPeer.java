package java.awt.peer;

interface MenuComponentPeer
{
	public abstract java.lang.Void dispose() ;
}

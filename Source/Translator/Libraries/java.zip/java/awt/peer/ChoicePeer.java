package java.awt.peer;

interface ChoicePeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void removeAll() ;
	public abstract java.lang.Void remove(java.lang.Integer parameter1) ;
	public abstract java.lang.Void select(java.lang.Integer parameter1) ;
	public abstract java.lang.Void add(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void addItem(java.lang.String parameter1, java.lang.Integer parameter2) ;
}

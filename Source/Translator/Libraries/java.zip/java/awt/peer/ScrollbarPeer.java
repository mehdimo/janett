package java.awt.peer;

interface ScrollbarPeer implements java.awt.peer.ComponentPeer
{
	public abstract java.lang.Void setLineIncrement(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setPageIncrement(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setValues(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

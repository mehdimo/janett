package java.awt.peer;

interface MenuBarPeer implements java.awt.peer.MenuComponentPeer
{
	public abstract java.lang.Void delMenu(java.lang.Integer parameter1) ;
	public abstract java.lang.Void addHelpMenu(java.awt.Menu parameter1) ;
	public abstract java.lang.Void addMenu(java.awt.Menu parameter1) ;
}

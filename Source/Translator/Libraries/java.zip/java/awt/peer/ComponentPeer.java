package java.awt.peer;

interface ComponentPeer
{
	public abstract java.lang.Void destroyBuffers() ;
	public abstract java.lang.Void disable() ;
	public abstract java.lang.Void dispose() ;
	public abstract java.lang.Void enable() ;
	public abstract java.lang.Void hide() ;
	public abstract java.lang.Void show() ;
	public abstract java.lang.Void updateCursorImmediately() ;
	public abstract java.lang.Boolean canDetermineObscurity() ;
	public abstract java.lang.Boolean handlesWheelScrolling() ;
	public abstract java.lang.Boolean isFocusable() ;
	public abstract java.lang.Boolean isObscured() ;
	public abstract java.lang.Void reshape(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Void setBounds(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Void repaint(java.lang.Long parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public abstract java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setVisible(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void handleEvent(java.awt.AWTEvent parameter1) ;
	public abstract java.lang.Void createBuffers(java.lang.Integer parameter1, java.awt.BufferCapabilities parameter2) ;
	public abstract java.lang.Void flip(java.awt.BufferCapabilities.FlipContents parameter1) ;
	public abstract java.lang.Void setBackground(java.awt.Color parameter1) ;
	public abstract java.lang.Void setForeground(java.awt.Color parameter1) ;
	public abstract java.lang.Boolean requestFocus(java.awt.Component parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3, java.lang.Long parameter4) ;
	public abstract java.awt.Dimension getMinimumSize() ;
	public abstract java.awt.Dimension getPreferredSize() ;
	public abstract java.awt.Dimension minimumSize() ;
	public abstract java.awt.Dimension preferredSize() ;
	public abstract java.lang.Void setFont(java.awt.Font parameter1) ;
	public abstract java.awt.Graphics getGraphics() ;
	public abstract java.lang.Void paint(java.awt.Graphics parameter1) ;
	public abstract java.lang.Void print(java.awt.Graphics parameter1) ;
	public abstract java.awt.GraphicsConfiguration getGraphicsConfiguration() ;
	public abstract java.awt.Image getBackBuffer() ;
	public abstract java.awt.Image createImage(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Point getLocationOnScreen() ;
	public abstract java.awt.Toolkit getToolkit() ;
	public abstract java.lang.Void coalescePaintEvent(java.awt.event.PaintEvent parameter1) ;
	public abstract java.awt.image.ColorModel getColorModel() ;
	public abstract java.awt.image.VolatileImage createVolatileImage(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.FontMetrics getFontMetrics(java.awt.Font parameter1) ;
	public abstract java.awt.Image createImage(java.awt.image.ImageProducer parameter1) ;
	public abstract java.lang.Integer checkImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.ImageObserver parameter4) ;
	public abstract java.lang.Boolean prepareImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.ImageObserver parameter4) ;
}

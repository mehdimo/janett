package java.awt.peer;

interface MenuPeer implements java.awt.peer.MenuItemPeer
{
	public abstract java.lang.Void addSeparator() ;
	public abstract java.lang.Void delItem(java.lang.Integer parameter1) ;
	public abstract java.lang.Void addItem(java.awt.MenuItem parameter1) ;
}

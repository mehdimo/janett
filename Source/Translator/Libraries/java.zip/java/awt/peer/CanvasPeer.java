package java.awt.peer;

interface CanvasPeer implements java.awt.peer.ComponentPeer
{
}

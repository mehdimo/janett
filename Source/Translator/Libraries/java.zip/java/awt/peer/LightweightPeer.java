package java.awt.peer;

interface LightweightPeer implements java.awt.peer.ComponentPeer
{
}

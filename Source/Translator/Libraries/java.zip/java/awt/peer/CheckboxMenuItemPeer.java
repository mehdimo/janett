package java.awt.peer;

interface CheckboxMenuItemPeer implements java.awt.peer.MenuItemPeer
{
	public abstract java.lang.Void setState(java.lang.Boolean parameter1) ;
}

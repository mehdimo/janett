package java.awt;

abstract class GridLayout implements java.awt.LayoutManager, java.io.Serializable
{
	public java.lang.Integer getColumns() ;
	public java.lang.Integer getHgap() ;
	public java.lang.Integer getRows() ;
	public java.lang.Integer getVgap() ;
	public GridLayout() ;
	public java.lang.Void setColumns(java.lang.Integer parameter1) ;
	public java.lang.Void setHgap(java.lang.Integer parameter1) ;
	public java.lang.Void setRows(java.lang.Integer parameter1) ;
	public java.lang.Void setVgap(java.lang.Integer parameter1) ;
	public GridLayout(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public GridLayout(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
}

package java.awt;

abstract class Menu extends java.awt.MenuItem implements java.awt.MenuContainer, javax.accessibility.Accessible
{
	public java.lang.Integer countItems() ;
	public java.lang.Integer getItemCount() ;
	public Menu() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void addSeparator() ;
	public java.lang.Void removeAll() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Boolean isTearOff() ;
	public java.lang.Void insertSeparator(java.lang.Integer parameter1) ;
	public java.lang.Void remove(java.lang.Integer parameter1) ;
	public java.lang.Void remove(java.awt.MenuComponent parameter1) ;
	public java.awt.MenuItem getItem(java.lang.Integer parameter1) ;
	public java.lang.Void insert(java.awt.MenuItem parameter1, java.lang.Integer parameter2) ;
	public java.lang.String paramString() ;
	public Menu(java.lang.String parameter1) ;
	public java.lang.Void add(java.lang.String parameter1) ;
	public java.lang.Void insert(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public Menu(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.awt.MenuItem add(java.awt.MenuItem parameter1) ;
	abstract class AccessibleAWTMenu extends java.awt.MenuItem.AccessibleAWTMenuItem
	{
		public AccessibleAWTMenu(java.awt.Menu parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

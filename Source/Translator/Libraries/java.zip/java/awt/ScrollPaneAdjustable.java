package java.awt;

abstract class ScrollPaneAdjustable implements java.awt.Adjustable, java.io.Serializable
{
	public java.lang.Integer getBlockIncrement() ;
	public java.lang.Integer getMaximum() ;
	public java.lang.Integer getMinimum() ;
	public java.lang.Integer getOrientation() ;
	public java.lang.Integer getUnitIncrement() ;
	public java.lang.Integer getValue() ;
	public java.lang.Integer getVisibleAmount() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public java.lang.Void setBlockIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setMaximum(java.lang.Integer parameter1) ;
	public java.lang.Void setMinimum(java.lang.Integer parameter1) ;
	public java.lang.Void setUnitIncrement(java.lang.Integer parameter1) ;
	public java.lang.Void setValue(java.lang.Integer parameter1) ;
	public java.lang.Void setVisibleAmount(java.lang.Integer parameter1) ;
	public java.lang.Void setValueIsAdjusting(java.lang.Boolean parameter1) ;
	public java.awt.event.AdjustmentListener[] getAdjustmentListeners() ;
	public java.lang.Void addAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	public java.lang.Void removeAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	public java.lang.String paramString() ;
	public java.lang.String toString() ;
}

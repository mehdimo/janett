package java.awt;

abstract class Label extends java.awt.Component implements javax.accessibility.Accessible
{
	public java.lang.Integer getAlignment() ;
	public Label() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void setAlignment(java.lang.Integer parameter1) ;
	public java.lang.String getText() ;
	public java.lang.String paramString() ;
	public Label(java.lang.String parameter1) ;
	public java.lang.Void setText(java.lang.String parameter1) ;
	public Label(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	java.lang.Integer LEFT;
	java.lang.Integer CENTER;
	java.lang.Integer RIGHT;
	abstract class AccessibleAWTLabel extends java.awt.Component.AccessibleAWTComponent
	{
		public AccessibleAWTLabel(java.awt.Label parameter1) ;
		public java.lang.String getAccessibleName() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

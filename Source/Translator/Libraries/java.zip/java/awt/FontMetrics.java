package java.awt;

abstract class FontMetrics implements java.io.Serializable
{
	public java.lang.Integer getAscent() ;
	public java.lang.Integer getDescent() ;
	public java.lang.Integer getHeight() ;
	public java.lang.Integer getLeading() ;
	public java.lang.Integer getMaxAdvance() ;
	public java.lang.Integer getMaxAscent() ;
	public java.lang.Integer getMaxDecent() ;
	public java.lang.Integer getMaxDescent() ;
	public java.lang.Boolean hasUniformLineMetrics() ;
	public java.lang.Integer[] getWidths() ;
	public java.lang.Integer charWidth(java.lang.Character parameter1) ;
	public java.lang.Integer charWidth(java.lang.Integer parameter1) ;
	public java.lang.Integer bytesWidth(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Integer charsWidth(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.awt.Font getFont() ;
	public FontMetrics(java.awt.Font parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Integer stringWidth(java.lang.String parameter1) ;
	public java.awt.font.LineMetrics getLineMetrics(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
	public java.awt.geom.Rectangle2D getMaxCharBounds(java.awt.Graphics parameter1) ;
	public java.awt.geom.Rectangle2D getStringBounds(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
	public java.awt.font.LineMetrics getLineMetrics(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
	public java.awt.font.LineMetrics getLineMetrics(java.lang.String parameter1, java.awt.Graphics parameter2) ;
	public java.awt.font.LineMetrics getLineMetrics(java.text.CharacterIterator parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
	public java.awt.geom.Rectangle2D getStringBounds(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
	public java.awt.geom.Rectangle2D getStringBounds(java.lang.String parameter1, java.awt.Graphics parameter2) ;
	public java.awt.geom.Rectangle2D getStringBounds(java.text.CharacterIterator parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.Graphics parameter4) ;
}

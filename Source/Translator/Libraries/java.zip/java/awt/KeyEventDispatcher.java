package java.awt;

interface KeyEventDispatcher
{
	public abstract java.lang.Boolean dispatchKeyEvent(java.awt.event.KeyEvent parameter1) ;
}

package java.awt;

abstract class Point extends java.awt.geom.Point2D implements java.io.Serializable
{
	public java.lang.Double getX() ;
	public java.lang.Double getY() ;
	public Point() ;
	public java.lang.Void setLocation(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public Point(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void move(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setLocation(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void translate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Point getLocation() ;
	public Point(java.awt.Point parameter1) ;
	public java.lang.Void setLocation(java.awt.Point parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	java.lang.Integer x;
	java.lang.Integer y;
}

package java.awt;

abstract class GraphicsConfiguration
{
	public java.awt.BufferCapabilities getBufferCapabilities() ;
	public abstract java.awt.GraphicsDevice getDevice() ;
	public java.awt.ImageCapabilities getImageCapabilities() ;
	public abstract java.awt.Rectangle getBounds() ;
	public abstract java.awt.geom.AffineTransform getDefaultTransform() ;
	public abstract java.awt.geom.AffineTransform getNormalizingTransform() ;
	public abstract java.awt.image.BufferedImage createCompatibleImage(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.image.BufferedImage createCompatibleImage(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.awt.image.ColorModel getColorModel() ;
	public abstract java.awt.image.ColorModel getColorModel(java.lang.Integer parameter1) ;
	public abstract java.awt.image.VolatileImage createCompatibleVolatileImage(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.VolatileImage createCompatibleVolatileImage(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.ImageCapabilities parameter3) ;
}

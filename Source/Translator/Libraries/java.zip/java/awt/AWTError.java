package java.awt;

abstract class AWTError extends java.lang.Error
{
}

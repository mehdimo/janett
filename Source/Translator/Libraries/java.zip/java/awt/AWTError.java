package java.awt;

abstract class AWTError extends java.lang.Error
{
	public AWTError(java.lang.String parameter1) ;
}

package java.awt;

abstract class BufferCapabilities implements java.lang.Cloneable
{
	public java.lang.Boolean isFullScreenRequired() ;
	public java.lang.Boolean isMultiBufferAvailable() ;
	public java.lang.Boolean isPageFlipping() ;
	public java.awt.BufferCapabilities.FlipContents getFlipContents() ;
	public java.awt.ImageCapabilities getBackBufferCapabilities() ;
	public java.awt.ImageCapabilities getFrontBufferCapabilities() ;
	public java.lang.Object clone() ;
	abstract class FlipContents extends java.awt.AttributeValue
	{
		java.awt.BufferCapabilities.FlipContents UNDEFINED;
		java.awt.BufferCapabilities.FlipContents BACKGROUND;
		java.awt.BufferCapabilities.FlipContents PRIOR;
		java.awt.BufferCapabilities.FlipContents COPIED;
	}
}

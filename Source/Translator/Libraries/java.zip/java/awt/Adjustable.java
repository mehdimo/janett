package java.awt;

interface Adjustable
{
	public abstract java.lang.Integer getBlockIncrement() ;
	public abstract java.lang.Integer getMaximum() ;
	public abstract java.lang.Integer getMinimum() ;
	public abstract java.lang.Integer getOrientation() ;
	public abstract java.lang.Integer getUnitIncrement() ;
	public abstract java.lang.Integer getValue() ;
	public abstract java.lang.Integer getVisibleAmount() ;
	public abstract java.lang.Void setBlockIncrement(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setMaximum(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setMinimum(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setUnitIncrement(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setValue(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setVisibleAmount(java.lang.Integer parameter1) ;
	public abstract java.lang.Void addAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	public abstract java.lang.Void removeAdjustmentListener(java.awt.event.AdjustmentListener parameter1) ;
	java.lang.Integer HORIZONTAL;
	java.lang.Integer VERTICAL;
	java.lang.Integer NO_ORIENTATION;
}

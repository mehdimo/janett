package java.awt;

abstract class TextComponent extends java.awt.Component implements javax.accessibility.Accessible
{
	public java.lang.Integer getCaretPosition() ;
	public java.lang.Integer getSelectionEnd() ;
	public java.lang.Integer getSelectionStart() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void selectAll() ;
	public java.lang.Boolean isEditable() ;
	public java.lang.Void setCaretPosition(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectionEnd(java.lang.Integer parameter1) ;
	public java.lang.Void setSelectionStart(java.lang.Integer parameter1) ;
	public java.lang.Void select(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void enableInputMethods(java.lang.Boolean parameter1) ;
	public java.lang.Void setEditable(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.awt.Color getBackground() ;
	public java.lang.Void setBackground(java.awt.Color parameter1) ;
	public java.lang.Void processTextEvent(java.awt.event.TextEvent parameter1) ;
	public java.awt.event.TextListener[] getTextListeners() ;
	public java.lang.Void addTextListener(java.awt.event.TextListener parameter1) ;
	public java.lang.Void removeTextListener(java.awt.event.TextListener parameter1) ;
	public java.lang.String getSelectedText() ;
	public java.lang.String getText() ;
	public java.lang.String paramString() ;
	public java.lang.Void setText(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTTextComponent extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleText, java.awt.event.TextListener
	{
		public java.lang.Integer getCaretPosition() ;
		public java.lang.Integer getCharCount() ;
		public java.lang.Integer getSelectionEnd() ;
		public java.lang.Integer getSelectionStart() ;
		public java.lang.Integer getIndexAtPoint(java.awt.Point parameter1) ;
		public java.awt.Rectangle getCharacterBounds(java.lang.Integer parameter1) ;
		public java.lang.Void textValueChanged(java.awt.event.TextEvent parameter1) ;
		public java.lang.String getSelectedText() ;
		public java.lang.String getAfterIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
		public java.lang.String getAtIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
		public java.lang.String getBeforeIndex(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
		public javax.accessibility.AccessibleText getAccessibleText() ;
		public javax.swing.text.AttributeSet getCharacterAttribute(java.lang.Integer parameter1) ;
	}
}

package java.awt;

abstract class MenuItem extends java.awt.MenuComponent implements javax.accessibility.Accessible
{
	public MenuItem() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void deleteShortcut() ;
	public java.lang.Void disable() ;
	public java.lang.Void enable() ;
	public java.lang.Boolean isEnabled() ;
	public java.lang.Void disableEvents(java.lang.Long parameter1) ;
	public java.lang.Void enableEvents(java.lang.Long parameter1) ;
	public java.lang.Void enable(java.lang.Boolean parameter1) ;
	public java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.awt.MenuShortcut getShortcut() ;
	public java.lang.Void setShortcut(java.awt.MenuShortcut parameter1) ;
	public java.lang.Void processActionEvent(java.awt.event.ActionEvent parameter1) ;
	public java.awt.event.ActionListener[] getActionListeners() ;
	public java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.String getActionCommand() ;
	public java.lang.String getLabel() ;
	public java.lang.String paramString() ;
	public MenuItem(java.lang.String parameter1) ;
	public java.lang.Void setActionCommand(java.lang.String parameter1) ;
	public java.lang.Void setLabel(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public MenuItem(java.lang.String parameter1, java.awt.MenuShortcut parameter2) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTMenuItem extends java.awt.MenuComponent.AccessibleAWTMenuComponent implements javax.accessibility.AccessibleAction, javax.accessibility.AccessibleValue
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public AccessibleAWTMenuItem(java.awt.MenuItem parameter1) ;
		public java.lang.Number getCurrentAccessibleValue() ;
		public java.lang.Number getMaximumAccessibleValue() ;
		public java.lang.Number getMinimumAccessibleValue() ;
		public java.lang.Boolean setCurrentAccessibleValue(java.lang.Number parameter1) ;
		public java.lang.String getAccessibleName() ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleAction getAccessibleAction() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleValue getAccessibleValue() ;
	}
}

package java.awt;

abstract class Graphics2D extends java.awt.Graphics
{
	public Graphics2D() ;
	public abstract java.lang.Void rotate(java.lang.Double parameter1) ;
	public abstract java.lang.Void scale(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void shear(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void translate(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void rotate(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3) ;
	public abstract java.lang.Void translate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void draw3DRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public java.lang.Void fill3DRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public abstract java.awt.Color getBackground() ;
	public abstract java.lang.Void setBackground(java.awt.Color parameter1) ;
	public abstract java.awt.Composite getComposite() ;
	public abstract java.lang.Void setComposite(java.awt.Composite parameter1) ;
	public abstract java.awt.GraphicsConfiguration getDeviceConfiguration() ;
	public abstract java.awt.Paint getPaint() ;
	public abstract java.lang.Void setPaint(java.awt.Paint parameter1) ;
	public abstract java.awt.RenderingHints getRenderingHints() ;
	public abstract java.lang.Void clip(java.awt.Shape parameter1) ;
	public abstract java.lang.Void draw(java.awt.Shape parameter1) ;
	public abstract java.lang.Void fill(java.awt.Shape parameter1) ;
	public abstract java.awt.Stroke getStroke() ;
	public abstract java.lang.Void setStroke(java.awt.Stroke parameter1) ;
	public abstract java.awt.font.FontRenderContext getFontRenderContext() ;
	public abstract java.lang.Void drawGlyphVector(java.awt.font.GlyphVector parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public abstract java.awt.geom.AffineTransform getTransform() ;
	public abstract java.lang.Void setTransform(java.awt.geom.AffineTransform parameter1) ;
	public abstract java.lang.Void transform(java.awt.geom.AffineTransform parameter1) ;
	public abstract java.lang.Void drawString(java.lang.String parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public abstract java.lang.Void drawString(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void drawString(java.text.AttributedCharacterIterator parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public abstract java.lang.Void drawString(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void addRenderingHints(java.util.Map parameter1) ;
	public abstract java.lang.Void setRenderingHints(java.util.Map parameter1) ;
	public abstract java.lang.Boolean hit(java.awt.Rectangle parameter1, java.awt.Shape parameter2, java.lang.Boolean parameter3) ;
	public abstract java.lang.Void drawRenderedImage(java.awt.image.RenderedImage parameter1, java.awt.geom.AffineTransform parameter2) ;
	public abstract java.lang.Void drawRenderableImage(java.awt.image.renderable.RenderableImage parameter1, java.awt.geom.AffineTransform parameter2) ;
	public abstract java.lang.Void drawImage(java.awt.image.BufferedImage parameter1, java.awt.image.BufferedImageOp parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Object getRenderingHint(java.awt.RenderingHints.Key parameter1) ;
	public abstract java.lang.Void setRenderingHint(java.awt.RenderingHints.Key parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Boolean drawImage(java.awt.Image parameter1, java.awt.geom.AffineTransform parameter2, java.awt.image.ImageObserver parameter3) ;
}

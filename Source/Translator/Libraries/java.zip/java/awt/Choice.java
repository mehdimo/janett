package java.awt;

abstract class Choice extends java.awt.Component implements java.awt.ItemSelectable, javax.accessibility.Accessible
{
	public java.lang.Integer countItems() ;
	public java.lang.Integer getItemCount() ;
	public java.lang.Integer getSelectedIndex() ;
	public Choice() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void removeAll() ;
	public java.lang.Void remove(java.lang.Integer parameter1) ;
	public java.lang.Void select(java.lang.Integer parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void processItemEvent(java.awt.event.ItemEvent parameter1) ;
	public java.awt.event.ItemListener[] getItemListeners() ;
	public java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String getSelectedItem() ;
	public java.lang.String paramString() ;
	public java.lang.String getItem(java.lang.Integer parameter1) ;
	public java.lang.Void add(java.lang.String parameter1) ;
	public java.lang.Void addItem(java.lang.String parameter1) ;
	public java.lang.Void remove(java.lang.String parameter1) ;
	public java.lang.Void select(java.lang.String parameter1) ;
	public java.lang.Void insert(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTChoice extends java.awt.Component.AccessibleAWTComponent implements javax.accessibility.AccessibleAction
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public AccessibleAWTChoice(java.awt.Choice parameter1) ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleAction getAccessibleAction() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

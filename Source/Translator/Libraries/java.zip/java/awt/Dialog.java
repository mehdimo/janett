package java.awt;

abstract class Dialog extends java.awt.Window
{
	public java.lang.Void addNotify() ;
	public java.lang.Void dispose() ;
	public java.lang.Void hide() ;
	public java.lang.Void show() ;
	public java.lang.Boolean isModal() ;
	public java.lang.Boolean isResizable() ;
	public java.lang.Boolean isUndecorated() ;
	public java.lang.Void setModal(java.lang.Boolean parameter1) ;
	public java.lang.Void setResizable(java.lang.Boolean parameter1) ;
	public java.lang.Void setUndecorated(java.lang.Boolean parameter1) ;
	public Dialog(java.awt.Dialog parameter1) ;
	public Dialog(java.awt.Frame parameter1) ;
	public Dialog(java.awt.Frame parameter1, java.lang.Boolean parameter2) ;
	public java.lang.String getTitle() ;
	public java.lang.String paramString() ;
	public java.lang.Void setTitle(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public Dialog(java.awt.Dialog parameter1, java.lang.String parameter2) ;
	public Dialog(java.awt.Dialog parameter1, java.lang.String parameter2, java.lang.Boolean parameter3) ;
	public Dialog(java.awt.Frame parameter1, java.lang.String parameter2) ;
	public Dialog(java.awt.Frame parameter1, java.lang.String parameter2, java.lang.Boolean parameter3) ;
	public Dialog(java.awt.Dialog parameter1, java.lang.String parameter2, java.lang.Boolean parameter3, java.awt.GraphicsConfiguration parameter4) ;
	public Dialog(java.awt.Frame parameter1, java.lang.String parameter2, java.lang.Boolean parameter3, java.awt.GraphicsConfiguration parameter4) ;
	abstract class AccessibleAWTDialog extends java.awt.Window.AccessibleAWTWindow
	{
		public AccessibleAWTDialog(java.awt.Dialog parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

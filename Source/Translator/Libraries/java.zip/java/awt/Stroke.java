package java.awt;

interface Stroke
{
	public abstract java.awt.Shape createStrokedShape(java.awt.Shape parameter1) ;
}

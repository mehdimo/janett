package java.awt;

abstract class MenuShortcut implements java.io.Serializable
{
	public java.lang.Integer getKey() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean usesShiftModifier() ;
	public MenuShortcut(java.lang.Integer parameter1) ;
	public MenuShortcut(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Boolean equals(java.awt.MenuShortcut parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String paramString() ;
	public java.lang.String toString() ;
}

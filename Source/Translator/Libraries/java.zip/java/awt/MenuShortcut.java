package java.awt;

abstract class MenuShortcut implements java.io.Serializable
{
	public java.lang.Integer getKey() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean usesShiftModifier() ;
	public java.lang.Boolean equals(java.awt.MenuShortcut parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String paramString() ;
	public java.lang.String toString() ;
}

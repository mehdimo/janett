package java.awt;

abstract class CheckboxMenuItem extends java.awt.MenuItem implements java.awt.ItemSelectable, javax.accessibility.Accessible
{
	public java.lang.Void addNotify() ;
	public java.lang.Boolean getState() ;
	public java.lang.Void setState(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void processItemEvent(java.awt.event.ItemEvent parameter1) ;
	public java.awt.event.ItemListener[] getItemListeners() ;
	public java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTCheckboxMenuItem extends java.awt.MenuItem.AccessibleAWTMenuItem implements javax.accessibility.AccessibleAction, javax.accessibility.AccessibleValue
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public java.lang.Number getCurrentAccessibleValue() ;
		public java.lang.Number getMaximumAccessibleValue() ;
		public java.lang.Number getMinimumAccessibleValue() ;
		public java.lang.Boolean setCurrentAccessibleValue(java.lang.Number parameter1) ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleAction getAccessibleAction() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleValue getAccessibleValue() ;
	}
}

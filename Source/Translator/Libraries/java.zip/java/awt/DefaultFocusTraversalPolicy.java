package java.awt;

abstract class DefaultFocusTraversalPolicy extends java.awt.ContainerOrderFocusTraversalPolicy
{
	public java.lang.Boolean accept(java.awt.Component parameter1) ;
}

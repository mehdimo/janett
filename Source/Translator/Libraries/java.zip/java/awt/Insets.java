package java.awt;

abstract class Insets implements java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	java.lang.Integer top;
	java.lang.Integer left;
	java.lang.Integer bottom;
	java.lang.Integer right;
}

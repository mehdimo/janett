package java.awt;

abstract class FileDialog extends java.awt.Dialog
{
	public java.lang.Integer getMode() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void setMode(java.lang.Integer parameter1) ;
	public java.io.FilenameFilter getFilenameFilter() ;
	public java.lang.Void setFilenameFilter(java.io.FilenameFilter parameter1) ;
	public java.lang.String getDirectory() ;
	public java.lang.String getFile() ;
	public java.lang.String paramString() ;
	public java.lang.Void setDirectory(java.lang.String parameter1) ;
	public java.lang.Void setFile(java.lang.String parameter1) ;
	java.lang.Integer LOAD;
	java.lang.Integer SAVE;
}

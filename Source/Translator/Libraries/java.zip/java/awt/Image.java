package java.awt;

abstract class Image
{
	public Image() ;
	public abstract java.lang.Void flush() ;
	public abstract java.awt.Graphics getGraphics() ;
	public java.awt.Image getScaledInstance(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Integer getHeight(java.awt.image.ImageObserver parameter1) ;
	public abstract java.lang.Integer getWidth(java.awt.image.ImageObserver parameter1) ;
	public abstract java.awt.image.ImageProducer getSource() ;
	public abstract java.lang.Object getProperty(java.lang.String parameter1, java.awt.image.ImageObserver parameter2) ;
	java.lang.Object UndefinedProperty;
	java.lang.Integer SCALE_DEFAULT;
	java.lang.Integer SCALE_FAST;
	java.lang.Integer SCALE_SMOOTH;
	java.lang.Integer SCALE_REPLICATE;
	java.lang.Integer SCALE_AREA_AVERAGING;
}

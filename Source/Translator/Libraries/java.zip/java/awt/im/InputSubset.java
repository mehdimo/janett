package java.awt.im;

abstract class InputSubset extends java.lang.Character.Subset
{
	java.awt.im.InputSubset LATIN;
	java.awt.im.InputSubset LATIN_DIGITS;
	java.awt.im.InputSubset TRADITIONAL_HANZI;
	java.awt.im.InputSubset SIMPLIFIED_HANZI;
	java.awt.im.InputSubset KANJI;
	java.awt.im.InputSubset HANJA;
	java.awt.im.InputSubset HALFWIDTH_KATAKANA;
	java.awt.im.InputSubset FULLWIDTH_LATIN;
	java.awt.im.InputSubset FULLWIDTH_DIGITS;
}

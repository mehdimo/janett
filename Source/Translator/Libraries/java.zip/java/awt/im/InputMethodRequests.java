package java.awt.im;

interface InputMethodRequests
{
	public abstract java.lang.Integer getCommittedTextLength() ;
	public abstract java.lang.Integer getInsertPositionOffset() ;
	public abstract java.awt.font.TextHitInfo getLocationOffset(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Rectangle getTextLocation(java.awt.font.TextHitInfo parameter1) ;
	public abstract java.text.AttributedCharacterIterator getCommittedText(java.lang.Integer parameter1, java.lang.Integer parameter2, java.text.AttributedCharacterIterator.Attribute[] parameter3) ;
	public abstract java.text.AttributedCharacterIterator cancelLatestCommittedText(java.text.AttributedCharacterIterator.Attribute[] parameter1) ;
	public abstract java.text.AttributedCharacterIterator getSelectedText(java.text.AttributedCharacterIterator.Attribute[] parameter1) ;
}

package java.awt.im;

abstract class InputContext
{
	public java.lang.Void dispose() ;
	public java.lang.Void endComposition() ;
	public java.lang.Void reconvert() ;
	public java.lang.Boolean isCompositionEnabled() ;
	public java.lang.Void setCompositionEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Void dispatchEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void removeNotify(java.awt.Component parameter1) ;
	public java.awt.im.InputContext getInstance() ;
	public java.lang.Void setCharacterSubsets(java.lang.Character.Subset[] parameter1) ;
	public java.lang.Object getInputMethodControlObject() ;
	public java.util.Locale getLocale() ;
	public java.lang.Boolean selectInputMethod(java.util.Locale parameter1) ;
}

package java.awt.im;

abstract class InputMethodHighlight
{
	public java.lang.Integer getState() ;
	public java.lang.Integer getVariation() ;
	public java.lang.Boolean isSelected() ;
	public InputMethodHighlight(java.lang.Boolean parameter1, java.lang.Integer parameter2) ;
	public InputMethodHighlight(java.lang.Boolean parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.util.Map getStyle() ;
	public InputMethodHighlight(java.lang.Boolean parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.util.Map parameter4) ;
	java.lang.Integer RAW_TEXT;
	java.lang.Integer CONVERTED_TEXT;
	java.awt.im.InputMethodHighlight UNSELECTED_RAW_TEXT_HIGHLIGHT;
	java.awt.im.InputMethodHighlight SELECTED_RAW_TEXT_HIGHLIGHT;
	java.awt.im.InputMethodHighlight UNSELECTED_CONVERTED_TEXT_HIGHLIGHT;
	java.awt.im.InputMethodHighlight SELECTED_CONVERTED_TEXT_HIGHLIGHT;
}

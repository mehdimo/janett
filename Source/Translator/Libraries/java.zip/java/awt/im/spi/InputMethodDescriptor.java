package java.awt.im.spi;

interface InputMethodDescriptor
{
	public abstract java.lang.Boolean hasDynamicLocaleList() ;
	public abstract java.awt.im.spi.InputMethod createInputMethod() ;
	public abstract java.util.Locale[] getAvailableLocales() ;
	public abstract java.awt.Image getInputMethodIcon(java.util.Locale parameter1) ;
	public abstract java.lang.String getInputMethodDisplayName(java.util.Locale parameter1, java.util.Locale parameter2) ;
}

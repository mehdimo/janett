package java.awt.im.spi;

interface InputMethod
{
	public abstract java.lang.Void activate() ;
	public abstract java.lang.Void dispose() ;
	public abstract java.lang.Void endComposition() ;
	public abstract java.lang.Void hideWindows() ;
	public abstract java.lang.Void reconvert() ;
	public abstract java.lang.Void removeNotify() ;
	public abstract java.lang.Boolean isCompositionEnabled() ;
	public abstract java.lang.Void deactivate(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setCompositionEnabled(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void dispatchEvent(java.awt.AWTEvent parameter1) ;
	public abstract java.lang.Void notifyClientWindowChange(java.awt.Rectangle parameter1) ;
	public abstract java.lang.Void setInputMethodContext(java.awt.im.spi.InputMethodContext parameter1) ;
	public abstract java.lang.Void setCharacterSubsets(java.lang.Character.Subset[] parameter1) ;
	public abstract java.lang.Object getControlObject() ;
	public abstract java.util.Locale getLocale() ;
	public abstract java.lang.Boolean setLocale(java.util.Locale parameter1) ;
}

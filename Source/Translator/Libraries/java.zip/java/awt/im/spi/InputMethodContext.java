package java.awt.im.spi;

interface InputMethodContext implements java.awt.im.InputMethodRequests
{
	public abstract java.lang.Void enableClientWindowNotification(java.awt.im.spi.InputMethod parameter1, java.lang.Boolean parameter2) ;
	public abstract java.awt.Window createInputMethodWindow(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public abstract javax.swing.JFrame createInputMethodJFrame(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void dispatchInputMethodEvent(java.lang.Integer parameter1, java.text.AttributedCharacterIterator parameter2, java.lang.Integer parameter3, java.awt.font.TextHitInfo parameter4, java.awt.font.TextHitInfo parameter5) ;
}

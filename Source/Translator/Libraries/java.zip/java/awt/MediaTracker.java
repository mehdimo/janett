package java.awt;

abstract class MediaTracker implements java.io.Serializable
{
	public java.lang.Void waitForAll() ;
	public java.lang.Boolean checkAll() ;
	public java.lang.Boolean isErrorAny() ;
	public java.lang.Void waitForID(java.lang.Integer parameter1) ;
	public java.lang.Boolean checkID(java.lang.Integer parameter1) ;
	public java.lang.Boolean isErrorID(java.lang.Integer parameter1) ;
	public java.lang.Boolean waitForID(java.lang.Integer parameter1, java.lang.Long parameter2) ;
	public java.lang.Integer statusID(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Boolean checkID(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Boolean waitForAll(java.lang.Long parameter1) ;
	public java.lang.Integer statusAll(java.lang.Boolean parameter1) ;
	public java.lang.Boolean checkAll(java.lang.Boolean parameter1) ;
	public MediaTracker(java.awt.Component parameter1) ;
	public java.lang.Void removeImage(java.awt.Image parameter1) ;
	public java.lang.Void addImage(java.awt.Image parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void removeImage(java.awt.Image parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void addImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void removeImage(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Object[] getErrorsAny() ;
	public java.lang.Object[] getErrorsID(java.lang.Integer parameter1) ;
	java.lang.Integer LOADING;
	java.lang.Integer ABORTED;
	java.lang.Integer ERRORED;
	java.lang.Integer COMPLETE;
}

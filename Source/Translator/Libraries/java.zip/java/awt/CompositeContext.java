package java.awt;

interface CompositeContext
{
	public abstract java.lang.Void dispose() ;
	public abstract java.lang.Void compose(java.awt.image.Raster parameter1, java.awt.image.Raster parameter2, java.awt.image.WritableRaster parameter3) ;
}

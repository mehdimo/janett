package java.awt;

abstract class FlowLayout implements java.awt.LayoutManager, java.io.Serializable
{
	public java.lang.Integer getAlignment() ;
	public java.lang.Integer getHgap() ;
	public java.lang.Integer getVgap() ;
	public java.lang.Void setAlignment(java.lang.Integer parameter1) ;
	public java.lang.Void setHgap(java.lang.Integer parameter1) ;
	public java.lang.Void setVgap(java.lang.Integer parameter1) ;
	public java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
	java.lang.Integer LEFT;
	java.lang.Integer CENTER;
	java.lang.Integer RIGHT;
	java.lang.Integer LEADING;
	java.lang.Integer TRAILING;
}

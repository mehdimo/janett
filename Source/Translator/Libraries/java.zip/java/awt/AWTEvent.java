package java.awt;

abstract class AWTEvent extends java.util.EventObject
{
	public java.lang.Integer getID() ;
	public java.lang.Void consume() ;
	public java.lang.Boolean isConsumed() ;
	public java.lang.Void setSource(java.lang.Object parameter1) ;
	public java.lang.String paramString() ;
	public java.lang.String toString() ;
	java.lang.Long COMPONENT_EVENT_MASK;
	java.lang.Long CONTAINER_EVENT_MASK;
	java.lang.Long FOCUS_EVENT_MASK;
	java.lang.Long KEY_EVENT_MASK;
	java.lang.Long MOUSE_EVENT_MASK;
	java.lang.Long MOUSE_MOTION_EVENT_MASK;
	java.lang.Long WINDOW_EVENT_MASK;
	java.lang.Long ACTION_EVENT_MASK;
	java.lang.Long ADJUSTMENT_EVENT_MASK;
	java.lang.Long ITEM_EVENT_MASK;
	java.lang.Long TEXT_EVENT_MASK;
	java.lang.Long INPUT_METHOD_EVENT_MASK;
	java.lang.Long PAINT_EVENT_MASK;
	java.lang.Long INVOCATION_EVENT_MASK;
	java.lang.Long HIERARCHY_EVENT_MASK;
	java.lang.Long HIERARCHY_BOUNDS_EVENT_MASK;
	java.lang.Long MOUSE_WHEEL_EVENT_MASK;
	java.lang.Long WINDOW_STATE_EVENT_MASK;
	java.lang.Long WINDOW_FOCUS_EVENT_MASK;
	java.lang.Integer RESERVED_ID_MAX;
}

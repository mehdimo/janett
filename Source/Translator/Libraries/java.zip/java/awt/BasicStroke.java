package java.awt;

abstract class BasicStroke implements java.awt.Stroke
{
	public java.lang.Float getDashPhase() ;
	public java.lang.Float getLineWidth() ;
	public java.lang.Float getMiterLimit() ;
	public java.lang.Integer getEndCap() ;
	public java.lang.Integer getLineJoin() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Float[] getDashArray() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.awt.Shape createStrokedShape(java.awt.Shape parameter1) ;
	java.lang.Integer JOIN_MITER;
	java.lang.Integer JOIN_ROUND;
	java.lang.Integer JOIN_BEVEL;
	java.lang.Integer CAP_BUTT;
	java.lang.Integer CAP_ROUND;
	java.lang.Integer CAP_SQUARE;
}

package java.awt;

abstract class RenderingHints implements java.util.Map, java.lang.Cloneable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Integer size() ;
	public java.lang.Void clear() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Void add(java.awt.RenderingHints parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Boolean containsKey(java.lang.Object parameter1) ;
	public java.lang.Boolean containsValue(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.util.Collection values() ;
	public RenderingHints(java.util.Map parameter1) ;
	public java.lang.Void putAll(java.util.Map parameter1) ;
	public java.util.Set entrySet() ;
	public java.util.Set keySet() ;
	public RenderingHints(java.awt.RenderingHints.Key parameter1, java.lang.Object parameter2) ;
	public java.lang.Object get(java.lang.Object parameter1) ;
	public java.lang.Object remove(java.lang.Object parameter1) ;
	public java.lang.Object put(java.lang.Object parameter1, java.lang.Object parameter2) ;
	java.awt.RenderingHints.Key KEY_ANTIALIASING;
	java.lang.Object VALUE_ANTIALIAS_ON;
	java.lang.Object VALUE_ANTIALIAS_OFF;
	java.lang.Object VALUE_ANTIALIAS_DEFAULT;
	java.awt.RenderingHints.Key KEY_RENDERING;
	java.lang.Object VALUE_RENDER_SPEED;
	java.lang.Object VALUE_RENDER_QUALITY;
	java.lang.Object VALUE_RENDER_DEFAULT;
	java.awt.RenderingHints.Key KEY_DITHERING;
	java.lang.Object VALUE_DITHER_DISABLE;
	java.lang.Object VALUE_DITHER_ENABLE;
	java.lang.Object VALUE_DITHER_DEFAULT;
	java.awt.RenderingHints.Key KEY_TEXT_ANTIALIASING;
	java.lang.Object VALUE_TEXT_ANTIALIAS_ON;
	java.lang.Object VALUE_TEXT_ANTIALIAS_OFF;
	java.lang.Object VALUE_TEXT_ANTIALIAS_DEFAULT;
	java.awt.RenderingHints.Key KEY_FRACTIONALMETRICS;
	java.lang.Object VALUE_FRACTIONALMETRICS_OFF;
	java.lang.Object VALUE_FRACTIONALMETRICS_ON;
	java.lang.Object VALUE_FRACTIONALMETRICS_DEFAULT;
	java.awt.RenderingHints.Key KEY_INTERPOLATION;
	java.lang.Object VALUE_INTERPOLATION_NEAREST_NEIGHBOR;
	java.lang.Object VALUE_INTERPOLATION_BILINEAR;
	java.lang.Object VALUE_INTERPOLATION_BICUBIC;
	java.awt.RenderingHints.Key KEY_ALPHA_INTERPOLATION;
	java.lang.Object VALUE_ALPHA_INTERPOLATION_SPEED;
	java.lang.Object VALUE_ALPHA_INTERPOLATION_QUALITY;
	java.lang.Object VALUE_ALPHA_INTERPOLATION_DEFAULT;
	java.awt.RenderingHints.Key KEY_COLOR_RENDERING;
	java.lang.Object VALUE_COLOR_RENDER_SPEED;
	java.lang.Object VALUE_COLOR_RENDER_QUALITY;
	java.lang.Object VALUE_COLOR_RENDER_DEFAULT;
	java.awt.RenderingHints.Key KEY_STROKE_CONTROL;
	java.lang.Object VALUE_STROKE_DEFAULT;
	java.lang.Object VALUE_STROKE_NORMALIZE;
	java.lang.Object VALUE_STROKE_PURE;
	abstract class Key
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Integer intKey() ;
		public Key(java.lang.Integer parameter1) ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public abstract java.lang.Boolean isCompatibleValue(java.lang.Object parameter1) ;
	}
}

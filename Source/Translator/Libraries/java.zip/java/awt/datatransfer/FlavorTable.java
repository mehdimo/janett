package java.awt.datatransfer;

interface FlavorTable implements java.awt.datatransfer.FlavorMap
{
	public abstract java.util.List getNativesForFlavor(java.awt.datatransfer.DataFlavor parameter1) ;
	public abstract java.util.List getFlavorsForNative(java.lang.String parameter1) ;
}

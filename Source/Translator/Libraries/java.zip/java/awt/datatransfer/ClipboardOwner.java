package java.awt.datatransfer;

interface ClipboardOwner
{
	public abstract java.lang.Void lostOwnership(java.awt.datatransfer.Clipboard parameter1, java.awt.datatransfer.Transferable parameter2) ;
}

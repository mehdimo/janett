package java.awt.datatransfer;

abstract class UnsupportedFlavorException extends java.lang.Exception
{
}

package java.awt.datatransfer;

abstract class UnsupportedFlavorException extends java.lang.Exception
{
	public UnsupportedFlavorException(java.awt.datatransfer.DataFlavor parameter1) ;
}

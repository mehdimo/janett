package java.awt.datatransfer;

abstract class StringSelection implements java.awt.datatransfer.Transferable, java.awt.datatransfer.ClipboardOwner
{
	public java.awt.datatransfer.DataFlavor[] getTransferDataFlavors() ;
	public java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
	public StringSelection(java.lang.String parameter1) ;
	public java.lang.Void lostOwnership(java.awt.datatransfer.Clipboard parameter1, java.awt.datatransfer.Transferable parameter2) ;
	public java.lang.Object getTransferData(java.awt.datatransfer.DataFlavor parameter1) ;
}

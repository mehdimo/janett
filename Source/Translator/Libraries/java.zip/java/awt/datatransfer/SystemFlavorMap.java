package java.awt.datatransfer;

abstract class SystemFlavorMap implements java.awt.datatransfer.FlavorMap, java.awt.datatransfer.FlavorTable
{
	public java.awt.datatransfer.FlavorMap getDefaultFlavorMap() ;
	public java.lang.Boolean isJavaMIMEType(java.lang.String parameter1) ;
	public java.awt.datatransfer.DataFlavor decodeDataFlavor(java.lang.String parameter1) ;
	public java.lang.Void addFlavorForUnencodedNative(java.lang.String parameter1, java.awt.datatransfer.DataFlavor parameter2) ;
	public java.lang.Void setFlavorsForNative(java.lang.String parameter1, java.awt.datatransfer.DataFlavor[] parameter2) ;
	public java.lang.String encodeDataFlavor(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.lang.Void addUnencodedNativeForFlavor(java.awt.datatransfer.DataFlavor parameter1, java.lang.String parameter2) ;
	public java.lang.Void setNativesForFlavor(java.awt.datatransfer.DataFlavor parameter1, java.lang.String[] parameter2) ;
	public java.lang.String decodeJavaMIMEType(java.lang.String parameter1) ;
	public java.lang.String encodeJavaMIMEType(java.lang.String parameter1) ;
	public java.util.List getNativesForFlavor(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.util.List getFlavorsForNative(java.lang.String parameter1) ;
	public java.util.Map getNativesForFlavors(java.awt.datatransfer.DataFlavor[] parameter1) ;
	public java.util.Map getFlavorsForNatives(java.lang.String[] parameter1) ;
}

package java.awt.datatransfer;

interface Transferable
{
	public abstract java.awt.datatransfer.DataFlavor[] getTransferDataFlavors() ;
	public abstract java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
	public abstract java.lang.Object getTransferData(java.awt.datatransfer.DataFlavor parameter1) ;
}

package java.awt.datatransfer;

abstract class DataFlavor implements java.io.Externalizable, java.lang.Cloneable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isFlavorJavaFileListType() ;
	public java.lang.Boolean isFlavorRemoteObjectType() ;
	public java.lang.Boolean isFlavorSerializedObjectType() ;
	public java.lang.Boolean isFlavorTextType() ;
	public java.lang.Boolean isMimeTypeSerializedObject() ;
	public java.lang.Boolean isRepresentationClassByteBuffer() ;
	public java.lang.Boolean isRepresentationClassCharBuffer() ;
	public java.lang.Boolean isRepresentationClassInputStream() ;
	public java.lang.Boolean isRepresentationClassReader() ;
	public java.lang.Boolean isRepresentationClassRemote() ;
	public java.lang.Boolean isRepresentationClassSerializable() ;
	public java.awt.datatransfer.DataFlavor getTextPlainUnicodeFlavor() ;
	public java.lang.Boolean equals(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.lang.Boolean isMimeTypeEqual(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.lang.Boolean match(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.lang.Void readExternal(java.io.ObjectInput parameter1) ;
	public java.lang.Void writeExternal(java.io.ObjectOutput parameter1) ;
	public java.lang.Class getDefaultRepresentationClass() ;
	public java.lang.Class getRepresentationClass() ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getDefaultRepresentationClassAsString() ;
	public java.lang.String getHumanPresentableName() ;
	public java.lang.String getMimeType() ;
	public java.lang.String getPrimaryType() ;
	public java.lang.String getSubType() ;
	public java.lang.String toString() ;
	public java.lang.Void setHumanPresentableName(java.lang.String parameter1) ;
	public java.lang.Boolean equals(java.lang.String parameter1) ;
	public java.lang.Boolean isMimeTypeEqual(java.lang.String parameter1) ;
	public java.awt.datatransfer.DataFlavor selectBestTextFlavor(java.awt.datatransfer.DataFlavor[] parameter1) ;
	public java.io.Reader getReaderForText(java.awt.datatransfer.Transferable parameter1) ;
	public java.lang.String getParameter(java.lang.String parameter1) ;
	public java.lang.String normalizeMimeType(java.lang.String parameter1) ;
	public java.lang.Class tryToLoadClass(java.lang.String parameter1, java.lang.ClassLoader parameter2) ;
	public java.lang.String normalizeMimeTypeParameter(java.lang.String parameter1, java.lang.String parameter2) ;
	java.awt.datatransfer.DataFlavor stringFlavor;
	java.awt.datatransfer.DataFlavor imageFlavor;
	java.awt.datatransfer.DataFlavor plainTextFlavor;
	java.lang.String javaSerializedObjectMimeType;
	java.awt.datatransfer.DataFlavor javaFileListFlavor;
	java.lang.String javaJVMLocalObjectMimeType;
	java.lang.String javaRemoteObjectMimeType;
}

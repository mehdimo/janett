package java.awt.datatransfer;

abstract class Clipboard
{
	public java.lang.String getName() ;
	public Clipboard(java.lang.String parameter1) ;
	public java.lang.Void setContents(java.awt.datatransfer.Transferable parameter1, java.awt.datatransfer.ClipboardOwner parameter2) ;
	public java.awt.datatransfer.Transferable getContents(java.lang.Object parameter1) ;
}

package java.awt.datatransfer;

interface FlavorMap
{
	public abstract java.util.Map getNativesForFlavors(java.awt.datatransfer.DataFlavor[] parameter1) ;
	public abstract java.util.Map getFlavorsForNatives(java.lang.String[] parameter1) ;
}

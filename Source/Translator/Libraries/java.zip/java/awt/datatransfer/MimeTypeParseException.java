package java.awt.datatransfer;

abstract class MimeTypeParseException extends java.lang.Exception
{
}

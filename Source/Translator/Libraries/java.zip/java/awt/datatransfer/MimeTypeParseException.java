package java.awt.datatransfer;

abstract class MimeTypeParseException extends java.lang.Exception
{
	public MimeTypeParseException() ;
	public MimeTypeParseException(java.lang.String parameter1) ;
}

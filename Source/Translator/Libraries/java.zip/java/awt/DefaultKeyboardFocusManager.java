package java.awt;

abstract class DefaultKeyboardFocusManager extends java.awt.KeyboardFocusManager
{
	public DefaultKeyboardFocusManager() ;
	public java.lang.Boolean dispatchEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void dequeueKeyEvents(java.lang.Long parameter1, java.awt.Component parameter2) ;
	public java.lang.Void enqueueKeyEvents(java.lang.Long parameter1, java.awt.Component parameter2) ;
	public java.lang.Void discardKeyEvents(java.awt.Component parameter1) ;
	public java.lang.Void focusNextComponent(java.awt.Component parameter1) ;
	public java.lang.Void focusPreviousComponent(java.awt.Component parameter1) ;
	public java.lang.Void upFocusCycle(java.awt.Component parameter1) ;
	public java.lang.Void downFocusCycle(java.awt.Container parameter1) ;
	public java.lang.Boolean dispatchKeyEvent(java.awt.event.KeyEvent parameter1) ;
	public java.lang.Boolean postProcessKeyEvent(java.awt.event.KeyEvent parameter1) ;
	public java.lang.Void processKeyEvent(java.awt.Component parameter1, java.awt.event.KeyEvent parameter2) ;
}

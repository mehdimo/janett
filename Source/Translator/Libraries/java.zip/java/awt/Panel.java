package java.awt;

abstract class Panel extends java.awt.Container implements javax.accessibility.Accessible
{
	public java.lang.Void addNotify() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTPanel extends java.awt.Container.AccessibleAWTContainer
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

package java.awt;

abstract class Panel extends java.awt.Container implements javax.accessibility.Accessible
{
	public Panel() ;
	public java.lang.Void addNotify() ;
	public Panel(java.awt.LayoutManager parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTPanel extends java.awt.Container.AccessibleAWTContainer
	{
		public AccessibleAWTPanel(java.awt.Panel parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

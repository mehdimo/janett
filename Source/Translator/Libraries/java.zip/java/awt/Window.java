package java.awt;

abstract class Window extends java.awt.Container implements javax.accessibility.Accessible
{
	public java.lang.Void addNotify() ;
	public java.lang.Void dispose() ;
	public java.lang.Void finalize() ;
	public java.lang.Void hide() ;
	public java.lang.Void pack() ;
	public java.lang.Void show() ;
	public java.lang.Void toBack() ;
	public java.lang.Void toFront() ;
	public java.lang.Boolean getFocusableWindowState() ;
	public java.lang.Boolean isActive() ;
	public java.lang.Boolean isFocusCycleRoot() ;
	public java.lang.Boolean isFocusableWindow() ;
	public java.lang.Boolean isFocused() ;
	public java.lang.Boolean isShowing() ;
	public java.lang.Void createBufferStrategy(java.lang.Integer parameter1) ;
	public java.lang.Void setFocusCycleRoot(java.lang.Boolean parameter1) ;
	public java.lang.Void setFocusableWindowState(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void createBufferStrategy(java.lang.Integer parameter1, java.awt.BufferCapabilities parameter2) ;
	public java.awt.Component getFocusOwner() ;
	public java.awt.Component getMostRecentFocusOwner() ;
	public java.lang.Void setLocationRelativeTo(java.awt.Component parameter1) ;
	public java.awt.Container getFocusCycleRootAncestor() ;
	public java.lang.Void setCursor(java.awt.Cursor parameter1) ;
	public java.lang.Boolean postEvent(java.awt.Event parameter1) ;
	public Window(java.awt.Frame parameter1) ;
	public java.awt.GraphicsConfiguration getGraphicsConfiguration() ;
	public java.awt.Toolkit getToolkit() ;
	public java.awt.Window getOwner() ;
	public java.awt.Window[] getOwnedWindows() ;
	public Window(java.awt.Window parameter1) ;
	public java.lang.Void processWindowEvent(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void processWindowFocusEvent(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void processWindowStateEvent(java.awt.event.WindowEvent parameter1) ;
	public java.awt.event.WindowFocusListener[] getWindowFocusListeners() ;
	public java.lang.Void addWindowFocusListener(java.awt.event.WindowFocusListener parameter1) ;
	public java.lang.Void removeWindowFocusListener(java.awt.event.WindowFocusListener parameter1) ;
	public java.awt.event.WindowListener[] getWindowListeners() ;
	public java.lang.Void addWindowListener(java.awt.event.WindowListener parameter1) ;
	public java.lang.Void removeWindowListener(java.awt.event.WindowListener parameter1) ;
	public java.awt.event.WindowStateListener[] getWindowStateListeners() ;
	public java.lang.Void addWindowStateListener(java.awt.event.WindowStateListener parameter1) ;
	public java.lang.Void removeWindowStateListener(java.awt.event.WindowStateListener parameter1) ;
	public java.awt.im.InputContext getInputContext() ;
	public java.awt.image.BufferStrategy getBufferStrategy() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.String getWarningString() ;
	public java.lang.Void applyResourceBundle(java.lang.String parameter1) ;
	public java.util.Locale getLocale() ;
	public java.lang.Void applyResourceBundle(java.util.ResourceBundle parameter1) ;
	public java.util.Set getFocusTraversalKeys(java.lang.Integer parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public Window(java.awt.Window parameter1, java.awt.GraphicsConfiguration parameter2) ;
	public java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTWindow extends java.awt.Container.AccessibleAWTContainer
	{
		public AccessibleAWTWindow(java.awt.Window parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

package java.awt;

abstract class FocusTraversalPolicy
{
	public abstract java.awt.Component getDefaultComponent(java.awt.Container parameter1) ;
	public abstract java.awt.Component getFirstComponent(java.awt.Container parameter1) ;
	public abstract java.awt.Component getLastComponent(java.awt.Container parameter1) ;
	public java.awt.Component getInitialComponent(java.awt.Window parameter1) ;
	public abstract java.awt.Component getComponentAfter(java.awt.Container parameter1, java.awt.Component parameter2) ;
	public abstract java.awt.Component getComponentBefore(java.awt.Container parameter1, java.awt.Component parameter2) ;
}

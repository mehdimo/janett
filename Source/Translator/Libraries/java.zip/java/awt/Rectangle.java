package java.awt;

abstract class Rectangle extends java.awt.geom.Rectangle2D implements java.awt.Shape, java.io.Serializable
{
	public java.lang.Double getHeight() ;
	public java.lang.Double getWidth() ;
	public java.lang.Double getX() ;
	public java.lang.Double getY() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Integer outcode(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void add(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void grow(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void move(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void resize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setLocation(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void translate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean contains(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean inside(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void reshape(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void setBounds(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Boolean contains(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.awt.Dimension getSize() ;
	public java.lang.Void setSize(java.awt.Dimension parameter1) ;
	public java.awt.Point getLocation() ;
	public java.lang.Void add(java.awt.Point parameter1) ;
	public java.lang.Void setLocation(java.awt.Point parameter1) ;
	public java.lang.Boolean contains(java.awt.Point parameter1) ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Void add(java.awt.Rectangle parameter1) ;
	public java.lang.Void setBounds(java.awt.Rectangle parameter1) ;
	public java.lang.Boolean contains(java.awt.Rectangle parameter1) ;
	public java.lang.Boolean intersects(java.awt.Rectangle parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.awt.Rectangle intersection(java.awt.Rectangle parameter1) ;
	public java.awt.Rectangle union(java.awt.Rectangle parameter1) ;
	public java.awt.geom.Rectangle2D createIntersection(java.awt.geom.Rectangle2D parameter1) ;
	public java.awt.geom.Rectangle2D createUnion(java.awt.geom.Rectangle2D parameter1) ;
	java.lang.Integer x;
	java.lang.Integer y;
	java.lang.Integer width;
	java.lang.Integer height;
}

package java.awt;

abstract class DisplayMode
{
	public java.lang.Integer getBitDepth() ;
	public java.lang.Integer getHeight() ;
	public java.lang.Integer getRefreshRate() ;
	public java.lang.Integer getWidth() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.awt.DisplayMode parameter1) ;
	java.lang.Integer BIT_DEPTH_MULTI;
	java.lang.Integer REFRESH_RATE_UNKNOWN;
}

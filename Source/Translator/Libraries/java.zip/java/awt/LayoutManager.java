package java.awt;

interface LayoutManager
{
	public abstract java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public abstract java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public abstract java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public abstract java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public abstract java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
}

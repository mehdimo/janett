package java.awt;

abstract class AlphaComposite implements java.awt.Composite
{
	public java.lang.Float getAlpha() ;
	public java.lang.Integer getRule() ;
	public java.lang.Integer hashCode() ;
	public java.awt.AlphaComposite getInstance(java.lang.Integer parameter1) ;
	public java.awt.AlphaComposite getInstance(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.awt.CompositeContext createContext(java.awt.image.ColorModel parameter1, java.awt.image.ColorModel parameter2, java.awt.RenderingHints parameter3) ;
	java.lang.Integer CLEAR;
	java.lang.Integer SRC;
	java.lang.Integer DST;
	java.lang.Integer SRC_OVER;
	java.lang.Integer DST_OVER;
	java.lang.Integer SRC_IN;
	java.lang.Integer DST_IN;
	java.lang.Integer SRC_OUT;
	java.lang.Integer DST_OUT;
	java.lang.Integer SRC_ATOP;
	java.lang.Integer DST_ATOP;
	java.lang.Integer XOR;
	java.awt.AlphaComposite Clear;
	java.awt.AlphaComposite Src;
	java.awt.AlphaComposite Dst;
	java.awt.AlphaComposite SrcOver;
	java.awt.AlphaComposite DstOver;
	java.awt.AlphaComposite SrcIn;
	java.awt.AlphaComposite DstIn;
	java.awt.AlphaComposite SrcOut;
	java.awt.AlphaComposite DstOut;
	java.awt.AlphaComposite SrcAtop;
	java.awt.AlphaComposite DstAtop;
	java.awt.AlphaComposite Xor;
}

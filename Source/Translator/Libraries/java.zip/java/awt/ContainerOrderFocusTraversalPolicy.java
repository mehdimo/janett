package java.awt;

abstract class ContainerOrderFocusTraversalPolicy extends java.awt.FocusTraversalPolicy implements java.io.Serializable
{
	public java.lang.Boolean getImplicitDownCycleTraversal() ;
	public java.lang.Void setImplicitDownCycleTraversal(java.lang.Boolean parameter1) ;
	public java.lang.Boolean accept(java.awt.Component parameter1) ;
	public java.awt.Component getDefaultComponent(java.awt.Container parameter1) ;
	public java.awt.Component getFirstComponent(java.awt.Container parameter1) ;
	public java.awt.Component getLastComponent(java.awt.Container parameter1) ;
	public java.awt.Component getComponentAfter(java.awt.Container parameter1, java.awt.Component parameter2) ;
	public java.awt.Component getComponentBefore(java.awt.Container parameter1, java.awt.Component parameter2) ;
}

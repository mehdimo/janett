package java.awt;

abstract class GraphicsDevice
{
	public java.lang.Integer getAvailableAcceleratedMemory() ;
	public abstract java.lang.Integer getType() ;
	public GraphicsDevice() ;
	public java.lang.Boolean isDisplayChangeSupported() ;
	public java.lang.Boolean isFullScreenSupported() ;
	public java.awt.DisplayMode getDisplayMode() ;
	public java.awt.DisplayMode[] getDisplayModes() ;
	public java.lang.Void setDisplayMode(java.awt.DisplayMode parameter1) ;
	public abstract java.awt.GraphicsConfiguration getDefaultConfiguration() ;
	public abstract java.awt.GraphicsConfiguration[] getConfigurations() ;
	public java.awt.Window getFullScreenWindow() ;
	public java.lang.Void setFullScreenWindow(java.awt.Window parameter1) ;
	public abstract java.lang.String getIDstring() ;
	public java.awt.GraphicsConfiguration getBestConfiguration(java.awt.GraphicsConfigTemplate parameter1) ;
	java.lang.Integer TYPE_RASTER_SCREEN;
	java.lang.Integer TYPE_PRINTER;
	java.lang.Integer TYPE_IMAGE_BUFFER;
}

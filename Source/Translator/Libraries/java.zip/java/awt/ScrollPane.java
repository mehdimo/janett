package java.awt;

abstract class ScrollPane extends java.awt.Container implements javax.accessibility.Accessible
{
	public java.lang.Integer getHScrollbarHeight() ;
	public java.lang.Integer getScrollbarDisplayPolicy() ;
	public java.lang.Integer getVScrollbarWidth() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void doLayout() ;
	public java.lang.Void layout() ;
	public java.lang.Boolean isWheelScrollingEnabled() ;
	public java.lang.Boolean eventTypeEnabled(java.lang.Integer parameter1) ;
	public java.lang.Void setScrollPosition(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setWheelScrollingEnabled(java.lang.Boolean parameter1) ;
	public java.awt.Adjustable getHAdjustable() ;
	public java.awt.Adjustable getVAdjustable() ;
	public java.awt.Dimension getViewportSize() ;
	public java.lang.Void printComponents(java.awt.Graphics parameter1) ;
	public java.lang.Void setLayout(java.awt.LayoutManager parameter1) ;
	public java.awt.Point getScrollPosition() ;
	public java.lang.Void setScrollPosition(java.awt.Point parameter1) ;
	public java.lang.Void processMouseWheelEvent(java.awt.event.MouseWheelEvent parameter1) ;
	public java.lang.String paramString() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.lang.Void addImpl(java.awt.Component parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	java.lang.Integer SCROLLBARS_AS_NEEDED;
	java.lang.Integer SCROLLBARS_ALWAYS;
	java.lang.Integer SCROLLBARS_NEVER;
	abstract class AccessibleAWTScrollPane extends java.awt.Container.AccessibleAWTContainer
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

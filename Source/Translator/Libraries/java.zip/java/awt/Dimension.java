package java.awt;

abstract class Dimension extends java.awt.geom.Dimension2D implements java.io.Serializable
{
	public java.lang.Double getHeight() ;
	public java.lang.Double getWidth() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Void setSize(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Dimension getSize() ;
	public java.lang.Void setSize(java.awt.Dimension parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	java.lang.Integer width;
	java.lang.Integer height;
}

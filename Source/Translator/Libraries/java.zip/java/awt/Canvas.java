package java.awt;

abstract class Canvas extends java.awt.Component implements javax.accessibility.Accessible
{
	public java.lang.Void addNotify() ;
	public java.lang.Void createBufferStrategy(java.lang.Integer parameter1) ;
	public java.lang.Void createBufferStrategy(java.lang.Integer parameter1, java.awt.BufferCapabilities parameter2) ;
	public java.lang.Void paint(java.awt.Graphics parameter1) ;
	public java.lang.Void update(java.awt.Graphics parameter1) ;
	public java.awt.image.BufferStrategy getBufferStrategy() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTCanvas extends java.awt.Component.AccessibleAWTComponent
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

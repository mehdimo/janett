package java.awt.dnd;

abstract class DragSourceDragEvent extends java.awt.dnd.DragSourceEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Integer getGestureModifiers() ;
	public java.lang.Integer getGestureModifiersEx() ;
	public java.lang.Integer getTargetActions() ;
	public java.lang.Integer getUserAction() ;
	public DragSourceDragEvent(java.awt.dnd.DragSourceContext parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public DragSourceDragEvent(java.awt.dnd.DragSourceContext parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
}

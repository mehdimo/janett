package java.awt.dnd;

abstract class DragSourceDragEvent extends java.awt.dnd.DragSourceEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Integer getGestureModifiers() ;
	public java.lang.Integer getGestureModifiersEx() ;
	public java.lang.Integer getTargetActions() ;
	public java.lang.Integer getUserAction() ;
}

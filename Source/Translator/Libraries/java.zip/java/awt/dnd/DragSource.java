package java.awt.dnd;

abstract class DragSource implements java.io.Serializable
{
	public java.lang.Boolean isDragImageSupported() ;
	public java.awt.datatransfer.FlavorMap getFlavorMap() ;
	public java.awt.dnd.DragSource getDefaultDragSource() ;
	public java.awt.dnd.DragSourceListener[] getDragSourceListeners() ;
	public java.lang.Void addDragSourceListener(java.awt.dnd.DragSourceListener parameter1) ;
	public java.lang.Void removeDragSourceListener(java.awt.dnd.DragSourceListener parameter1) ;
	public java.awt.dnd.DragSourceMotionListener[] getDragSourceMotionListeners() ;
	public java.lang.Void addDragSourceMotionListener(java.awt.dnd.DragSourceMotionListener parameter1) ;
	public java.lang.Void removeDragSourceMotionListener(java.awt.dnd.DragSourceMotionListener parameter1) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	public java.awt.dnd.DragGestureRecognizer createDefaultDragGestureRecognizer(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.dnd.DragGestureListener parameter3) ;
	public java.awt.dnd.DragGestureRecognizer createDragGestureRecognizer(java.lang.Class parameter1, java.awt.Component parameter2, java.lang.Integer parameter3, java.awt.dnd.DragGestureListener parameter4) ;
	public java.lang.Void startDrag(java.awt.dnd.DragGestureEvent parameter1, java.awt.Cursor parameter2, java.awt.datatransfer.Transferable parameter3, java.awt.dnd.DragSourceListener parameter4) ;
	public java.lang.Void startDrag(java.awt.dnd.DragGestureEvent parameter1, java.awt.Cursor parameter2, java.awt.datatransfer.Transferable parameter3, java.awt.dnd.DragSourceListener parameter4, java.awt.datatransfer.FlavorMap parameter5) ;
	public java.lang.Void startDrag(java.awt.dnd.DragGestureEvent parameter1, java.awt.Cursor parameter2, java.awt.Image parameter3, java.awt.Point parameter4, java.awt.datatransfer.Transferable parameter5, java.awt.dnd.DragSourceListener parameter6) ;
	public java.lang.Void startDrag(java.awt.dnd.DragGestureEvent parameter1, java.awt.Cursor parameter2, java.awt.Image parameter3, java.awt.Point parameter4, java.awt.datatransfer.Transferable parameter5, java.awt.dnd.DragSourceListener parameter6, java.awt.datatransfer.FlavorMap parameter7) ;
	public java.awt.dnd.DragSourceContext createDragSourceContext(java.awt.dnd.peer.DragSourceContextPeer parameter1, java.awt.dnd.DragGestureEvent parameter2, java.awt.Cursor parameter3, java.awt.Image parameter4, java.awt.Point parameter5, java.awt.datatransfer.Transferable parameter6, java.awt.dnd.DragSourceListener parameter7) ;
	java.awt.Cursor DefaultCopyDrop;
	java.awt.Cursor DefaultMoveDrop;
	java.awt.Cursor DefaultLinkDrop;
	java.awt.Cursor DefaultCopyNoDrop;
	java.awt.Cursor DefaultMoveNoDrop;
	java.awt.Cursor DefaultLinkNoDrop;
}

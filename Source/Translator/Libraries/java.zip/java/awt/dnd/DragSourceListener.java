package java.awt.dnd;

interface DragSourceListener implements java.util.EventListener
{
	public abstract java.lang.Void dragEnter(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public abstract java.lang.Void dragOver(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public abstract java.lang.Void dropActionChanged(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public abstract java.lang.Void dragDropEnd(java.awt.dnd.DragSourceDropEvent parameter1) ;
	public abstract java.lang.Void dragExit(java.awt.dnd.DragSourceEvent parameter1) ;
}

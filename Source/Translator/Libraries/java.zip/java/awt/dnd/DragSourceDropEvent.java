package java.awt.dnd;

abstract class DragSourceDropEvent extends java.awt.dnd.DragSourceEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Boolean getDropSuccess() ;
}

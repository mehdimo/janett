package java.awt.dnd;

abstract class DragSourceDropEvent extends java.awt.dnd.DragSourceEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Boolean getDropSuccess() ;
	public DragSourceDropEvent(java.awt.dnd.DragSourceContext parameter1) ;
	public DragSourceDropEvent(java.awt.dnd.DragSourceContext parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public DragSourceDropEvent(java.awt.dnd.DragSourceContext parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
}

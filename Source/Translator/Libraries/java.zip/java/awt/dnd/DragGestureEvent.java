package java.awt.dnd;

abstract class DragGestureEvent extends java.util.EventObject
{
	public java.lang.Integer getDragAction() ;
	public java.awt.Component getComponent() ;
	public java.awt.Point getDragOrigin() ;
	public java.awt.dnd.DragGestureRecognizer getSourceAsDragGestureRecognizer() ;
	public java.awt.dnd.DragSource getDragSource() ;
	public java.awt.event.InputEvent getTriggerEvent() ;
	public java.lang.Object[] toArray() ;
	public java.util.Iterator iterator() ;
	public java.lang.Void startDrag(java.awt.Cursor parameter1, java.awt.datatransfer.Transferable parameter2) ;
	public java.lang.Object[] toArray(java.lang.Object[] parameter1) ;
	public java.lang.Void startDrag(java.awt.Cursor parameter1, java.awt.datatransfer.Transferable parameter2, java.awt.dnd.DragSourceListener parameter3) ;
	public java.lang.Void startDrag(java.awt.Cursor parameter1, java.awt.Image parameter2, java.awt.Point parameter3, java.awt.datatransfer.Transferable parameter4, java.awt.dnd.DragSourceListener parameter5) ;
}

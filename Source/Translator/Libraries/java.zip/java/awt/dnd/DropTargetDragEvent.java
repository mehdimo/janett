package java.awt.dnd;

abstract class DropTargetDragEvent extends java.awt.dnd.DropTargetEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Integer getSourceActions() ;
	public java.lang.Void rejectDrag() ;
	public java.lang.Void acceptDrag(java.lang.Integer parameter1) ;
	public java.awt.Point getLocation() ;
	public java.awt.datatransfer.DataFlavor[] getCurrentDataFlavors() ;
	public java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.util.List getCurrentDataFlavorsAsList() ;
	public DropTargetDragEvent(java.awt.dnd.DropTargetContext parameter1, java.awt.Point parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

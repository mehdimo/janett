package java.awt.dnd;

abstract class DropTargetEvent extends java.util.EventObject
{
	public java.awt.dnd.DropTargetContext getDropTargetContext() ;
}

package java.awt.dnd;

interface Autoscroll
{
	public abstract java.awt.Insets getAutoscrollInsets() ;
	public abstract java.lang.Void autoscroll(java.awt.Point parameter1) ;
}

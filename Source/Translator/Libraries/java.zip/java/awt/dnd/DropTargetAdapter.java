package java.awt.dnd;

abstract class DropTargetAdapter implements java.awt.dnd.DropTargetListener
{
	public java.lang.Void dragEnter(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void dragOver(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void dropActionChanged(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void dragExit(java.awt.dnd.DropTargetEvent parameter1) ;
}

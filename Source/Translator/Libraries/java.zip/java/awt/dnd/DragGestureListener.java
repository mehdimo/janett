package java.awt.dnd;

interface DragGestureListener implements java.util.EventListener
{
	public abstract java.lang.Void dragGestureRecognized(java.awt.dnd.DragGestureEvent parameter1) ;
}

package java.awt.dnd;

interface DropTargetListener implements java.util.EventListener
{
	public abstract java.lang.Void dragEnter(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public abstract java.lang.Void dragOver(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public abstract java.lang.Void dropActionChanged(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public abstract java.lang.Void drop(java.awt.dnd.DropTargetDropEvent parameter1) ;
	public abstract java.lang.Void dragExit(java.awt.dnd.DropTargetEvent parameter1) ;
}

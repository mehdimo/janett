package java.awt.dnd;

abstract class InvalidDnDOperationException extends java.lang.IllegalStateException
{
	public InvalidDnDOperationException() ;
	public InvalidDnDOperationException(java.lang.String parameter1) ;
}

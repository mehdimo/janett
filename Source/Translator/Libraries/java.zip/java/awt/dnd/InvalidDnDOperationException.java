package java.awt.dnd;

abstract class InvalidDnDOperationException extends java.lang.IllegalStateException
{
}

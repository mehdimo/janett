package java.awt.dnd;

abstract class DropTargetDropEvent extends java.awt.dnd.DropTargetEvent
{
	public java.lang.Integer getDropAction() ;
	public java.lang.Integer getSourceActions() ;
	public java.lang.Void rejectDrop() ;
	public java.lang.Boolean isLocalTransfer() ;
	public java.lang.Void acceptDrop(java.lang.Integer parameter1) ;
	public java.lang.Void dropComplete(java.lang.Boolean parameter1) ;
	public java.awt.Point getLocation() ;
	public java.awt.datatransfer.DataFlavor[] getCurrentDataFlavors() ;
	public java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.awt.datatransfer.Transferable getTransferable() ;
	public java.util.List getCurrentDataFlavorsAsList() ;
	public DropTargetDropEvent(java.awt.dnd.DropTargetContext parameter1, java.awt.Point parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public DropTargetDropEvent(java.awt.dnd.DropTargetContext parameter1, java.awt.Point parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
}

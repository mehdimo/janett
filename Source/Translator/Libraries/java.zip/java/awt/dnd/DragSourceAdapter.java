package java.awt.dnd;

abstract class DragSourceAdapter implements java.awt.dnd.DragSourceListener, java.awt.dnd.DragSourceMotionListener
{
	public DragSourceAdapter() ;
	public java.lang.Void dragEnter(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragMouseMoved(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragOver(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dropActionChanged(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragDropEnd(java.awt.dnd.DragSourceDropEvent parameter1) ;
	public java.lang.Void dragExit(java.awt.dnd.DragSourceEvent parameter1) ;
}

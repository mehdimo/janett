package java.awt.dnd;

abstract class DropTarget implements java.awt.dnd.DropTargetListener, java.io.Serializable
{
	public java.lang.Integer getDefaultActions() ;
	public DropTarget() ;
	public java.lang.Void clearAutoscroll() ;
	public java.lang.Boolean isActive() ;
	public java.lang.Void setDefaultActions(java.lang.Integer parameter1) ;
	public java.lang.Void setActive(java.lang.Boolean parameter1) ;
	public java.awt.Component getComponent() ;
	public java.lang.Void setComponent(java.awt.Component parameter1) ;
	public java.lang.Void initializeAutoscrolling(java.awt.Point parameter1) ;
	public java.lang.Void updateAutoscroll(java.awt.Point parameter1) ;
	public java.awt.datatransfer.FlavorMap getFlavorMap() ;
	public java.lang.Void setFlavorMap(java.awt.datatransfer.FlavorMap parameter1) ;
	public java.awt.dnd.DropTargetContext createDropTargetContext() ;
	public java.awt.dnd.DropTargetContext getDropTargetContext() ;
	public java.lang.Void dragEnter(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void dragOver(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void dropActionChanged(java.awt.dnd.DropTargetDragEvent parameter1) ;
	public java.lang.Void drop(java.awt.dnd.DropTargetDropEvent parameter1) ;
	public java.lang.Void dragExit(java.awt.dnd.DropTargetEvent parameter1) ;
	public java.lang.Void addDropTargetListener(java.awt.dnd.DropTargetListener parameter1) ;
	public java.lang.Void removeDropTargetListener(java.awt.dnd.DropTargetListener parameter1) ;
	public java.lang.Void addNotify(java.awt.peer.ComponentPeer parameter1) ;
	public java.lang.Void removeNotify(java.awt.peer.ComponentPeer parameter1) ;
	public DropTarget(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.dnd.DropTargetListener parameter3) ;
	public DropTarget(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.dnd.DropTargetListener parameter3, java.lang.Boolean parameter4) ;
	public DropTarget(java.awt.Component parameter1, java.awt.dnd.DropTargetListener parameter2) ;
	public DropTarget(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.dnd.DropTargetListener parameter3, java.lang.Boolean parameter4, java.awt.datatransfer.FlavorMap parameter5) ;
	public java.awt.dnd.DropTarget.DropTargetAutoScroller createDropTargetAutoScroller(java.awt.Component parameter1, java.awt.Point parameter2) ;
	abstract class DropTargetAutoScroller implements java.awt.event.ActionListener
	{
		public java.lang.Void stop() ;
		public java.lang.Void updateLocation(java.awt.Point parameter1) ;
		public java.lang.Void actionPerformed(java.awt.event.ActionEvent parameter1) ;
		public DropTargetAutoScroller(java.awt.Component parameter1, java.awt.Point parameter2) ;
	}
}

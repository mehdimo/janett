package java.awt.dnd;

abstract class DropTargetContext implements java.io.Serializable
{
	public java.lang.Integer getTargetActions() ;
	public java.lang.Void rejectDrag() ;
	public java.lang.Void rejectDrop() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void acceptDrag(java.lang.Integer parameter1) ;
	public java.lang.Void acceptDrop(java.lang.Integer parameter1) ;
	public java.lang.Void setTargetActions(java.lang.Integer parameter1) ;
	public java.lang.Void dropComplete(java.lang.Boolean parameter1) ;
	public java.awt.Component getComponent() ;
	public java.awt.datatransfer.DataFlavor[] getCurrentDataFlavors() ;
	public java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
	public java.awt.datatransfer.Transferable getTransferable() ;
	public java.awt.dnd.DropTarget getDropTarget() ;
	public java.lang.Void addNotify(java.awt.dnd.peer.DropTargetContextPeer parameter1) ;
	public java.util.List getCurrentDataFlavorsAsList() ;
	public java.awt.datatransfer.Transferable createTransferableProxy(java.awt.datatransfer.Transferable parameter1, java.lang.Boolean parameter2) ;
	abstract class TransferableProxy implements java.awt.datatransfer.Transferable
	{
		public java.awt.datatransfer.DataFlavor[] getTransferDataFlavors() ;
		public java.lang.Boolean isDataFlavorSupported(java.awt.datatransfer.DataFlavor parameter1) ;
		public java.lang.Object getTransferData(java.awt.datatransfer.DataFlavor parameter1) ;
	}
}

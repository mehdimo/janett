package java.awt.dnd;

abstract class DragGestureRecognizer implements java.io.Serializable
{
	public java.lang.Integer getSourceActions() ;
	public abstract java.lang.Void registerListeners() ;
	public java.lang.Void resetRecognizer() ;
	public abstract java.lang.Void unregisterListeners() ;
	public java.lang.Void setSourceActions(java.lang.Integer parameter1) ;
	public java.awt.Component getComponent() ;
	public java.lang.Void setComponent(java.awt.Component parameter1) ;
	public java.lang.Void fireDragGestureRecognized(java.lang.Integer parameter1, java.awt.Point parameter2) ;
	public java.lang.Void addDragGestureListener(java.awt.dnd.DragGestureListener parameter1) ;
	public java.lang.Void removeDragGestureListener(java.awt.dnd.DragGestureListener parameter1) ;
	public java.awt.dnd.DragSource getDragSource() ;
	public java.awt.event.InputEvent getTriggerEvent() ;
	public java.lang.Void appendEvent(java.awt.event.InputEvent parameter1) ;
}

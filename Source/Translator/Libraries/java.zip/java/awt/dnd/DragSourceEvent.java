package java.awt.dnd;

abstract class DragSourceEvent extends java.util.EventObject
{
	public java.lang.Integer getX() ;
	public java.lang.Integer getY() ;
	public java.awt.Point getLocation() ;
	public java.awt.dnd.DragSourceContext getDragSourceContext() ;
	public DragSourceEvent(java.awt.dnd.DragSourceContext parameter1) ;
	public DragSourceEvent(java.awt.dnd.DragSourceContext parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package java.awt.dnd;

abstract class DragSourceEvent extends java.util.EventObject
{
	public java.lang.Integer getX() ;
	public java.lang.Integer getY() ;
	public java.awt.Point getLocation() ;
	public java.awt.dnd.DragSourceContext getDragSourceContext() ;
}

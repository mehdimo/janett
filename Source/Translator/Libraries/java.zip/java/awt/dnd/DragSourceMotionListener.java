package java.awt.dnd;

interface DragSourceMotionListener implements java.util.EventListener
{
	public abstract java.lang.Void dragMouseMoved(java.awt.dnd.DragSourceDragEvent parameter1) ;
}

package java.awt.dnd;

abstract class DragSourceContext implements java.awt.dnd.DragSourceListener, java.awt.dnd.DragSourceMotionListener, java.io.Serializable
{
	public java.lang.Integer getSourceActions() ;
	public java.lang.Void transferablesFlavorsChanged() ;
	public java.lang.Void updateCurrentCursor(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.awt.Component getComponent() ;
	public java.awt.Cursor getCursor() ;
	public java.lang.Void setCursor(java.awt.Cursor parameter1) ;
	public java.awt.datatransfer.Transferable getTransferable() ;
	public java.awt.dnd.DragGestureEvent getTrigger() ;
	public java.awt.dnd.DragSource getDragSource() ;
	public java.lang.Void dragEnter(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragMouseMoved(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragOver(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dropActionChanged(java.awt.dnd.DragSourceDragEvent parameter1) ;
	public java.lang.Void dragDropEnd(java.awt.dnd.DragSourceDropEvent parameter1) ;
	public java.lang.Void dragExit(java.awt.dnd.DragSourceEvent parameter1) ;
	public java.lang.Void addDragSourceListener(java.awt.dnd.DragSourceListener parameter1) ;
	public java.lang.Void removeDragSourceListener(java.awt.dnd.DragSourceListener parameter1) ;
}

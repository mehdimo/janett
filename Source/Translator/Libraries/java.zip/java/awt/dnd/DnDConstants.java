package java.awt.dnd;

abstract class DnDConstants
{
	java.lang.Integer ACTION_NONE;
	java.lang.Integer ACTION_COPY;
	java.lang.Integer ACTION_MOVE;
	java.lang.Integer ACTION_COPY_OR_MOVE;
	java.lang.Integer ACTION_LINK;
	java.lang.Integer ACTION_REFERENCE;
}

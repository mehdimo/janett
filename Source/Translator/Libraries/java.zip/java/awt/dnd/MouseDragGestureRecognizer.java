package java.awt.dnd;

abstract class MouseDragGestureRecognizer extends java.awt.dnd.DragGestureRecognizer implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener
{
	public java.lang.Void registerListeners() ;
	public java.lang.Void unregisterListeners() ;
	public MouseDragGestureRecognizer(java.awt.dnd.DragSource parameter1) ;
	public java.lang.Void mouseClicked(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseDragged(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseEntered(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseExited(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseMoved(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mousePressed(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseReleased(java.awt.event.MouseEvent parameter1) ;
	public MouseDragGestureRecognizer(java.awt.dnd.DragSource parameter1, java.awt.Component parameter2) ;
	public MouseDragGestureRecognizer(java.awt.dnd.DragSource parameter1, java.awt.Component parameter2, java.lang.Integer parameter3) ;
	public MouseDragGestureRecognizer(java.awt.dnd.DragSource parameter1, java.awt.Component parameter2, java.lang.Integer parameter3, java.awt.dnd.DragGestureListener parameter4) ;
}

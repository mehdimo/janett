package java.awt.dnd.peer;

interface DropTargetContextPeer
{
	public abstract java.lang.Integer getTargetActions() ;
	public abstract java.lang.Void rejectDrag() ;
	public abstract java.lang.Void rejectDrop() ;
	public abstract java.lang.Boolean isTransferableJVMLocal() ;
	public abstract java.lang.Void acceptDrag(java.lang.Integer parameter1) ;
	public abstract java.lang.Void acceptDrop(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setTargetActions(java.lang.Integer parameter1) ;
	public abstract java.lang.Void dropComplete(java.lang.Boolean parameter1) ;
	public abstract java.awt.datatransfer.DataFlavor[] getTransferDataFlavors() ;
	public abstract java.awt.datatransfer.Transferable getTransferable() ;
	public abstract java.awt.dnd.DropTarget getDropTarget() ;
}

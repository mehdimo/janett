package java.awt.dnd.peer;

interface DragSourceContextPeer
{
	public abstract java.lang.Void transferablesFlavorsChanged() ;
	public abstract java.awt.Cursor getCursor() ;
	public abstract java.lang.Void setCursor(java.awt.Cursor parameter1) ;
	public abstract java.lang.Void startDrag(java.awt.dnd.DragSourceContext parameter1, java.awt.Cursor parameter2, java.awt.Image parameter3, java.awt.Point parameter4) ;
}

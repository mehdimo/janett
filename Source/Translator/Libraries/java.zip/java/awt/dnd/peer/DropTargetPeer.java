package java.awt.dnd.peer;

interface DropTargetPeer
{
	public abstract java.lang.Void addDropTarget(java.awt.dnd.DropTarget parameter1) ;
	public abstract java.lang.Void removeDropTarget(java.awt.dnd.DropTarget parameter1) ;
}

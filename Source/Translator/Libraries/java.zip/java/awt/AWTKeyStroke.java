package java.awt;

abstract class AWTKeyStroke implements java.io.Serializable
{
	public java.lang.Character getKeyChar() ;
	public java.lang.Integer getKeyCode() ;
	public java.lang.Integer getKeyEventType() ;
	public java.lang.Integer getModifiers() ;
	public java.lang.Integer hashCode() ;
	public AWTKeyStroke() ;
	public java.lang.Boolean isOnKeyRelease() ;
	public AWTKeyStroke(java.lang.Character parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4) ;
	public java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.Character parameter1) ;
	public java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void registerSubclass(java.lang.Class parameter1) ;
	public java.lang.Object readResolve() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.awt.AWTKeyStroke getAWTKeyStrokeForEvent(java.awt.event.KeyEvent parameter1) ;
	public java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.Character parameter1, java.lang.Integer parameter2) ;
	public java.awt.AWTKeyStroke getAWTKeyStroke(java.lang.String parameter1) ;
}

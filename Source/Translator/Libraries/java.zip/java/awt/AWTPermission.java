package java.awt;

abstract class AWTPermission extends java.security.BasicPermission
{
	public AWTPermission(java.lang.String parameter1) ;
	public AWTPermission(java.lang.String parameter1, java.lang.String parameter2) ;
}

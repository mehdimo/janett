package java.awt;

abstract class AWTPermission extends java.security.BasicPermission
{
}

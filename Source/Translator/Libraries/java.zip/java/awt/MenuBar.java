package java.awt;

abstract class MenuBar extends java.awt.MenuComponent implements java.awt.MenuContainer, javax.accessibility.Accessible
{
	public java.lang.Integer countMenus() ;
	public java.lang.Integer getMenuCount() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void remove(java.lang.Integer parameter1) ;
	public java.awt.Menu getHelpMenu() ;
	public java.awt.Menu getMenu(java.lang.Integer parameter1) ;
	public java.lang.Void setHelpMenu(java.awt.Menu parameter1) ;
	public java.lang.Void remove(java.awt.MenuComponent parameter1) ;
	public java.lang.Void deleteShortcut(java.awt.MenuShortcut parameter1) ;
	public java.util.Enumeration shortcuts() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.awt.Menu add(java.awt.Menu parameter1) ;
	public java.awt.MenuItem getShortcutMenuItem(java.awt.MenuShortcut parameter1) ;
	abstract class AccessibleAWTMenuBar extends java.awt.MenuComponent.AccessibleAWTMenuComponent
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
	}
}

package java.awt;

abstract class GraphicsEnvironment
{
	public GraphicsEnvironment() ;
	public java.lang.Boolean isHeadless() ;
	public java.lang.Boolean isHeadlessInstance() ;
	public abstract java.awt.Font[] getAllFonts() ;
	public abstract java.awt.GraphicsDevice getDefaultScreenDevice() ;
	public abstract java.awt.GraphicsDevice[] getScreenDevices() ;
	public java.awt.GraphicsEnvironment getLocalGraphicsEnvironment() ;
	public java.awt.Point getCenterPoint() ;
	public java.awt.Rectangle getMaximumWindowBounds() ;
	public abstract java.lang.String[] getAvailableFontFamilyNames() ;
	public abstract java.awt.Graphics2D createGraphics(java.awt.image.BufferedImage parameter1) ;
	public abstract java.lang.String[] getAvailableFontFamilyNames(java.util.Locale parameter1) ;
}

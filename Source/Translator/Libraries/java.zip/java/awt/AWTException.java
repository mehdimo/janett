package java.awt;

abstract class AWTException extends java.lang.Exception
{
	public AWTException(java.lang.String parameter1) ;
}

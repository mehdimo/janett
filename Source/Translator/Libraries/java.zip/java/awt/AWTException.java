package java.awt;

abstract class AWTException extends java.lang.Exception
{
}

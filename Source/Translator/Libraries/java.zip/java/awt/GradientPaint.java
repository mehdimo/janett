package java.awt;

abstract class GradientPaint implements java.awt.Paint
{
	public java.lang.Integer getTransparency() ;
	public java.lang.Boolean isCyclic() ;
	public java.awt.Color getColor1() ;
	public java.awt.Color getColor2() ;
	public java.awt.geom.Point2D getPoint1() ;
	public java.awt.geom.Point2D getPoint2() ;
	public java.awt.PaintContext createContext(java.awt.image.ColorModel parameter1, java.awt.Rectangle parameter2, java.awt.geom.Rectangle2D parameter3, java.awt.geom.AffineTransform parameter4, java.awt.RenderingHints parameter5) ;
}

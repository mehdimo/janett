package java.awt;

abstract class GradientPaint implements java.awt.Paint
{
	public java.lang.Integer getTransparency() ;
	public java.lang.Boolean isCyclic() ;
	public java.awt.Color getColor1() ;
	public java.awt.Color getColor2() ;
	public java.awt.geom.Point2D getPoint1() ;
	public java.awt.geom.Point2D getPoint2() ;
	public GradientPaint(java.lang.Float parameter1, java.lang.Float parameter2, java.awt.Color parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.awt.Color parameter6) ;
	public GradientPaint(java.lang.Float parameter1, java.lang.Float parameter2, java.awt.Color parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.awt.Color parameter6, java.lang.Boolean parameter7) ;
	public GradientPaint(java.awt.geom.Point2D parameter1, java.awt.Color parameter2, java.awt.geom.Point2D parameter3, java.awt.Color parameter4) ;
	public GradientPaint(java.awt.geom.Point2D parameter1, java.awt.Color parameter2, java.awt.geom.Point2D parameter3, java.awt.Color parameter4, java.lang.Boolean parameter5) ;
	public java.awt.PaintContext createContext(java.awt.image.ColorModel parameter1, java.awt.Rectangle parameter2, java.awt.geom.Rectangle2D parameter3, java.awt.geom.AffineTransform parameter4, java.awt.RenderingHints parameter5) ;
}

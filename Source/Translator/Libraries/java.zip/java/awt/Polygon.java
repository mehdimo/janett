package java.awt;

abstract class Polygon implements java.awt.Shape, java.io.Serializable
{
	public Polygon() ;
	public java.lang.Void invalidate() ;
	public java.lang.Void reset() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void addPoint(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void translate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean contains(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean inside(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public Polygon(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Boolean contains(java.awt.Point parameter1) ;
	public java.awt.Rectangle getBoundingBox() ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	java.lang.Integer npoints;
	java.lang.Integer[] xpoints;
	java.lang.Integer[] ypoints;
}

package java.awt;

abstract class HeadlessException extends java.lang.UnsupportedOperationException
{
}

package java.awt;

abstract class HeadlessException extends java.lang.UnsupportedOperationException
{
	public HeadlessException() ;
	public HeadlessException(java.lang.String parameter1) ;
}

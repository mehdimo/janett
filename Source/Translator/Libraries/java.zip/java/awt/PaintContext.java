package java.awt;

interface PaintContext
{
	public abstract java.lang.Void dispose() ;
	public abstract java.awt.image.ColorModel getColorModel() ;
	public abstract java.awt.image.Raster getRaster(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
}

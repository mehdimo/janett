package java.awt;

abstract class Cursor implements java.io.Serializable
{
	public java.lang.Integer getType() ;
	public java.lang.Void finalize() ;
	public Cursor(java.lang.Integer parameter1) ;
	public java.awt.Cursor getDefaultCursor() ;
	public java.awt.Cursor getPredefinedCursor(java.lang.Integer parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public Cursor(java.lang.String parameter1) ;
	public java.awt.Cursor getSystemCustomCursor(java.lang.String parameter1) ;
	java.lang.Integer DEFAULT_CURSOR;
	java.lang.Integer CROSSHAIR_CURSOR;
	java.lang.Integer TEXT_CURSOR;
	java.lang.Integer WAIT_CURSOR;
	java.lang.Integer SW_RESIZE_CURSOR;
	java.lang.Integer SE_RESIZE_CURSOR;
	java.lang.Integer NW_RESIZE_CURSOR;
	java.lang.Integer NE_RESIZE_CURSOR;
	java.lang.Integer N_RESIZE_CURSOR;
	java.lang.Integer S_RESIZE_CURSOR;
	java.lang.Integer W_RESIZE_CURSOR;
	java.lang.Integer E_RESIZE_CURSOR;
	java.lang.Integer HAND_CURSOR;
	java.lang.Integer MOVE_CURSOR;
	java.lang.Integer CUSTOM_CURSOR;
}

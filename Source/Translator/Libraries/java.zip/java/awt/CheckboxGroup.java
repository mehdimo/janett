package java.awt;

abstract class CheckboxGroup implements java.io.Serializable
{
	public java.awt.Checkbox getCurrent() ;
	public java.awt.Checkbox getSelectedCheckbox() ;
	public java.lang.Void setCurrent(java.awt.Checkbox parameter1) ;
	public java.lang.Void setSelectedCheckbox(java.awt.Checkbox parameter1) ;
	public java.lang.String toString() ;
}

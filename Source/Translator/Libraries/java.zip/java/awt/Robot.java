package java.awt;

abstract class Robot
{
	public java.lang.Integer getAutoDelay() ;
	public java.lang.Void waitForIdle() ;
	public java.lang.Boolean isAutoWaitForIdle() ;
	public java.lang.Void delay(java.lang.Integer parameter1) ;
	public java.lang.Void keyPress(java.lang.Integer parameter1) ;
	public java.lang.Void keyRelease(java.lang.Integer parameter1) ;
	public java.lang.Void mousePress(java.lang.Integer parameter1) ;
	public java.lang.Void mouseRelease(java.lang.Integer parameter1) ;
	public java.lang.Void mouseWheel(java.lang.Integer parameter1) ;
	public java.lang.Void setAutoDelay(java.lang.Integer parameter1) ;
	public java.lang.Void mouseMove(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setAutoWaitForIdle(java.lang.Boolean parameter1) ;
	public java.awt.Color getPixelColor(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.String toString() ;
	public java.awt.image.BufferedImage createScreenCapture(java.awt.Rectangle parameter1) ;
}

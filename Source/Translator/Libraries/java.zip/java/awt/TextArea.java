package java.awt;

abstract class TextArea extends java.awt.TextComponent
{
	public java.lang.Integer getColumns() ;
	public java.lang.Integer getRows() ;
	public java.lang.Integer getScrollbarVisibility() ;
	public TextArea() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void setColumns(java.lang.Integer parameter1) ;
	public java.lang.Void setRows(java.lang.Integer parameter1) ;
	public TextArea(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Dimension getMinimumSize() ;
	public java.awt.Dimension getPreferredSize() ;
	public java.awt.Dimension minimumSize() ;
	public java.awt.Dimension preferredSize() ;
	public java.awt.Dimension getMinimumSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Dimension getPreferredSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Dimension minimumSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Dimension preferredSize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.String paramString() ;
	public TextArea(java.lang.String parameter1) ;
	public java.lang.Void append(java.lang.String parameter1) ;
	public java.lang.Void appendText(java.lang.String parameter1) ;
	public java.lang.Void insert(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void insertText(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public TextArea(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void replaceRange(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void replaceText(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public TextArea(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	java.lang.Integer SCROLLBARS_BOTH;
	java.lang.Integer SCROLLBARS_VERTICAL_ONLY;
	java.lang.Integer SCROLLBARS_HORIZONTAL_ONLY;
	java.lang.Integer SCROLLBARS_NONE;
	abstract class AccessibleAWTTextArea extends java.awt.TextComponent.AccessibleAWTTextComponent
	{
		public AccessibleAWTTextArea(java.awt.TextArea parameter1) ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

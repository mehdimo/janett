package java.awt;

abstract class JobAttributes implements java.lang.Cloneable
{
	public java.lang.Integer getCopies() ;
	public java.lang.Integer getFromPage() ;
	public java.lang.Integer getMaxPage() ;
	public java.lang.Integer getMinPage() ;
	public java.lang.Integer getToPage() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Void setCopiesToDefault() ;
	public java.lang.Void setMultipleDocumentHandlingToDefault() ;
	public java.lang.Void setSidesToDefault() ;
	public void getPageRanges() ;
	public java.lang.Void setCopies(java.lang.Integer parameter1) ;
	public java.lang.Void setFromPage(java.lang.Integer parameter1) ;
	public java.lang.Void setMaxPage(java.lang.Integer parameter1) ;
	public java.lang.Void setMinPage(java.lang.Integer parameter1) ;
	public java.lang.Void setToPage(java.lang.Integer parameter1) ;
	public void setPageRanges() ;
	public java.lang.Void set(java.awt.JobAttributes parameter1) ;
	public java.awt.JobAttributes.DefaultSelectionType getDefaultSelection() ;
	public java.lang.Void setDefaultSelection(java.awt.JobAttributes.DefaultSelectionType parameter1) ;
	public java.awt.JobAttributes.DestinationType getDestination() ;
	public java.lang.Void setDestination(java.awt.JobAttributes.DestinationType parameter1) ;
	public java.awt.JobAttributes.DialogType getDialog() ;
	public java.lang.Void setDialog(java.awt.JobAttributes.DialogType parameter1) ;
	public java.awt.JobAttributes.MultipleDocumentHandlingType getMultipleDocumentHandling() ;
	public java.lang.Void setMultipleDocumentHandling(java.awt.JobAttributes.MultipleDocumentHandlingType parameter1) ;
	public java.awt.JobAttributes.SidesType getSides() ;
	public java.lang.Void setSides(java.awt.JobAttributes.SidesType parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getFileName() ;
	public java.lang.String getPrinter() ;
	public java.lang.String toString() ;
	public java.lang.Void setFileName(java.lang.String parameter1) ;
	public java.lang.Void setPrinter(java.lang.String parameter1) ;
	abstract class DestinationType extends java.awt.AttributeValue
	{
		java.awt.JobAttributes.DestinationType FILE;
		java.awt.JobAttributes.DestinationType PRINTER;
	}
	abstract class DialogType extends java.awt.AttributeValue
	{
		java.awt.JobAttributes.DialogType COMMON;
		java.awt.JobAttributes.DialogType NATIVE;
		java.awt.JobAttributes.DialogType NONE;
	}
	abstract class DefaultSelectionType extends java.awt.AttributeValue
	{
		java.awt.JobAttributes.DefaultSelectionType ALL;
		java.awt.JobAttributes.DefaultSelectionType RANGE;
		java.awt.JobAttributes.DefaultSelectionType SELECTION;
	}
	abstract class MultipleDocumentHandlingType extends java.awt.AttributeValue
	{
		java.awt.JobAttributes.MultipleDocumentHandlingType SEPARATE_DOCUMENTS_COLLATED_COPIES;
		java.awt.JobAttributes.MultipleDocumentHandlingType SEPARATE_DOCUMENTS_UNCOLLATED_COPIES;
	}
	abstract class SidesType extends java.awt.AttributeValue
	{
		java.awt.JobAttributes.SidesType ONE_SIDED;
		java.awt.JobAttributes.SidesType TWO_SIDED_LONG_EDGE;
		java.awt.JobAttributes.SidesType TWO_SIDED_SHORT_EDGE;
	}
}

package java.awt;

interface LayoutManager2 implements java.awt.LayoutManager
{
	public abstract java.lang.Float getLayoutAlignmentX(java.awt.Container parameter1) ;
	public abstract java.lang.Float getLayoutAlignmentY(java.awt.Container parameter1) ;
	public abstract java.lang.Void invalidateLayout(java.awt.Container parameter1) ;
	public abstract java.awt.Dimension maximumLayoutSize(java.awt.Container parameter1) ;
	public abstract java.lang.Void addLayoutComponent(java.awt.Component parameter1, java.lang.Object parameter2) ;
}

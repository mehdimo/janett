package java.awt.event;

abstract class ItemEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getStateChange() ;
	public java.awt.ItemSelectable getItemSelectable() ;
	public java.lang.Object getItem() ;
	public java.lang.String paramString() ;
	java.lang.Integer ITEM_FIRST;
	java.lang.Integer ITEM_LAST;
	java.lang.Integer ITEM_STATE_CHANGED;
	java.lang.Integer SELECTED;
	java.lang.Integer DESELECTED;
}

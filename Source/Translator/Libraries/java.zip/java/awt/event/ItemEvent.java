package java.awt.event;

abstract class ItemEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getStateChange() ;
	public java.awt.ItemSelectable getItemSelectable() ;
	public java.lang.Object getItem() ;
	public java.lang.String paramString() ;
	public ItemEvent(java.awt.ItemSelectable parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.lang.Integer parameter4) ;
	java.lang.Integer ITEM_FIRST;
	java.lang.Integer ITEM_LAST;
	java.lang.Integer ITEM_STATE_CHANGED;
	java.lang.Integer SELECTED;
	java.lang.Integer DESELECTED;
}

package java.awt.event;

abstract class InputEvent extends java.awt.event.ComponentEvent
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Integer getModifiersEx() ;
	public java.lang.Long getWhen() ;
	public java.lang.Void consume() ;
	public java.lang.Boolean isAltDown() ;
	public java.lang.Boolean isAltGraphDown() ;
	public java.lang.Boolean isConsumed() ;
	public java.lang.Boolean isControlDown() ;
	public java.lang.Boolean isMetaDown() ;
	public java.lang.Boolean isShiftDown() ;
	public java.lang.String getModifiersExText(java.lang.Integer parameter1) ;
	java.lang.Integer SHIFT_MASK;
	java.lang.Integer CTRL_MASK;
	java.lang.Integer META_MASK;
	java.lang.Integer ALT_MASK;
	java.lang.Integer ALT_GRAPH_MASK;
	java.lang.Integer BUTTON1_MASK;
	java.lang.Integer BUTTON2_MASK;
	java.lang.Integer BUTTON3_MASK;
	java.lang.Integer SHIFT_DOWN_MASK;
	java.lang.Integer CTRL_DOWN_MASK;
	java.lang.Integer META_DOWN_MASK;
	java.lang.Integer ALT_DOWN_MASK;
	java.lang.Integer BUTTON1_DOWN_MASK;
	java.lang.Integer BUTTON2_DOWN_MASK;
	java.lang.Integer BUTTON3_DOWN_MASK;
	java.lang.Integer ALT_GRAPH_DOWN_MASK;
}

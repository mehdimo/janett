package java.awt.event;

abstract class ActionEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Long getWhen() ;
	public java.lang.String getActionCommand() ;
	public java.lang.String paramString() ;
	public ActionEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
	public ActionEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.String parameter3, java.lang.Integer parameter4) ;
	public ActionEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.String parameter3, java.lang.Long parameter4, java.lang.Integer parameter5) ;
	java.lang.Integer SHIFT_MASK;
	java.lang.Integer CTRL_MASK;
	java.lang.Integer META_MASK;
	java.lang.Integer ALT_MASK;
	java.lang.Integer ACTION_FIRST;
	java.lang.Integer ACTION_LAST;
	java.lang.Integer ACTION_PERFORMED;
}

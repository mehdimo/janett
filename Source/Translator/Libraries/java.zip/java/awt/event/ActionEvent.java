package java.awt.event;

abstract class ActionEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Long getWhen() ;
	public java.lang.String getActionCommand() ;
	public java.lang.String paramString() ;
	java.lang.Integer SHIFT_MASK;
	java.lang.Integer CTRL_MASK;
	java.lang.Integer META_MASK;
	java.lang.Integer ALT_MASK;
	java.lang.Integer ACTION_FIRST;
	java.lang.Integer ACTION_LAST;
	java.lang.Integer ACTION_PERFORMED;
}

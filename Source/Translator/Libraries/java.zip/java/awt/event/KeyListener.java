package java.awt.event;

interface KeyListener implements java.util.EventListener
{
	public abstract java.lang.Void keyPressed(java.awt.event.KeyEvent parameter1) ;
	public abstract java.lang.Void keyReleased(java.awt.event.KeyEvent parameter1) ;
	public abstract java.lang.Void keyTyped(java.awt.event.KeyEvent parameter1) ;
}

package java.awt.event;

interface InputMethodListener implements java.util.EventListener
{
	public abstract java.lang.Void caretPositionChanged(java.awt.event.InputMethodEvent parameter1) ;
	public abstract java.lang.Void inputMethodTextChanged(java.awt.event.InputMethodEvent parameter1) ;
}

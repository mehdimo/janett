package java.awt.event;

interface HierarchyListener implements java.util.EventListener
{
	public abstract java.lang.Void hierarchyChanged(java.awt.event.HierarchyEvent parameter1) ;
}

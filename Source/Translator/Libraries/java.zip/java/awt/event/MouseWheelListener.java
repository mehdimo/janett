package java.awt.event;

interface MouseWheelListener implements java.util.EventListener
{
	public abstract java.lang.Void mouseWheelMoved(java.awt.event.MouseWheelEvent parameter1) ;
}

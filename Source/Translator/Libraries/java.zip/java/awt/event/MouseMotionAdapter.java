package java.awt.event;

abstract class MouseMotionAdapter implements java.awt.event.MouseMotionListener
{
	public MouseMotionAdapter() ;
	public java.lang.Void mouseDragged(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseMoved(java.awt.event.MouseEvent parameter1) ;
}

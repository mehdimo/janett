package java.awt.event;

abstract class WindowAdapter implements java.awt.event.WindowListener, java.awt.event.WindowStateListener, java.awt.event.WindowFocusListener
{
	public WindowAdapter() ;
	public java.lang.Void windowActivated(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowClosed(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowClosing(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowDeactivated(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowDeiconified(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowGainedFocus(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowIconified(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowLostFocus(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowOpened(java.awt.event.WindowEvent parameter1) ;
	public java.lang.Void windowStateChanged(java.awt.event.WindowEvent parameter1) ;
}

package java.awt.event;

abstract class MouseEvent extends java.awt.event.InputEvent
{
	public java.lang.Integer getButton() ;
	public java.lang.Integer getClickCount() ;
	public java.lang.Integer getX() ;
	public java.lang.Integer getY() ;
	public java.lang.Boolean isPopupTrigger() ;
	public java.lang.Void translatePoint(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public MouseEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Boolean parameter8) ;
	public MouseEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Boolean parameter8, java.lang.Integer parameter9) ;
	public java.awt.Point getPoint() ;
	public java.lang.String paramString() ;
	public java.lang.String getMouseModifiersText(java.lang.Integer parameter1) ;
	java.lang.Integer MOUSE_FIRST;
	java.lang.Integer MOUSE_LAST;
	java.lang.Integer MOUSE_CLICKED;
	java.lang.Integer MOUSE_PRESSED;
	java.lang.Integer MOUSE_RELEASED;
	java.lang.Integer MOUSE_MOVED;
	java.lang.Integer MOUSE_ENTERED;
	java.lang.Integer MOUSE_EXITED;
	java.lang.Integer MOUSE_DRAGGED;
	java.lang.Integer MOUSE_WHEEL;
	java.lang.Integer NOBUTTON;
	java.lang.Integer BUTTON1;
	java.lang.Integer BUTTON2;
	java.lang.Integer BUTTON3;
}

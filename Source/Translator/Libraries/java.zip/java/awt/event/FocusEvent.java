package java.awt.event;

abstract class FocusEvent extends java.awt.event.ComponentEvent
{
	public java.lang.Boolean isTemporary() ;
	public java.awt.Component getOppositeComponent() ;
	public java.lang.String paramString() ;
	java.lang.Integer FOCUS_FIRST;
	java.lang.Integer FOCUS_LAST;
	java.lang.Integer FOCUS_GAINED;
	java.lang.Integer FOCUS_LOST;
}

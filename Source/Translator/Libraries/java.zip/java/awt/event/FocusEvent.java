package java.awt.event;

abstract class FocusEvent extends java.awt.event.ComponentEvent
{
	public java.lang.Boolean isTemporary() ;
	public java.awt.Component getOppositeComponent() ;
	public FocusEvent(java.awt.Component parameter1, java.lang.Integer parameter2) ;
	public FocusEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.String paramString() ;
	public FocusEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3, java.awt.Component parameter4) ;
	java.lang.Integer FOCUS_FIRST;
	java.lang.Integer FOCUS_LAST;
	java.lang.Integer FOCUS_GAINED;
	java.lang.Integer FOCUS_LOST;
}

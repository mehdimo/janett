package java.awt.event;

interface HierarchyBoundsListener implements java.util.EventListener
{
	public abstract java.lang.Void ancestorMoved(java.awt.event.HierarchyEvent parameter1) ;
	public abstract java.lang.Void ancestorResized(java.awt.event.HierarchyEvent parameter1) ;
}

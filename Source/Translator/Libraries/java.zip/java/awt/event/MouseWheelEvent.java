package java.awt.event;

abstract class MouseWheelEvent extends java.awt.event.MouseEvent
{
	public java.lang.Integer getScrollAmount() ;
	public java.lang.Integer getScrollType() ;
	public java.lang.Integer getUnitsToScroll() ;
	public java.lang.Integer getWheelRotation() ;
	public MouseWheelEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7, java.lang.Boolean parameter8, java.lang.Integer parameter9, java.lang.Integer parameter10, 
	java.lang.Integer parameter11) ;
	public java.lang.String paramString() ;
	java.lang.Integer WHEEL_UNIT_SCROLL;
	java.lang.Integer WHEEL_BLOCK_SCROLL;
}

package java.awt.event;

abstract class MouseWheelEvent extends java.awt.event.MouseEvent
{
	public java.lang.Integer getScrollAmount() ;
	public java.lang.Integer getScrollType() ;
	public java.lang.Integer getUnitsToScroll() ;
	public java.lang.Integer getWheelRotation() ;
	public java.lang.String paramString() ;
	java.lang.Integer WHEEL_UNIT_SCROLL;
	java.lang.Integer WHEEL_BLOCK_SCROLL;
}

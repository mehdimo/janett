package java.awt.event;

interface TextListener implements java.util.EventListener
{
	public abstract java.lang.Void textValueChanged(java.awt.event.TextEvent parameter1) ;
}

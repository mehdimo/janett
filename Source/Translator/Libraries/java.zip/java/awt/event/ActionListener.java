package java.awt.event;

interface ActionListener implements java.util.EventListener
{
	public abstract java.lang.Void actionPerformed(java.awt.event.ActionEvent parameter1) ;
}

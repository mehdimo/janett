package java.awt.event;

abstract class KeyAdapter implements java.awt.event.KeyListener
{
	public KeyAdapter() ;
	public java.lang.Void keyPressed(java.awt.event.KeyEvent parameter1) ;
	public java.lang.Void keyReleased(java.awt.event.KeyEvent parameter1) ;
	public java.lang.Void keyTyped(java.awt.event.KeyEvent parameter1) ;
}

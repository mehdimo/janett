package java.awt.event;

interface FocusListener implements java.util.EventListener
{
	public abstract java.lang.Void focusGained(java.awt.event.FocusEvent parameter1) ;
	public abstract java.lang.Void focusLost(java.awt.event.FocusEvent parameter1) ;
}

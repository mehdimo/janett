package java.awt.event;

interface MouseListener implements java.util.EventListener
{
	public abstract java.lang.Void mouseClicked(java.awt.event.MouseEvent parameter1) ;
	public abstract java.lang.Void mouseEntered(java.awt.event.MouseEvent parameter1) ;
	public abstract java.lang.Void mouseExited(java.awt.event.MouseEvent parameter1) ;
	public abstract java.lang.Void mousePressed(java.awt.event.MouseEvent parameter1) ;
	public abstract java.lang.Void mouseReleased(java.awt.event.MouseEvent parameter1) ;
}

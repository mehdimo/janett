package java.awt.event;

interface WindowListener implements java.util.EventListener
{
	public abstract java.lang.Void windowActivated(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowClosed(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowClosing(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowDeactivated(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowDeiconified(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowIconified(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowOpened(java.awt.event.WindowEvent parameter1) ;
}

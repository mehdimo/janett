package java.awt.event;

abstract class InvocationEvent extends java.awt.AWTEvent implements java.awt.ActiveEvent
{
	public java.lang.Long getWhen() ;
	public java.lang.Void dispatch() ;
	public java.lang.Exception getException() ;
	public java.lang.String paramString() ;
	java.lang.Integer INVOCATION_FIRST;
	java.lang.Integer INVOCATION_DEFAULT;
	java.lang.Integer INVOCATION_LAST;
}

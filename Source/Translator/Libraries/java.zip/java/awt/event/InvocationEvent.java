package java.awt.event;

abstract class InvocationEvent extends java.awt.AWTEvent implements java.awt.ActiveEvent
{
	public java.lang.Long getWhen() ;
	public java.lang.Void dispatch() ;
	public java.lang.Exception getException() ;
	public java.lang.String paramString() ;
	public InvocationEvent(java.lang.Object parameter1, java.lang.Runnable parameter2) ;
	public InvocationEvent(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Runnable parameter3, java.lang.Object parameter4, java.lang.Boolean parameter5) ;
	public InvocationEvent(java.lang.Object parameter1, java.lang.Runnable parameter2, java.lang.Object parameter3, java.lang.Boolean parameter4) ;
	java.lang.Integer INVOCATION_FIRST;
	java.lang.Integer INVOCATION_DEFAULT;
	java.lang.Integer INVOCATION_LAST;
}

package java.awt.event;

abstract class FocusAdapter implements java.awt.event.FocusListener
{
	public java.lang.Void focusGained(java.awt.event.FocusEvent parameter1) ;
	public java.lang.Void focusLost(java.awt.event.FocusEvent parameter1) ;
}

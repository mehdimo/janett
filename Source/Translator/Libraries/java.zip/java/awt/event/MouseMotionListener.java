package java.awt.event;

interface MouseMotionListener implements java.util.EventListener
{
	public abstract java.lang.Void mouseDragged(java.awt.event.MouseEvent parameter1) ;
	public abstract java.lang.Void mouseMoved(java.awt.event.MouseEvent parameter1) ;
}

package java.awt.event;

interface ContainerListener implements java.util.EventListener
{
	public abstract java.lang.Void componentAdded(java.awt.event.ContainerEvent parameter1) ;
	public abstract java.lang.Void componentRemoved(java.awt.event.ContainerEvent parameter1) ;
}

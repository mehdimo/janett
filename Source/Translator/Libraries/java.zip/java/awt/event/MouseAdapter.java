package java.awt.event;

abstract class MouseAdapter implements java.awt.event.MouseListener
{
	public MouseAdapter() ;
	public java.lang.Void mouseClicked(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseEntered(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseExited(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mousePressed(java.awt.event.MouseEvent parameter1) ;
	public java.lang.Void mouseReleased(java.awt.event.MouseEvent parameter1) ;
}

package java.awt.event;

abstract class TextEvent extends java.awt.AWTEvent
{
	public java.lang.String paramString() ;
	java.lang.Integer TEXT_FIRST;
	java.lang.Integer TEXT_LAST;
	java.lang.Integer TEXT_VALUE_CHANGED;
}

package java.awt.event;

abstract class WindowEvent extends java.awt.event.ComponentEvent
{
	public java.lang.Integer getNewState() ;
	public java.lang.Integer getOldState() ;
	public java.awt.Window getOppositeWindow() ;
	public java.awt.Window getWindow() ;
	public java.lang.String paramString() ;
	java.lang.Integer WINDOW_FIRST;
	java.lang.Integer WINDOW_OPENED;
	java.lang.Integer WINDOW_CLOSING;
	java.lang.Integer WINDOW_CLOSED;
	java.lang.Integer WINDOW_ICONIFIED;
	java.lang.Integer WINDOW_DEICONIFIED;
	java.lang.Integer WINDOW_ACTIVATED;
	java.lang.Integer WINDOW_DEACTIVATED;
	java.lang.Integer WINDOW_GAINED_FOCUS;
	java.lang.Integer WINDOW_LOST_FOCUS;
	java.lang.Integer WINDOW_STATE_CHANGED;
	java.lang.Integer WINDOW_LAST;
}

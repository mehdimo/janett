package java.awt.event;

abstract class WindowEvent extends java.awt.event.ComponentEvent
{
	public java.lang.Integer getNewState() ;
	public java.lang.Integer getOldState() ;
	public java.awt.Window getOppositeWindow() ;
	public java.awt.Window getWindow() ;
	public WindowEvent(java.awt.Window parameter1, java.lang.Integer parameter2) ;
	public WindowEvent(java.awt.Window parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.String paramString() ;
	public WindowEvent(java.awt.Window parameter1, java.lang.Integer parameter2, java.awt.Window parameter3) ;
	public WindowEvent(java.awt.Window parameter1, java.lang.Integer parameter2, java.awt.Window parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	java.lang.Integer WINDOW_FIRST;
	java.lang.Integer WINDOW_OPENED;
	java.lang.Integer WINDOW_CLOSING;
	java.lang.Integer WINDOW_CLOSED;
	java.lang.Integer WINDOW_ICONIFIED;
	java.lang.Integer WINDOW_DEICONIFIED;
	java.lang.Integer WINDOW_ACTIVATED;
	java.lang.Integer WINDOW_DEACTIVATED;
	java.lang.Integer WINDOW_GAINED_FOCUS;
	java.lang.Integer WINDOW_LOST_FOCUS;
	java.lang.Integer WINDOW_STATE_CHANGED;
	java.lang.Integer WINDOW_LAST;
}

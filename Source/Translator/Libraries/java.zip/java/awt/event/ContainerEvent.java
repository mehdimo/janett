package java.awt.event;

abstract class ContainerEvent extends java.awt.event.ComponentEvent
{
	public java.awt.Component getChild() ;
	public java.awt.Container getContainer() ;
	public java.lang.String paramString() ;
	public ContainerEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.Component parameter3) ;
	java.lang.Integer CONTAINER_FIRST;
	java.lang.Integer CONTAINER_LAST;
	java.lang.Integer COMPONENT_ADDED;
	java.lang.Integer COMPONENT_REMOVED;
}

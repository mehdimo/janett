package java.awt.event;

interface AWTEventListener implements java.util.EventListener
{
	public abstract java.lang.Void eventDispatched(java.awt.AWTEvent parameter1) ;
}

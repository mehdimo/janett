package java.awt.event;

abstract class AdjustmentEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getAdjustmentType() ;
	public java.lang.Integer getValue() ;
	public java.lang.Boolean getValueIsAdjusting() ;
	public java.awt.Adjustable getAdjustable() ;
	public AdjustmentEvent(java.awt.Adjustable parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public AdjustmentEvent(java.awt.Adjustable parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public java.lang.String paramString() ;
	java.lang.Integer ADJUSTMENT_FIRST;
	java.lang.Integer ADJUSTMENT_LAST;
	java.lang.Integer ADJUSTMENT_VALUE_CHANGED;
	java.lang.Integer UNIT_INCREMENT;
	java.lang.Integer UNIT_DECREMENT;
	java.lang.Integer BLOCK_DECREMENT;
	java.lang.Integer BLOCK_INCREMENT;
	java.lang.Integer TRACK;
}

package java.awt.event;

interface WindowFocusListener implements java.util.EventListener
{
	public abstract java.lang.Void windowGainedFocus(java.awt.event.WindowEvent parameter1) ;
	public abstract java.lang.Void windowLostFocus(java.awt.event.WindowEvent parameter1) ;
}

package java.awt.event;

abstract class HierarchyEvent extends java.awt.AWTEvent
{
	public java.lang.Long getChangeFlags() ;
	public java.awt.Component getChanged() ;
	public java.awt.Component getComponent() ;
	public java.awt.Container getChangedParent() ;
	public java.lang.String paramString() ;
	java.lang.Integer HIERARCHY_FIRST;
	java.lang.Integer HIERARCHY_CHANGED;
	java.lang.Integer ANCESTOR_MOVED;
	java.lang.Integer ANCESTOR_RESIZED;
	java.lang.Integer HIERARCHY_LAST;
	java.lang.Integer PARENT_CHANGED;
	java.lang.Integer DISPLAYABILITY_CHANGED;
	java.lang.Integer SHOWING_CHANGED;
}

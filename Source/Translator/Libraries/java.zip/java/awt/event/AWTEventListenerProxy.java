package java.awt.event;

abstract class AWTEventListenerProxy extends java.util.EventListenerProxy implements java.awt.event.AWTEventListener
{
	public java.lang.Long getEventMask() ;
	public java.lang.Void eventDispatched(java.awt.AWTEvent parameter1) ;
}

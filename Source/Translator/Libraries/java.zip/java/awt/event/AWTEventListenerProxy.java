package java.awt.event;

abstract class AWTEventListenerProxy extends java.util.EventListenerProxy implements java.awt.event.AWTEventListener
{
	public java.lang.Long getEventMask() ;
	public java.lang.Void eventDispatched(java.awt.AWTEvent parameter1) ;
	public AWTEventListenerProxy(java.lang.Long parameter1, java.awt.event.AWTEventListener parameter2) ;
}

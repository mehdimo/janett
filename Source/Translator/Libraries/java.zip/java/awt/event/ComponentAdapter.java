package java.awt.event;

abstract class ComponentAdapter implements java.awt.event.ComponentListener
{
	public ComponentAdapter() ;
	public java.lang.Void componentHidden(java.awt.event.ComponentEvent parameter1) ;
	public java.lang.Void componentMoved(java.awt.event.ComponentEvent parameter1) ;
	public java.lang.Void componentResized(java.awt.event.ComponentEvent parameter1) ;
	public java.lang.Void componentShown(java.awt.event.ComponentEvent parameter1) ;
}

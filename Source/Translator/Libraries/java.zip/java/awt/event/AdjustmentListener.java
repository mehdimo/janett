package java.awt.event;

interface AdjustmentListener implements java.util.EventListener
{
	public abstract java.lang.Void adjustmentValueChanged(java.awt.event.AdjustmentEvent parameter1) ;
}

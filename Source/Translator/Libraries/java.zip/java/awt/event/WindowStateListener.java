package java.awt.event;

interface WindowStateListener implements java.util.EventListener
{
	public abstract java.lang.Void windowStateChanged(java.awt.event.WindowEvent parameter1) ;
}

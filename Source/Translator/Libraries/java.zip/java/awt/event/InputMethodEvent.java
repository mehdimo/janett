package java.awt.event;

abstract class InputMethodEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getCommittedCharacterCount() ;
	public java.lang.Long getWhen() ;
	public java.lang.Void consume() ;
	public java.lang.Boolean isConsumed() ;
	public java.awt.font.TextHitInfo getCaret() ;
	public java.awt.font.TextHitInfo getVisiblePosition() ;
	public java.lang.String paramString() ;
	public java.text.AttributedCharacterIterator getText() ;
	public InputMethodEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.awt.font.TextHitInfo parameter3, java.awt.font.TextHitInfo parameter4) ;
	public InputMethodEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.lang.Long parameter3, java.text.AttributedCharacterIterator parameter4, java.lang.Integer parameter5, java.awt.font.TextHitInfo parameter6, java.awt.font.TextHitInfo parameter7) ;
	public InputMethodEvent(java.awt.Component parameter1, java.lang.Integer parameter2, java.text.AttributedCharacterIterator parameter3, java.lang.Integer parameter4, java.awt.font.TextHitInfo parameter5, java.awt.font.TextHitInfo parameter6) ;
	java.lang.Integer INPUT_METHOD_FIRST;
	java.lang.Integer INPUT_METHOD_TEXT_CHANGED;
	java.lang.Integer CARET_POSITION_CHANGED;
	java.lang.Integer INPUT_METHOD_LAST;
}

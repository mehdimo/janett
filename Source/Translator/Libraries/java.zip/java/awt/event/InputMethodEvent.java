package java.awt.event;

abstract class InputMethodEvent extends java.awt.AWTEvent
{
	public java.lang.Integer getCommittedCharacterCount() ;
	public java.lang.Long getWhen() ;
	public java.lang.Void consume() ;
	public java.lang.Boolean isConsumed() ;
	public java.awt.font.TextHitInfo getCaret() ;
	public java.awt.font.TextHitInfo getVisiblePosition() ;
	public java.lang.String paramString() ;
	public java.text.AttributedCharacterIterator getText() ;
	java.lang.Integer INPUT_METHOD_FIRST;
	java.lang.Integer INPUT_METHOD_TEXT_CHANGED;
	java.lang.Integer CARET_POSITION_CHANGED;
	java.lang.Integer INPUT_METHOD_LAST;
}

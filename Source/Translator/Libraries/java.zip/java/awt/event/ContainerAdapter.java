package java.awt.event;

abstract class ContainerAdapter implements java.awt.event.ContainerListener
{
	public ContainerAdapter() ;
	public java.lang.Void componentAdded(java.awt.event.ContainerEvent parameter1) ;
	public java.lang.Void componentRemoved(java.awt.event.ContainerEvent parameter1) ;
}

package java.awt.event;

abstract class PaintEvent extends java.awt.event.ComponentEvent
{
	public java.awt.Rectangle getUpdateRect() ;
	public java.lang.Void setUpdateRect(java.awt.Rectangle parameter1) ;
	public java.lang.String paramString() ;
	java.lang.Integer PAINT_FIRST;
	java.lang.Integer PAINT_LAST;
	java.lang.Integer PAINT;
	java.lang.Integer UPDATE;
}

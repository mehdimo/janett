package java.awt.event;

abstract class HierarchyBoundsAdapter implements java.awt.event.HierarchyBoundsListener
{
	public java.lang.Void ancestorMoved(java.awt.event.HierarchyEvent parameter1) ;
	public java.lang.Void ancestorResized(java.awt.event.HierarchyEvent parameter1) ;
}

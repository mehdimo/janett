package java.awt.event;

abstract class ComponentEvent extends java.awt.AWTEvent
{
	public java.awt.Component getComponent() ;
	public ComponentEvent(java.awt.Component parameter1, java.lang.Integer parameter2) ;
	public java.lang.String paramString() ;
	java.lang.Integer COMPONENT_FIRST;
	java.lang.Integer COMPONENT_LAST;
	java.lang.Integer COMPONENT_MOVED;
	java.lang.Integer COMPONENT_RESIZED;
	java.lang.Integer COMPONENT_SHOWN;
	java.lang.Integer COMPONENT_HIDDEN;
}

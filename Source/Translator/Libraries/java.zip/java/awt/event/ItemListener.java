package java.awt.event;

interface ItemListener implements java.util.EventListener
{
	public abstract java.lang.Void itemStateChanged(java.awt.event.ItemEvent parameter1) ;
}

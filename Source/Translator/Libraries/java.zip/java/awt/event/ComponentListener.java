package java.awt.event;

interface ComponentListener implements java.util.EventListener
{
	public abstract java.lang.Void componentHidden(java.awt.event.ComponentEvent parameter1) ;
	public abstract java.lang.Void componentMoved(java.awt.event.ComponentEvent parameter1) ;
	public abstract java.lang.Void componentResized(java.awt.event.ComponentEvent parameter1) ;
	public abstract java.lang.Void componentShown(java.awt.event.ComponentEvent parameter1) ;
}

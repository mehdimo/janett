package java.awt;

interface KeyEventPostProcessor
{
	public abstract java.lang.Boolean postProcessKeyEvent(java.awt.event.KeyEvent parameter1) ;
}

package java.awt;

interface Composite
{
	public abstract java.awt.CompositeContext createContext(java.awt.image.ColorModel parameter1, java.awt.image.ColorModel parameter2, java.awt.RenderingHints parameter3) ;
}

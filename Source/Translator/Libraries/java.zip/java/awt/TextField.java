package java.awt;

abstract class TextField extends java.awt.TextComponent
{
	public java.lang.Character getEchoChar() ;
	public java.lang.Integer getColumns() ;
	public TextField() ;
	public java.lang.Void addNotify() ;
	public java.lang.Boolean echoCharIsSet() ;
	public java.lang.Void setEchoChar(java.lang.Character parameter1) ;
	public java.lang.Void setEchoCharacter(java.lang.Character parameter1) ;
	public TextField(java.lang.Integer parameter1) ;
	public java.lang.Void setColumns(java.lang.Integer parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.awt.Dimension getMinimumSize() ;
	public java.awt.Dimension getPreferredSize() ;
	public java.awt.Dimension minimumSize() ;
	public java.awt.Dimension preferredSize() ;
	public java.awt.Dimension getMinimumSize(java.lang.Integer parameter1) ;
	public java.awt.Dimension getPreferredSize(java.lang.Integer parameter1) ;
	public java.awt.Dimension minimumSize(java.lang.Integer parameter1) ;
	public java.awt.Dimension preferredSize(java.lang.Integer parameter1) ;
	public java.lang.Void processActionEvent(java.awt.event.ActionEvent parameter1) ;
	public java.awt.event.ActionListener[] getActionListeners() ;
	public java.lang.Void addActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.Void removeActionListener(java.awt.event.ActionListener parameter1) ;
	public java.lang.String paramString() ;
	public TextField(java.lang.String parameter1) ;
	public java.lang.Void setText(java.lang.String parameter1) ;
	public TextField(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTTextField extends java.awt.TextComponent.AccessibleAWTTextComponent
	{
		public AccessibleAWTTextField(java.awt.TextField parameter1) ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

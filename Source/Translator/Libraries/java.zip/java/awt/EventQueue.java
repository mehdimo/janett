package java.awt;

abstract class EventQueue
{
	public java.lang.Long getMostRecentEventTime() ;
	public EventQueue() ;
	public java.lang.Void pop() ;
	public java.lang.Boolean isDispatchThread() ;
	public java.awt.AWTEvent getCurrentEvent() ;
	public java.awt.AWTEvent getNextEvent() ;
	public java.awt.AWTEvent peekEvent() ;
	public java.awt.AWTEvent peekEvent(java.lang.Integer parameter1) ;
	public java.lang.Void dispatchEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void postEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void push(java.awt.EventQueue parameter1) ;
	public java.lang.Void invokeAndWait(java.lang.Runnable parameter1) ;
	public java.lang.Void invokeLater(java.lang.Runnable parameter1) ;
}

package java.awt;

abstract class MenuComponent implements java.io.Serializable
{
	public MenuComponent() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void dispatchEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.lang.Boolean postEvent(java.awt.Event parameter1) ;
	public java.awt.Font getFont() ;
	public java.lang.Void setFont(java.awt.Font parameter1) ;
	public java.awt.MenuContainer getParent() ;
	public java.awt.peer.MenuComponentPeer getPeer() ;
	public java.lang.Object getTreeLock() ;
	public java.lang.String getName() ;
	public java.lang.String paramString() ;
	public java.lang.String toString() ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	abstract class AccessibleAWTMenuComponent extends javax.accessibility.AccessibleContext implements java.io.Serializable, javax.accessibility.AccessibleComponent, javax.accessibility.AccessibleSelection
	{
		public java.lang.Integer getAccessibleChildrenCount() ;
		public java.lang.Integer getAccessibleIndexInParent() ;
		public java.lang.Integer getAccessibleSelectionCount() ;
		public java.lang.Void clearAccessibleSelection() ;
		public java.lang.Void requestFocus() ;
		public java.lang.Void selectAllAccessibleSelection() ;
		public java.lang.Boolean isEnabled() ;
		public java.lang.Boolean isFocusTraversable() ;
		public java.lang.Boolean isShowing() ;
		public java.lang.Boolean isVisible() ;
		public java.lang.Void addAccessibleSelection(java.lang.Integer parameter1) ;
		public java.lang.Void removeAccessibleSelection(java.lang.Integer parameter1) ;
		public java.lang.Boolean isAccessibleChildSelected(java.lang.Integer parameter1) ;
		public java.lang.Void setEnabled(java.lang.Boolean parameter1) ;
		public java.lang.Void setVisible(java.lang.Boolean parameter1) ;
		public java.awt.Color getBackground() ;
		public java.awt.Color getForeground() ;
		public java.lang.Void setBackground(java.awt.Color parameter1) ;
		public java.lang.Void setForeground(java.awt.Color parameter1) ;
		public java.awt.Cursor getCursor() ;
		public java.lang.Void setCursor(java.awt.Cursor parameter1) ;
		public java.awt.Dimension getSize() ;
		public java.lang.Void setSize(java.awt.Dimension parameter1) ;
		public java.awt.Font getFont() ;
		public java.lang.Void setFont(java.awt.Font parameter1) ;
		public AccessibleAWTMenuComponent(java.awt.MenuComponent parameter1) ;
		public java.awt.Point getLocation() ;
		public java.awt.Point getLocationOnScreen() ;
		public java.lang.Void setLocation(java.awt.Point parameter1) ;
		public java.lang.Boolean contains(java.awt.Point parameter1) ;
		public java.awt.Rectangle getBounds() ;
		public java.lang.Void setBounds(java.awt.Rectangle parameter1) ;
		public java.lang.Void addFocusListener(java.awt.event.FocusListener parameter1) ;
		public java.lang.Void removeFocusListener(java.awt.event.FocusListener parameter1) ;
		public java.lang.String getAccessibleDescription() ;
		public java.lang.String getAccessibleName() ;
		public java.util.Locale getLocale() ;
		public javax.accessibility.Accessible getAccessibleParent() ;
		public javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
		public javax.accessibility.Accessible getAccessibleSelection(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleComponent getAccessibleComponent() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleSelection getAccessibleSelection() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
		public java.awt.FontMetrics getFontMetrics(java.awt.Font parameter1) ;
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point parameter1) ;
	}
}

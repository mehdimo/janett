package java.awt;

abstract class Container extends java.awt.Component
{
	public java.lang.Float getAlignmentX() ;
	public java.lang.Float getAlignmentY() ;
	public java.lang.Integer countComponents() ;
	public java.lang.Integer getComponentCount() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void doLayout() ;
	public java.lang.Void invalidate() ;
	public java.lang.Void layout() ;
	public java.lang.Void removeAll() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Void transferFocusBackward() ;
	public java.lang.Void transferFocusDownCycle() ;
	public java.lang.Void validate() ;
	public java.lang.Void validateTree() ;
	public java.lang.Boolean isFocusCycleRoot() ;
	public java.lang.Boolean isFocusTraversalPolicySet() ;
	public java.lang.Void remove(java.lang.Integer parameter1) ;
	public java.lang.Boolean areFocusTraversalKeysSet(java.lang.Integer parameter1) ;
	public java.lang.Void setFocusCycleRoot(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.awt.Component[] getComponents() ;
	public java.awt.Component getComponent(java.lang.Integer parameter1) ;
	public java.awt.Component findComponentAt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Component getComponentAt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Component locate(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void remove(java.awt.Component parameter1) ;
	public java.lang.Boolean isAncestorOf(java.awt.Component parameter1) ;
	public java.lang.Void applyComponentOrientation(java.awt.ComponentOrientation parameter1) ;
	public java.lang.Boolean isFocusCycleRoot(java.awt.Container parameter1) ;
	public java.awt.Dimension getMaximumSize() ;
	public java.awt.Dimension getMinimumSize() ;
	public java.awt.Dimension getPreferredSize() ;
	public java.awt.Dimension minimumSize() ;
	public java.awt.Dimension preferredSize() ;
	public java.lang.Void deliverEvent(java.awt.Event parameter1) ;
	public java.awt.FocusTraversalPolicy getFocusTraversalPolicy() ;
	public java.lang.Void setFocusTraversalPolicy(java.awt.FocusTraversalPolicy parameter1) ;
	public java.lang.Void setFont(java.awt.Font parameter1) ;
	public java.lang.Void paint(java.awt.Graphics parameter1) ;
	public java.lang.Void paintComponents(java.awt.Graphics parameter1) ;
	public java.lang.Void print(java.awt.Graphics parameter1) ;
	public java.lang.Void printComponents(java.awt.Graphics parameter1) ;
	public java.lang.Void update(java.awt.Graphics parameter1) ;
	public java.awt.Insets getInsets() ;
	public java.awt.Insets insets() ;
	public java.awt.LayoutManager getLayout() ;
	public java.lang.Void setLayout(java.awt.LayoutManager parameter1) ;
	public java.lang.Void processContainerEvent(java.awt.event.ContainerEvent parameter1) ;
	public java.awt.event.ContainerListener[] getContainerListeners() ;
	public java.lang.Void addContainerListener(java.awt.event.ContainerListener parameter1) ;
	public java.lang.Void removeContainerListener(java.awt.event.ContainerListener parameter1) ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void list(java.io.PrintStream parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void list(java.io.PrintWriter parameter1, java.lang.Integer parameter2) ;
	public java.lang.String paramString() ;
	public java.util.Set getFocusTraversalKeys(java.lang.Integer parameter1) ;
	public java.lang.Void setFocusTraversalKeys(java.lang.Integer parameter1, java.util.Set parameter2) ;
	public java.awt.Component add(java.awt.Component parameter1) ;
	public java.awt.Component add(java.awt.Component parameter1, java.lang.Integer parameter2) ;
	public java.awt.Component findComponentAt(java.awt.Point parameter1) ;
	public java.awt.Component getComponentAt(java.awt.Point parameter1) ;
	public java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void add(java.awt.Component parameter1, java.lang.Object parameter2) ;
	public java.lang.Void add(java.awt.Component parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void addImpl(java.awt.Component parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	public java.awt.Component add(java.lang.String parameter1, java.awt.Component parameter2) ;
	abstract class AccessibleAWTContainer extends java.awt.Component.AccessibleAWTComponent
	{
		public java.lang.Integer getAccessibleChildrenCount() ;
		public javax.accessibility.Accessible getAccessibleChild(java.lang.Integer parameter1) ;
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point parameter1) ;
	}
	abstract class AccessibleAWTContainer$AccessibleContainerHandler implements java.awt.event.ContainerListener
	{
		public java.lang.Void componentAdded(java.awt.event.ContainerEvent parameter1) ;
		public java.lang.Void componentRemoved(java.awt.event.ContainerEvent parameter1) ;
	}
}

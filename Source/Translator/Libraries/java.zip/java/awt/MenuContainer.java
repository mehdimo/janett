package java.awt;

interface MenuContainer
{
	public abstract java.lang.Boolean postEvent(java.awt.Event parameter1) ;
	public abstract java.awt.Font getFont() ;
	public abstract java.lang.Void remove(java.awt.MenuComponent parameter1) ;
}

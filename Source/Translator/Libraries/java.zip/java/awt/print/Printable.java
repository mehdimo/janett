package java.awt.print;

interface Printable
{
	public abstract java.lang.Integer print(java.awt.Graphics parameter1, java.awt.print.PageFormat parameter2, java.lang.Integer parameter3) ;
	java.lang.Integer PAGE_EXISTS;
	java.lang.Integer NO_SUCH_PAGE;
}

package java.awt.print;

abstract class PrinterAbortException extends java.awt.print.PrinterException
{
}

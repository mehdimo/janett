package java.awt.print;

abstract class PrinterAbortException extends java.awt.print.PrinterException
{
	public PrinterAbortException() ;
	public PrinterAbortException(java.lang.String parameter1) ;
}

package java.awt.print;

interface Pageable
{
	public abstract java.lang.Integer getNumberOfPages() ;
	public abstract java.awt.print.PageFormat getPageFormat(java.lang.Integer parameter1) ;
	public abstract java.awt.print.Printable getPrintable(java.lang.Integer parameter1) ;
	java.lang.Integer UNKNOWN_NUMBER_OF_PAGES;
}

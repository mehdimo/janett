package java.awt.print;

abstract class PrinterException extends java.lang.Exception
{
	public PrinterException() ;
	public PrinterException(java.lang.String parameter1) ;
}

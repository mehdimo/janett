package java.awt.print;

abstract class PrinterException extends java.lang.Exception
{
}

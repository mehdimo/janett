package java.awt.print;

abstract class Book implements java.awt.print.Pageable
{
	public java.lang.Integer getNumberOfPages() ;
	public java.awt.print.PageFormat getPageFormat(java.lang.Integer parameter1) ;
	public java.awt.print.Printable getPrintable(java.lang.Integer parameter1) ;
	public java.lang.Void setPage(java.lang.Integer parameter1, java.awt.print.Printable parameter2, java.awt.print.PageFormat parameter3) ;
	public java.lang.Void append(java.awt.print.Printable parameter1, java.awt.print.PageFormat parameter2) ;
	public java.lang.Void append(java.awt.print.Printable parameter1, java.awt.print.PageFormat parameter2, java.lang.Integer parameter3) ;
}

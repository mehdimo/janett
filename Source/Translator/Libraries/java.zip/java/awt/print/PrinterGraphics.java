package java.awt.print;

interface PrinterGraphics
{
	public abstract java.awt.print.PrinterJob getPrinterJob() ;
}

package java.awt.print;

abstract class PrinterJob
{
	public abstract java.lang.Integer getCopies() ;
	public abstract java.lang.Void cancel() ;
	public abstract java.lang.Void print() ;
	public abstract java.lang.Boolean isCancelled() ;
	public abstract java.lang.Boolean printDialog() ;
	public abstract java.lang.Void setCopies(java.lang.Integer parameter1) ;
	public java.awt.print.PageFormat defaultPage() ;
	public abstract java.lang.Void setPageable(java.awt.print.Pageable parameter1) ;
	public abstract java.lang.Void setPrintable(java.awt.print.Printable parameter1) ;
	public java.awt.print.PrinterJob getPrinterJob() ;
	public abstract java.lang.String getJobName() ;
	public abstract java.lang.String getUserName() ;
	public abstract java.lang.Void setJobName(java.lang.String parameter1) ;
	public javax.print.PrintService getPrintService() ;
	public javax.print.PrintService[] lookupPrintServices() ;
	public java.lang.Void setPrintService(javax.print.PrintService parameter1) ;
	public java.lang.Void print(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
	public java.lang.Boolean printDialog(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
	public abstract java.awt.print.PageFormat defaultPage(java.awt.print.PageFormat parameter1) ;
	public abstract java.awt.print.PageFormat pageDialog(java.awt.print.PageFormat parameter1) ;
	public abstract java.awt.print.PageFormat validatePage(java.awt.print.PageFormat parameter1) ;
	public abstract java.lang.Void setPrintable(java.awt.print.Printable parameter1, java.awt.print.PageFormat parameter2) ;
	public java.awt.print.PageFormat pageDialog(javax.print.attribute.PrintRequestAttributeSet parameter1) ;
	public javax.print.StreamPrintServiceFactory[] lookupStreamPrintServices(java.lang.String parameter1) ;
}

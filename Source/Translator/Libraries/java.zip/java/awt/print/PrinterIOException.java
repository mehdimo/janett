package java.awt.print;

abstract class PrinterIOException extends java.awt.print.PrinterException
{
	public java.io.IOException getIOException() ;
	public PrinterIOException(java.io.IOException parameter1) ;
	public java.lang.Throwable getCause() ;
}

package java.awt.print;

abstract class PrinterIOException extends java.awt.print.PrinterException
{
	public java.io.IOException getIOException() ;
	public java.lang.Throwable getCause() ;
}

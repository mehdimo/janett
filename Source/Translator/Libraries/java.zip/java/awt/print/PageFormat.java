package java.awt.print;

abstract class PageFormat implements java.lang.Cloneable
{
	public java.lang.Double getHeight() ;
	public java.lang.Double getImageableHeight() ;
	public java.lang.Double getImageableWidth() ;
	public java.lang.Double getImageableX() ;
	public java.lang.Double getImageableY() ;
	public java.lang.Double getWidth() ;
	public java.lang.Integer getOrientation() ;
	public java.lang.Double[] getMatrix() ;
	public java.lang.Void setOrientation(java.lang.Integer parameter1) ;
	public java.awt.print.Paper getPaper() ;
	public java.lang.Void setPaper(java.awt.print.Paper parameter1) ;
	public java.lang.Object clone() ;
	java.lang.Integer LANDSCAPE;
	java.lang.Integer PORTRAIT;
	java.lang.Integer REVERSE_LANDSCAPE;
}

package java.awt.print;

abstract class Paper implements java.lang.Cloneable
{
	public java.lang.Double getHeight() ;
	public java.lang.Double getImageableHeight() ;
	public java.lang.Double getImageableWidth() ;
	public java.lang.Double getImageableX() ;
	public java.lang.Double getImageableY() ;
	public java.lang.Double getWidth() ;
	public java.lang.Void setSize(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setImageableArea(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Object clone() ;
}

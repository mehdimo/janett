package java.awt.font;

abstract class TextHitInfo
{
	public java.lang.Integer getCharIndex() ;
	public java.lang.Integer getInsertionIndex() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isLeadingEdge() ;
	public java.awt.font.TextHitInfo getOtherHit() ;
	public java.awt.font.TextHitInfo afterOffset(java.lang.Integer parameter1) ;
	public java.awt.font.TextHitInfo beforeOffset(java.lang.Integer parameter1) ;
	public java.awt.font.TextHitInfo getOffsetHit(java.lang.Integer parameter1) ;
	public java.awt.font.TextHitInfo leading(java.lang.Integer parameter1) ;
	public java.awt.font.TextHitInfo trailing(java.lang.Integer parameter1) ;
	public java.lang.Boolean equals(java.awt.font.TextHitInfo parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

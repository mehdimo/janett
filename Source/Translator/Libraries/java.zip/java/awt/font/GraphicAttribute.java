package java.awt.font;

abstract class GraphicAttribute
{
	public abstract java.lang.Float getAdvance() ;
	public abstract java.lang.Float getAscent() ;
	public abstract java.lang.Float getDescent() ;
	public java.lang.Integer getAlignment() ;
	public abstract java.lang.Void draw(java.awt.Graphics2D parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public java.awt.font.GlyphJustificationInfo getJustificationInfo() ;
	public java.awt.geom.Rectangle2D getBounds() ;
	java.lang.Integer TOP_ALIGNMENT;
	java.lang.Integer BOTTOM_ALIGNMENT;
	java.lang.Integer ROMAN_BASELINE;
	java.lang.Integer CENTER_BASELINE;
	java.lang.Integer HANGING_BASELINE;
}

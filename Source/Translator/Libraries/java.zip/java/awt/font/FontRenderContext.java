package java.awt.font;

abstract class FontRenderContext
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isAntiAliased() ;
	public java.lang.Boolean usesFractionalMetrics() ;
	public java.lang.Boolean equals(java.awt.font.FontRenderContext parameter1) ;
	public java.awt.geom.AffineTransform getTransform() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
}

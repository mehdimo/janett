package java.awt.font;

abstract class FontRenderContext
{
	public java.lang.Integer hashCode() ;
	public FontRenderContext() ;
	public java.lang.Boolean isAntiAliased() ;
	public java.lang.Boolean usesFractionalMetrics() ;
	public java.lang.Boolean equals(java.awt.font.FontRenderContext parameter1) ;
	public java.awt.geom.AffineTransform getTransform() ;
	public FontRenderContext(java.awt.geom.AffineTransform parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
}

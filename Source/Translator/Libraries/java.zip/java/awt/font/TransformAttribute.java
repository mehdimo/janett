package java.awt.font;

abstract class TransformAttribute implements java.io.Serializable
{
	public java.lang.Boolean isIdentity() ;
	public java.awt.geom.AffineTransform getTransform() ;
	public TransformAttribute(java.awt.geom.AffineTransform parameter1) ;
}

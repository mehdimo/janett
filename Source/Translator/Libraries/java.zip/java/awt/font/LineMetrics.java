package java.awt.font;

abstract class LineMetrics
{
	public abstract java.lang.Float getAscent() ;
	public abstract java.lang.Float getDescent() ;
	public abstract java.lang.Float getHeight() ;
	public abstract java.lang.Float getLeading() ;
	public abstract java.lang.Float getStrikethroughOffset() ;
	public abstract java.lang.Float getStrikethroughThickness() ;
	public abstract java.lang.Float getUnderlineOffset() ;
	public abstract java.lang.Float getUnderlineThickness() ;
	public abstract java.lang.Integer getBaselineIndex() ;
	public abstract java.lang.Integer getNumChars() ;
	public LineMetrics() ;
	public abstract java.lang.Float[] getBaselineOffsets() ;
}

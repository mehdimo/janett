package java.awt.font;

abstract class NumericShaper implements java.io.Serializable
{
	public java.lang.Integer getRanges() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isContextual() ;
	public java.lang.Void shape(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void shape(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.awt.font.NumericShaper getContextualShaper(java.lang.Integer parameter1) ;
	public java.awt.font.NumericShaper getShaper(java.lang.Integer parameter1) ;
	public java.awt.font.NumericShaper getContextualShaper(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	java.lang.Integer EUROPEAN;
	java.lang.Integer ARABIC;
	java.lang.Integer EASTERN_ARABIC;
	java.lang.Integer DEVANAGARI;
	java.lang.Integer BENGALI;
	java.lang.Integer GURMUKHI;
	java.lang.Integer GUJARATI;
	java.lang.Integer ORIYA;
	java.lang.Integer TAMIL;
	java.lang.Integer TELUGU;
	java.lang.Integer KANNADA;
	java.lang.Integer MALAYALAM;
	java.lang.Integer THAI;
	java.lang.Integer LAO;
	java.lang.Integer TIBETAN;
	java.lang.Integer MYANMAR;
	java.lang.Integer ETHIOPIC;
	java.lang.Integer KHMER;
	java.lang.Integer MONGOLIAN;
	java.lang.Integer ALL_RANGES;
}

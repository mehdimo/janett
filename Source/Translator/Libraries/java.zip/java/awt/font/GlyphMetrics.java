package java.awt.font;

abstract class GlyphMetrics
{
	public java.lang.Float getAdvance() ;
	public java.lang.Float getAdvanceX() ;
	public java.lang.Float getAdvanceY() ;
	public java.lang.Float getLSB() ;
	public java.lang.Float getRSB() ;
	public java.lang.Integer getType() ;
	public java.lang.Boolean isCombining() ;
	public java.lang.Boolean isComponent() ;
	public java.lang.Boolean isLigature() ;
	public java.lang.Boolean isStandard() ;
	public java.lang.Boolean isWhitespace() ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	java.lang.Byte STANDARD;
	java.lang.Byte LIGATURE;
	java.lang.Byte COMBINING;
	java.lang.Byte COMPONENT;
	java.lang.Byte WHITESPACE;
}

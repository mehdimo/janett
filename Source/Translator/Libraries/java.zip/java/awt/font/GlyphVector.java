package java.awt.font;

abstract class GlyphVector implements java.lang.Cloneable
{
	public java.lang.Integer getLayoutFlags() ;
	public abstract java.lang.Integer getNumGlyphs() ;
	public abstract java.lang.Void performDefaultLayout() ;
	public java.lang.Integer getGlyphCharIndex(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getGlyphCode(java.lang.Integer parameter1) ;
	public abstract java.lang.Float[] getGlyphPositions(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float[] parameter3) ;
	public java.lang.Integer[] getGlyphCharIndices(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3) ;
	public abstract java.lang.Integer[] getGlyphCodes(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3) ;
	public abstract java.awt.Font getFont() ;
	public abstract java.awt.Shape getOutline() ;
	public abstract java.awt.Shape getOutline(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public abstract java.awt.Shape getGlyphLogicalBounds(java.lang.Integer parameter1) ;
	public abstract java.awt.Shape getGlyphOutline(java.lang.Integer parameter1) ;
	public abstract java.awt.Shape getGlyphVisualBounds(java.lang.Integer parameter1) ;
	public java.awt.Shape getGlyphOutline(java.lang.Integer parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public abstract java.awt.font.FontRenderContext getFontRenderContext() ;
	public abstract java.awt.font.GlyphJustificationInfo getGlyphJustificationInfo(java.lang.Integer parameter1) ;
	public abstract java.awt.font.GlyphMetrics getGlyphMetrics(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean equals(java.awt.font.GlyphVector parameter1) ;
	public abstract java.awt.geom.AffineTransform getGlyphTransform(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setGlyphTransform(java.lang.Integer parameter1, java.awt.geom.AffineTransform parameter2) ;
	public abstract java.awt.geom.Point2D getGlyphPosition(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setGlyphPosition(java.lang.Integer parameter1, java.awt.geom.Point2D parameter2) ;
	public abstract java.awt.geom.Rectangle2D getLogicalBounds() ;
	public abstract java.awt.geom.Rectangle2D getVisualBounds() ;
	public java.awt.Rectangle getGlyphPixelBounds(java.lang.Integer parameter1, java.awt.font.FontRenderContext parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
	public java.awt.Rectangle getPixelBounds(java.awt.font.FontRenderContext parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	java.lang.Integer FLAG_HAS_TRANSFORMS;
	java.lang.Integer FLAG_HAS_POSITION_ADJUSTMENTS;
	java.lang.Integer FLAG_RUN_RTL;
	java.lang.Integer FLAG_COMPLEX_GLYPHS;
	java.lang.Integer FLAG_MASK;
}

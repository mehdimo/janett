package java.awt.font;

abstract class LineBreakMeasurer
{
	public java.lang.Integer getPosition() ;
	public java.lang.Integer nextOffset(java.lang.Float parameter1) ;
	public java.lang.Integer nextOffset(java.lang.Float parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void setPosition(java.lang.Integer parameter1) ;
	public java.awt.font.TextLayout nextLayout(java.lang.Float parameter1) ;
	public java.awt.font.TextLayout nextLayout(java.lang.Float parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Void deleteChar(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void insertChar(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2) ;
	public LineBreakMeasurer(java.text.AttributedCharacterIterator parameter1, java.awt.font.FontRenderContext parameter2) ;
	public LineBreakMeasurer(java.text.AttributedCharacterIterator parameter1, java.text.BreakIterator parameter2, java.awt.font.FontRenderContext parameter3) ;
}

package java.awt.font;

abstract class ShapeGraphicAttribute extends java.awt.font.GraphicAttribute
{
	public java.lang.Float getAdvance() ;
	public java.lang.Float getAscent() ;
	public java.lang.Float getDescent() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Void draw(java.awt.Graphics2D parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public ShapeGraphicAttribute(java.awt.Shape parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Boolean equals(java.awt.font.ShapeGraphicAttribute parameter1) ;
	public java.awt.geom.Rectangle2D getBounds() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	java.lang.Boolean STROKE;
	java.lang.Boolean FILL;
}

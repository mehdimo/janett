package java.awt.font;

abstract class TextMeasurer implements java.lang.Cloneable
{
	public java.lang.Integer getLineBreakIndex(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Float getAdvanceBetween(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.font.TextLayout getLayout(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Object clone() ;
	public java.lang.Void deleteChar(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void insertChar(java.text.AttributedCharacterIterator parameter1, java.lang.Integer parameter2) ;
}

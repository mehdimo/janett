package java.awt.font;

abstract class TextLayout implements java.lang.Cloneable
{
	public java.lang.Byte getBaseline() ;
	public java.lang.Float getAdvance() ;
	public java.lang.Float getAscent() ;
	public java.lang.Float getDescent() ;
	public java.lang.Float getLeading() ;
	public java.lang.Float getVisibleAdvance() ;
	public java.lang.Integer getCharacterCount() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isLeftToRight() ;
	public java.lang.Boolean isVertical() ;
	public java.lang.Float[] getBaselineOffsets() ;
	public java.lang.Void handleJustify(java.lang.Float parameter1) ;
	public java.lang.Byte getCharacterLevel(java.lang.Integer parameter1) ;
	public java.lang.Void draw(java.awt.Graphics2D parameter1, java.lang.Float parameter2, java.lang.Float parameter3) ;
	public java.awt.Shape[] getCaretShapes(java.lang.Integer parameter1) ;
	public java.awt.Shape getBlackBoxBounds(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Shape getLogicalHighlightShape(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.font.TextHitInfo hitTestChar(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.awt.font.TextHitInfo getNextLeftHit(java.lang.Integer parameter1) ;
	public java.awt.font.TextHitInfo getNextRightHit(java.lang.Integer parameter1) ;
	public java.lang.Float[] getCaretInfo(java.awt.font.TextHitInfo parameter1) ;
	public java.awt.font.TextLayout getJustifiedLayout(java.lang.Float parameter1) ;
	public java.lang.Boolean equals(java.awt.font.TextLayout parameter1) ;
	public java.awt.geom.Rectangle2D getBounds() ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.awt.Shape getCaretShape(java.awt.font.TextHitInfo parameter1) ;
	public java.awt.Shape getOutline(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.Shape getLogicalHighlightShape(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.geom.Rectangle2D parameter3) ;
	public java.awt.Shape[] getCaretShapes(java.lang.Integer parameter1, java.awt.geom.Rectangle2D parameter2) ;
	public java.awt.font.TextHitInfo getNextLeftHit(java.awt.font.TextHitInfo parameter1) ;
	public java.awt.font.TextHitInfo getNextRightHit(java.awt.font.TextHitInfo parameter1) ;
	public java.awt.font.TextHitInfo getVisualOtherHit(java.awt.font.TextHitInfo parameter1) ;
	public java.lang.Integer[] getLogicalRangesForVisualSelection(java.awt.font.TextHitInfo parameter1, java.awt.font.TextHitInfo parameter2) ;
	public java.awt.font.TextHitInfo getNextLeftHit(java.lang.Integer parameter1, java.awt.font.TextLayout.CaretPolicy parameter2) ;
	public java.awt.font.TextHitInfo getNextRightHit(java.lang.Integer parameter1, java.awt.font.TextLayout.CaretPolicy parameter2) ;
	public java.awt.font.TextHitInfo hitTestChar(java.lang.Float parameter1, java.lang.Float parameter2, java.awt.geom.Rectangle2D parameter3) ;
	public java.lang.Float[] getCaretInfo(java.awt.font.TextHitInfo parameter1, java.awt.geom.Rectangle2D parameter2) ;
	public java.awt.Shape getVisualHighlightShape(java.awt.font.TextHitInfo parameter1, java.awt.font.TextHitInfo parameter2) ;
	public java.awt.Shape[] getCaretShapes(java.lang.Integer parameter1, java.awt.geom.Rectangle2D parameter2, java.awt.font.TextLayout.CaretPolicy parameter3) ;
	public java.awt.Shape getCaretShape(java.awt.font.TextHitInfo parameter1, java.awt.geom.Rectangle2D parameter2) ;
	public java.awt.Shape getVisualHighlightShape(java.awt.font.TextHitInfo parameter1, java.awt.font.TextHitInfo parameter2, java.awt.geom.Rectangle2D parameter3) ;
	java.awt.font.TextLayout.CaretPolicy DEFAULT_CARET_POLICY;
	abstract class CaretPolicy
	{
		public java.awt.font.TextHitInfo getStrongCaret(java.awt.font.TextHitInfo parameter1, java.awt.font.TextHitInfo parameter2, java.awt.font.TextLayout parameter3) ;
	}
}

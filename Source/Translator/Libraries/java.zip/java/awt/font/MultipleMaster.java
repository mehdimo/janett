package java.awt.font;

interface MultipleMaster
{
	public abstract java.lang.Integer getNumDesignAxes() ;
	public abstract java.lang.Float[] getDesignAxisDefaults() ;
	public abstract java.lang.Float[] getDesignAxisRanges() ;
	public abstract java.awt.Font deriveMMFont(java.lang.Float[] parameter1) ;
	public abstract java.awt.Font deriveMMFont(java.lang.Float[] parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5) ;
	public abstract java.lang.String[] getDesignAxisNames() ;
}

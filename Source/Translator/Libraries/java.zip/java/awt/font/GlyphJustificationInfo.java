package java.awt.font;

abstract class GlyphJustificationInfo
{
	public GlyphJustificationInfo(java.lang.Float parameter1, java.lang.Boolean parameter2, java.lang.Integer parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Boolean parameter6, java.lang.Integer parameter7, java.lang.Float parameter8, java.lang.Float parameter9) ;
	java.lang.Integer PRIORITY_KASHIDA;
	java.lang.Integer PRIORITY_WHITESPACE;
	java.lang.Integer PRIORITY_INTERCHAR;
	java.lang.Integer PRIORITY_NONE;
	java.lang.Float weight;
	java.lang.Integer growPriority;
	java.lang.Boolean growAbsorb;
	java.lang.Float growLeftLimit;
	java.lang.Float growRightLimit;
	java.lang.Integer shrinkPriority;
	java.lang.Boolean shrinkAbsorb;
	java.lang.Float shrinkLeftLimit;
	java.lang.Float shrinkRightLimit;
}

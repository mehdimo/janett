package java.awt.font;

abstract class GlyphJustificationInfo
{
	java.lang.Integer PRIORITY_KASHIDA;
	java.lang.Integer PRIORITY_WHITESPACE;
	java.lang.Integer PRIORITY_INTERCHAR;
	java.lang.Integer PRIORITY_NONE;
	java.lang.Float weight;
	java.lang.Integer growPriority;
	java.lang.Boolean growAbsorb;
	java.lang.Float growLeftLimit;
	java.lang.Float growRightLimit;
	java.lang.Integer shrinkPriority;
	java.lang.Boolean shrinkAbsorb;
	java.lang.Float shrinkLeftLimit;
	java.lang.Float shrinkRightLimit;
}

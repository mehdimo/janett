package java.awt;

abstract class Frame extends java.awt.Window implements java.awt.MenuContainer
{
	public java.lang.Integer getCursorType() ;
	public java.lang.Integer getExtendedState() ;
	public java.lang.Integer getState() ;
	public Frame() ;
	public java.lang.Void addNotify() ;
	public java.lang.Void finalize() ;
	public java.lang.Void removeNotify() ;
	public java.lang.Boolean isResizable() ;
	public java.lang.Boolean isUndecorated() ;
	public java.lang.Void setCursor(java.lang.Integer parameter1) ;
	public java.lang.Void setExtendedState(java.lang.Integer parameter1) ;
	public java.lang.Void setState(java.lang.Integer parameter1) ;
	public java.lang.Void setResizable(java.lang.Boolean parameter1) ;
	public java.lang.Void setUndecorated(java.lang.Boolean parameter1) ;
	public java.awt.Frame[] getFrames() ;
	public Frame(java.awt.GraphicsConfiguration parameter1) ;
	public java.awt.Image getIconImage() ;
	public java.lang.Void setIconImage(java.awt.Image parameter1) ;
	public java.awt.MenuBar getMenuBar() ;
	public java.lang.Void setMenuBar(java.awt.MenuBar parameter1) ;
	public java.lang.Void remove(java.awt.MenuComponent parameter1) ;
	public java.awt.Rectangle getMaximizedBounds() ;
	public java.lang.Void setMaximizedBounds(java.awt.Rectangle parameter1) ;
	public java.lang.String getTitle() ;
	public java.lang.String paramString() ;
	public Frame(java.lang.String parameter1) ;
	public java.lang.Void setTitle(java.lang.String parameter1) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public Frame(java.lang.String parameter1, java.awt.GraphicsConfiguration parameter2) ;
	java.lang.Integer DEFAULT_CURSOR;
	java.lang.Integer CROSSHAIR_CURSOR;
	java.lang.Integer TEXT_CURSOR;
	java.lang.Integer WAIT_CURSOR;
	java.lang.Integer SW_RESIZE_CURSOR;
	java.lang.Integer SE_RESIZE_CURSOR;
	java.lang.Integer NW_RESIZE_CURSOR;
	java.lang.Integer NE_RESIZE_CURSOR;
	java.lang.Integer N_RESIZE_CURSOR;
	java.lang.Integer S_RESIZE_CURSOR;
	java.lang.Integer W_RESIZE_CURSOR;
	java.lang.Integer E_RESIZE_CURSOR;
	java.lang.Integer HAND_CURSOR;
	java.lang.Integer MOVE_CURSOR;
	java.lang.Integer NORMAL;
	java.lang.Integer ICONIFIED;
	java.lang.Integer MAXIMIZED_HORIZ;
	java.lang.Integer MAXIMIZED_VERT;
	java.lang.Integer MAXIMIZED_BOTH;
	abstract class AccessibleAWTFrame extends java.awt.Window.AccessibleAWTWindow
	{
		public AccessibleAWTFrame(java.awt.Frame parameter1) ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

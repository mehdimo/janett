package java.awt;

abstract class Checkbox extends java.awt.Component implements java.awt.ItemSelectable, javax.accessibility.Accessible
{
	public Checkbox() ;
	public java.lang.Void addNotify() ;
	public java.lang.Boolean getState() ;
	public java.lang.Void setState(java.lang.Boolean parameter1) ;
	public java.lang.Void processEvent(java.awt.AWTEvent parameter1) ;
	public java.awt.CheckboxGroup getCheckboxGroup() ;
	public java.lang.Void setCheckboxGroup(java.awt.CheckboxGroup parameter1) ;
	public java.lang.Void processItemEvent(java.awt.event.ItemEvent parameter1) ;
	public java.awt.event.ItemListener[] getItemListeners() ;
	public java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public java.lang.Object[] getSelectedObjects() ;
	public java.lang.String getLabel() ;
	public java.lang.String paramString() ;
	public Checkbox(java.lang.String parameter1) ;
	public java.lang.Void setLabel(java.lang.String parameter1) ;
	public Checkbox(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public Checkbox(java.lang.String parameter1, java.awt.CheckboxGroup parameter2, java.lang.Boolean parameter3) ;
	public Checkbox(java.lang.String parameter1, java.lang.Boolean parameter2, java.awt.CheckboxGroup parameter3) ;
	public java.util.EventListener[] getListeners(java.lang.Class parameter1) ;
	abstract class AccessibleAWTCheckbox extends java.awt.Component.AccessibleAWTComponent implements java.awt.event.ItemListener, javax.accessibility.AccessibleAction, javax.accessibility.AccessibleValue
	{
		public java.lang.Integer getAccessibleActionCount() ;
		public java.lang.Boolean doAccessibleAction(java.lang.Integer parameter1) ;
		public AccessibleAWTCheckbox(java.awt.Checkbox parameter1) ;
		public java.lang.Void itemStateChanged(java.awt.event.ItemEvent parameter1) ;
		public java.lang.Number getCurrentAccessibleValue() ;
		public java.lang.Number getMaximumAccessibleValue() ;
		public java.lang.Number getMinimumAccessibleValue() ;
		public java.lang.Boolean setCurrentAccessibleValue(java.lang.Number parameter1) ;
		public java.lang.String getAccessibleActionDescription(java.lang.Integer parameter1) ;
		public javax.accessibility.AccessibleAction getAccessibleAction() ;
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
		public javax.accessibility.AccessibleValue getAccessibleValue() ;
	}
}

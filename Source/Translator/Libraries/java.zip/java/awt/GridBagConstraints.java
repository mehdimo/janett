package java.awt;

abstract class GridBagConstraints implements java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Object clone() ;
	java.lang.Integer RELATIVE;
	java.lang.Integer REMAINDER;
	java.lang.Integer NONE;
	java.lang.Integer BOTH;
	java.lang.Integer HORIZONTAL;
	java.lang.Integer VERTICAL;
	java.lang.Integer CENTER;
	java.lang.Integer NORTH;
	java.lang.Integer NORTHEAST;
	java.lang.Integer EAST;
	java.lang.Integer SOUTHEAST;
	java.lang.Integer SOUTH;
	java.lang.Integer SOUTHWEST;
	java.lang.Integer WEST;
	java.lang.Integer NORTHWEST;
	java.lang.Integer PAGE_START;
	java.lang.Integer PAGE_END;
	java.lang.Integer LINE_START;
	java.lang.Integer LINE_END;
	java.lang.Integer FIRST_LINE_START;
	java.lang.Integer FIRST_LINE_END;
	java.lang.Integer LAST_LINE_START;
	java.lang.Integer LAST_LINE_END;
	java.lang.Integer gridx;
	java.lang.Integer gridy;
	java.lang.Integer gridwidth;
	java.lang.Integer gridheight;
	java.lang.Double weightx;
	java.lang.Double weighty;
	java.lang.Integer anchor;
	java.lang.Integer fill;
	java.awt.Insets insets;
	java.lang.Integer ipadx;
	java.lang.Integer ipady;
}

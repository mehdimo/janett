package java.awt;

abstract class IllegalComponentStateException extends java.lang.IllegalStateException
{
}

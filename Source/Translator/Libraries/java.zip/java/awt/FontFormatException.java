package java.awt;

abstract class FontFormatException extends java.lang.Exception
{
}

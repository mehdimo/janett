package java.awt;

abstract class FontFormatException extends java.lang.Exception
{
	public FontFormatException(java.lang.String parameter1) ;
}

package java.awt;

interface ItemSelectable
{
	public abstract java.lang.Void addItemListener(java.awt.event.ItemListener parameter1) ;
	public abstract java.lang.Void removeItemListener(java.awt.event.ItemListener parameter1) ;
	public abstract java.lang.Object[] getSelectedObjects() ;
}

package java.awt;

abstract class GridBagLayout implements java.awt.LayoutManager2, java.io.Serializable
{
	public void getLayoutWeights() ;
	public void getLayoutDimensions() ;
	public java.lang.Void removeLayoutComponent(java.awt.Component parameter1) ;
	public java.lang.Float getLayoutAlignmentX(java.awt.Container parameter1) ;
	public java.lang.Float getLayoutAlignmentY(java.awt.Container parameter1) ;
	public java.lang.Void ArrangeGrid(java.awt.Container parameter1) ;
	public java.lang.Void arrangeGrid(java.awt.Container parameter1) ;
	public java.lang.Void invalidateLayout(java.awt.Container parameter1) ;
	public java.lang.Void layoutContainer(java.awt.Container parameter1) ;
	public java.awt.Point getLayoutOrigin() ;
	public java.awt.Point location(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.String toString() ;
	public java.lang.Void addLayoutComponent(java.lang.String parameter1, java.awt.Component parameter2) ;
	public java.awt.Dimension maximumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension minimumLayoutSize(java.awt.Container parameter1) ;
	public java.awt.Dimension preferredLayoutSize(java.awt.Container parameter1) ;
	public java.awt.GridBagConstraints getConstraints(java.awt.Component parameter1) ;
	public java.awt.GridBagConstraints lookupConstraints(java.awt.Component parameter1) ;
	public java.lang.Void setConstraints(java.awt.Component parameter1, java.awt.GridBagConstraints parameter2) ;
	public java.awt.GridBagLayoutInfo GetLayoutInfo(java.awt.Container parameter1, java.lang.Integer parameter2) ;
	public java.awt.GridBagLayoutInfo getLayoutInfo(java.awt.Container parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void AdjustForGravity(java.awt.GridBagConstraints parameter1, java.awt.Rectangle parameter2) ;
	public java.lang.Void adjustForGravity(java.awt.GridBagConstraints parameter1, java.awt.Rectangle parameter2) ;
	public java.lang.Void addLayoutComponent(java.awt.Component parameter1, java.lang.Object parameter2) ;
	public java.awt.Dimension GetMinSize(java.awt.Container parameter1, java.awt.GridBagLayoutInfo parameter2) ;
	public java.awt.Dimension getMinSize(java.awt.Container parameter1, java.awt.GridBagLayoutInfo parameter2) ;
	java.lang.Integer[] columnWidths;
	java.lang.Integer[] rowHeights;
	java.lang.Double[] columnWeights;
	java.lang.Double[] rowWeights;
}

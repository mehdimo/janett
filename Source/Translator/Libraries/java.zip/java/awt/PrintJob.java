package java.awt;

abstract class PrintJob
{
	public abstract java.lang.Integer getPageResolution() ;
	public PrintJob() ;
	public abstract java.lang.Void end() ;
	public java.lang.Void finalize() ;
	public abstract java.lang.Boolean lastPageFirst() ;
	public abstract java.awt.Dimension getPageDimension() ;
	public abstract java.awt.Graphics getGraphics() ;
}

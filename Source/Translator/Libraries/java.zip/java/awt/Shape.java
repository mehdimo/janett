package java.awt;

interface Shape
{
	public abstract java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public abstract java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public abstract java.awt.Rectangle getBounds() ;
	public abstract java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public abstract java.awt.geom.Rectangle2D getBounds2D() ;
	public abstract java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public abstract java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public abstract java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public abstract java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
}

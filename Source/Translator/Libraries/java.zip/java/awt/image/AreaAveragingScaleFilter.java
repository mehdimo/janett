package java.awt.image;

abstract class AreaAveragingScaleFilter extends java.awt.image.ReplicateScaleFilter
{
	public java.lang.Void setHints(java.lang.Integer parameter1) ;
	public AreaAveragingScaleFilter(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Byte[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
}

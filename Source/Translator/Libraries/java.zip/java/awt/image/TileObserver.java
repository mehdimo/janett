package java.awt.image;

interface TileObserver
{
	public abstract java.lang.Void tileUpdate(java.awt.image.WritableRenderedImage parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Boolean parameter4) ;
}

package java.awt.image;

abstract class SampleModel
{
	public java.lang.Integer getDataType() ;
	public java.lang.Integer getHeight() ;
	public java.lang.Integer getNumBands() ;
	public abstract java.lang.Integer getNumDataElements() ;
	public java.lang.Integer getTransferType() ;
	public java.lang.Integer getWidth() ;
	public abstract java.lang.Integer[] getSampleSize() ;
	public abstract java.lang.Integer getSampleSize(java.lang.Integer parameter1) ;
	public abstract java.awt.image.DataBuffer createDataBuffer() ;
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Double parameter4, java.awt.image.DataBuffer parameter5) ;
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Float parameter4, java.awt.image.DataBuffer parameter5) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Double[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public java.lang.Double[] getSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Double[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Float[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public java.lang.Float[] getSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Float[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public java.lang.Integer[] getSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6, java.awt.image.DataBuffer parameter7) ;
	public abstract java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.DataBuffer parameter5) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Double[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Double[] getPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Double[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Float[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Float[] getPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Float[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Integer[] getPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer[] parameter5, java.awt.image.DataBuffer parameter6) ;
	public java.lang.Double getSampleDouble(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Float getSampleFloat(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.DataBuffer parameter4) ;
	public abstract java.lang.Integer getSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Double[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Double[] getPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Double[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Float[] getPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Integer[] getPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public abstract java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.image.SampleModel createSubsetSampleModel(java.lang.Integer[] parameter1) ;
	public java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Object parameter5, java.awt.image.DataBuffer parameter6) ;
	public abstract java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Object getDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Object parameter5, java.awt.image.DataBuffer parameter6) ;
	public abstract java.lang.Object getDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.awt.image.DataBuffer parameter4) ;
}

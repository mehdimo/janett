package java.awt.image;

abstract class VolatileImage extends java.awt.Image
{
	public abstract java.lang.Integer getHeight() ;
	public abstract java.lang.Integer getWidth() ;
	public VolatileImage() ;
	public java.lang.Void flush() ;
	public abstract java.lang.Boolean contentsLost() ;
	public java.awt.Graphics getGraphics() ;
	public abstract java.awt.Graphics2D createGraphics() ;
	public abstract java.lang.Integer validate(java.awt.GraphicsConfiguration parameter1) ;
	public abstract java.awt.ImageCapabilities getCapabilities() ;
	public abstract java.awt.image.BufferedImage getSnapshot() ;
	public java.awt.image.ImageProducer getSource() ;
	java.lang.Integer IMAGE_OK;
	java.lang.Integer IMAGE_RESTORED;
	java.lang.Integer IMAGE_INCOMPATIBLE;
}

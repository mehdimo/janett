package java.awt.image;

abstract class ImagingOpException extends java.lang.RuntimeException
{
	public ImagingOpException(java.lang.String parameter1) ;
}

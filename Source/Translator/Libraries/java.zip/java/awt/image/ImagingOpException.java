package java.awt.image;

abstract class ImagingOpException extends java.lang.RuntimeException
{
}

package java.awt.image;

abstract class PackedColorModel extends java.awt.image.ColorModel
{
	public java.lang.Integer[] getMasks() ;
	public java.lang.Integer getMask(java.lang.Integer parameter1) ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean isCompatibleSampleModel(java.awt.image.SampleModel parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.awt.image.WritableRaster getAlphaRaster(java.awt.image.WritableRaster parameter1) ;
}

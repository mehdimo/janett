package java.awt.image;

abstract class PackedColorModel extends java.awt.image.ColorModel
{
	public java.lang.Integer[] getMasks() ;
	public java.lang.Integer getMask(java.lang.Integer parameter1) ;
	public PackedColorModel(java.awt.color.ColorSpace parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Boolean parameter7, java.lang.Integer parameter8, java.lang.Integer parameter9) ;
	public PackedColorModel(java.awt.color.ColorSpace parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7) ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean isCompatibleSampleModel(java.awt.image.SampleModel parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.awt.image.WritableRaster getAlphaRaster(java.awt.image.WritableRaster parameter1) ;
}

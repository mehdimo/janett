package java.awt.image;

abstract class BandCombineOp implements java.awt.image.RasterOp
{
	public void getMatrix() ;
	public java.awt.RenderingHints getRenderingHints() ;
	public BandCombineOp() ;
	public java.awt.geom.Rectangle2D getBounds2D(java.awt.image.Raster parameter1) ;
	public java.awt.image.WritableRaster createCompatibleDestRaster(java.awt.image.Raster parameter1) ;
	public java.awt.geom.Point2D getPoint2D(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2) ;
	public java.awt.image.WritableRaster filter(java.awt.image.Raster parameter1, java.awt.image.WritableRaster parameter2) ;
}

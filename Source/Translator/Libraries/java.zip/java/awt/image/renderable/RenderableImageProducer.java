package java.awt.image.renderable;

abstract class RenderableImageProducer implements java.awt.image.ImageProducer, java.lang.Runnable
{
	public java.lang.Void run() ;
	public java.lang.Void addConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void removeConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void requestTopDownLeftRightResend(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void startProduction(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Boolean isConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void setRenderContext(java.awt.image.renderable.RenderContext parameter1) ;
}

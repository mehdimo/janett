package java.awt.image.renderable;

interface RenderedImageFactory
{
	public abstract java.awt.image.RenderedImage create(java.awt.image.renderable.ParameterBlock parameter1, java.awt.RenderingHints parameter2) ;
}

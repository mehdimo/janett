package java.awt.image.renderable;

abstract class ParameterBlock implements java.lang.Cloneable, java.io.Serializable
{
	public java.lang.Integer getNumParameters() ;
	public java.lang.Integer getNumSources() ;
	public ParameterBlock() ;
	public java.lang.Void removeParameters() ;
	public java.lang.Void removeSources() ;
	public java.lang.Byte getByteParameter(java.lang.Integer parameter1) ;
	public java.lang.Character getCharParameter(java.lang.Integer parameter1) ;
	public java.lang.Double getDoubleParameter(java.lang.Integer parameter1) ;
	public java.lang.Float getFloatParameter(java.lang.Integer parameter1) ;
	public java.lang.Integer getIntParameter(java.lang.Integer parameter1) ;
	public java.lang.Long getLongParameter(java.lang.Integer parameter1) ;
	public java.lang.Short getShortParameter(java.lang.Integer parameter1) ;
	public java.awt.image.RenderedImage getRenderedSource(java.lang.Integer parameter1) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Byte parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Byte parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Character parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Character parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Double parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Double parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Float parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Float parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Integer parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Long parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Short parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Short parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.RenderableImage getRenderableSource(java.lang.Integer parameter1) ;
	public java.lang.Class[] getParamClasses() ;
	public java.lang.Object clone() ;
	public java.lang.Object shallowClone() ;
	public java.lang.Object getObjectParameter(java.lang.Integer parameter1) ;
	public java.lang.Object getSource(java.lang.Integer parameter1) ;
	public java.util.Vector getParameters() ;
	public java.util.Vector getSources() ;
	public ParameterBlock(java.util.Vector parameter1) ;
	public java.lang.Void setParameters(java.util.Vector parameter1) ;
	public java.lang.Void setSources(java.util.Vector parameter1) ;
	public java.awt.image.renderable.ParameterBlock add(java.lang.Object parameter1) ;
	public java.awt.image.renderable.ParameterBlock addSource(java.lang.Object parameter1) ;
	public java.awt.image.renderable.ParameterBlock set(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.renderable.ParameterBlock setSource(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public ParameterBlock(java.util.Vector parameter1, java.util.Vector parameter2) ;
}

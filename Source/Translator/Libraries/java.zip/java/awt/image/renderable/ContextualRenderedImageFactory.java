package java.awt.image.renderable;

interface ContextualRenderedImageFactory implements java.awt.image.renderable.RenderedImageFactory
{
	public abstract java.lang.Boolean isDynamic() ;
	public abstract java.lang.String[] getPropertyNames() ;
	public abstract java.awt.geom.Rectangle2D getBounds2D(java.awt.image.renderable.ParameterBlock parameter1) ;
	public abstract java.awt.image.RenderedImage create(java.awt.image.renderable.RenderContext parameter1, java.awt.image.renderable.ParameterBlock parameter2) ;
	public abstract java.lang.Object getProperty(java.awt.image.renderable.ParameterBlock parameter1, java.lang.String parameter2) ;
	public abstract java.awt.image.renderable.RenderContext mapRenderContext(java.lang.Integer parameter1, java.awt.image.renderable.RenderContext parameter2, java.awt.image.renderable.ParameterBlock parameter3, java.awt.image.renderable.RenderableImage parameter4) ;
}

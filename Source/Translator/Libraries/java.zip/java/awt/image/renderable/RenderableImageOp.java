package java.awt.image.renderable;

abstract class RenderableImageOp implements java.awt.image.renderable.RenderableImage
{
	public java.lang.Float getHeight() ;
	public java.lang.Float getMinX() ;
	public java.lang.Float getMinY() ;
	public java.lang.Float getWidth() ;
	public java.lang.Boolean isDynamic() ;
	public java.awt.image.RenderedImage createDefaultRendering() ;
	public java.awt.image.renderable.ParameterBlock getParameterBlock() ;
	public java.lang.String[] getPropertyNames() ;
	public java.util.Vector getSources() ;
	public java.awt.image.RenderedImage createScaledRendering(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.RenderingHints parameter3) ;
	public java.awt.image.RenderedImage createRendering(java.awt.image.renderable.RenderContext parameter1) ;
	public RenderableImageOp(java.awt.image.renderable.ContextualRenderedImageFactory parameter1, java.awt.image.renderable.ParameterBlock parameter2) ;
	public java.awt.image.renderable.ParameterBlock setParameterBlock(java.awt.image.renderable.ParameterBlock parameter1) ;
	public java.lang.Object getProperty(java.lang.String parameter1) ;
}

package java.awt.image.renderable;

abstract class RenderContext implements java.lang.Cloneable
{
	public java.awt.RenderingHints getRenderingHints() ;
	public java.lang.Void setRenderingHints(java.awt.RenderingHints parameter1) ;
	public java.awt.Shape getAreaOfInterest() ;
	public java.lang.Void setAreaOfInterest(java.awt.Shape parameter1) ;
	public java.awt.geom.AffineTransform getTransform() ;
	public RenderContext(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void concatenateTransform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void concetenateTransform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void preConcatenateTransform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void preConcetenateTransform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void setTransform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Object clone() ;
	public RenderContext(java.awt.geom.AffineTransform parameter1, java.awt.RenderingHints parameter2) ;
	public RenderContext(java.awt.geom.AffineTransform parameter1, java.awt.Shape parameter2) ;
	public RenderContext(java.awt.geom.AffineTransform parameter1, java.awt.Shape parameter2, java.awt.RenderingHints parameter3) ;
}

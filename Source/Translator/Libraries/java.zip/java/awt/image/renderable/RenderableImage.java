package java.awt.image.renderable;

interface RenderableImage
{
	public abstract java.lang.Float getHeight() ;
	public abstract java.lang.Float getMinX() ;
	public abstract java.lang.Float getMinY() ;
	public abstract java.lang.Float getWidth() ;
	public abstract java.lang.Boolean isDynamic() ;
	public abstract java.awt.image.RenderedImage createDefaultRendering() ;
	public abstract java.lang.String[] getPropertyNames() ;
	public abstract java.util.Vector getSources() ;
	public abstract java.awt.image.RenderedImage createScaledRendering(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.RenderingHints parameter3) ;
	public abstract java.awt.image.RenderedImage createRendering(java.awt.image.renderable.RenderContext parameter1) ;
	public abstract java.lang.Object getProperty(java.lang.String parameter1) ;
	java.lang.String HINTS_OBSERVED;
}

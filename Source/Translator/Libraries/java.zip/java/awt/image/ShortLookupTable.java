package java.awt.image;

abstract class ShortLookupTable extends java.awt.image.LookupTable
{
	public void getTable() ;
	public ShortLookupTable(java.lang.Integer parameter1, java.lang.Short[] parameter2) ;
	public ShortLookupTable() ;
	public java.lang.Integer[] lookupPixel(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2) ;
	public java.lang.Short[] lookupPixel(java.lang.Short[] parameter1, java.lang.Short[] parameter2) ;
}

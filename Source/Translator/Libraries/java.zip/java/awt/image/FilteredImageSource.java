package java.awt.image;

abstract class FilteredImageSource implements java.awt.image.ImageProducer
{
	public java.lang.Void addConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void removeConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void requestTopDownLeftRightResend(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void startProduction(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Boolean isConsumer(java.awt.image.ImageConsumer parameter1) ;
}

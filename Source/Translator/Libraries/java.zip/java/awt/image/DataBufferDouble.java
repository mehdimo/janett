package java.awt.image;

abstract class DataBufferDouble extends java.awt.image.DataBuffer
{
	public java.lang.Double[] getData() ;
	public void getBankData() ;
	public java.lang.Double getElemDouble(java.lang.Integer parameter1) ;
	public java.lang.Float getElemFloat(java.lang.Integer parameter1) ;
	public java.lang.Integer getElem(java.lang.Integer parameter1) ;
	public DataBufferDouble(java.lang.Integer parameter1) ;
	public java.lang.Double[] getData(java.lang.Integer parameter1) ;
	public java.lang.Void setElemDouble(java.lang.Integer parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setElemFloat(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Double getElemDouble(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Float getElemFloat(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer getElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public DataBufferDouble(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElemDouble(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Double parameter3) ;
	public java.lang.Void setElemFloat(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float parameter3) ;
	public java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataBufferDouble(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public DataBufferDouble(java.lang.Double[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataBufferDouble() ;
	public DataBufferDouble() ;
}

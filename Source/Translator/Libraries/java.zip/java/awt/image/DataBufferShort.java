package java.awt.image;

abstract class DataBufferShort extends java.awt.image.DataBuffer
{
	public java.lang.Short[] getData() ;
	public void getBankData() ;
	public java.lang.Integer getElem(java.lang.Integer parameter1) ;
	public DataBufferShort(java.lang.Integer parameter1) ;
	public java.lang.Short[] getData(java.lang.Integer parameter1) ;
	public java.lang.Integer getElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public DataBufferShort(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataBufferShort(java.lang.Short[] parameter1, java.lang.Integer parameter2) ;
	public DataBufferShort(java.lang.Short[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataBufferShort() ;
	public DataBufferShort() ;
}

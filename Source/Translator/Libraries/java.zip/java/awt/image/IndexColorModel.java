package java.awt.image;

abstract class IndexColorModel extends java.awt.image.ColorModel
{
	public java.lang.Integer getMapSize() ;
	public java.lang.Integer getTransparency() ;
	public java.lang.Integer getTransparentPixel() ;
	public java.lang.Void finalize() ;
	public java.lang.Boolean isValid() ;
	public java.lang.Integer[] getComponentSize() ;
	public java.lang.Integer getAlpha(java.lang.Integer parameter1) ;
	public java.lang.Integer getBlue(java.lang.Integer parameter1) ;
	public java.lang.Integer getGreen(java.lang.Integer parameter1) ;
	public java.lang.Integer getRGB(java.lang.Integer parameter1) ;
	public java.lang.Integer getRed(java.lang.Integer parameter1) ;
	public java.lang.Boolean isValid(java.lang.Integer parameter1) ;
	public java.lang.Integer[] getComponents(java.lang.Integer parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void getAlphas(java.lang.Byte[] parameter1) ;
	public java.lang.Void getBlues(java.lang.Byte[] parameter1) ;
	public java.lang.Void getGreens(java.lang.Byte[] parameter1) ;
	public java.lang.Void getReds(java.lang.Byte[] parameter1) ;
	public java.lang.Void getRGBs(java.lang.Integer[] parameter1) ;
	public java.lang.Integer getDataElement(java.lang.Integer[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean isCompatibleRaster(java.awt.image.Raster parameter1) ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean isCompatibleSampleModel(java.awt.image.SampleModel parameter1) ;
	public java.awt.image.WritableRaster createCompatibleWritableRaster(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer[] getComponents(java.lang.Object parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.String toString() ;
	public java.math.BigInteger getValidPixels() ;
	public java.awt.image.BufferedImage convertToIntDiscrete(java.awt.image.Raster parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Object getDataElements(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public java.lang.Object getDataElements(java.lang.Integer[] parameter1, java.lang.Integer parameter2, java.lang.Object parameter3) ;
}

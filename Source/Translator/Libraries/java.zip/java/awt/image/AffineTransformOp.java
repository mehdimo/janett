package java.awt.image;

abstract class AffineTransformOp implements java.awt.image.BufferedImageOp, java.awt.image.RasterOp
{
	public java.lang.Integer getInterpolationType() ;
	public java.awt.RenderingHints getRenderingHints() ;
	public java.awt.geom.AffineTransform getTransform() ;
	public java.awt.geom.Rectangle2D getBounds2D(java.awt.image.BufferedImage parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D(java.awt.image.Raster parameter1) ;
	public java.awt.image.WritableRaster createCompatibleDestRaster(java.awt.image.Raster parameter1) ;
	public java.awt.geom.Point2D getPoint2D(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2) ;
	public java.awt.image.BufferedImage filter(java.awt.image.BufferedImage parameter1, java.awt.image.BufferedImage parameter2) ;
	public java.awt.image.BufferedImage createCompatibleDestImage(java.awt.image.BufferedImage parameter1, java.awt.image.ColorModel parameter2) ;
	public java.awt.image.WritableRaster filter(java.awt.image.Raster parameter1, java.awt.image.WritableRaster parameter2) ;
	java.lang.Integer TYPE_NEAREST_NEIGHBOR;
	java.lang.Integer TYPE_BILINEAR;
}

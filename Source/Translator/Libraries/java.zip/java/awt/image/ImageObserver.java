package java.awt.image;

interface ImageObserver
{
	public abstract java.lang.Boolean imageUpdate(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	java.lang.Integer WIDTH;
	java.lang.Integer HEIGHT;
	java.lang.Integer PROPERTIES;
	java.lang.Integer SOMEBITS;
	java.lang.Integer FRAMEBITS;
	java.lang.Integer ALLBITS;
	java.lang.Integer ERROR;
	java.lang.Integer ABORT;
}

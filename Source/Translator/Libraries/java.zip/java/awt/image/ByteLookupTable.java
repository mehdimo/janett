package java.awt.image;

abstract class ByteLookupTable extends java.awt.image.LookupTable
{
	public void getTable() ;
	public ByteLookupTable(java.lang.Integer parameter1, java.lang.Byte[] parameter2) ;
	public ByteLookupTable() ;
	public java.lang.Byte[] lookupPixel(java.lang.Byte[] parameter1, java.lang.Byte[] parameter2) ;
	public java.lang.Integer[] lookupPixel(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2) ;
}

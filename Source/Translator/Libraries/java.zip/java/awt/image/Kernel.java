package java.awt.image;

abstract class Kernel implements java.lang.Cloneable
{
	public java.lang.Integer getHeight() ;
	public java.lang.Integer getWidth() ;
	public java.lang.Integer getXOrigin() ;
	public java.lang.Integer getYOrigin() ;
	public Kernel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float[] parameter3) ;
	public java.lang.Float[] getKernelData(java.lang.Float[] parameter1) ;
	public java.lang.Object clone() ;
}

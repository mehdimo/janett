package java.awt.image;

abstract class PixelInterleavedSampleModel extends java.awt.image.ComponentSampleModel
{
	public java.lang.Integer hashCode() ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.SampleModel createSubsetSampleModel(java.lang.Integer[] parameter1) ;
}

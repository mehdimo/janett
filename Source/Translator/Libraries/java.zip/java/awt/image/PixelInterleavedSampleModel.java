package java.awt.image;

abstract class PixelInterleavedSampleModel extends java.awt.image.ComponentSampleModel
{
	public java.lang.Integer hashCode() ;
	public PixelInterleavedSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6) ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.SampleModel createSubsetSampleModel(java.lang.Integer[] parameter1) ;
}

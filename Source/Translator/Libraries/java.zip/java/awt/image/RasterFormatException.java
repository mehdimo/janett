package java.awt.image;

abstract class RasterFormatException extends java.lang.RuntimeException
{
	public RasterFormatException(java.lang.String parameter1) ;
}

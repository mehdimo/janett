package java.awt.image;

abstract class RasterFormatException extends java.lang.RuntimeException
{
}

package java.awt.image;

abstract class BufferedImageFilter extends java.awt.image.ImageFilter implements java.lang.Cloneable
{
	public java.lang.Void imageComplete(java.lang.Integer parameter1) ;
	public java.lang.Void setDimensions(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.BufferedImageOp getBufferedImageOp() ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Byte[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setColorModel(java.awt.image.ColorModel parameter1) ;
}

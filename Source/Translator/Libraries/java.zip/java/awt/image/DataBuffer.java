package java.awt.image;

abstract class DataBuffer
{
	public java.lang.Integer getDataType() ;
	public java.lang.Integer getNumBanks() ;
	public java.lang.Integer getOffset() ;
	public java.lang.Integer getSize() ;
	public java.lang.Integer[] getOffsets() ;
	public java.lang.Double getElemDouble(java.lang.Integer parameter1) ;
	public java.lang.Float getElemFloat(java.lang.Integer parameter1) ;
	public java.lang.Integer getDataTypeSize(java.lang.Integer parameter1) ;
	public java.lang.Integer getElem(java.lang.Integer parameter1) ;
	public java.lang.Void setElemDouble(java.lang.Integer parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setElemFloat(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.Double getElemDouble(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Float getElemFloat(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer getElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setElemDouble(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Double parameter3) ;
	public java.lang.Void setElemFloat(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float parameter3) ;
	public abstract java.lang.Void setElem(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	java.lang.Integer TYPE_BYTE;
	java.lang.Integer TYPE_USHORT;
	java.lang.Integer TYPE_SHORT;
	java.lang.Integer TYPE_INT;
	java.lang.Integer TYPE_FLOAT;
	java.lang.Integer TYPE_DOUBLE;
	java.lang.Integer TYPE_UNDEFINED;
}

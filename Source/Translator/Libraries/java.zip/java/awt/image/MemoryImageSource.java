package java.awt.image;

abstract class MemoryImageSource implements java.awt.image.ImageProducer
{
	public java.lang.Void newPixels() ;
	public java.lang.Void newPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void newPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Boolean parameter5) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.Void setAnimated(java.lang.Boolean parameter1) ;
	public java.lang.Void setFullBufferUpdates(java.lang.Boolean parameter1) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.ColorModel parameter3, java.lang.Byte[] parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.ColorModel parameter3, java.lang.Integer[] parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.lang.Void newPixels(java.lang.Byte[] parameter1, java.awt.image.ColorModel parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void newPixels(java.lang.Integer[] parameter1, java.awt.image.ColorModel parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void addConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void removeConsumer(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void requestTopDownLeftRightResend(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Void startProduction(java.awt.image.ImageConsumer parameter1) ;
	public java.lang.Boolean isConsumer(java.awt.image.ImageConsumer parameter1) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.util.Hashtable parameter6) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.ColorModel parameter3, java.lang.Byte[] parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.util.Hashtable parameter7) ;
	public MemoryImageSource(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.ColorModel parameter3, java.lang.Integer[] parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.util.Hashtable parameter7) ;
}

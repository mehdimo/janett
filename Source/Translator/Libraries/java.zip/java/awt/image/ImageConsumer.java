package java.awt.image;

interface ImageConsumer
{
	public abstract java.lang.Void imageComplete(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setHints(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setDimensions(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Byte[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public abstract java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public abstract java.lang.Void setColorModel(java.awt.image.ColorModel parameter1) ;
	public abstract java.lang.Void setProperties(java.util.Hashtable parameter1) ;
	java.lang.Integer RANDOMPIXELORDER;
	java.lang.Integer TOPDOWNLEFTRIGHT;
	java.lang.Integer COMPLETESCANLINES;
	java.lang.Integer SINGLEPASS;
	java.lang.Integer SINGLEFRAME;
	java.lang.Integer IMAGEERROR;
	java.lang.Integer SINGLEFRAMEDONE;
	java.lang.Integer STATICIMAGEDONE;
	java.lang.Integer IMAGEABORTED;
}

package java.awt.image;

abstract class DirectColorModel extends java.awt.image.PackedColorModel
{
	public java.lang.Integer getAlphaMask() ;
	public java.lang.Integer getBlueMask() ;
	public java.lang.Integer getGreenMask() ;
	public java.lang.Integer getRedMask() ;
	public java.lang.Integer getAlpha(java.lang.Integer parameter1) ;
	public java.lang.Integer getBlue(java.lang.Integer parameter1) ;
	public java.lang.Integer getGreen(java.lang.Integer parameter1) ;
	public java.lang.Integer getRGB(java.lang.Integer parameter1) ;
	public java.lang.Integer getRed(java.lang.Integer parameter1) ;
	public java.lang.Integer[] getComponents(java.lang.Integer parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.Integer getDataElement(java.lang.Integer[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean isCompatibleRaster(java.awt.image.Raster parameter1) ;
	public java.awt.image.WritableRaster createCompatibleWritableRaster(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer getAlpha(java.lang.Object parameter1) ;
	public java.lang.Integer getBlue(java.lang.Object parameter1) ;
	public java.lang.Integer getGreen(java.lang.Object parameter1) ;
	public java.lang.Integer getRGB(java.lang.Object parameter1) ;
	public java.lang.Integer getRed(java.lang.Object parameter1) ;
	public java.lang.Integer[] getComponents(java.lang.Object parameter1, java.lang.Integer[] parameter2, java.lang.Integer parameter3) ;
	public java.lang.String toString() ;
	public java.awt.image.ColorModel coerceData(java.awt.image.WritableRaster parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Object getDataElements(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public java.lang.Object getDataElements(java.lang.Integer[] parameter1, java.lang.Integer parameter2, java.lang.Object parameter3) ;
}

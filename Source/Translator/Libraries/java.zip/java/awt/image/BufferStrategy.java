package java.awt.image;

abstract class BufferStrategy
{
	public BufferStrategy() ;
	public abstract java.lang.Void show() ;
	public abstract java.lang.Boolean contentsLost() ;
	public abstract java.lang.Boolean contentsRestored() ;
	public abstract java.awt.BufferCapabilities getCapabilities() ;
	public abstract java.awt.Graphics getDrawGraphics() ;
}

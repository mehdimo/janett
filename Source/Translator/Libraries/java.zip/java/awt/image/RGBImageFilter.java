package java.awt.image;

abstract class RGBImageFilter extends java.awt.image.ImageFilter
{
	public RGBImageFilter() ;
	public abstract java.lang.Integer filterRGB(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void filterRGBPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer[] parameter5, java.lang.Integer parameter6, java.lang.Integer parameter7) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Byte[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setColorModel(java.awt.image.ColorModel parameter1) ;
	public java.lang.Void substituteColorModel(java.awt.image.ColorModel parameter1, java.awt.image.ColorModel parameter2) ;
	public java.awt.image.IndexColorModel filterIndexColorModel(java.awt.image.IndexColorModel parameter1) ;
}

package java.awt.image;

abstract class PixelGrabber implements java.awt.image.ImageConsumer
{
	public java.lang.Integer getHeight() ;
	public java.lang.Integer getStatus() ;
	public java.lang.Integer getWidth() ;
	public java.lang.Integer status() ;
	public java.lang.Void abortGrabbing() ;
	public java.lang.Void startGrabbing() ;
	public java.lang.Boolean grabPixels() ;
	public java.lang.Void imageComplete(java.lang.Integer parameter1) ;
	public java.lang.Void setHints(java.lang.Integer parameter1) ;
	public java.lang.Void setDimensions(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean grabPixels(java.lang.Long parameter1) ;
	public PixelGrabber(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Boolean parameter6) ;
	public PixelGrabber(java.awt.Image parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.awt.image.ColorModel getColorModel() ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Byte[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.ColorModel parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Void setColorModel(java.awt.image.ColorModel parameter1) ;
	public PixelGrabber(java.awt.image.ImageProducer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6, java.lang.Integer parameter7, java.lang.Integer parameter8) ;
	public java.lang.Object getPixels() ;
	public java.lang.Void setProperties(java.util.Hashtable parameter1) ;
}

package java.awt.image;

interface RenderedImage
{
	public abstract java.lang.Integer getHeight() ;
	public abstract java.lang.Integer getMinTileX() ;
	public abstract java.lang.Integer getMinTileY() ;
	public abstract java.lang.Integer getMinX() ;
	public abstract java.lang.Integer getMinY() ;
	public abstract java.lang.Integer getNumXTiles() ;
	public abstract java.lang.Integer getNumYTiles() ;
	public abstract java.lang.Integer getTileGridXOffset() ;
	public abstract java.lang.Integer getTileGridYOffset() ;
	public abstract java.lang.Integer getTileHeight() ;
	public abstract java.lang.Integer getTileWidth() ;
	public abstract java.lang.Integer getWidth() ;
	public abstract java.awt.image.ColorModel getColorModel() ;
	public abstract java.awt.image.Raster getData() ;
	public abstract java.awt.image.Raster getTile(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.image.SampleModel getSampleModel() ;
	public abstract java.lang.String[] getPropertyNames() ;
	public abstract java.util.Vector getSources() ;
	public abstract java.awt.image.Raster getData(java.awt.Rectangle parameter1) ;
	public abstract java.awt.image.WritableRaster copyData(java.awt.image.WritableRaster parameter1) ;
	public abstract java.lang.Object getProperty(java.lang.String parameter1) ;
}

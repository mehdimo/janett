package java.awt.image;

abstract class MultiPixelPackedSampleModel extends java.awt.image.SampleModel
{
	public java.lang.Integer getDataBitOffset() ;
	public java.lang.Integer getNumDataElements() ;
	public java.lang.Integer getPixelBitStride() ;
	public java.lang.Integer getScanlineStride() ;
	public java.lang.Integer getTransferType() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer[] getSampleSize() ;
	public java.lang.Integer getBitOffset(java.lang.Integer parameter1) ;
	public java.lang.Integer getSampleSize(java.lang.Integer parameter1) ;
	public java.lang.Integer getOffset(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public MultiPixelPackedSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public MultiPixelPackedSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6) ;
	public java.awt.image.DataBuffer createDataBuffer() ;
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.awt.image.DataBuffer parameter5) ;
	public java.lang.Integer getSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Integer[] getPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.awt.image.SampleModel createCompatibleSampleModel(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.SampleModel createSubsetSampleModel(java.lang.Integer[] parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.awt.image.DataBuffer parameter4) ;
	public java.lang.Object getDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.awt.image.DataBuffer parameter4) ;
}

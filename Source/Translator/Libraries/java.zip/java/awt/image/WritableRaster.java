package java.awt.image;

abstract class WritableRaster extends java.awt.image.Raster
{
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Double parameter4) ;
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Float parameter4) ;
	public java.lang.Void setSample(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Double[] parameter6) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Float[] parameter6) ;
	public java.lang.Void setSamples(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer[] parameter6) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Double[] parameter5) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Float[] parameter5) ;
	public java.lang.Void setPixels(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer[] parameter5) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Double[] parameter3) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Float[] parameter3) ;
	public java.lang.Void setPixel(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer[] parameter3) ;
	public java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.Raster parameter3) ;
	public java.lang.Void setRect(java.lang.Integer parameter1, java.lang.Integer parameter2, java.awt.image.Raster parameter3) ;
	public java.lang.Void setRect(java.awt.image.Raster parameter1) ;
	public java.awt.image.WritableRaster getWritableParent() ;
	public java.awt.image.WritableRaster createWritableTranslatedChild(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.image.WritableRaster createWritableChild(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5, java.lang.Integer parameter6, java.lang.Integer[] parameter7) ;
	public java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.lang.Object parameter5) ;
	public java.lang.Void setDataElements(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Object parameter3) ;
	public WritableRaster(java.awt.image.SampleModel parameter1, java.awt.Point parameter2) ;
	public WritableRaster(java.awt.image.SampleModel parameter1, java.awt.image.DataBuffer parameter2, java.awt.Point parameter3) ;
	public WritableRaster(java.awt.image.SampleModel parameter1, java.awt.image.DataBuffer parameter2, java.awt.Rectangle parameter3, java.awt.Point parameter4, java.awt.image.WritableRaster parameter5) ;
}

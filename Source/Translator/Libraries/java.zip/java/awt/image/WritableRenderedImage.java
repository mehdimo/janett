package java.awt.image;

interface WritableRenderedImage implements java.awt.image.RenderedImage
{
	public abstract java.lang.Boolean hasTileWriters() ;
	public abstract java.lang.Void releaseWritableTile(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Boolean isTileWritable(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.awt.Point[] getWritableTileIndices() ;
	public abstract java.lang.Void setData(java.awt.image.Raster parameter1) ;
	public abstract java.lang.Void addTileObserver(java.awt.image.TileObserver parameter1) ;
	public abstract java.lang.Void removeTileObserver(java.awt.image.TileObserver parameter1) ;
	public abstract java.awt.image.WritableRaster getWritableTile(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
}

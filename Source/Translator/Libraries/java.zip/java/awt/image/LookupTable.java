package java.awt.image;

abstract class LookupTable
{
	public java.lang.Integer getNumComponents() ;
	public java.lang.Integer getOffset() ;
	public LookupTable(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer[] lookupPixel(java.lang.Integer[] parameter1, java.lang.Integer[] parameter2) ;
}

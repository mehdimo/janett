package java.awt.image;

interface ImageProducer
{
	public abstract java.lang.Void addConsumer(java.awt.image.ImageConsumer parameter1) ;
	public abstract java.lang.Void removeConsumer(java.awt.image.ImageConsumer parameter1) ;
	public abstract java.lang.Void requestTopDownLeftRightResend(java.awt.image.ImageConsumer parameter1) ;
	public abstract java.lang.Void startProduction(java.awt.image.ImageConsumer parameter1) ;
	public abstract java.lang.Boolean isConsumer(java.awt.image.ImageConsumer parameter1) ;
}

package java.awt;

abstract class TexturePaint implements java.awt.Paint
{
	public java.lang.Integer getTransparency() ;
	public java.awt.geom.Rectangle2D getAnchorRect() ;
	public java.awt.image.BufferedImage getImage() ;
	public java.awt.PaintContext createContext(java.awt.image.ColorModel parameter1, java.awt.Rectangle parameter2, java.awt.geom.Rectangle2D parameter3, java.awt.geom.AffineTransform parameter4, java.awt.RenderingHints parameter5) ;
}

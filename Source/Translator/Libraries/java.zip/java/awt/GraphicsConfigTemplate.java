package java.awt;

abstract class GraphicsConfigTemplate implements java.io.Serializable
{
	public abstract java.lang.Boolean isGraphicsConfigSupported(java.awt.GraphicsConfiguration parameter1) ;
	public abstract java.awt.GraphicsConfiguration getBestConfiguration(java.awt.GraphicsConfiguration[] parameter1) ;
	java.lang.Integer REQUIRED;
	java.lang.Integer PREFERRED;
	java.lang.Integer UNNECESSARY;
}

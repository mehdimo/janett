package java.awt;

abstract class ImageCapabilities implements java.lang.Cloneable
{
	public java.lang.Boolean isAccelerated() ;
	public java.lang.Boolean isTrueVolatile() ;
	public java.lang.Object clone() ;
}

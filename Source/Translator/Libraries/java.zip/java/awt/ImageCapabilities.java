package java.awt;

abstract class ImageCapabilities implements java.lang.Cloneable
{
	public java.lang.Boolean isAccelerated() ;
	public java.lang.Boolean isTrueVolatile() ;
	public ImageCapabilities(java.lang.Boolean parameter1) ;
	public java.lang.Object clone() ;
}

package java.awt.color;

abstract class ColorSpace implements java.io.Serializable
{
	public java.lang.Integer getNumComponents() ;
	public java.lang.Integer getType() ;
	public java.lang.Boolean isCS_sRGB() ;
	public java.lang.Float getMaxValue(java.lang.Integer parameter1) ;
	public java.lang.Float getMinValue(java.lang.Integer parameter1) ;
	public ColorSpace(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Float[] fromCIEXYZ(java.lang.Float[] parameter1) ;
	public abstract java.lang.Float[] fromRGB(java.lang.Float[] parameter1) ;
	public abstract java.lang.Float[] toCIEXYZ(java.lang.Float[] parameter1) ;
	public abstract java.lang.Float[] toRGB(java.lang.Float[] parameter1) ;
	public java.awt.color.ColorSpace getInstance(java.lang.Integer parameter1) ;
	public java.lang.String getName(java.lang.Integer parameter1) ;
	java.lang.Integer TYPE_XYZ;
	java.lang.Integer TYPE_Lab;
	java.lang.Integer TYPE_Luv;
	java.lang.Integer TYPE_YCbCr;
	java.lang.Integer TYPE_Yxy;
	java.lang.Integer TYPE_RGB;
	java.lang.Integer TYPE_GRAY;
	java.lang.Integer TYPE_HSV;
	java.lang.Integer TYPE_HLS;
	java.lang.Integer TYPE_CMYK;
	java.lang.Integer TYPE_CMY;
	java.lang.Integer TYPE_2CLR;
	java.lang.Integer TYPE_3CLR;
	java.lang.Integer TYPE_4CLR;
	java.lang.Integer TYPE_5CLR;
	java.lang.Integer TYPE_6CLR;
	java.lang.Integer TYPE_7CLR;
	java.lang.Integer TYPE_8CLR;
	java.lang.Integer TYPE_9CLR;
	java.lang.Integer TYPE_ACLR;
	java.lang.Integer TYPE_BCLR;
	java.lang.Integer TYPE_CCLR;
	java.lang.Integer TYPE_DCLR;
	java.lang.Integer TYPE_ECLR;
	java.lang.Integer TYPE_FCLR;
	java.lang.Integer CS_sRGB;
	java.lang.Integer CS_LINEAR_RGB;
	java.lang.Integer CS_CIEXYZ;
	java.lang.Integer CS_PYCC;
	java.lang.Integer CS_GRAY;
}

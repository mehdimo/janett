package java.awt.color;

abstract class ICC_ProfileRGB extends java.awt.color.ICC_Profile
{
	public java.lang.Float[] getMediaWhitePoint() ;
	public void getMatrix() ;
	public java.lang.Float getGamma(java.lang.Integer parameter1) ;
	public java.lang.Short[] getTRC(java.lang.Integer parameter1) ;
	java.lang.Integer REDCOMPONENT;
	java.lang.Integer GREENCOMPONENT;
	java.lang.Integer BLUECOMPONENT;
}

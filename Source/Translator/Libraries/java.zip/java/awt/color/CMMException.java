package java.awt.color;

abstract class CMMException extends java.lang.RuntimeException
{
}

package java.awt.color;

abstract class ICC_ProfileGray extends java.awt.color.ICC_Profile
{
	public java.lang.Float getGamma() ;
	public java.lang.Float[] getMediaWhitePoint() ;
	public java.lang.Short[] getTRC() ;
}

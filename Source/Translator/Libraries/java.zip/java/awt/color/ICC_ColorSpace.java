package java.awt.color;

abstract class ICC_ColorSpace extends java.awt.color.ColorSpace
{
	public java.lang.Float getMaxValue(java.lang.Integer parameter1) ;
	public java.lang.Float getMinValue(java.lang.Integer parameter1) ;
	public java.lang.Float[] fromCIEXYZ(java.lang.Float[] parameter1) ;
	public java.lang.Float[] fromRGB(java.lang.Float[] parameter1) ;
	public java.lang.Float[] toCIEXYZ(java.lang.Float[] parameter1) ;
	public java.lang.Float[] toRGB(java.lang.Float[] parameter1) ;
	public java.awt.color.ICC_Profile getProfile() ;
	public ICC_ColorSpace(java.awt.color.ICC_Profile parameter1) ;
}

package java.awt.color;

abstract class ProfileDataException extends java.lang.RuntimeException
{
}

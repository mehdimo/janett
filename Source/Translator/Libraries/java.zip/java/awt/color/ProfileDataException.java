package java.awt.color;

abstract class ProfileDataException extends java.lang.RuntimeException
{
	public ProfileDataException(java.lang.String parameter1) ;
}

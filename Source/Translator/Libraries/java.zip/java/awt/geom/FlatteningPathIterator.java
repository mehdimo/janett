package java.awt.geom;

abstract class FlatteningPathIterator implements java.awt.geom.PathIterator
{
	public java.lang.Double getFlatness() ;
	public java.lang.Integer getRecursionLimit() ;
	public java.lang.Integer getWindingRule() ;
	public java.lang.Void next() ;
	public java.lang.Boolean isDone() ;
	public java.lang.Integer currentSegment(java.lang.Double[] parameter1) ;
	public java.lang.Integer currentSegment(java.lang.Float[] parameter1) ;
}

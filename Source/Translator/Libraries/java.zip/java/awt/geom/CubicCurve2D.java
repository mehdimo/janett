package java.awt.geom;

abstract class CubicCurve2D implements java.awt.Shape, java.lang.Cloneable
{
	public abstract java.lang.Double getCtrlX1() ;
	public abstract java.lang.Double getCtrlX2() ;
	public abstract java.lang.Double getCtrlY1() ;
	public abstract java.lang.Double getCtrlY2() ;
	public java.lang.Double getFlatness() ;
	public java.lang.Double getFlatnessSq() ;
	public abstract java.lang.Double getX1() ;
	public abstract java.lang.Double getX2() ;
	public abstract java.lang.Double getY1() ;
	public abstract java.lang.Double getY2() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Double getFlatness(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
	public java.lang.Double getFlatnessSq(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
	public abstract java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
	public java.lang.Integer solveCubic(java.lang.Double[] parameter1) ;
	public java.lang.Double getFlatness(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Double getFlatnessSq(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setCurve(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void subdivide(java.lang.Double[] parameter1, java.lang.Integer parameter2, java.lang.Double[] parameter3, java.lang.Integer parameter4, java.lang.Double[] parameter5, java.lang.Integer parameter6) ;
	public java.lang.Integer solveCubic(java.lang.Double[] parameter1, java.lang.Double[] parameter2) ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Void setCurve(java.awt.geom.CubicCurve2D parameter1) ;
	public abstract java.awt.geom.Point2D getCtrlP1() ;
	public abstract java.awt.geom.Point2D getCtrlP2() ;
	public abstract java.awt.geom.Point2D getP1() ;
	public abstract java.awt.geom.Point2D getP2() ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.lang.Void setCurve(java.awt.geom.Point2D[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Void subdivide(java.awt.geom.CubicCurve2D parameter1, java.awt.geom.CubicCurve2D parameter2) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	public java.lang.Void subdivide(java.awt.geom.CubicCurve2D parameter1, java.awt.geom.CubicCurve2D parameter2, java.awt.geom.CubicCurve2D parameter3) ;
	public java.lang.Void setCurve(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2, java.awt.geom.Point2D parameter3, java.awt.geom.Point2D parameter4) ;
	abstract class Float extends java.awt.geom.CubicCurve2D
	{
		public java.lang.Double getCtrlX1() ;
		public java.lang.Double getCtrlX2() ;
		public java.lang.Double getCtrlY1() ;
		public java.lang.Double getCtrlY2() ;
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
		public java.lang.Void setCurve(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Float parameter6, java.lang.Float parameter7, java.lang.Float parameter8) ;
		public java.awt.geom.Point2D getCtrlP1() ;
		public java.awt.geom.Point2D getCtrlP2() ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Float x1;
		java.lang.Float y1;
		java.lang.Float ctrlx1;
		java.lang.Float ctrly1;
		java.lang.Float ctrlx2;
		java.lang.Float ctrly2;
		java.lang.Float x2;
		java.lang.Float y2;
	}
	abstract class Double extends java.awt.geom.CubicCurve2D
	{
		public java.lang.Double getCtrlX1() ;
		public java.lang.Double getCtrlX2() ;
		public java.lang.Double getCtrlY1() ;
		public java.lang.Double getCtrlY2() ;
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
		public java.awt.geom.Point2D getCtrlP1() ;
		public java.awt.geom.Point2D getCtrlP2() ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Double x1;
		java.lang.Double y1;
		java.lang.Double ctrlx1;
		java.lang.Double ctrly1;
		java.lang.Double ctrlx2;
		java.lang.Double ctrly2;
		java.lang.Double x2;
		java.lang.Double y2;
	}
}

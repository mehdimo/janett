package java.awt.geom;

abstract class Rectangle2D extends java.awt.geom.RectangularShape
{
	public java.lang.Integer hashCode() ;
	public abstract java.lang.Integer outcode(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void add(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setFrame(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public abstract java.lang.Void setRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersectsLine(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersectsLine(java.awt.geom.Line2D parameter1) ;
	public java.lang.Integer outcode(java.awt.geom.Point2D parameter1) ;
	public java.lang.Void add(java.awt.geom.Point2D parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	public java.lang.Void add(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Void setRect(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	public abstract java.awt.geom.Rectangle2D createIntersection(java.awt.geom.Rectangle2D parameter1) ;
	public abstract java.awt.geom.Rectangle2D createUnion(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Void intersect(java.awt.geom.Rectangle2D parameter1, java.awt.geom.Rectangle2D parameter2, java.awt.geom.Rectangle2D parameter3) ;
	public java.lang.Void union(java.awt.geom.Rectangle2D parameter1, java.awt.geom.Rectangle2D parameter2, java.awt.geom.Rectangle2D parameter3) ;
	java.lang.Integer OUT_LEFT;
	java.lang.Integer OUT_TOP;
	java.lang.Integer OUT_RIGHT;
	java.lang.Integer OUT_BOTTOM;
	abstract class Double extends java.awt.geom.Rectangle2D
	{
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public java.lang.Boolean isEmpty() ;
		public java.lang.Integer outcode(java.lang.Double parameter1, java.lang.Double parameter2) ;
		public java.lang.Void setRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		public java.lang.Void setRect(java.awt.geom.Rectangle2D parameter1) ;
		public java.lang.String toString() ;
		public java.awt.geom.Rectangle2D createIntersection(java.awt.geom.Rectangle2D parameter1) ;
		public java.awt.geom.Rectangle2D createUnion(java.awt.geom.Rectangle2D parameter1) ;
		java.lang.Double x;
		java.lang.Double y;
		java.lang.Double width;
		java.lang.Double height;
	}
	abstract class Float extends java.awt.geom.Rectangle2D
	{
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public java.lang.Boolean isEmpty() ;
		public java.lang.Integer outcode(java.lang.Double parameter1, java.lang.Double parameter2) ;
		public java.lang.Void setRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.lang.Void setRect(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		public java.lang.Void setRect(java.awt.geom.Rectangle2D parameter1) ;
		public java.lang.String toString() ;
		public java.awt.geom.Rectangle2D createIntersection(java.awt.geom.Rectangle2D parameter1) ;
		public java.awt.geom.Rectangle2D createUnion(java.awt.geom.Rectangle2D parameter1) ;
		java.lang.Float x;
		java.lang.Float y;
		java.lang.Float width;
		java.lang.Float height;
	}
}

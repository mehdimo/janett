package java.awt.geom;

abstract class Ellipse2D extends java.awt.geom.RectangularShape
{
	public Ellipse2D() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	abstract class Double extends java.awt.geom.Ellipse2D
	{
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public Double() ;
		public java.lang.Boolean isEmpty() ;
		public Double(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.lang.Void setFrame(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Double x;
		java.lang.Double y;
		java.lang.Double width;
		java.lang.Double height;
	}
	abstract class Float extends java.awt.geom.Ellipse2D
	{
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public Float() ;
		public java.lang.Boolean isEmpty() ;
		public java.lang.Void setFrame(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public Float(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
		public java.lang.Void setFrame(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Float x;
		java.lang.Float y;
		java.lang.Float width;
		java.lang.Float height;
	}
}

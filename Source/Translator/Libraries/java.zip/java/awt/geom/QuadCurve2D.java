package java.awt.geom;

abstract class QuadCurve2D implements java.awt.Shape, java.lang.Cloneable
{
	public abstract java.lang.Double getCtrlX() ;
	public abstract java.lang.Double getCtrlY() ;
	public java.lang.Double getFlatness() ;
	public java.lang.Double getFlatnessSq() ;
	public abstract java.lang.Double getX1() ;
	public abstract java.lang.Double getX2() ;
	public abstract java.lang.Double getY1() ;
	public abstract java.lang.Double getY2() ;
	public QuadCurve2D() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Double getFlatness(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Double getFlatnessSq(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public abstract java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Integer solveQuadratic(java.lang.Double[] parameter1) ;
	public java.lang.Double getFlatness(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Double getFlatnessSq(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setCurve(java.lang.Double[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void subdivide(java.lang.Double[] parameter1, java.lang.Integer parameter2, java.lang.Double[] parameter3, java.lang.Integer parameter4, java.lang.Double[] parameter5, java.lang.Integer parameter6) ;
	public java.lang.Integer solveQuadratic(java.lang.Double[] parameter1, java.lang.Double[] parameter2) ;
	public java.awt.Rectangle getBounds() ;
	public abstract java.awt.geom.Point2D getCtrlPt() ;
	public abstract java.awt.geom.Point2D getP1() ;
	public abstract java.awt.geom.Point2D getP2() ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.lang.Void setCurve(java.awt.geom.Point2D[] parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setCurve(java.awt.geom.QuadCurve2D parameter1) ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	public java.lang.Void subdivide(java.awt.geom.QuadCurve2D parameter1, java.awt.geom.QuadCurve2D parameter2) ;
	public java.lang.Void setCurve(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2, java.awt.geom.Point2D parameter3) ;
	public java.lang.Void subdivide(java.awt.geom.QuadCurve2D parameter1, java.awt.geom.QuadCurve2D parameter2, java.awt.geom.QuadCurve2D parameter3) ;
	abstract class Double extends java.awt.geom.QuadCurve2D
	{
		public java.lang.Double getCtrlX() ;
		public java.lang.Double getCtrlY() ;
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public Double() ;
		public Double(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
		public java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
		public java.awt.geom.Point2D getCtrlPt() ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Double x1;
		java.lang.Double y1;
		java.lang.Double ctrlx;
		java.lang.Double ctrly;
		java.lang.Double x2;
		java.lang.Double y2;
	}
	abstract class Float extends java.awt.geom.QuadCurve2D
	{
		public java.lang.Double getCtrlX() ;
		public java.lang.Double getCtrlY() ;
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public Float() ;
		public java.lang.Void setCurve(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
		public Float(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Float parameter6) ;
		public java.lang.Void setCurve(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Float parameter6) ;
		public java.awt.geom.Point2D getCtrlPt() ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Float x1;
		java.lang.Float y1;
		java.lang.Float ctrlx;
		java.lang.Float ctrly;
		java.lang.Float x2;
		java.lang.Float y2;
	}
}

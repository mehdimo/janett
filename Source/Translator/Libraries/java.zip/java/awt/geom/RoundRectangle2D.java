package java.awt.geom;

abstract class RoundRectangle2D extends java.awt.geom.RectangularShape
{
	public abstract java.lang.Double getArcHeight() ;
	public abstract java.lang.Double getArcWidth() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setFrame(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public abstract java.lang.Void setRoundRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Void setRoundRect(java.awt.geom.RoundRectangle2D parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	abstract class Double extends java.awt.geom.RoundRectangle2D
	{
		public java.lang.Double getArcHeight() ;
		public java.lang.Double getArcWidth() ;
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public java.lang.Boolean isEmpty() ;
		public java.lang.Void setRoundRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		public java.lang.Void setRoundRect(java.awt.geom.RoundRectangle2D parameter1) ;
		java.lang.Double x;
		java.lang.Double y;
		java.lang.Double width;
		java.lang.Double height;
		java.lang.Double arcwidth;
		java.lang.Double archeight;
	}
	abstract class Float extends java.awt.geom.RoundRectangle2D
	{
		public java.lang.Double getArcHeight() ;
		public java.lang.Double getArcWidth() ;
		public java.lang.Double getHeight() ;
		public java.lang.Double getWidth() ;
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public java.lang.Boolean isEmpty() ;
		public java.lang.Void setRoundRect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
		public java.lang.Void setRoundRect(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Float parameter6) ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		public java.lang.Void setRoundRect(java.awt.geom.RoundRectangle2D parameter1) ;
		java.lang.Float x;
		java.lang.Float y;
		java.lang.Float width;
		java.lang.Float height;
		java.lang.Float arcwidth;
		java.lang.Float archeight;
	}
}

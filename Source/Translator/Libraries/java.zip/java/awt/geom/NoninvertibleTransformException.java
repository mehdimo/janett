package java.awt.geom;

abstract class NoninvertibleTransformException extends java.lang.Exception
{
}

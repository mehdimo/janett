package java.awt.geom;

abstract class NoninvertibleTransformException extends java.lang.Exception
{
	public NoninvertibleTransformException(java.lang.String parameter1) ;
}

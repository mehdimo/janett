package java.awt.geom;

abstract class RectangularShape implements java.awt.Shape, java.lang.Cloneable
{
	public java.lang.Double getCenterX() ;
	public java.lang.Double getCenterY() ;
	public abstract java.lang.Double getHeight() ;
	public java.lang.Double getMaxX() ;
	public java.lang.Double getMaxY() ;
	public java.lang.Double getMinX() ;
	public java.lang.Double getMinY() ;
	public abstract java.lang.Double getWidth() ;
	public abstract java.lang.Double getX() ;
	public abstract java.lang.Double getY() ;
	public abstract java.lang.Boolean isEmpty() ;
	public abstract java.lang.Void setFrame(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void setFrameFromCenter(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void setFrameFromDiagonal(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.awt.geom.Rectangle2D getFrame() ;
	public java.lang.Void setFrame(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Void setFrame(java.awt.geom.Point2D parameter1, java.awt.geom.Dimension2D parameter2) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setFrameFromCenter(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2) ;
	public java.lang.Void setFrameFromDiagonal(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2) ;
}

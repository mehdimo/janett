package java.awt.geom;

abstract class Dimension2D implements java.lang.Cloneable
{
	public abstract java.lang.Double getHeight() ;
	public abstract java.lang.Double getWidth() ;
	public Dimension2D() ;
	public abstract java.lang.Void setSize(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setSize(java.awt.geom.Dimension2D parameter1) ;
	public java.lang.Object clone() ;
}

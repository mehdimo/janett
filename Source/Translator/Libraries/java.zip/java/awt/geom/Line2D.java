package java.awt.geom;

abstract class Line2D implements java.awt.Shape, java.lang.Cloneable
{
	public abstract java.lang.Double getX1() ;
	public abstract java.lang.Double getX2() ;
	public abstract java.lang.Double getY1() ;
	public abstract java.lang.Double getY2() ;
	public java.lang.Double ptLineDist(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double ptLineDistSq(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double ptSegDist(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double ptSegDistSq(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Integer relativeCCW(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void setLine(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersectsLine(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Double ptLineDist(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Double ptLineDistSq(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Double ptSegDist(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Double ptSegDistSq(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Integer relativeCCW(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6) ;
	public java.lang.Boolean linesIntersect(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4, java.lang.Double parameter5, java.lang.Double parameter6, java.lang.Double parameter7, java.lang.Double parameter8) ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Void setLine(java.awt.geom.Line2D parameter1) ;
	public java.lang.Boolean intersectsLine(java.awt.geom.Line2D parameter1) ;
	public abstract java.awt.geom.Point2D getP1() ;
	public abstract java.awt.geom.Point2D getP2() ;
	public java.lang.Double ptLineDist(java.awt.geom.Point2D parameter1) ;
	public java.lang.Double ptLineDistSq(java.awt.geom.Point2D parameter1) ;
	public java.lang.Double ptSegDist(java.awt.geom.Point2D parameter1) ;
	public java.lang.Double ptSegDistSq(java.awt.geom.Point2D parameter1) ;
	public java.lang.Integer relativeCCW(java.awt.geom.Point2D parameter1) ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setLine(java.awt.geom.Point2D parameter1, java.awt.geom.Point2D parameter2) ;
	abstract class Double extends java.awt.geom.Line2D
	{
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public java.lang.Void setLine(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Double x1;
		java.lang.Double y1;
		java.lang.Double x2;
		java.lang.Double y2;
	}
	abstract class Float extends java.awt.geom.Line2D
	{
		public java.lang.Double getX1() ;
		public java.lang.Double getX2() ;
		public java.lang.Double getY1() ;
		public java.lang.Double getY2() ;
		public java.lang.Void setLine(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
		public java.lang.Void setLine(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
		public java.awt.geom.Point2D getP1() ;
		public java.awt.geom.Point2D getP2() ;
		public java.awt.geom.Rectangle2D getBounds2D() ;
		java.lang.Float x1;
		java.lang.Float y1;
		java.lang.Float x2;
		java.lang.Float y2;
	}
}

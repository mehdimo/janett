package java.awt.geom;

interface PathIterator
{
	public abstract java.lang.Integer getWindingRule() ;
	public abstract java.lang.Void next() ;
	public abstract java.lang.Boolean isDone() ;
	public abstract java.lang.Integer currentSegment(java.lang.Double[] parameter1) ;
	public abstract java.lang.Integer currentSegment(java.lang.Float[] parameter1) ;
	java.lang.Integer WIND_EVEN_ODD;
	java.lang.Integer WIND_NON_ZERO;
	java.lang.Integer SEG_MOVETO;
	java.lang.Integer SEG_LINETO;
	java.lang.Integer SEG_QUADTO;
	java.lang.Integer SEG_CUBICTO;
	java.lang.Integer SEG_CLOSE;
}

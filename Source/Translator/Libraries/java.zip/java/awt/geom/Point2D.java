package java.awt.geom;

abstract class Point2D implements java.lang.Cloneable
{
	public abstract java.lang.Double getX() ;
	public abstract java.lang.Double getY() ;
	public java.lang.Integer hashCode() ;
	public Point2D() ;
	public java.lang.Double distance(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double distanceSq(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void setLocation(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double distance(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Double distanceSq(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Double distance(java.awt.geom.Point2D parameter1) ;
	public java.lang.Double distanceSq(java.awt.geom.Point2D parameter1) ;
	public java.lang.Void setLocation(java.awt.geom.Point2D parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	abstract class Double extends java.awt.geom.Point2D
	{
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public Double() ;
		public Double(java.lang.Double parameter1, java.lang.Double parameter2) ;
		public java.lang.Void setLocation(java.lang.Double parameter1, java.lang.Double parameter2) ;
		public java.lang.String toString() ;
		java.lang.Double x;
		java.lang.Double y;
	}
	abstract class Float extends java.awt.geom.Point2D
	{
		public java.lang.Double getX() ;
		public java.lang.Double getY() ;
		public Float() ;
		public java.lang.Void setLocation(java.lang.Double parameter1, java.lang.Double parameter2) ;
		public Float(java.lang.Float parameter1, java.lang.Float parameter2) ;
		public java.lang.Void setLocation(java.lang.Float parameter1, java.lang.Float parameter2) ;
		public java.lang.String toString() ;
		java.lang.Float x;
		java.lang.Float y;
	}
}

package java.awt.geom;

abstract class Area implements java.awt.Shape, java.lang.Cloneable
{
	public java.lang.Void reset() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Boolean isPolygonal() ;
	public java.lang.Boolean isRectangular() ;
	public java.lang.Boolean isSingular() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.awt.Rectangle getBounds() ;
	public java.lang.Void transform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void add(java.awt.geom.Area parameter1) ;
	public java.lang.Void exclusiveOr(java.awt.geom.Area parameter1) ;
	public java.lang.Void intersect(java.awt.geom.Area parameter1) ;
	public java.lang.Void subtract(java.awt.geom.Area parameter1) ;
	public java.lang.Boolean equals(java.awt.geom.Area parameter1) ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.awt.geom.Area createTransformedArea(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
}

package java.awt.geom;

abstract class IllegalPathStateException extends java.lang.RuntimeException
{
}

package java.awt.geom;

abstract class IllegalPathStateException extends java.lang.RuntimeException
{
	public IllegalPathStateException() ;
	public IllegalPathStateException(java.lang.String parameter1) ;
}

package java.awt.geom;

abstract class GeneralPath implements java.awt.Shape, java.lang.Cloneable
{
	public java.lang.Integer getWindingRule() ;
	public GeneralPath() ;
	public java.lang.Void closePath() ;
	public java.lang.Void reset() ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Boolean contains(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Boolean intersects(java.lang.Double parameter1, java.lang.Double parameter2, java.lang.Double parameter3, java.lang.Double parameter4) ;
	public java.lang.Void lineTo(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.lang.Void moveTo(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.lang.Void quadTo(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4) ;
	public java.lang.Void curveTo(java.lang.Float parameter1, java.lang.Float parameter2, java.lang.Float parameter3, java.lang.Float parameter4, java.lang.Float parameter5, java.lang.Float parameter6) ;
	public GeneralPath(java.lang.Integer parameter1) ;
	public java.lang.Void setWindingRule(java.lang.Integer parameter1) ;
	public GeneralPath(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.awt.Rectangle getBounds() ;
	public GeneralPath(java.awt.Shape parameter1) ;
	public java.lang.Void append(java.awt.Shape parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void transform(java.awt.geom.AffineTransform parameter1) ;
	public java.lang.Void append(java.awt.geom.PathIterator parameter1, java.lang.Boolean parameter2) ;
	public java.awt.geom.Point2D getCurrentPoint() ;
	public java.lang.Boolean contains(java.awt.geom.Point2D parameter1) ;
	public java.awt.geom.Rectangle2D getBounds2D() ;
	public java.lang.Boolean contains(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Boolean intersects(java.awt.geom.Rectangle2D parameter1) ;
	public java.lang.Object clone() ;
	public java.awt.Shape createTransformedShape(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1) ;
	public java.awt.geom.PathIterator getPathIterator(java.awt.geom.AffineTransform parameter1, java.lang.Double parameter2) ;
	java.lang.Integer WIND_EVEN_ODD;
	java.lang.Integer WIND_NON_ZERO;
}

package java.awt;

interface Transparency
{
	public abstract java.lang.Integer getTransparency() ;
	java.lang.Integer OPAQUE;
	java.lang.Integer BITMASK;
	java.lang.Integer TRANSLUCENT;
}

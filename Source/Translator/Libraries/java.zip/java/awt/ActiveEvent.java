package java.awt;

interface ActiveEvent
{
	public abstract java.lang.Void dispatch() ;
}

package java.awt;

abstract class ComponentOrientation implements java.io.Serializable
{
	public java.lang.Boolean isHorizontal() ;
	public java.lang.Boolean isLeftToRight() ;
	public java.awt.ComponentOrientation getOrientation(java.util.Locale parameter1) ;
	public java.awt.ComponentOrientation getOrientation(java.util.ResourceBundle parameter1) ;
	java.awt.ComponentOrientation LEFT_TO_RIGHT;
	java.awt.ComponentOrientation RIGHT_TO_LEFT;
	java.awt.ComponentOrientation UNKNOWN;
}

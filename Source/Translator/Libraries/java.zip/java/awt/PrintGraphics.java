package java.awt;

interface PrintGraphics
{
	public abstract java.awt.PrintJob getPrintJob() ;
}

package java.security;

abstract class KeyFactory
{
	public java.lang.String getAlgorithm() ;
	public java.security.Provider getProvider() ;
	public java.security.Key translateKey(java.security.Key parameter1) ;
	public java.security.KeyFactory getInstance(java.lang.String parameter1) ;
	public java.security.PrivateKey generatePrivate(java.security.spec.KeySpec parameter1) ;
	public java.security.PublicKey generatePublic(java.security.spec.KeySpec parameter1) ;
	public java.security.KeyFactory getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.KeyFactory getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
	public java.security.spec.KeySpec getKeySpec(java.security.Key parameter1, java.lang.Class parameter2) ;
}

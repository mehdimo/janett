package java.security;

abstract class Signer extends java.security.Identity
{
	public java.lang.String toString() ;
	public java.lang.Void setKeyPair(java.security.KeyPair parameter1) ;
	public java.security.PrivateKey getPrivateKey() ;
}

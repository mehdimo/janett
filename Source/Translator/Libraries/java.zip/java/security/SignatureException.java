package java.security;

abstract class SignatureException extends java.security.GeneralSecurityException
{
}

package java.security;

abstract class DigestOutputStream extends java.io.FilterOutputStream
{
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void on(java.lang.Boolean parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.String toString() ;
	public java.security.MessageDigest getMessageDigest() ;
	public java.lang.Void setMessageDigest(java.security.MessageDigest parameter1) ;
}

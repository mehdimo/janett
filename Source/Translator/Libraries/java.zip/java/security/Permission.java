package java.security;

abstract class Permission implements java.security.Guard, java.io.Serializable
{
	public abstract java.lang.Integer hashCode() ;
	public java.lang.Void checkGuard(java.lang.Object parameter1) ;
	public abstract java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String getActions() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public abstract java.lang.Boolean implies(java.security.Permission parameter1) ;
	public java.security.PermissionCollection newPermissionCollection() ;
}

package java.security;

abstract class AlgorithmParameterGeneratorSpi
{
	public abstract java.security.AlgorithmParameters engineGenerateParameters() ;
	public abstract java.lang.Void engineInit(java.lang.Integer parameter1, java.security.SecureRandom parameter2) ;
	public abstract java.lang.Void engineInit(java.security.spec.AlgorithmParameterSpec parameter1, java.security.SecureRandom parameter2) ;
}

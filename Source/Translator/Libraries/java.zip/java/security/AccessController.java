package java.security;

abstract class AccessController
{
	public java.security.AccessControlContext getContext() ;
	public java.lang.Void checkPermission(java.security.Permission parameter1) ;
	public java.lang.Object doPrivileged(java.security.PrivilegedAction parameter1) ;
	public java.lang.Object doPrivileged(java.security.PrivilegedExceptionAction parameter1) ;
	public java.lang.Object doPrivileged(java.security.PrivilegedAction parameter1, java.security.AccessControlContext parameter2) ;
	public java.lang.Object doPrivileged(java.security.PrivilegedExceptionAction parameter1, java.security.AccessControlContext parameter2) ;
}

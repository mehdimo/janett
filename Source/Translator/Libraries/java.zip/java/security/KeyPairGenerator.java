package java.security;

abstract class KeyPairGenerator extends java.security.KeyPairGeneratorSpi
{
	public java.lang.Void initialize(java.lang.Integer parameter1) ;
	public java.lang.String getAlgorithm() ;
	public java.security.KeyPair genKeyPair() ;
	public java.security.KeyPair generateKeyPair() ;
	public java.security.Provider getProvider() ;
	public java.lang.Void initialize(java.lang.Integer parameter1, java.security.SecureRandom parameter2) ;
	public java.lang.Void initialize(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public java.security.KeyPairGenerator getInstance(java.lang.String parameter1) ;
	public java.lang.Void initialize(java.security.spec.AlgorithmParameterSpec parameter1, java.security.SecureRandom parameter2) ;
	public java.security.KeyPairGenerator getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.KeyPairGenerator getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

package java.security;

abstract class Policy
{
	public abstract java.lang.Void refresh() ;
	public java.security.Policy getPolicy() ;
	public java.lang.Void setPolicy(java.security.Policy parameter1) ;
	public java.lang.Boolean implies(java.security.ProtectionDomain parameter1, java.security.Permission parameter2) ;
	public abstract java.security.PermissionCollection getPermissions(java.security.CodeSource parameter1) ;
	public java.security.PermissionCollection getPermissions(java.security.ProtectionDomain parameter1) ;
}

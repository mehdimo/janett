package java.security;

abstract class IdentityScope extends java.security.Identity
{
	public abstract java.lang.Integer size() ;
	public java.lang.String toString() ;
	public abstract java.lang.Void addIdentity(java.security.Identity parameter1) ;
	public abstract java.lang.Void removeIdentity(java.security.Identity parameter1) ;
	public java.security.IdentityScope getSystemScope() ;
	public java.lang.Void setSystemScope(java.security.IdentityScope parameter1) ;
	public abstract java.util.Enumeration identities() ;
	public abstract java.security.Identity getIdentity(java.lang.String parameter1) ;
	public java.security.Identity getIdentity(java.security.Principal parameter1) ;
	public abstract java.security.Identity getIdentity(java.security.PublicKey parameter1) ;
}

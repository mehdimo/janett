package java.security.cert;

abstract class CertPathValidator
{
	public java.lang.String getAlgorithm() ;
	public java.lang.String getDefaultType() ;
	public java.security.Provider getProvider() ;
	public java.security.cert.CertPathValidator getInstance(java.lang.String parameter1) ;
	public java.security.cert.CertPathValidator getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.cert.CertPathValidator getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
	public java.security.cert.CertPathValidatorResult validate(java.security.cert.CertPath parameter1, java.security.cert.CertPathParameters parameter2) ;
}

package java.security.cert;

abstract class PKIXParameters implements java.security.cert.CertPathParameters
{
	public java.lang.Boolean getPolicyQualifiersRejected() ;
	public java.lang.Boolean isAnyPolicyInhibited() ;
	public java.lang.Boolean isExplicitPolicyRequired() ;
	public java.lang.Boolean isPolicyMappingInhibited() ;
	public java.lang.Boolean isRevocationEnabled() ;
	public java.lang.Void setAnyPolicyInhibited(java.lang.Boolean parameter1) ;
	public java.lang.Void setExplicitPolicyRequired(java.lang.Boolean parameter1) ;
	public java.lang.Void setPolicyMappingInhibited(java.lang.Boolean parameter1) ;
	public java.lang.Void setPolicyQualifiersRejected(java.lang.Boolean parameter1) ;
	public java.lang.Void setRevocationEnabled(java.lang.Boolean parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.String getSigProvider() ;
	public java.lang.String toString() ;
	public java.lang.Void setSigProvider(java.lang.String parameter1) ;
	public java.security.cert.CertSelector getTargetCertConstraints() ;
	public java.lang.Void setTargetCertConstraints(java.security.cert.CertSelector parameter1) ;
	public java.lang.Void addCertStore(java.security.cert.CertStore parameter1) ;
	public java.lang.Void addCertPathChecker(java.security.cert.PKIXCertPathChecker parameter1) ;
	public java.util.Date getDate() ;
	public java.lang.Void setDate(java.util.Date parameter1) ;
	public java.util.List getCertPathCheckers() ;
	public java.util.List getCertStores() ;
	public java.lang.Void setCertPathCheckers(java.util.List parameter1) ;
	public java.lang.Void setCertStores(java.util.List parameter1) ;
	public java.util.Set getInitialPolicies() ;
	public java.util.Set getTrustAnchors() ;
	public java.lang.Void setInitialPolicies(java.util.Set parameter1) ;
	public java.lang.Void setTrustAnchors(java.util.Set parameter1) ;
}

package java.security.cert;

abstract class TrustAnchor
{
	public java.lang.Byte[] getNameConstraints() ;
	public java.lang.String getCAName() ;
	public java.lang.String toString() ;
	public java.security.PublicKey getCAPublicKey() ;
	public java.security.cert.X509Certificate getTrustedCert() ;
}

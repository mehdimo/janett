package java.security.cert;

abstract class PolicyQualifierInfo
{
	public java.lang.Byte[] getEncoded() ;
	public java.lang.Byte[] getPolicyQualifier() ;
	public java.lang.String getPolicyQualifierId() ;
	public java.lang.String toString() ;
}

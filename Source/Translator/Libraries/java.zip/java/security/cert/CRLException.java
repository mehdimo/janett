package java.security.cert;

abstract class CRLException extends java.security.GeneralSecurityException
{
}

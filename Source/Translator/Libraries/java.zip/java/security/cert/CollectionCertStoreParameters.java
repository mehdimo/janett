package java.security.cert;

abstract class CollectionCertStoreParameters implements java.security.cert.CertStoreParameters
{
	public java.lang.Object clone() ;
	public java.lang.String toString() ;
	public java.util.Collection getCollection() ;
}

package java.security.cert;

abstract class CertificateException extends java.security.GeneralSecurityException
{
}

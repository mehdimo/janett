package java.security.cert;

abstract class X509CRLSelector implements java.security.cert.CRLSelector
{
	public java.lang.Void addIssuerName(java.lang.Byte[] parameter1) ;
	public java.lang.Object clone() ;
	public java.lang.String toString() ;
	public java.lang.Void addIssuerName(java.lang.String parameter1) ;
	public java.math.BigInteger getMaxCRL() ;
	public java.math.BigInteger getMinCRL() ;
	public java.lang.Void setMaxCRLNumber(java.math.BigInteger parameter1) ;
	public java.lang.Void setMinCRLNumber(java.math.BigInteger parameter1) ;
	public java.lang.Boolean match(java.security.cert.CRL parameter1) ;
	public java.security.cert.X509Certificate getCertificateChecking() ;
	public java.lang.Void setCertificateChecking(java.security.cert.X509Certificate parameter1) ;
	public java.util.Collection getIssuerNames() ;
	public java.lang.Void setIssuerNames(java.util.Collection parameter1) ;
	public java.util.Date getDateAndTime() ;
	public java.lang.Void setDateAndTime(java.util.Date parameter1) ;
}

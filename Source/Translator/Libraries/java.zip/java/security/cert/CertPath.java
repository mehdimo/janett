package java.security.cert;

abstract class CertPath implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public abstract java.lang.Byte[] getEncoded() ;
	public java.lang.Object writeReplace() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getType() ;
	public java.lang.String toString() ;
	public abstract java.lang.Byte[] getEncoded(java.lang.String parameter1) ;
	public abstract java.util.Iterator getEncodings() ;
	public abstract java.util.List getCertificates() ;
	abstract class CertPathRep implements java.io.Serializable
	{
		public java.lang.Object readResolve() ;
	}
}

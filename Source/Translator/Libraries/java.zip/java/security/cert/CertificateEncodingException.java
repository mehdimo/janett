package java.security.cert;

abstract class CertificateEncodingException extends java.security.cert.CertificateException
{
}

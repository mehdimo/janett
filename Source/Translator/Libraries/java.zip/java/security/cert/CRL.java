package java.security.cert;

abstract class CRL
{
	public java.lang.String getType() ;
	public abstract java.lang.String toString() ;
	public abstract java.lang.Boolean isRevoked(java.security.cert.Certificate parameter1) ;
}

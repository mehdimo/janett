package java.security.cert;

interface CertPathBuilderResult implements java.lang.Cloneable
{
	public abstract java.lang.Object clone() ;
	public abstract java.security.cert.CertPath getCertPath() ;
}

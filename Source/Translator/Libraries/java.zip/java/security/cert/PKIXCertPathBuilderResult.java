package java.security.cert;

abstract class PKIXCertPathBuilderResult extends java.security.cert.PKIXCertPathValidatorResult implements java.security.cert.CertPathBuilderResult
{
	public java.lang.String toString() ;
	public java.security.cert.CertPath getCertPath() ;
}

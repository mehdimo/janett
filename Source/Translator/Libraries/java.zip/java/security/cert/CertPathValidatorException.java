package java.security.cert;

abstract class CertPathValidatorException extends java.security.GeneralSecurityException
{
	public java.lang.Integer getIndex() ;
	public java.lang.Void printStackTrace() ;
	public java.lang.Void printStackTrace(java.io.PrintStream parameter1) ;
	public java.lang.Void printStackTrace(java.io.PrintWriter parameter1) ;
	public java.lang.String getMessage() ;
	public java.lang.String toString() ;
	public java.lang.Throwable getCause() ;
	public java.security.cert.CertPath getCertPath() ;
}

package java.security.cert;

interface CRLSelector implements java.lang.Cloneable
{
	public abstract java.lang.Object clone() ;
	public abstract java.lang.Boolean match(java.security.cert.CRL parameter1) ;
}

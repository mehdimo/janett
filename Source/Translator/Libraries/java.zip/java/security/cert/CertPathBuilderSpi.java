package java.security.cert;

abstract class CertPathBuilderSpi
{
	public abstract java.security.cert.CertPathBuilderResult engineBuild(java.security.cert.CertPathParameters parameter1) ;
}

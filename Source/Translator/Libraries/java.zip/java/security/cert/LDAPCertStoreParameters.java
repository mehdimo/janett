package java.security.cert;

abstract class LDAPCertStoreParameters implements java.security.cert.CertStoreParameters
{
	public java.lang.Integer getPort() ;
	public java.lang.Object clone() ;
	public java.lang.String getServerName() ;
	public java.lang.String toString() ;
}

package java.security.cert;

abstract class CertificateNotYetValidException extends java.security.cert.CertificateException
{
}

package java.security.cert;

abstract class CertificateParsingException extends java.security.cert.CertificateException
{
}

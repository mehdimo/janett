package java.security.cert;

abstract class X509Certificate extends java.security.cert.Certificate implements java.security.cert.X509Extension
{
	public abstract java.lang.Integer getBasicConstraints() ;
	public abstract java.lang.Integer getVersion() ;
	public abstract java.lang.Void checkValidity() ;
	public abstract java.lang.Byte[] getSigAlgParams() ;
	public abstract java.lang.Byte[] getSignature() ;
	public abstract java.lang.Byte[] getTBSCertificate() ;
	public abstract java.lang.Boolean[] getIssuerUniqueID() ;
	public abstract java.lang.Boolean[] getKeyUsage() ;
	public abstract java.lang.Boolean[] getSubjectUniqueID() ;
	public abstract java.lang.String getSigAlgName() ;
	public abstract java.lang.String getSigAlgOID() ;
	public abstract java.math.BigInteger getSerialNumber() ;
	public abstract java.security.Principal getIssuerDN() ;
	public abstract java.security.Principal getSubjectDN() ;
	public java.util.Collection getIssuerAlternativeNames() ;
	public java.util.Collection getSubjectAlternativeNames() ;
	public abstract java.util.Date getNotAfter() ;
	public abstract java.util.Date getNotBefore() ;
	public abstract java.lang.Void checkValidity(java.util.Date parameter1) ;
	public java.util.List getExtendedKeyUsage() ;
	public javax.security.auth.x500.X500Principal getIssuerX500Principal() ;
	public javax.security.auth.x500.X500Principal getSubjectX500Principal() ;
}

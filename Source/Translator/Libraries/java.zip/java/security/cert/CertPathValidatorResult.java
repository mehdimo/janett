package java.security.cert;

interface CertPathValidatorResult implements java.lang.Cloneable
{
	public abstract java.lang.Object clone() ;
}

package java.security.cert;

abstract class CertificateFactory
{
	public java.lang.String getType() ;
	public java.security.Provider getProvider() ;
	public java.util.Iterator getCertPathEncodings() ;
	public java.security.cert.CRL generateCRL(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath generateCertPath(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath generateCertPath(java.util.List parameter1) ;
	public java.security.cert.Certificate generateCertificate(java.io.InputStream parameter1) ;
	public java.security.cert.CertificateFactory getInstance(java.lang.String parameter1) ;
	public java.util.Collection generateCRLs(java.io.InputStream parameter1) ;
	public java.util.Collection generateCertificates(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath generateCertPath(java.io.InputStream parameter1, java.lang.String parameter2) ;
	public java.security.cert.CertificateFactory getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.cert.CertificateFactory getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

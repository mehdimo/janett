package java.security.cert;

abstract class X509CRLEntry implements java.security.cert.X509Extension
{
	public java.lang.Integer hashCode() ;
	public abstract java.lang.Boolean hasExtensions() ;
	public abstract java.lang.Byte[] getEncoded() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String toString() ;
	public abstract java.math.BigInteger getSerialNumber() ;
	public abstract java.util.Date getRevocationDate() ;
}

package java.security.cert;

abstract class CertificateExpiredException extends java.security.cert.CertificateException
{
}

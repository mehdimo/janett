package java.security.cert;

interface CertSelector implements java.lang.Cloneable
{
	public abstract java.lang.Object clone() ;
	public abstract java.lang.Boolean match(java.security.cert.Certificate parameter1) ;
}

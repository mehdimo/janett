package java.security.cert;

interface CertStoreParameters implements java.lang.Cloneable
{
	public abstract java.lang.Object clone() ;
}

package java.security.cert;

abstract class PKIXCertPathChecker implements java.lang.Cloneable
{
	public abstract java.lang.Boolean isForwardCheckingSupported() ;
	public abstract java.lang.Void init(java.lang.Boolean parameter1) ;
	public java.lang.Object clone() ;
	public abstract java.util.Set getSupportedExtensions() ;
	public abstract java.lang.Void check(java.security.cert.Certificate parameter1, java.util.Collection parameter2) ;
}

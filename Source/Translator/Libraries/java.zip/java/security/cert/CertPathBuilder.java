package java.security.cert;

abstract class CertPathBuilder
{
	public java.lang.String getAlgorithm() ;
	public java.lang.String getDefaultType() ;
	public java.security.Provider getProvider() ;
	public java.security.cert.CertPathBuilder getInstance(java.lang.String parameter1) ;
	public java.security.cert.CertPathBuilderResult build(java.security.cert.CertPathParameters parameter1) ;
	public java.security.cert.CertPathBuilder getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.cert.CertPathBuilder getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

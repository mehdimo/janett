package java.security.cert;

abstract class X509CRL extends java.security.cert.CRL implements java.security.cert.X509Extension
{
	public abstract java.lang.Integer getVersion() ;
	public java.lang.Integer hashCode() ;
	public abstract java.lang.Byte[] getEncoded() ;
	public abstract java.lang.Byte[] getSigAlgParams() ;
	public abstract java.lang.Byte[] getSignature() ;
	public abstract java.lang.Byte[] getTBSCertList() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String getSigAlgName() ;
	public abstract java.lang.String getSigAlgOID() ;
	public abstract java.security.Principal getIssuerDN() ;
	public abstract java.lang.Void verify(java.security.PublicKey parameter1) ;
	public abstract java.util.Date getNextUpdate() ;
	public abstract java.util.Date getThisUpdate() ;
	public abstract java.util.Set getRevokedCertificates() ;
	public javax.security.auth.x500.X500Principal getIssuerX500Principal() ;
	public abstract java.lang.Void verify(java.security.PublicKey parameter1, java.lang.String parameter2) ;
	public abstract java.security.cert.X509CRLEntry getRevokedCertificate(java.math.BigInteger parameter1) ;
}

package java.security.cert;

abstract class PKIXBuilderParameters extends java.security.cert.PKIXParameters
{
	public java.lang.Integer getMaxPathLength() ;
	public java.lang.Void setMaxPathLength(java.lang.Integer parameter1) ;
	public java.lang.String toString() ;
}

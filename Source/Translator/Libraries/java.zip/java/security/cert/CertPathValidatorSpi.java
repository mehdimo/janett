package java.security.cert;

abstract class CertPathValidatorSpi
{
	public abstract java.security.cert.CertPathValidatorResult engineValidate(java.security.cert.CertPath parameter1, java.security.cert.CertPathParameters parameter2) ;
}

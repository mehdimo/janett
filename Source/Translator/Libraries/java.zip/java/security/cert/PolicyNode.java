package java.security.cert;

interface PolicyNode
{
	public abstract java.lang.Integer getDepth() ;
	public abstract java.lang.Boolean isCritical() ;
	public abstract java.lang.String getValidPolicy() ;
	public abstract java.security.cert.PolicyNode getParent() ;
	public abstract java.util.Iterator getChildren() ;
	public abstract java.util.Set getExpectedPolicies() ;
	public abstract java.util.Set getPolicyQualifiers() ;
}

package java.security.cert;

interface X509Extension
{
	public abstract java.lang.Boolean hasUnsupportedCriticalExtension() ;
	public abstract java.lang.Byte[] getExtensionValue(java.lang.String parameter1) ;
	public abstract java.util.Set getCriticalExtensionOIDs() ;
	public abstract java.util.Set getNonCriticalExtensionOIDs() ;
}

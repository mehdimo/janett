package java.security.cert;

abstract class CertStoreSpi
{
	public abstract java.util.Collection engineGetCRLs(java.security.cert.CRLSelector parameter1) ;
	public abstract java.util.Collection engineGetCertificates(java.security.cert.CertSelector parameter1) ;
}

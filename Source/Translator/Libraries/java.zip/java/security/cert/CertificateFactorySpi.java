package java.security.cert;

abstract class CertificateFactorySpi
{
	public java.util.Iterator engineGetCertPathEncodings() ;
	public abstract java.security.cert.CRL engineGenerateCRL(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath engineGenerateCertPath(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath engineGenerateCertPath(java.util.List parameter1) ;
	public abstract java.security.cert.Certificate engineGenerateCertificate(java.io.InputStream parameter1) ;
	public abstract java.util.Collection engineGenerateCRLs(java.io.InputStream parameter1) ;
	public abstract java.util.Collection engineGenerateCertificates(java.io.InputStream parameter1) ;
	public java.security.cert.CertPath engineGenerateCertPath(java.io.InputStream parameter1, java.lang.String parameter2) ;
}

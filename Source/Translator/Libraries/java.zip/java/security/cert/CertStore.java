package java.security.cert;

abstract class CertStore
{
	public java.lang.String getDefaultType() ;
	public java.lang.String getType() ;
	public java.security.Provider getProvider() ;
	public java.security.cert.CertStoreParameters getCertStoreParameters() ;
	public java.util.Collection getCRLs(java.security.cert.CRLSelector parameter1) ;
	public java.util.Collection getCertificates(java.security.cert.CertSelector parameter1) ;
	public java.security.cert.CertStore getInstance(java.lang.String parameter1, java.security.cert.CertStoreParameters parameter2) ;
	public java.security.cert.CertStore getInstance(java.lang.String parameter1, java.security.cert.CertStoreParameters parameter2, java.lang.String parameter3) ;
	public java.security.cert.CertStore getInstance(java.lang.String parameter1, java.security.cert.CertStoreParameters parameter2, java.security.Provider parameter3) ;
}

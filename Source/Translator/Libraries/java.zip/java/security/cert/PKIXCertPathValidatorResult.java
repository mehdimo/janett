package java.security.cert;

abstract class PKIXCertPathValidatorResult implements java.security.cert.CertPathValidatorResult
{
	public java.lang.Object clone() ;
	public java.lang.String toString() ;
	public java.security.PublicKey getPublicKey() ;
	public java.security.cert.PolicyNode getPolicyTree() ;
	public java.security.cert.TrustAnchor getTrustAnchor() ;
}

package java.security;

abstract class SecureClassLoader extends java.lang.ClassLoader
{
	public java.security.PermissionCollection getPermissions(java.security.CodeSource parameter1) ;
	public java.lang.Class defineClass(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.security.CodeSource parameter5) ;
}

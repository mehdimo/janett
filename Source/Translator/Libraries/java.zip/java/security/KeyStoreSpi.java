package java.security;

abstract class KeyStoreSpi
{
	public abstract java.lang.Integer engineSize() ;
	public abstract java.lang.Void engineLoad(java.io.InputStream parameter1, java.lang.Character[] parameter2) ;
	public abstract java.lang.Void engineStore(java.io.OutputStream parameter1, java.lang.Character[] parameter2) ;
	public abstract java.lang.Void engineDeleteEntry(java.lang.String parameter1) ;
	public abstract java.lang.Boolean engineContainsAlias(java.lang.String parameter1) ;
	public abstract java.lang.Boolean engineIsCertificateEntry(java.lang.String parameter1) ;
	public abstract java.lang.Boolean engineIsKeyEntry(java.lang.String parameter1) ;
	public abstract java.util.Enumeration engineAliases() ;
	public abstract java.lang.String engineGetCertificateAlias(java.security.cert.Certificate parameter1) ;
	public abstract java.security.Key engineGetKey(java.lang.String parameter1, java.lang.Character[] parameter2) ;
	public abstract java.security.cert.Certificate engineGetCertificate(java.lang.String parameter1) ;
	public abstract java.security.cert.Certificate[] engineGetCertificateChain(java.lang.String parameter1) ;
	public abstract java.lang.Void engineSetCertificateEntry(java.lang.String parameter1, java.security.cert.Certificate parameter2) ;
	public abstract java.lang.Void engineSetKeyEntry(java.lang.String parameter1, java.lang.Byte[] parameter2, java.security.cert.Certificate[] parameter3) ;
	public abstract java.util.Date engineGetCreationDate(java.lang.String parameter1) ;
	public abstract java.lang.Void engineSetKeyEntry(java.lang.String parameter1, java.security.Key parameter2, java.lang.Character[] parameter3, java.security.cert.Certificate[] parameter4) ;
}

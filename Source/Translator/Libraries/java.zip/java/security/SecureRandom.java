package java.security;

abstract class SecureRandom extends java.util.Random
{
	public java.lang.Integer next(java.lang.Integer parameter1) ;
	public java.lang.Byte[] generateSeed(java.lang.Integer parameter1) ;
	public java.lang.Byte[] getSeed(java.lang.Integer parameter1) ;
	public java.lang.Void setSeed(java.lang.Long parameter1) ;
	public java.lang.Void nextBytes(java.lang.Byte[] parameter1) ;
	public java.lang.Void setSeed(java.lang.Byte[] parameter1) ;
	public java.security.Provider getProvider() ;
	public java.security.SecureRandom getInstance(java.lang.String parameter1) ;
	public java.security.SecureRandom getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.SecureRandom getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

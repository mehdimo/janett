package java.security;

interface PublicKey implements java.security.Key
{
	java.lang.Long serialVersionUID;
}

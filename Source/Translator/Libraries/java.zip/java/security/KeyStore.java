package java.security;

abstract class KeyStore
{
	public java.lang.Integer size() ;
	public java.lang.Void load(java.io.InputStream parameter1, java.lang.Character[] parameter2) ;
	public java.lang.Void store(java.io.OutputStream parameter1, java.lang.Character[] parameter2) ;
	public java.lang.String getDefaultType() ;
	public java.lang.String getType() ;
	public java.lang.Void deleteEntry(java.lang.String parameter1) ;
	public java.lang.Boolean containsAlias(java.lang.String parameter1) ;
	public java.lang.Boolean isCertificateEntry(java.lang.String parameter1) ;
	public java.lang.Boolean isKeyEntry(java.lang.String parameter1) ;
	public java.security.Provider getProvider() ;
	public java.util.Enumeration aliases() ;
	public java.lang.String getCertificateAlias(java.security.cert.Certificate parameter1) ;
	public java.security.Key getKey(java.lang.String parameter1, java.lang.Character[] parameter2) ;
	public java.security.KeyStore getInstance(java.lang.String parameter1) ;
	public java.security.cert.Certificate getCertificate(java.lang.String parameter1) ;
	public java.security.cert.Certificate[] getCertificateChain(java.lang.String parameter1) ;
	public java.lang.Void setCertificateEntry(java.lang.String parameter1, java.security.cert.Certificate parameter2) ;
	public java.lang.Void setKeyEntry(java.lang.String parameter1, java.lang.Byte[] parameter2, java.security.cert.Certificate[] parameter3) ;
	public java.util.Date getCreationDate(java.lang.String parameter1) ;
	public java.security.KeyStore getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.KeyStore getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
	public java.lang.Void setKeyEntry(java.lang.String parameter1, java.security.Key parameter2, java.lang.Character[] parameter3, java.security.cert.Certificate[] parameter4) ;
}

package java.security;

abstract class InvalidKeyException extends java.security.KeyException
{
}

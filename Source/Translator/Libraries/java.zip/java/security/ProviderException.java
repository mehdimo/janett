package java.security;

abstract class ProviderException extends java.lang.RuntimeException
{
}

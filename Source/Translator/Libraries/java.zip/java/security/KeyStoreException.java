package java.security;

abstract class KeyStoreException extends java.security.GeneralSecurityException
{
}

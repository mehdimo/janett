package java.security;

interface Key implements java.io.Serializable
{
	public abstract java.lang.Byte[] getEncoded() ;
	public abstract java.lang.String getAlgorithm() ;
	public abstract java.lang.String getFormat() ;
	java.lang.Long serialVersionUID;
}

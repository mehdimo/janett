package java.security;

abstract class SecureRandomSpi implements java.io.Serializable
{
	public abstract java.lang.Byte[] engineGenerateSeed(java.lang.Integer parameter1) ;
	public abstract java.lang.Void engineNextBytes(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void engineSetSeed(java.lang.Byte[] parameter1) ;
}

package java.security;

abstract class AccessControlContext
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.security.DomainCombiner getDomainCombiner() ;
	public java.lang.Void checkPermission(java.security.Permission parameter1) ;
}

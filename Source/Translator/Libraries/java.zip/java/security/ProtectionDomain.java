package java.security;

abstract class ProtectionDomain
{
	public java.lang.ClassLoader getClassLoader() ;
	public java.lang.String toString() ;
	public java.security.CodeSource getCodeSource() ;
	public java.lang.Boolean implies(java.security.Permission parameter1) ;
	public java.security.PermissionCollection getPermissions() ;
	public java.security.Principal[] getPrincipals() ;
}

package java.security;

abstract class AlgorithmParameters
{
	public java.lang.Byte[] getEncoded() ;
	public java.lang.Void init(java.lang.Byte[] parameter1) ;
	public java.lang.String getAlgorithm() ;
	public java.lang.String toString() ;
	public java.lang.Byte[] getEncoded(java.lang.String parameter1) ;
	public java.lang.Void init(java.lang.Byte[] parameter1, java.lang.String parameter2) ;
	public java.security.Provider getProvider() ;
	public java.lang.Void init(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public java.security.AlgorithmParameters getInstance(java.lang.String parameter1) ;
	public java.security.spec.AlgorithmParameterSpec getParameterSpec(java.lang.Class parameter1) ;
	public java.security.AlgorithmParameters getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.AlgorithmParameters getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

package java.security;

abstract class GeneralSecurityException extends java.lang.Exception
{
}

package java.security;

abstract class SignedObject implements java.io.Serializable
{
	public java.lang.Byte[] getSignature() ;
	public java.lang.Object getObject() ;
	public java.lang.String getAlgorithm() ;
	public java.lang.Boolean verify(java.security.PublicKey parameter1, java.security.Signature parameter2) ;
}

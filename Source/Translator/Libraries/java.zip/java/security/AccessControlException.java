package java.security;

abstract class AccessControlException extends java.lang.SecurityException
{
	public java.security.Permission getPermission() ;
}

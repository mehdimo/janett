package java.security;

abstract class Permissions extends java.security.PermissionCollection implements java.io.Serializable
{
	public java.lang.Void add(java.security.Permission parameter1) ;
	public java.lang.Boolean implies(java.security.Permission parameter1) ;
	public java.util.Enumeration elements() ;
}

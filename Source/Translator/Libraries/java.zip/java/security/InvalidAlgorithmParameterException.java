package java.security;

abstract class InvalidAlgorithmParameterException extends java.security.GeneralSecurityException
{
}

package java.security;

abstract class KeyFactorySpi
{
	public abstract java.security.Key engineTranslateKey(java.security.Key parameter1) ;
	public abstract java.security.PrivateKey engineGeneratePrivate(java.security.spec.KeySpec parameter1) ;
	public abstract java.security.PublicKey engineGeneratePublic(java.security.spec.KeySpec parameter1) ;
	public abstract java.security.spec.KeySpec engineGetKeySpec(java.security.Key parameter1, java.lang.Class parameter2) ;
}

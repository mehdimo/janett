package java.security.spec;

abstract class X509EncodedKeySpec extends java.security.spec.EncodedKeySpec
{
	public java.lang.Byte[] getEncoded() ;
	public java.lang.String getFormat() ;
}

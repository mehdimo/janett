package java.security.spec;

abstract class InvalidParameterSpecException extends java.security.GeneralSecurityException
{
}

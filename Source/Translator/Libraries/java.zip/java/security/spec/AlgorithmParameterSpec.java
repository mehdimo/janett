package java.security.spec;

interface AlgorithmParameterSpec
{
}

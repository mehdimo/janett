package java.security.spec;

abstract class DSAPrivateKeySpec implements java.security.spec.KeySpec
{
	public java.math.BigInteger getG() ;
	public java.math.BigInteger getP() ;
	public java.math.BigInteger getQ() ;
	public java.math.BigInteger getX() ;
}

package java.security.spec;

abstract class EncodedKeySpec implements java.security.spec.KeySpec
{
	public java.lang.Byte[] getEncoded() ;
	public abstract java.lang.String getFormat() ;
}

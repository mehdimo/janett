package java.security.spec;

abstract class InvalidKeySpecException extends java.security.GeneralSecurityException
{
}

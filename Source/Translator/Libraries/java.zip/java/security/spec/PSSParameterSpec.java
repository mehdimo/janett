package java.security.spec;

abstract class PSSParameterSpec implements java.security.spec.AlgorithmParameterSpec
{
	public java.lang.Integer getSaltLength() ;
}

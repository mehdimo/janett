package java.security.spec;

abstract class RSAOtherPrimeInfo
{
	public java.math.BigInteger getCrtCoefficient() ;
	public java.math.BigInteger getExponent() ;
	public java.math.BigInteger getPrime() ;
}

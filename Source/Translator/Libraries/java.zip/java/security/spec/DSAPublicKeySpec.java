package java.security.spec;

abstract class DSAPublicKeySpec implements java.security.spec.KeySpec
{
	public java.math.BigInteger getG() ;
	public java.math.BigInteger getP() ;
	public java.math.BigInteger getQ() ;
	public java.math.BigInteger getY() ;
}

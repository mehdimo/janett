package java.security.spec;

abstract class DSAParameterSpec implements java.security.spec.AlgorithmParameterSpec, java.security.interfaces.DSAParams
{
	public java.math.BigInteger getG() ;
	public java.math.BigInteger getP() ;
	public java.math.BigInteger getQ() ;
}

package java.security.spec;

abstract class RSAPrivateCrtKeySpec extends java.security.spec.RSAPrivateKeySpec
{
	public java.math.BigInteger getCrtCoefficient() ;
	public java.math.BigInteger getPrimeExponentP() ;
	public java.math.BigInteger getPrimeExponentQ() ;
	public java.math.BigInteger getPrimeP() ;
	public java.math.BigInteger getPrimeQ() ;
	public java.math.BigInteger getPublicExponent() ;
}

package java.security.spec;

abstract class RSAKeyGenParameterSpec implements java.security.spec.AlgorithmParameterSpec
{
	public java.lang.Integer getKeysize() ;
	public java.math.BigInteger getPublicExponent() ;
	java.math.BigInteger F0;
	java.math.BigInteger F4;
}

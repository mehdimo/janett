package java.security.spec;

abstract class RSAPrivateKeySpec implements java.security.spec.KeySpec
{
	public java.math.BigInteger getModulus() ;
	public java.math.BigInteger getPrivateExponent() ;
}

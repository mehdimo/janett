package java.security.spec;

abstract class RSAPublicKeySpec implements java.security.spec.KeySpec
{
	public java.math.BigInteger getModulus() ;
	public java.math.BigInteger getPublicExponent() ;
}

package java.security;

interface Certificate
{
	public abstract java.lang.Void decode(java.io.InputStream parameter1) ;
	public abstract java.lang.Void encode(java.io.OutputStream parameter1) ;
	public abstract java.lang.String getFormat() ;
	public abstract java.lang.String toString(java.lang.Boolean parameter1) ;
	public abstract java.security.Principal getGuarantor() ;
	public abstract java.security.Principal getPrincipal() ;
	public abstract java.security.PublicKey getPublicKey() ;
}

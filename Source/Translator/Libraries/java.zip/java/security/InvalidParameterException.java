package java.security;

abstract class InvalidParameterException extends java.lang.IllegalArgumentException
{
}

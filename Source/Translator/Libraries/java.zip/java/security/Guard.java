package java.security;

interface Guard
{
	public abstract java.lang.Void checkGuard(java.lang.Object parameter1) ;
}

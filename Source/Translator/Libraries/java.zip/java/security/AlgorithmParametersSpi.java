package java.security;

abstract class AlgorithmParametersSpi
{
	public abstract java.lang.Byte[] engineGetEncoded() ;
	public abstract java.lang.Void engineInit(java.lang.Byte[] parameter1) ;
	public abstract java.lang.String engineToString() ;
	public abstract java.lang.Byte[] engineGetEncoded(java.lang.String parameter1) ;
	public abstract java.lang.Void engineInit(java.lang.Byte[] parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void engineInit(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public abstract java.security.spec.AlgorithmParameterSpec engineGetParameterSpec(java.lang.Class parameter1) ;
}

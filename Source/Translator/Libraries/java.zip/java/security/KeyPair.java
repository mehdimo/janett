package java.security;

abstract class KeyPair implements java.io.Serializable
{
	public java.security.PrivateKey getPrivate() ;
	public java.security.PublicKey getPublic() ;
}

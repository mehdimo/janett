package java.security;

abstract class GuardedObject implements java.io.Serializable
{
	public java.lang.Object getObject() ;
}

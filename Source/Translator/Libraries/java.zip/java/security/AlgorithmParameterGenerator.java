package java.security;

abstract class AlgorithmParameterGenerator
{
	public java.lang.Void init(java.lang.Integer parameter1) ;
	public java.lang.String getAlgorithm() ;
	public java.security.AlgorithmParameters generateParameters() ;
	public java.security.Provider getProvider() ;
	public java.lang.Void init(java.lang.Integer parameter1, java.security.SecureRandom parameter2) ;
	public java.lang.Void init(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public java.security.AlgorithmParameterGenerator getInstance(java.lang.String parameter1) ;
	public java.lang.Void init(java.security.spec.AlgorithmParameterSpec parameter1, java.security.SecureRandom parameter2) ;
	public java.security.AlgorithmParameterGenerator getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.AlgorithmParameterGenerator getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

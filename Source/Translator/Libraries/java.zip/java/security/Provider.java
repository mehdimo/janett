package java.security;

abstract class Provider extends java.util.Properties
{
	public java.lang.Double getVersion() ;
	public java.lang.Void clear() ;
	public java.lang.Void load(java.io.InputStream parameter1) ;
	public java.lang.String getInfo() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.util.Collection values() ;
	public java.lang.Void putAll(java.util.Map parameter1) ;
	public java.util.Set entrySet() ;
	public java.util.Set keySet() ;
	public java.lang.Object remove(java.lang.Object parameter1) ;
	public java.lang.Object put(java.lang.Object parameter1, java.lang.Object parameter2) ;
}

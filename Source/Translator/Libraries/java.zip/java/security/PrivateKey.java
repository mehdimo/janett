package java.security;

interface PrivateKey implements java.security.Key
{
	java.lang.Long serialVersionUID;
}

package java.security;

interface PrivilegedExceptionAction
{
	public abstract java.lang.Object run() ;
}

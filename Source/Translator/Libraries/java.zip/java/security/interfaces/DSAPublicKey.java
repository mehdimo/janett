package java.security.interfaces;

interface DSAPublicKey implements java.security.interfaces.DSAKey, java.security.PublicKey
{
	public abstract java.math.BigInteger getY() ;
	java.lang.Long serialVersionUID;
}

package java.security.interfaces;

interface DSAKeyPairGenerator
{
	public abstract java.lang.Void initialize(java.lang.Integer parameter1, java.lang.Boolean parameter2, java.security.SecureRandom parameter3) ;
	public abstract java.lang.Void initialize(java.security.interfaces.DSAParams parameter1, java.security.SecureRandom parameter2) ;
}

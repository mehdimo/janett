package java.security.interfaces;

interface DSAPrivateKey implements java.security.interfaces.DSAKey, java.security.PrivateKey
{
	public abstract java.math.BigInteger getX() ;
	java.lang.Long serialVersionUID;
}

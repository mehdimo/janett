package java.security.interfaces;

interface RSAPublicKey implements java.security.PublicKey, java.security.interfaces.RSAKey
{
	public abstract java.math.BigInteger getPublicExponent() ;
}

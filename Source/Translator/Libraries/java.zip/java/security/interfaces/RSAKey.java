package java.security.interfaces;

interface RSAKey
{
	public abstract java.math.BigInteger getModulus() ;
}

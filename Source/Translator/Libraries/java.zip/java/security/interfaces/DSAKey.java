package java.security.interfaces;

interface DSAKey
{
	public abstract java.security.interfaces.DSAParams getParams() ;
}

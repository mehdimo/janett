package java.security.interfaces;

interface RSAPrivateKey implements java.security.PrivateKey, java.security.interfaces.RSAKey
{
	public abstract java.math.BigInteger getPrivateExponent() ;
}

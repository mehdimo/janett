package java.security.interfaces;

interface DSAParams
{
	public abstract java.math.BigInteger getG() ;
	public abstract java.math.BigInteger getP() ;
	public abstract java.math.BigInteger getQ() ;
}

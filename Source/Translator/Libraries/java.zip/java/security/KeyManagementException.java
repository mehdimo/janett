package java.security;

abstract class KeyManagementException extends java.security.KeyException
{
}

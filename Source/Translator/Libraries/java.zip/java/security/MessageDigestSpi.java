package java.security;

abstract class MessageDigestSpi
{
	public java.lang.Integer engineGetDigestLength() ;
	public abstract java.lang.Void engineReset() ;
	public abstract java.lang.Byte[] engineDigest() ;
	public abstract java.lang.Void engineUpdate(java.lang.Byte parameter1) ;
	public java.lang.Integer engineDigest(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void engineUpdate(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Object clone() ;
}

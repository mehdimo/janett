package java.security;

interface Principal
{
	public abstract java.lang.Integer hashCode() ;
	public abstract java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String getName() ;
	public abstract java.lang.String toString() ;
}

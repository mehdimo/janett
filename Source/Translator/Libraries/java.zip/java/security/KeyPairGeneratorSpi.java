package java.security;

abstract class KeyPairGeneratorSpi
{
	public abstract java.security.KeyPair generateKeyPair() ;
	public abstract java.lang.Void initialize(java.lang.Integer parameter1, java.security.SecureRandom parameter2) ;
	public java.lang.Void initialize(java.security.spec.AlgorithmParameterSpec parameter1, java.security.SecureRandom parameter2) ;
}

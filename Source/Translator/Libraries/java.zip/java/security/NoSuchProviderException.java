package java.security;

abstract class NoSuchProviderException extends java.security.GeneralSecurityException
{
}

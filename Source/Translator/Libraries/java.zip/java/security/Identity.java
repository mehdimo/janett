package java.security;

abstract class Identity implements java.security.Principal, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getInfo() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Void setInfo(java.lang.String parameter1) ;
	public java.lang.String toString(java.lang.Boolean parameter1) ;
	public java.security.Certificate[] certificates() ;
	public java.lang.Void addCertificate(java.security.Certificate parameter1) ;
	public java.lang.Void removeCertificate(java.security.Certificate parameter1) ;
	public java.lang.Boolean identityEquals(java.security.Identity parameter1) ;
	public java.security.IdentityScope getScope() ;
	public java.security.PublicKey getPublicKey() ;
	public java.lang.Void setPublicKey(java.security.PublicKey parameter1) ;
}

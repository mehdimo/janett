package java.security;

interface PrivilegedAction
{
	public abstract java.lang.Object run() ;
}

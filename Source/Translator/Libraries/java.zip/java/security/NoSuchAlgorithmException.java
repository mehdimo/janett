package java.security;

abstract class NoSuchAlgorithmException extends java.security.GeneralSecurityException
{
}

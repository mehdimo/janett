package java.security;

abstract class SignatureSpi
{
	public abstract java.lang.Byte[] engineSign() ;
	public abstract java.lang.Void engineUpdate(java.lang.Byte parameter1) ;
	public abstract java.lang.Boolean engineVerify(java.lang.Byte[] parameter1) ;
	public java.lang.Integer engineSign(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void engineUpdate(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Boolean engineVerify(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Object clone() ;
	public java.security.AlgorithmParameters engineGetParameters() ;
	public abstract java.lang.Void engineInitSign(java.security.PrivateKey parameter1) ;
	public abstract java.lang.Void engineInitVerify(java.security.PublicKey parameter1) ;
	public java.lang.Void engineSetParameter(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public abstract java.lang.Object engineGetParameter(java.lang.String parameter1) ;
	public abstract java.lang.Void engineSetParameter(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void engineInitSign(java.security.PrivateKey parameter1, java.security.SecureRandom parameter2) ;
}

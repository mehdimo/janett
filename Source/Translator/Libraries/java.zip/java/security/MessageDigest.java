package java.security;

abstract class MessageDigest extends java.security.MessageDigestSpi
{
	public java.lang.Integer getDigestLength() ;
	public java.lang.Void reset() ;
	public java.lang.Byte[] digest() ;
	public java.lang.Void update(java.lang.Byte parameter1) ;
	public java.lang.Void update(java.lang.Byte[] parameter1) ;
	public java.lang.Byte[] digest(java.lang.Byte[] parameter1) ;
	public java.lang.Integer digest(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void update(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Boolean isEqual(java.lang.Byte[] parameter1, java.lang.Byte[] parameter2) ;
	public java.lang.Object clone() ;
	public java.lang.String getAlgorithm() ;
	public java.lang.String toString() ;
	public java.security.Provider getProvider() ;
	public java.security.MessageDigest getInstance(java.lang.String parameter1) ;
	public java.security.MessageDigest getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.MessageDigest getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

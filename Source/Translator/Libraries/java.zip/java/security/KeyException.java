package java.security;

abstract class KeyException extends java.security.GeneralSecurityException
{
}

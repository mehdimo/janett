package java.security;

abstract class UnrecoverableKeyException extends java.security.GeneralSecurityException
{
}

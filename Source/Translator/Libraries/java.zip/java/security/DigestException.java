package java.security;

abstract class DigestException extends java.security.GeneralSecurityException
{
}

package java.security.acl;

abstract class NotOwnerException extends java.lang.Exception
{
}

package java.security.acl;

abstract class AclNotFoundException extends java.lang.Exception
{
}

package java.security.acl;

interface AclEntry implements java.lang.Cloneable
{
	public abstract java.lang.Void setNegativePermissions() ;
	public abstract java.lang.Boolean isNegative() ;
	public abstract java.lang.Object clone() ;
	public abstract java.lang.String toString() ;
	public abstract java.security.Principal getPrincipal() ;
	public abstract java.lang.Boolean setPrincipal(java.security.Principal parameter1) ;
	public abstract java.lang.Boolean addPermission(java.security.acl.Permission parameter1) ;
	public abstract java.lang.Boolean checkPermission(java.security.acl.Permission parameter1) ;
	public abstract java.lang.Boolean removePermission(java.security.acl.Permission parameter1) ;
	public abstract java.util.Enumeration permissions() ;
}

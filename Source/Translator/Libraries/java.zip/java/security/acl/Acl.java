package java.security.acl;

interface Acl implements java.security.acl.Owner
{
	public abstract java.lang.String getName() ;
	public abstract java.lang.String toString() ;
	public abstract java.util.Enumeration entries() ;
	public abstract java.lang.Void setName(java.security.Principal parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Boolean addEntry(java.security.Principal parameter1, java.security.acl.AclEntry parameter2) ;
	public abstract java.lang.Boolean removeEntry(java.security.Principal parameter1, java.security.acl.AclEntry parameter2) ;
	public abstract java.lang.Boolean checkPermission(java.security.Principal parameter1, java.security.acl.Permission parameter2) ;
	public abstract java.util.Enumeration getPermissions(java.security.Principal parameter1) ;
}

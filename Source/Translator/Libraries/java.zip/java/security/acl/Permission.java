package java.security.acl;

interface Permission
{
	public abstract java.lang.Boolean equals(java.lang.Object parameter1) ;
	public abstract java.lang.String toString() ;
}

package java.security.acl;

interface Group implements java.security.Principal
{
	public abstract java.lang.Boolean addMember(java.security.Principal parameter1) ;
	public abstract java.lang.Boolean isMember(java.security.Principal parameter1) ;
	public abstract java.lang.Boolean removeMember(java.security.Principal parameter1) ;
	public abstract java.util.Enumeration members() ;
}

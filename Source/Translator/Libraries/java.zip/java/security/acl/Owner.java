package java.security.acl;

interface Owner
{
	public abstract java.lang.Boolean isOwner(java.security.Principal parameter1) ;
	public abstract java.lang.Boolean addOwner(java.security.Principal parameter1, java.security.Principal parameter2) ;
	public abstract java.lang.Boolean deleteOwner(java.security.Principal parameter1, java.security.Principal parameter2) ;
}

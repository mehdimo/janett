package java.security.acl;

abstract class LastOwnerException extends java.lang.Exception
{
}

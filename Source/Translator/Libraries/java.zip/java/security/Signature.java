package java.security;

abstract class Signature extends java.security.SignatureSpi
{
	public java.lang.Byte[] sign() ;
	public java.lang.Void update(java.lang.Byte parameter1) ;
	public java.lang.Void update(java.lang.Byte[] parameter1) ;
	public java.lang.Boolean verify(java.lang.Byte[] parameter1) ;
	public java.lang.Integer sign(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void update(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Boolean verify(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Object clone() ;
	public java.lang.String getAlgorithm() ;
	public java.lang.String toString() ;
	public java.security.AlgorithmParameters getParameters() ;
	public java.lang.Void initSign(java.security.PrivateKey parameter1) ;
	public java.security.Provider getProvider() ;
	public java.lang.Void initVerify(java.security.PublicKey parameter1) ;
	public java.lang.Void initVerify(java.security.cert.Certificate parameter1) ;
	public java.lang.Void setParameter(java.security.spec.AlgorithmParameterSpec parameter1) ;
	public java.lang.Object getParameter(java.lang.String parameter1) ;
	public java.lang.Void setParameter(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void initSign(java.security.PrivateKey parameter1, java.security.SecureRandom parameter2) ;
	public java.security.Signature getInstance(java.lang.String parameter1) ;
	public java.security.Signature getInstance(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.Signature getInstance(java.lang.String parameter1, java.security.Provider parameter2) ;
}

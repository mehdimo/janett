package java.security;

abstract class PermissionCollection implements java.io.Serializable
{
	public java.lang.Void setReadOnly() ;
	public java.lang.Boolean isReadOnly() ;
	public java.lang.String toString() ;
	public abstract java.lang.Void add(java.security.Permission parameter1) ;
	public abstract java.lang.Boolean implies(java.security.Permission parameter1) ;
	public abstract java.util.Enumeration elements() ;
}

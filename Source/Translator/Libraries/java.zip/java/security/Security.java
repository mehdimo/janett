package java.security;

abstract class Security
{
	public java.lang.Void removeProvider(java.lang.String parameter1) ;
	public java.security.Provider[] getProviders() ;
	public java.lang.Integer addProvider(java.security.Provider parameter1) ;
	public java.lang.Integer insertProviderAt(java.security.Provider parameter1, java.lang.Integer parameter2) ;
	public java.lang.String getProperty(java.lang.String parameter1) ;
	public java.lang.Void setProperty(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.security.Provider getProvider(java.lang.String parameter1) ;
	public java.security.Provider[] getProviders(java.lang.String parameter1) ;
	public java.security.Provider[] getProviders(java.util.Map parameter1) ;
	public java.util.Set getAlgorithms(java.lang.String parameter1) ;
	public java.lang.String getAlgorithmProperty(java.lang.String parameter1, java.lang.String parameter2) ;
}

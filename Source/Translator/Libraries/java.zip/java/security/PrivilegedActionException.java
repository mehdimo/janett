package java.security;

abstract class PrivilegedActionException extends java.lang.Exception
{
	public java.lang.Exception getException() ;
	public java.lang.String toString() ;
	public java.lang.Throwable getCause() ;
}

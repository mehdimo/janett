package java.security;

abstract class SecurityPermission extends java.security.BasicPermission
{
}

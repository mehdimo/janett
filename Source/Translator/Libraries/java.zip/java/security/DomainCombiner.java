package java.security;

interface DomainCombiner
{
	public abstract java.security.ProtectionDomain[] combine(java.security.ProtectionDomain[] parameter1, java.security.ProtectionDomain[] parameter2) ;
}

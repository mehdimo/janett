package java.sql;

interface PreparedStatement implements java.sql.Statement
{
	public abstract java.lang.Integer executeUpdate() ;
	public abstract java.lang.Void addBatch() ;
	public abstract java.lang.Void clearParameters() ;
	public abstract java.lang.Boolean execute() ;
	public abstract java.lang.Void setByte(java.lang.Integer parameter1, java.lang.Byte parameter2) ;
	public abstract java.lang.Void setDouble(java.lang.Integer parameter1, java.lang.Double parameter2) ;
	public abstract java.lang.Void setFloat(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public abstract java.lang.Void setInt(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setNull(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void setLong(java.lang.Integer parameter1, java.lang.Long parameter2) ;
	public abstract java.lang.Void setShort(java.lang.Integer parameter1, java.lang.Short parameter2) ;
	public abstract java.lang.Void setBoolean(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public abstract java.lang.Void setBytes(java.lang.Integer parameter1, java.lang.Byte[] parameter2) ;
	public abstract java.lang.Void setAsciiStream(java.lang.Integer parameter1, java.io.InputStream parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void setBinaryStream(java.lang.Integer parameter1, java.io.InputStream parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void setUnicodeStream(java.lang.Integer parameter1, java.io.InputStream parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void setCharacterStream(java.lang.Integer parameter1, java.io.Reader parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void setObject(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public abstract java.lang.Void setObject(java.lang.Integer parameter1, java.lang.Object parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void setObject(java.lang.Integer parameter1, java.lang.Object parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Void setNull(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
	public abstract java.lang.Void setString(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Void setBigDecimal(java.lang.Integer parameter1, java.math.BigDecimal parameter2) ;
	public abstract java.lang.Void setURL(java.lang.Integer parameter1, java.net.URL parameter2) ;
	public abstract java.lang.Void setArray(java.lang.Integer parameter1, java.sql.Array parameter2) ;
	public abstract java.lang.Void setBlob(java.lang.Integer parameter1, java.sql.Blob parameter2) ;
	public abstract java.lang.Void setClob(java.lang.Integer parameter1, java.sql.Clob parameter2) ;
	public abstract java.lang.Void setDate(java.lang.Integer parameter1, java.sql.Date parameter2) ;
	public abstract java.sql.ParameterMetaData getParameterMetaData() ;
	public abstract java.lang.Void setRef(java.lang.Integer parameter1, java.sql.Ref parameter2) ;
	public abstract java.sql.ResultSet executeQuery() ;
	public abstract java.sql.ResultSetMetaData getMetaData() ;
	public abstract java.lang.Void setTime(java.lang.Integer parameter1, java.sql.Time parameter2) ;
	public abstract java.lang.Void setTimestamp(java.lang.Integer parameter1, java.sql.Timestamp parameter2) ;
	public abstract java.lang.Void setDate(java.lang.Integer parameter1, java.sql.Date parameter2, java.util.Calendar parameter3) ;
	public abstract java.lang.Void setTime(java.lang.Integer parameter1, java.sql.Time parameter2, java.util.Calendar parameter3) ;
	public abstract java.lang.Void setTimestamp(java.lang.Integer parameter1, java.sql.Timestamp parameter2, java.util.Calendar parameter3) ;
}

package java.sql;

abstract class DriverPropertyInfo
{
	java.lang.String name;
	java.lang.String description;
	java.lang.Boolean required;
	java.lang.String value;
	java.lang.String[] choices;
}

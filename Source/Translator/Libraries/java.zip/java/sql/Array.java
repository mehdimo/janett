package java.sql;

interface Array
{
	public abstract java.lang.Integer getBaseType() ;
	public abstract java.lang.Object getArray() ;
	public abstract java.lang.Object getArray(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String getBaseTypeName() ;
	public abstract java.sql.ResultSet getResultSet() ;
	public abstract java.sql.ResultSet getResultSet(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Object getArray(java.lang.Long parameter1, java.lang.Integer parameter2, java.util.Map parameter3) ;
	public abstract java.lang.Object getArray(java.util.Map parameter1) ;
	public abstract java.sql.ResultSet getResultSet(java.lang.Long parameter1, java.lang.Integer parameter2, java.util.Map parameter3) ;
	public abstract java.sql.ResultSet getResultSet(java.util.Map parameter1) ;
}

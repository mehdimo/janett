package java.sql;

interface Ref
{
	public abstract java.lang.Object getObject() ;
	public abstract java.lang.Void setObject(java.lang.Object parameter1) ;
	public abstract java.lang.String getBaseTypeName() ;
	public abstract java.lang.Object getObject(java.util.Map parameter1) ;
}

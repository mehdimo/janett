package java.sql;

abstract class SQLException extends java.lang.Exception
{
	public java.lang.Integer getErrorCode() ;
	public java.lang.String getSQLState() ;
	public java.sql.SQLException getNextException() ;
	public java.lang.Void setNextException(java.sql.SQLException parameter1) ;
}

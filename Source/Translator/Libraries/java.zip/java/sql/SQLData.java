package java.sql;

interface SQLData
{
	public abstract java.lang.String getSQLTypeName() ;
	public abstract java.lang.Void writeSQL(java.sql.SQLOutput parameter1) ;
	public abstract java.lang.Void readSQL(java.sql.SQLInput parameter1, java.lang.String parameter2) ;
}

package java.sql;

interface ParameterMetaData
{
	public abstract java.lang.Integer getParameterCount() ;
	public abstract java.lang.Integer getParameterMode(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getParameterType(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getPrecision(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getScale(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer isNullable(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isSigned(java.lang.Integer parameter1) ;
	public abstract java.lang.String getParameterClassName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getParameterTypeName(java.lang.Integer parameter1) ;
	java.lang.Integer parameterNoNulls;
	java.lang.Integer parameterNullable;
	java.lang.Integer parameterNullableUnknown;
	java.lang.Integer parameterModeUnknown;
	java.lang.Integer parameterModeIn;
	java.lang.Integer parameterModeInOut;
	java.lang.Integer parameterModeOut;
}

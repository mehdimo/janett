package java.sql;

abstract class Date extends java.util.Date
{
	public java.lang.Integer getHours() ;
	public java.lang.Integer getMinutes() ;
	public java.lang.Integer getSeconds() ;
	public java.lang.Void setHours(java.lang.Integer parameter1) ;
	public java.lang.Void setMinutes(java.lang.Integer parameter1) ;
	public java.lang.Void setSeconds(java.lang.Integer parameter1) ;
	public java.lang.Void setTime(java.lang.Long parameter1) ;
	public java.lang.String toString() ;
	public java.sql.Date valueOf(java.lang.String parameter1) ;
}

package java.sql;

abstract class BatchUpdateException extends java.sql.SQLException
{
	public java.lang.Integer[] getUpdateCounts() ;
}

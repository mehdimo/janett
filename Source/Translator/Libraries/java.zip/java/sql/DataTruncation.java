package java.sql;

abstract class DataTruncation extends java.sql.SQLWarning
{
	public java.lang.Integer getDataSize() ;
	public java.lang.Integer getIndex() ;
	public java.lang.Integer getTransferSize() ;
	public java.lang.Boolean getParameter() ;
	public java.lang.Boolean getRead() ;
}

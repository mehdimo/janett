package java.sql;

interface SQLInput
{
	public abstract java.lang.Byte readByte() ;
	public abstract java.lang.Double readDouble() ;
	public abstract java.lang.Float readFloat() ;
	public abstract java.lang.Integer readInt() ;
	public abstract java.lang.Long readLong() ;
	public abstract java.lang.Short readShort() ;
	public abstract java.lang.Boolean readBoolean() ;
	public abstract java.lang.Boolean wasNull() ;
	public abstract java.lang.Byte[] readBytes() ;
	public abstract java.io.InputStream readAsciiStream() ;
	public abstract java.io.InputStream readBinaryStream() ;
	public abstract java.io.Reader readCharacterStream() ;
	public abstract java.lang.Object readObject() ;
	public abstract java.lang.String readString() ;
	public abstract java.math.BigDecimal readBigDecimal() ;
	public abstract java.net.URL readURL() ;
	public abstract java.sql.Array readArray() ;
	public abstract java.sql.Blob readBlob() ;
	public abstract java.sql.Clob readClob() ;
	public abstract java.sql.Date readDate() ;
	public abstract java.sql.Ref readRef() ;
	public abstract java.sql.Time readTime() ;
	public abstract java.sql.Timestamp readTimestamp() ;
}

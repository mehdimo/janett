package java.sql;

abstract class DriverManager
{
	public java.lang.Integer getLoginTimeout() ;
	public java.lang.Void setLoginTimeout(java.lang.Integer parameter1) ;
	public java.io.PrintStream getLogStream() ;
	public java.lang.Void setLogStream(java.io.PrintStream parameter1) ;
	public java.io.PrintWriter getLogWriter() ;
	public java.lang.Void setLogWriter(java.io.PrintWriter parameter1) ;
	public java.lang.Void println(java.lang.String parameter1) ;
	public java.lang.Void deregisterDriver(java.sql.Driver parameter1) ;
	public java.lang.Void registerDriver(java.sql.Driver parameter1) ;
	public java.util.Enumeration getDrivers() ;
	public java.sql.Connection getConnection(java.lang.String parameter1) ;
	public java.sql.Driver getDriver(java.lang.String parameter1) ;
	public java.sql.Connection getConnection(java.lang.String parameter1, java.util.Properties parameter2) ;
	public java.sql.Connection getConnection(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3) ;
}

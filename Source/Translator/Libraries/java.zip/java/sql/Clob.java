package java.sql;

interface Clob
{
	public abstract java.lang.Long length() ;
	public abstract java.lang.Void truncate(java.lang.Long parameter1) ;
	public abstract java.io.InputStream getAsciiStream() ;
	public abstract java.io.OutputStream setAsciiStream(java.lang.Long parameter1) ;
	public abstract java.io.Reader getCharacterStream() ;
	public abstract java.io.Writer setCharacterStream(java.lang.Long parameter1) ;
	public abstract java.lang.String getSubString(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer setString(java.lang.Long parameter1, java.lang.String parameter2) ;
	public abstract java.lang.Integer setString(java.lang.Long parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Long position(java.lang.String parameter1, java.lang.Long parameter2) ;
	public abstract java.lang.Long position(java.sql.Clob parameter1, java.lang.Long parameter2) ;
}

package java.sql;

interface Savepoint
{
	public abstract java.lang.Integer getSavepointId() ;
	public abstract java.lang.String getSavepointName() ;
}

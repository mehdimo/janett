package java.sql;

interface SQLOutput
{
	public abstract java.lang.Void writeByte(java.lang.Byte parameter1) ;
	public abstract java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public abstract java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public abstract java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeLong(java.lang.Long parameter1) ;
	public abstract java.lang.Void writeShort(java.lang.Short parameter1) ;
	public abstract java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void writeBytes(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void writeAsciiStream(java.io.InputStream parameter1) ;
	public abstract java.lang.Void writeBinaryStream(java.io.InputStream parameter1) ;
	public abstract java.lang.Void writeCharacterStream(java.io.Reader parameter1) ;
	public abstract java.lang.Void writeString(java.lang.String parameter1) ;
	public abstract java.lang.Void writeBigDecimal(java.math.BigDecimal parameter1) ;
	public abstract java.lang.Void writeURL(java.net.URL parameter1) ;
	public abstract java.lang.Void writeArray(java.sql.Array parameter1) ;
	public abstract java.lang.Void writeBlob(java.sql.Blob parameter1) ;
	public abstract java.lang.Void writeClob(java.sql.Clob parameter1) ;
	public abstract java.lang.Void writeDate(java.sql.Date parameter1) ;
	public abstract java.lang.Void writeRef(java.sql.Ref parameter1) ;
	public abstract java.lang.Void writeObject(java.sql.SQLData parameter1) ;
	public abstract java.lang.Void writeStruct(java.sql.Struct parameter1) ;
	public abstract java.lang.Void writeTime(java.sql.Time parameter1) ;
	public abstract java.lang.Void writeTimestamp(java.sql.Timestamp parameter1) ;
}

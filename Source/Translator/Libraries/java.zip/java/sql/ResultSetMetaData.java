package java.sql;

interface ResultSetMetaData
{
	public abstract java.lang.Integer getColumnCount() ;
	public abstract java.lang.Integer getColumnDisplaySize(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getColumnType(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getPrecision(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer getScale(java.lang.Integer parameter1) ;
	public abstract java.lang.Integer isNullable(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isAutoIncrement(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isCaseSensitive(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isCurrency(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isDefinitelyWritable(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isReadOnly(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isSearchable(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isSigned(java.lang.Integer parameter1) ;
	public abstract java.lang.Boolean isWritable(java.lang.Integer parameter1) ;
	public abstract java.lang.String getCatalogName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getColumnClassName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getColumnLabel(java.lang.Integer parameter1) ;
	public abstract java.lang.String getColumnName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getColumnTypeName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getSchemaName(java.lang.Integer parameter1) ;
	public abstract java.lang.String getTableName(java.lang.Integer parameter1) ;
	java.lang.Integer columnNoNulls;
	java.lang.Integer columnNullable;
	java.lang.Integer columnNullableUnknown;
}

package java.sql;

interface Driver
{
	public abstract java.lang.Integer getMajorVersion() ;
	public abstract java.lang.Integer getMinorVersion() ;
	public abstract java.lang.Boolean jdbcCompliant() ;
	public abstract java.lang.Boolean acceptsURL(java.lang.String parameter1) ;
	public abstract java.sql.Connection connect(java.lang.String parameter1, java.util.Properties parameter2) ;
	public abstract java.sql.DriverPropertyInfo[] getPropertyInfo(java.lang.String parameter1, java.util.Properties parameter2) ;
}

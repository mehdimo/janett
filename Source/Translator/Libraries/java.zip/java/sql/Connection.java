package java.sql;

interface Connection
{
	public abstract java.lang.Integer getHoldability() ;
	public abstract java.lang.Integer getTransactionIsolation() ;
	public abstract java.lang.Void clearWarnings() ;
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void commit() ;
	public abstract java.lang.Void rollback() ;
	public abstract java.lang.Boolean getAutoCommit() ;
	public abstract java.lang.Boolean isClosed() ;
	public abstract java.lang.Boolean isReadOnly() ;
	public abstract java.lang.Void setHoldability(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setTransactionIsolation(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setAutoCommit(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void setReadOnly(java.lang.Boolean parameter1) ;
	public abstract java.lang.String getCatalog() ;
	public abstract java.lang.Void setCatalog(java.lang.String parameter1) ;
	public abstract java.sql.DatabaseMetaData getMetaData() ;
	public abstract java.sql.SQLWarning getWarnings() ;
	public abstract java.sql.Savepoint setSavepoint() ;
	public abstract java.lang.Void releaseSavepoint(java.sql.Savepoint parameter1) ;
	public abstract java.lang.Void rollback(java.sql.Savepoint parameter1) ;
	public abstract java.sql.Statement createStatement() ;
	public abstract java.sql.Statement createStatement(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.sql.Statement createStatement(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.util.Map getTypeMap() ;
	public abstract java.lang.Void setTypeMap(java.util.Map parameter1) ;
	public abstract java.lang.String nativeSQL(java.lang.String parameter1) ;
	public abstract java.sql.CallableStatement prepareCall(java.lang.String parameter1) ;
	public abstract java.sql.CallableStatement prepareCall(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.sql.CallableStatement prepareCall(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1, java.lang.Integer[] parameter2) ;
	public abstract java.sql.Savepoint setSavepoint(java.lang.String parameter1) ;
	public abstract java.sql.PreparedStatement prepareStatement(java.lang.String parameter1, java.lang.String[] parameter2) ;
	java.lang.Integer TRANSACTION_NONE;
	java.lang.Integer TRANSACTION_READ_UNCOMMITTED;
	java.lang.Integer TRANSACTION_READ_COMMITTED;
	java.lang.Integer TRANSACTION_REPEATABLE_READ;
	java.lang.Integer TRANSACTION_SERIALIZABLE;
}

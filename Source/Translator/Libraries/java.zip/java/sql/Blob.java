package java.sql;

interface Blob
{
	public abstract java.lang.Long length() ;
	public abstract java.lang.Void truncate(java.lang.Long parameter1) ;
	public abstract java.lang.Byte[] getBytes(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Integer setBytes(java.lang.Long parameter1, java.lang.Byte[] parameter2) ;
	public abstract java.lang.Integer setBytes(java.lang.Long parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public abstract java.lang.Long position(java.lang.Byte[] parameter1, java.lang.Long parameter2) ;
	public abstract java.io.InputStream getBinaryStream() ;
	public abstract java.io.OutputStream setBinaryStream(java.lang.Long parameter1) ;
	public abstract java.lang.Long position(java.sql.Blob parameter1, java.lang.Long parameter2) ;
}

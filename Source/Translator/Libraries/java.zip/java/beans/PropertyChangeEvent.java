package java.beans;

abstract class PropertyChangeEvent extends java.util.EventObject
{
	public java.lang.Object getNewValue() ;
	public java.lang.Object getOldValue() ;
	public java.lang.Object getPropagationId() ;
	public java.lang.Void setPropagationId(java.lang.Object parameter1) ;
	public java.lang.String getPropertyName() ;
	public PropertyChangeEvent(java.lang.Object parameter1, java.lang.String parameter2, java.lang.Object parameter3, java.lang.Object parameter4) ;
}

package java.beans;

abstract class MethodDescriptor extends java.beans.FeatureDescriptor
{
	public java.beans.ParameterDescriptor[] getParameterDescriptors() ;
	public java.lang.reflect.Method getMethod() ;
}

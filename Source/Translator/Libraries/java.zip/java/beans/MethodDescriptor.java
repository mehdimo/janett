package java.beans;

abstract class MethodDescriptor extends java.beans.FeatureDescriptor
{
	public java.beans.ParameterDescriptor[] getParameterDescriptors() ;
	public java.lang.reflect.Method getMethod() ;
	public MethodDescriptor(java.lang.reflect.Method parameter1) ;
	public MethodDescriptor(java.lang.reflect.Method parameter1, java.beans.ParameterDescriptor[] parameter2) ;
}

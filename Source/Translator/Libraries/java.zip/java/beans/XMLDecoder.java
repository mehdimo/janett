package java.beans;

abstract class XMLDecoder
{
	public java.lang.Void close() ;
	public java.beans.ExceptionListener getExceptionListener() ;
	public java.lang.Void setExceptionListener(java.beans.ExceptionListener parameter1) ;
	public XMLDecoder(java.io.InputStream parameter1) ;
	public java.lang.Object getOwner() ;
	public java.lang.Object readObject() ;
	public java.lang.Void setOwner(java.lang.Object parameter1) ;
	public XMLDecoder(java.io.InputStream parameter1, java.lang.Object parameter2) ;
	public XMLDecoder(java.io.InputStream parameter1, java.lang.Object parameter2, java.beans.ExceptionListener parameter3) ;
}

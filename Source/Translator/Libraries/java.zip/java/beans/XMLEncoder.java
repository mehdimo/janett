package java.beans;

abstract class XMLEncoder extends java.beans.Encoder
{
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void writeExpression(java.beans.Expression parameter1) ;
	public java.lang.Void writeStatement(java.beans.Statement parameter1) ;
	public XMLEncoder(java.io.OutputStream parameter1) ;
	public java.lang.Object getOwner() ;
	public java.lang.Void setOwner(java.lang.Object parameter1) ;
	public java.lang.Void writeObject(java.lang.Object parameter1) ;
}

package java.beans;

interface Visibility
{
	public abstract java.lang.Void dontUseGui() ;
	public abstract java.lang.Void okToUseGui() ;
	public abstract java.lang.Boolean avoidingGui() ;
	public abstract java.lang.Boolean needsGui() ;
}

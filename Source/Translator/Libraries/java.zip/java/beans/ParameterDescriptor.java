package java.beans;

abstract class ParameterDescriptor extends java.beans.FeatureDescriptor
{
}

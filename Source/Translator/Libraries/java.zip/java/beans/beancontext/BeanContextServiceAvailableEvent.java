package java.beans.beancontext;

abstract class BeanContextServiceAvailableEvent extends java.beans.beancontext.BeanContextEvent
{
	public java.beans.beancontext.BeanContextServices getSourceAsBeanContextServices() ;
	public java.lang.Class getServiceClass() ;
	public java.util.Iterator getCurrentServiceSelectors() ;
	public BeanContextServiceAvailableEvent(java.beans.beancontext.BeanContextServices parameter1, java.lang.Class parameter2) ;
}

package java.beans.beancontext;

interface BeanContextServicesListener implements java.beans.beancontext.BeanContextServiceRevokedListener
{
	public abstract java.lang.Void serviceAvailable(java.beans.beancontext.BeanContextServiceAvailableEvent parameter1) ;
}

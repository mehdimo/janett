package java.beans.beancontext;

interface BeanContextServiceProviderBeanInfo implements java.beans.BeanInfo
{
	public abstract java.beans.BeanInfo[] getServicesBeanInfo() ;
}

package java.beans.beancontext;

abstract class BeanContextChildSupport implements java.beans.beancontext.BeanContextChild, java.beans.beancontext.BeanContextServicesListener, java.io.Serializable
{
	public java.lang.Void initializeBeanContextResources() ;
	public java.lang.Void releaseBeanContextResources() ;
	public java.lang.Boolean isDelegated() ;
	public java.beans.beancontext.BeanContext getBeanContext() ;
	public java.lang.Void setBeanContext(java.beans.beancontext.BeanContext parameter1) ;
	public java.lang.Boolean validatePendingSetBeanContext(java.beans.beancontext.BeanContext parameter1) ;
	public java.beans.beancontext.BeanContextChild getBeanContextChildPeer() ;
	public java.lang.Void serviceAvailable(java.beans.beancontext.BeanContextServiceAvailableEvent parameter1) ;
	public java.lang.Void serviceRevoked(java.beans.beancontext.BeanContextServiceRevokedEvent parameter1) ;
	public java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void removePropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void addVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
	public java.lang.Void removeVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Void fireVetoableChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	java.beans.beancontext.BeanContextChild beanContextChildPeer;
}

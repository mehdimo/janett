package java.beans.beancontext;

interface BeanContextServices implements java.beans.beancontext.BeanContext, java.beans.beancontext.BeanContextServicesListener
{
	public abstract java.lang.Void addBeanContextServicesListener(java.beans.beancontext.BeanContextServicesListener parameter1) ;
	public abstract java.lang.Void removeBeanContextServicesListener(java.beans.beancontext.BeanContextServicesListener parameter1) ;
	public abstract java.lang.Boolean hasService(java.lang.Class parameter1) ;
	public abstract java.util.Iterator getCurrentServiceClasses() ;
	public abstract java.lang.Boolean addService(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2) ;
	public abstract java.lang.Void revokeService(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2, java.lang.Boolean parameter3) ;
	public abstract java.util.Iterator getCurrentServiceSelectors(java.lang.Class parameter1) ;
	public abstract java.lang.Void releaseService(java.beans.beancontext.BeanContextChild parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public abstract java.lang.Object getService(java.beans.beancontext.BeanContextChild parameter1, java.lang.Object parameter2, java.lang.Class parameter3, java.lang.Object parameter4, java.beans.beancontext.BeanContextServiceRevokedListener parameter5) ;
}

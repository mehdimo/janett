package java.beans.beancontext;

interface BeanContextProxy
{
	public abstract java.beans.beancontext.BeanContextChild getBeanContextProxy() ;
}

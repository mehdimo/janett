package java.beans.beancontext;

interface BeanContextMembershipListener implements java.util.EventListener
{
	public abstract java.lang.Void childrenAdded(java.beans.beancontext.BeanContextMembershipEvent parameter1) ;
	public abstract java.lang.Void childrenRemoved(java.beans.beancontext.BeanContextMembershipEvent parameter1) ;
}

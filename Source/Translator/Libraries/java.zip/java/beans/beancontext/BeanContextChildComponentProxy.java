package java.beans.beancontext;

interface BeanContextChildComponentProxy
{
	public abstract java.awt.Component getComponent() ;
}

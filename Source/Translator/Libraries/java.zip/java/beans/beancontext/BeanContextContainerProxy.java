package java.beans.beancontext;

interface BeanContextContainerProxy
{
	public abstract java.awt.Container getContainer() ;
}

package java.beans.beancontext;

abstract class BeanContextServicesSupport extends java.beans.beancontext.BeanContextSupport implements java.beans.beancontext.BeanContextServices
{
	public java.lang.Void initialize() ;
	public java.lang.Void initializeBeanContextResources() ;
	public java.lang.Void releaseBeanContextResources() ;
	public java.lang.Void fireServiceAdded(java.beans.beancontext.BeanContextServiceAvailableEvent parameter1) ;
	public java.lang.Void serviceAvailable(java.beans.beancontext.BeanContextServiceAvailableEvent parameter1) ;
	public java.lang.Void fireServiceRevoked(java.beans.beancontext.BeanContextServiceRevokedEvent parameter1) ;
	public java.lang.Void serviceRevoked(java.beans.beancontext.BeanContextServiceRevokedEvent parameter1) ;
	public java.beans.beancontext.BeanContextServices getBeanContextServicesPeer() ;
	public java.lang.Void addBeanContextServicesListener(java.beans.beancontext.BeanContextServicesListener parameter1) ;
	public java.lang.Void removeBeanContextServicesListener(java.beans.beancontext.BeanContextServicesListener parameter1) ;
	public java.lang.Void bcsPreDeserializationHook(java.io.ObjectInputStream parameter1) ;
	public java.lang.Void bcsPreSerializationHook(java.io.ObjectOutputStream parameter1) ;
	public java.lang.Void fireServiceAdded(java.lang.Class parameter1) ;
	public java.lang.Boolean hasService(java.lang.Class parameter1) ;
	public java.lang.Void fireServiceRevoked(java.lang.Class parameter1, java.lang.Boolean parameter2) ;
	public java.util.Iterator getCurrentServiceClasses() ;
	public java.lang.Boolean addService(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2) ;
	public java.lang.Void revokeService(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Boolean addService(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2, java.lang.Boolean parameter3) ;
	public java.beans.beancontext.BeanContextServicesListener getChildBeanContextServicesListener(java.lang.Object parameter1) ;
	public java.lang.Void childJustRemovedHook(java.lang.Object parameter1, java.beans.beancontext.BeanContextSupport.BCSChild parameter2) ;
	public java.util.Iterator getCurrentServiceSelectors(java.lang.Class parameter1) ;
	public java.beans.beancontext.BeanContextServicesSupport.BCSSServiceProvider createBCSSServiceProvider(java.lang.Class parameter1, java.beans.beancontext.BeanContextServiceProvider parameter2) ;
	public java.beans.beancontext.BeanContextSupport.BCSChild createBCSChild(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.lang.Void releaseService(java.beans.beancontext.BeanContextChild parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public java.lang.Object getService(java.beans.beancontext.BeanContextChild parameter1, java.lang.Object parameter2, java.lang.Class parameter3, java.lang.Object parameter4, java.beans.beancontext.BeanContextServiceRevokedListener parameter5) ;
	abstract class BCSSChild extends java.beans.beancontext.BeanContextSupport.BCSChild
	{
	}
	abstract class BCSSProxyServiceProvider implements java.beans.beancontext.BeanContextServiceProvider, java.beans.beancontext.BeanContextServiceRevokedListener
	{
		public java.lang.Void serviceRevoked(java.beans.beancontext.BeanContextServiceRevokedEvent parameter1) ;
		public java.lang.Void releaseService(java.beans.beancontext.BeanContextServices parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
		public java.util.Iterator getCurrentServiceSelectors(java.beans.beancontext.BeanContextServices parameter1, java.lang.Class parameter2) ;
		public java.lang.Object getService(java.beans.beancontext.BeanContextServices parameter1, java.lang.Object parameter2, java.lang.Class parameter3, java.lang.Object parameter4) ;
	}
	abstract class BCSSServiceProvider implements java.io.Serializable
	{
		public java.beans.beancontext.BeanContextServiceProvider getServiceProvider() ;
	}
}

package java.beans.beancontext;

abstract class BeanContextSupport extends java.beans.beancontext.BeanContextChildSupport implements java.beans.beancontext.BeanContext, java.io.Serializable, java.beans.PropertyChangeListener, java.beans.VetoableChangeListener
{
	public java.lang.Integer size() ;
	public BeanContextSupport() ;
	public java.lang.Void clear() ;
	public java.lang.Void dontUseGui() ;
	public java.lang.Void initialize() ;
	public java.lang.Void okToUseGui() ;
	public java.lang.Boolean avoidingGui() ;
	public java.lang.Boolean isDesignTime() ;
	public java.lang.Boolean isEmpty() ;
	public java.lang.Boolean isSerializing() ;
	public java.lang.Boolean needsGui() ;
	public java.lang.Void setDesignTime(java.lang.Boolean parameter1) ;
	public java.lang.Void propertyChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.lang.Void vetoableChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.beans.beancontext.BeanContext getBeanContextPeer() ;
	public BeanContextSupport(java.beans.beancontext.BeanContext parameter1) ;
	public java.lang.Void fireChildrenAdded(java.beans.beancontext.BeanContextMembershipEvent parameter1) ;
	public java.lang.Void fireChildrenRemoved(java.beans.beancontext.BeanContextMembershipEvent parameter1) ;
	public java.lang.Void addBeanContextMembershipListener(java.beans.beancontext.BeanContextMembershipListener parameter1) ;
	public java.lang.Void removeBeanContextMembershipListener(java.beans.beancontext.BeanContextMembershipListener parameter1) ;
	public java.lang.Void bcsPreDeserializationHook(java.io.ObjectInputStream parameter1) ;
	public java.lang.Void readChildren(java.io.ObjectInputStream parameter1) ;
	public java.lang.Void bcsPreSerializationHook(java.io.ObjectOutputStream parameter1) ;
	public java.lang.Void writeChildren(java.io.ObjectOutputStream parameter1) ;
	public java.lang.Object[] copyChildren() ;
	public java.lang.Object[] toArray() ;
	public java.lang.Boolean add(java.lang.Object parameter1) ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.lang.Boolean containsKey(java.lang.Object parameter1) ;
	public java.lang.Boolean remove(java.lang.Object parameter1) ;
	public java.lang.Boolean validatePendingAdd(java.lang.Object parameter1) ;
	public java.lang.Boolean validatePendingRemove(java.lang.Object parameter1) ;
	public java.lang.Boolean remove(java.lang.Object parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Boolean addAll(java.util.Collection parameter1) ;
	public java.lang.Boolean containsAll(java.util.Collection parameter1) ;
	public java.lang.Boolean removeAll(java.util.Collection parameter1) ;
	public java.lang.Boolean retainAll(java.util.Collection parameter1) ;
	public java.util.Iterator bcsChildren() ;
	public java.util.Iterator iterator() ;
	public java.util.Locale getLocale() ;
	public java.lang.Void setLocale(java.util.Locale parameter1) ;
	public java.beans.PropertyChangeListener getChildPropertyChangeListener(java.lang.Object parameter1) ;
	public java.beans.VetoableChangeListener getChildVetoableChangeListener(java.lang.Object parameter1) ;
	public java.beans.Visibility getChildVisibility(java.lang.Object parameter1) ;
	public java.beans.beancontext.BeanContextChild getChildBeanContextChild(java.lang.Object parameter1) ;
	public java.beans.beancontext.BeanContextMembershipListener getChildBeanContextMembershipListener(java.lang.Object parameter1) ;
	public java.lang.Void childDeserializedHook(java.lang.Object parameter1, java.beans.beancontext.BeanContextSupport.BCSChild parameter2) ;
	public java.lang.Void childJustAddedHook(java.lang.Object parameter1, java.beans.beancontext.BeanContextSupport.BCSChild parameter2) ;
	public java.lang.Void childJustRemovedHook(java.lang.Object parameter1, java.beans.beancontext.BeanContextSupport.BCSChild parameter2) ;
	public java.io.Serializable getChildSerializable(java.lang.Object parameter1) ;
	public java.lang.Boolean classEquals(java.lang.Class parameter1, java.lang.Class parameter2) ;
	public java.lang.Object[] toArray(java.lang.Object[] parameter1) ;
	public java.lang.Object instantiateChild(java.lang.String parameter1) ;
	public java.lang.Void deserialize(java.io.ObjectInputStream parameter1, java.util.Collection parameter2) ;
	public java.lang.Void serialize(java.io.ObjectOutputStream parameter1, java.util.Collection parameter2) ;
	public BeanContextSupport(java.beans.beancontext.BeanContext parameter1, java.util.Locale parameter2) ;
	public BeanContextSupport(java.beans.beancontext.BeanContext parameter1, java.util.Locale parameter2, java.lang.Boolean parameter3) ;
	public BeanContextSupport(java.beans.beancontext.BeanContext parameter1, java.util.Locale parameter2, java.lang.Boolean parameter3, java.lang.Boolean parameter4) ;
	public java.beans.beancontext.BeanContextSupport.BCSChild createBCSChild(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.io.InputStream getResourceAsStream(java.lang.String parameter1, java.beans.beancontext.BeanContextChild parameter2) ;
	public java.net.URL getResource(java.lang.String parameter1, java.beans.beancontext.BeanContextChild parameter2) ;
	abstract class BCSIterator implements java.util.Iterator
	{
		public java.lang.Void remove() ;
		public java.lang.Boolean hasNext() ;
		public java.lang.Object next() ;
	}
	abstract class BCSChild implements java.io.Serializable
	{
	}
}

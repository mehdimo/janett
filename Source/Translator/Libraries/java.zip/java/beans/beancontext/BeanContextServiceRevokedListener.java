package java.beans.beancontext;

interface BeanContextServiceRevokedListener implements java.util.EventListener
{
	public abstract java.lang.Void serviceRevoked(java.beans.beancontext.BeanContextServiceRevokedEvent parameter1) ;
}

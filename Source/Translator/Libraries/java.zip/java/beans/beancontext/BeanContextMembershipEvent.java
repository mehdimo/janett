package java.beans.beancontext;

abstract class BeanContextMembershipEvent extends java.beans.beancontext.BeanContextEvent
{
	public java.lang.Integer size() ;
	public java.lang.Object[] toArray() ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.util.Iterator iterator() ;
	public BeanContextMembershipEvent(java.beans.beancontext.BeanContext parameter1, java.lang.Object[] parameter2) ;
	public BeanContextMembershipEvent(java.beans.beancontext.BeanContext parameter1, java.util.Collection parameter2) ;
}

package java.beans.beancontext;

abstract class BeanContextMembershipEvent extends java.beans.beancontext.BeanContextEvent
{
	public java.lang.Integer size() ;
	public java.lang.Object[] toArray() ;
	public java.lang.Boolean contains(java.lang.Object parameter1) ;
	public java.util.Iterator iterator() ;
}

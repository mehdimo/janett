package java.beans.beancontext;

interface BeanContext implements java.beans.beancontext.BeanContextChild, java.util.Collection, java.beans.DesignMode, java.beans.Visibility
{
	public abstract java.lang.Void addBeanContextMembershipListener(java.beans.beancontext.BeanContextMembershipListener parameter1) ;
	public abstract java.lang.Void removeBeanContextMembershipListener(java.beans.beancontext.BeanContextMembershipListener parameter1) ;
	public abstract java.lang.Object instantiateChild(java.lang.String parameter1) ;
	public abstract java.io.InputStream getResourceAsStream(java.lang.String parameter1, java.beans.beancontext.BeanContextChild parameter2) ;
	public abstract java.net.URL getResource(java.lang.String parameter1, java.beans.beancontext.BeanContextChild parameter2) ;
	java.lang.Object globalHierarchyLock;
}

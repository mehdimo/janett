package java.beans.beancontext;

interface BeanContextChild
{
	public abstract java.beans.beancontext.BeanContext getBeanContext() ;
	public abstract java.lang.Void setBeanContext(java.beans.beancontext.BeanContext parameter1) ;
	public abstract java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public abstract java.lang.Void removePropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public abstract java.lang.Void addVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
	public abstract java.lang.Void removeVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
}

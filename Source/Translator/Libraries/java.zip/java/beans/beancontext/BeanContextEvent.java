package java.beans.beancontext;

abstract class BeanContextEvent extends java.util.EventObject
{
	public java.lang.Boolean isPropagated() ;
	public java.beans.beancontext.BeanContext getBeanContext() ;
	public java.beans.beancontext.BeanContext getPropagatedFrom() ;
	public BeanContextEvent(java.beans.beancontext.BeanContext parameter1) ;
	public java.lang.Void setPropagatedFrom(java.beans.beancontext.BeanContext parameter1) ;
}

package java.beans.beancontext;

abstract class BeanContextServiceRevokedEvent extends java.beans.beancontext.BeanContextEvent
{
	public java.lang.Boolean isCurrentServiceInvalidNow() ;
	public java.beans.beancontext.BeanContextServices getSourceAsBeanContextServices() ;
	public java.lang.Class getServiceClass() ;
	public java.lang.Boolean isServiceClass(java.lang.Class parameter1) ;
	public BeanContextServiceRevokedEvent(java.beans.beancontext.BeanContextServices parameter1, java.lang.Class parameter2, java.lang.Boolean parameter3) ;
}

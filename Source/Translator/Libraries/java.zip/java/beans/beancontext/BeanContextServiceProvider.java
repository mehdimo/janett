package java.beans.beancontext;

interface BeanContextServiceProvider
{
	public abstract java.lang.Void releaseService(java.beans.beancontext.BeanContextServices parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
	public abstract java.util.Iterator getCurrentServiceSelectors(java.beans.beancontext.BeanContextServices parameter1, java.lang.Class parameter2) ;
	public abstract java.lang.Object getService(java.beans.beancontext.BeanContextServices parameter1, java.lang.Object parameter2, java.lang.Class parameter3, java.lang.Object parameter4) ;
}

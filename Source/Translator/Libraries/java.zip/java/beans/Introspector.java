package java.beans;

abstract class Introspector
{
	public java.lang.Void flushCaches() ;
	public java.lang.Void flushFromCaches(java.lang.Class parameter1) ;
	public java.lang.String[] getBeanInfoSearchPath() ;
	public java.lang.Void setBeanInfoSearchPath(java.lang.String[] parameter1) ;
	public java.beans.BeanInfo getBeanInfo(java.lang.Class parameter1) ;
	public java.beans.BeanInfo getBeanInfo(java.lang.Class parameter1, java.lang.Integer parameter2) ;
	public java.lang.String decapitalize(java.lang.String parameter1) ;
	public java.beans.BeanInfo getBeanInfo(java.lang.Class parameter1, java.lang.Class parameter2) ;
	java.lang.Integer USE_ALL_BEANINFO;
	java.lang.Integer IGNORE_IMMEDIATE_BEANINFO;
	java.lang.Integer IGNORE_ALL_BEANINFO;
}

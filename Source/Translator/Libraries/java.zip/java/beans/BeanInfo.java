package java.beans;

interface BeanInfo
{
	public abstract java.lang.Integer getDefaultEventIndex() ;
	public abstract java.lang.Integer getDefaultPropertyIndex() ;
	public abstract java.awt.Image getIcon(java.lang.Integer parameter1) ;
	public abstract java.beans.BeanDescriptor getBeanDescriptor() ;
	public abstract java.beans.BeanInfo[] getAdditionalBeanInfo() ;
	public abstract java.beans.EventSetDescriptor[] getEventSetDescriptors() ;
	public abstract java.beans.MethodDescriptor[] getMethodDescriptors() ;
	public abstract java.beans.PropertyDescriptor[] getPropertyDescriptors() ;
	java.lang.Integer ICON_COLOR_16x16;
	java.lang.Integer ICON_COLOR_32x32;
	java.lang.Integer ICON_MONO_16x16;
	java.lang.Integer ICON_MONO_32x32;
}

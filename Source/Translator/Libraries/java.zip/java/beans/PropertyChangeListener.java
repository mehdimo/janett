package java.beans;

interface PropertyChangeListener implements java.util.EventListener
{
	public abstract java.lang.Void propertyChange(java.beans.PropertyChangeEvent parameter1) ;
}

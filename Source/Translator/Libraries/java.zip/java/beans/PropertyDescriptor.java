package java.beans;

abstract class PropertyDescriptor extends java.beans.FeatureDescriptor
{
	public java.lang.Boolean isBound() ;
	public java.lang.Boolean isConstrained() ;
	public java.lang.Void setBound(java.lang.Boolean parameter1) ;
	public java.lang.Void setConstrained(java.lang.Boolean parameter1) ;
	public java.lang.Class getPropertyEditorClass() ;
	public java.lang.Class getPropertyType() ;
	public java.lang.Void setPropertyEditorClass(java.lang.Class parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.reflect.Method getReadMethod() ;
	public java.lang.reflect.Method getWriteMethod() ;
	public java.lang.Void setReadMethod(java.lang.reflect.Method parameter1) ;
	public java.lang.Void setWriteMethod(java.lang.reflect.Method parameter1) ;
}

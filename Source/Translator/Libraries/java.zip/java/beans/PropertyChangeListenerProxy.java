package java.beans;

abstract class PropertyChangeListenerProxy extends java.util.EventListenerProxy implements java.beans.PropertyChangeListener
{
	public java.lang.Void propertyChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.lang.String getPropertyName() ;
}

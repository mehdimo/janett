package java.beans;

abstract class IntrospectionException extends java.lang.Exception
{
	public IntrospectionException(java.lang.String parameter1) ;
}

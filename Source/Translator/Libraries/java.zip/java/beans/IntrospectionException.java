package java.beans;

abstract class IntrospectionException extends java.lang.Exception
{
}

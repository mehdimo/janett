package java.beans;

interface DesignMode
{
	public abstract java.lang.Boolean isDesignTime() ;
	public abstract java.lang.Void setDesignTime(java.lang.Boolean parameter1) ;
	java.lang.String PROPERTYNAME;
}

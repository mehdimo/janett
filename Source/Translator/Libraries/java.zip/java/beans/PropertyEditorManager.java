package java.beans;

abstract class PropertyEditorManager
{
	public PropertyEditorManager() ;
	public java.lang.String[] getEditorSearchPath() ;
	public java.lang.Void setEditorSearchPath(java.lang.String[] parameter1) ;
	public java.beans.PropertyEditor findEditor(java.lang.Class parameter1) ;
	public java.lang.Void registerEditor(java.lang.Class parameter1, java.lang.Class parameter2) ;
}

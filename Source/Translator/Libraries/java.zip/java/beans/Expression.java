package java.beans;

abstract class Expression extends java.beans.Statement
{
	public java.lang.Object getValue() ;
	public java.lang.Void setValue(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public Expression(java.lang.Object parameter1, java.lang.String parameter2, java.lang.Object[] parameter3) ;
	public Expression(java.lang.Object parameter1, java.lang.Object parameter2, java.lang.String parameter3, java.lang.Object[] parameter4) ;
}

package java.beans;

abstract class Expression extends java.beans.Statement
{
	public java.lang.Object getValue() ;
	public java.lang.Void setValue(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

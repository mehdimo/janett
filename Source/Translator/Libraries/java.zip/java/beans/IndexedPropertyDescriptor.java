package java.beans;

abstract class IndexedPropertyDescriptor extends java.beans.PropertyDescriptor
{
	public java.lang.Class getIndexedPropertyType() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.reflect.Method getIndexedReadMethod() ;
	public java.lang.reflect.Method getIndexedWriteMethod() ;
	public java.lang.Void setIndexedReadMethod(java.lang.reflect.Method parameter1) ;
	public java.lang.Void setIndexedWriteMethod(java.lang.reflect.Method parameter1) ;
	public IndexedPropertyDescriptor(java.lang.String parameter1, java.lang.Class parameter2) ;
	public IndexedPropertyDescriptor(java.lang.String parameter1, java.lang.reflect.Method parameter2, java.lang.reflect.Method parameter3, java.lang.reflect.Method parameter4, java.lang.reflect.Method parameter5) ;
	public IndexedPropertyDescriptor(java.lang.String parameter1, java.lang.Class parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5, java.lang.String parameter6) ;
}

package java.beans;

abstract class IndexedPropertyDescriptor extends java.beans.PropertyDescriptor
{
	public java.lang.Class getIndexedPropertyType() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.reflect.Method getIndexedReadMethod() ;
	public java.lang.reflect.Method getIndexedWriteMethod() ;
	public java.lang.Void setIndexedReadMethod(java.lang.reflect.Method parameter1) ;
	public java.lang.Void setIndexedWriteMethod(java.lang.reflect.Method parameter1) ;
}

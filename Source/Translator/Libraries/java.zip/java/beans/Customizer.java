package java.beans;

interface Customizer
{
	public abstract java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Void setObject(java.lang.Object parameter1) ;
}

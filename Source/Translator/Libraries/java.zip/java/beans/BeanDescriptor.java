package java.beans;

abstract class BeanDescriptor extends java.beans.FeatureDescriptor
{
	public java.lang.Class getBeanClass() ;
	public java.lang.Class getCustomizerClass() ;
	public BeanDescriptor(java.lang.Class parameter1) ;
	public BeanDescriptor(java.lang.Class parameter1, java.lang.Class parameter2) ;
}

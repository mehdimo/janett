package java.beans;

abstract class BeanDescriptor extends java.beans.FeatureDescriptor
{
	public java.lang.Class getBeanClass() ;
	public java.lang.Class getCustomizerClass() ;
}

package java.beans;

abstract class SimpleBeanInfo implements java.beans.BeanInfo
{
	public java.lang.Integer getDefaultEventIndex() ;
	public java.lang.Integer getDefaultPropertyIndex() ;
	public java.awt.Image getIcon(java.lang.Integer parameter1) ;
	public java.beans.BeanDescriptor getBeanDescriptor() ;
	public java.beans.BeanInfo[] getAdditionalBeanInfo() ;
	public java.beans.EventSetDescriptor[] getEventSetDescriptors() ;
	public java.beans.MethodDescriptor[] getMethodDescriptors() ;
	public java.beans.PropertyDescriptor[] getPropertyDescriptors() ;
	public java.awt.Image loadImage(java.lang.String parameter1) ;
}

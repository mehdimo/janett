package java.beans;

abstract class FeatureDescriptor
{
	public FeatureDescriptor() ;
	public java.lang.Boolean isExpert() ;
	public java.lang.Boolean isHidden() ;
	public java.lang.Boolean isPreferred() ;
	public java.lang.Void setExpert(java.lang.Boolean parameter1) ;
	public java.lang.Void setHidden(java.lang.Boolean parameter1) ;
	public java.lang.Void setPreferred(java.lang.Boolean parameter1) ;
	public java.lang.String getDisplayName() ;
	public java.lang.String getName() ;
	public java.lang.String getShortDescription() ;
	public java.lang.Void setDisplayName(java.lang.String parameter1) ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public java.lang.Void setShortDescription(java.lang.String parameter1) ;
	public java.util.Enumeration attributeNames() ;
	public java.lang.Object getValue(java.lang.String parameter1) ;
	public java.lang.Void setValue(java.lang.String parameter1, java.lang.Object parameter2) ;
}

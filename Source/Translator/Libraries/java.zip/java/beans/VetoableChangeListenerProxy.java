package java.beans;

abstract class VetoableChangeListenerProxy extends java.util.EventListenerProxy implements java.beans.VetoableChangeListener
{
	public java.lang.Void vetoableChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.lang.String getPropertyName() ;
}

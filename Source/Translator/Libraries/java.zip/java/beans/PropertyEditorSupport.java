package java.beans;

abstract class PropertyEditorSupport implements java.beans.PropertyEditor
{
	public PropertyEditorSupport() ;
	public java.lang.Void firePropertyChange() ;
	public java.lang.Boolean isPaintable() ;
	public java.lang.Boolean supportsCustomEditor() ;
	public java.awt.Component getCustomEditor() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Object getValue() ;
	public PropertyEditorSupport(java.lang.Object parameter1) ;
	public java.lang.Void setValue(java.lang.Object parameter1) ;
	public java.lang.String getAsText() ;
	public java.lang.String getJavaInitializationString() ;
	public java.lang.String[] getTags() ;
	public java.lang.Void setAsText(java.lang.String parameter1) ;
	public java.lang.Void paintValue(java.awt.Graphics parameter1, java.awt.Rectangle parameter2) ;
}

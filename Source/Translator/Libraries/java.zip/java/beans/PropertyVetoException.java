package java.beans;

abstract class PropertyVetoException extends java.lang.Exception
{
	public java.beans.PropertyChangeEvent getPropertyChangeEvent() ;
	public PropertyVetoException(java.lang.String parameter1, java.beans.PropertyChangeEvent parameter2) ;
}

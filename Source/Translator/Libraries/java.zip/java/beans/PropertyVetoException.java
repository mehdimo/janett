package java.beans;

abstract class PropertyVetoException extends java.lang.Exception
{
	public java.beans.PropertyChangeEvent getPropertyChangeEvent() ;
}

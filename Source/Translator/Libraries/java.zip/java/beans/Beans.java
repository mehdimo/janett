package java.beans;

abstract class Beans
{
	public java.lang.Boolean isDesignTime() ;
	public java.lang.Boolean isGuiAvailable() ;
	public java.lang.Void setDesignTime(java.lang.Boolean parameter1) ;
	public java.lang.Void setGuiAvailable(java.lang.Boolean parameter1) ;
	public java.lang.Boolean isInstanceOf(java.lang.Object parameter1, java.lang.Class parameter2) ;
	public java.lang.Object getInstanceOf(java.lang.Object parameter1, java.lang.Class parameter2) ;
	public java.lang.Object instantiate(java.lang.ClassLoader parameter1, java.lang.String parameter2) ;
	public java.lang.Object instantiate(java.lang.ClassLoader parameter1, java.lang.String parameter2, java.beans.beancontext.BeanContext parameter3) ;
	public java.lang.Object instantiate(java.lang.ClassLoader parameter1, java.lang.String parameter2, java.beans.beancontext.BeanContext parameter3, java.beans.AppletInitializer parameter4) ;
}

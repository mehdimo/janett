package java.beans;

abstract class Statement
{
	public java.lang.Void execute() ;
	public java.lang.Object getTarget() ;
	public java.lang.Object[] getArguments() ;
	public java.lang.String getMethodName() ;
	public java.lang.String toString() ;
}

package java.beans;

abstract class Statement
{
	public java.lang.Void execute() ;
	public java.lang.Object getTarget() ;
	public java.lang.Object[] getArguments() ;
	public java.lang.String getMethodName() ;
	public java.lang.String toString() ;
	public Statement(java.lang.Object parameter1, java.lang.String parameter2, java.lang.Object[] parameter3) ;
}

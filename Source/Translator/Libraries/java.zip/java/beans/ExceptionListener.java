package java.beans;

interface ExceptionListener
{
	public abstract java.lang.Void exceptionThrown(java.lang.Exception parameter1) ;
}

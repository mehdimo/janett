package java.beans;

abstract class VetoableChangeSupport implements java.io.Serializable
{
	public java.lang.Void fireVetoableChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.beans.VetoableChangeListener[] getVetoableChangeListeners() ;
	public java.lang.Void addVetoableChangeListener(java.beans.VetoableChangeListener parameter1) ;
	public java.lang.Void removeVetoableChangeListener(java.beans.VetoableChangeListener parameter1) ;
	public java.lang.Boolean hasListeners(java.lang.String parameter1) ;
	public java.lang.Void fireVetoableChange(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void fireVetoableChange(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public java.beans.VetoableChangeListener[] getVetoableChangeListeners(java.lang.String parameter1) ;
	public java.lang.Void addVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
	public java.lang.Void removeVetoableChangeListener(java.lang.String parameter1, java.beans.VetoableChangeListener parameter2) ;
	public java.lang.Void fireVetoableChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
}

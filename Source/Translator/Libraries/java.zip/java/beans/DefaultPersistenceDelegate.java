package java.beans;

abstract class DefaultPersistenceDelegate extends java.beans.PersistenceDelegate
{
	public java.lang.Boolean mutatesTo(java.lang.Object parameter1, java.lang.Object parameter2) ;
	public java.beans.Expression instantiate(java.lang.Object parameter1, java.beans.Encoder parameter2) ;
	public java.lang.Void initialize(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.Object parameter3, java.beans.Encoder parameter4) ;
}

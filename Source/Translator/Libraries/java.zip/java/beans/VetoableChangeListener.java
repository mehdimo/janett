package java.beans;

interface VetoableChangeListener implements java.util.EventListener
{
	public abstract java.lang.Void vetoableChange(java.beans.PropertyChangeEvent parameter1) ;
}

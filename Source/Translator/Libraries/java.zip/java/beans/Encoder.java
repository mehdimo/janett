package java.beans;

abstract class Encoder
{
	public Encoder() ;
	public java.beans.ExceptionListener getExceptionListener() ;
	public java.lang.Void setExceptionListener(java.beans.ExceptionListener parameter1) ;
	public java.lang.Void writeExpression(java.beans.Expression parameter1) ;
	public java.lang.Void writeStatement(java.beans.Statement parameter1) ;
	public java.lang.Void writeObject(java.lang.Object parameter1) ;
	public java.beans.PersistenceDelegate getPersistenceDelegate(java.lang.Class parameter1) ;
	public java.lang.Void setPersistenceDelegate(java.lang.Class parameter1, java.beans.PersistenceDelegate parameter2) ;
	public java.lang.Object get(java.lang.Object parameter1) ;
	public java.lang.Object remove(java.lang.Object parameter1) ;
}

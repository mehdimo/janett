package java.beans;

abstract class EventSetDescriptor extends java.beans.FeatureDescriptor
{
	public java.lang.Boolean isInDefaultEventSet() ;
	public java.lang.Boolean isUnicast() ;
	public java.lang.Void setInDefaultEventSet(java.lang.Boolean parameter1) ;
	public java.lang.Void setUnicast(java.lang.Boolean parameter1) ;
	public java.beans.MethodDescriptor[] getListenerMethodDescriptors() ;
	public java.lang.Class getListenerType() ;
	public java.lang.reflect.Method getAddListenerMethod() ;
	public java.lang.reflect.Method getGetListenerMethod() ;
	public java.lang.reflect.Method getRemoveListenerMethod() ;
	public java.lang.reflect.Method[] getListenerMethods() ;
}

package java.beans;

abstract class EventSetDescriptor extends java.beans.FeatureDescriptor
{
	public java.lang.Boolean isInDefaultEventSet() ;
	public java.lang.Boolean isUnicast() ;
	public java.lang.Void setInDefaultEventSet(java.lang.Boolean parameter1) ;
	public java.lang.Void setUnicast(java.lang.Boolean parameter1) ;
	public java.beans.MethodDescriptor[] getListenerMethodDescriptors() ;
	public java.lang.Class getListenerType() ;
	public java.lang.reflect.Method getAddListenerMethod() ;
	public java.lang.reflect.Method getGetListenerMethod() ;
	public java.lang.reflect.Method getRemoveListenerMethod() ;
	public java.lang.reflect.Method[] getListenerMethods() ;
	public EventSetDescriptor(java.lang.Class parameter1, java.lang.String parameter2, java.lang.Class parameter3, java.lang.String parameter4) ;
	public EventSetDescriptor(java.lang.String parameter1, java.lang.Class parameter2, java.beans.MethodDescriptor[] parameter3, java.lang.reflect.Method parameter4, java.lang.reflect.Method parameter5) ;
	public EventSetDescriptor(java.lang.String parameter1, java.lang.Class parameter2, java.lang.reflect.Method[] parameter3, java.lang.reflect.Method parameter4, java.lang.reflect.Method parameter5) ;
	public EventSetDescriptor(java.lang.Class parameter1, java.lang.String parameter2, java.lang.Class parameter3, java.lang.String[] parameter4, java.lang.String parameter5, java.lang.String parameter6) ;
	public EventSetDescriptor(java.lang.String parameter1, java.lang.Class parameter2, java.lang.reflect.Method[] parameter3, java.lang.reflect.Method parameter4, java.lang.reflect.Method parameter5, java.lang.reflect.Method parameter6) ;
	public EventSetDescriptor(java.lang.Class parameter1, java.lang.String parameter2, java.lang.Class parameter3, java.lang.String[] parameter4, java.lang.String parameter5, java.lang.String parameter6, java.lang.String parameter7) ;
}

package java.beans;

interface AppletInitializer
{
	public abstract java.lang.Void activate(java.applet.Applet parameter1) ;
	public abstract java.lang.Void initialize(java.applet.Applet parameter1, java.beans.beancontext.BeanContext parameter2) ;
}

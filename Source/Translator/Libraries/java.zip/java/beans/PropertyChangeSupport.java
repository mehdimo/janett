package java.beans;

abstract class PropertyChangeSupport implements java.io.Serializable
{
	public java.lang.Void firePropertyChange(java.beans.PropertyChangeEvent parameter1) ;
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners() ;
	public java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public java.lang.Boolean hasListeners(java.lang.String parameter1) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.Boolean parameter3) ;
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners(java.lang.String parameter1) ;
	public java.lang.Void addPropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void removePropertyChangeListener(java.lang.String parameter1, java.beans.PropertyChangeListener parameter2) ;
	public java.lang.Void firePropertyChange(java.lang.String parameter1, java.lang.Object parameter2, java.lang.Object parameter3) ;
}

package java.beans;

abstract class EventHandler implements java.lang.reflect.InvocationHandler
{
	public java.lang.Object getTarget() ;
	public java.lang.String getAction() ;
	public java.lang.String getEventPropertyName() ;
	public java.lang.String getListenerMethodName() ;
	public java.lang.Object invoke(java.lang.Object parameter1, java.lang.reflect.Method parameter2, java.lang.Object[] parameter3) ;
	public java.lang.Object create(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.String parameter3) ;
	public java.lang.Object create(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.String parameter3, java.lang.String parameter4) ;
	public java.lang.Object create(java.lang.Class parameter1, java.lang.Object parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5) ;
}

package java.beans;

interface PropertyEditor
{
	public abstract java.lang.Boolean isPaintable() ;
	public abstract java.lang.Boolean supportsCustomEditor() ;
	public abstract java.awt.Component getCustomEditor() ;
	public abstract java.lang.Void addPropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Void removePropertyChangeListener(java.beans.PropertyChangeListener parameter1) ;
	public abstract java.lang.Object getValue() ;
	public abstract java.lang.Void setValue(java.lang.Object parameter1) ;
	public abstract java.lang.String getAsText() ;
	public abstract java.lang.String getJavaInitializationString() ;
	public abstract java.lang.String[] getTags() ;
	public abstract java.lang.Void setAsText(java.lang.String parameter1) ;
	public abstract java.lang.Void paintValue(java.awt.Graphics parameter1, java.awt.Rectangle parameter2) ;
}

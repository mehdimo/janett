package java.io;

abstract class UnsupportedEncodingException extends java.io.IOException
{
	public UnsupportedEncodingException() ;
	public UnsupportedEncodingException(java.lang.String parameter1) ;
}

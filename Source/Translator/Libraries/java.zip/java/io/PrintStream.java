package java.io;

abstract class PrintStream extends java.io.FilterOutputStream
{
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void println() ;
	public java.lang.Void setError() ;
	public java.lang.Boolean checkError() ;
	public java.lang.Void print(java.lang.Character parameter1) ;
	public java.lang.Void println(java.lang.Character parameter1) ;
	public java.lang.Void print(java.lang.Double parameter1) ;
	public java.lang.Void println(java.lang.Double parameter1) ;
	public java.lang.Void print(java.lang.Float parameter1) ;
	public java.lang.Void println(java.lang.Float parameter1) ;
	public java.lang.Void print(java.lang.Integer parameter1) ;
	public java.lang.Void println(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void print(java.lang.Long parameter1) ;
	public java.lang.Void println(java.lang.Long parameter1) ;
	public java.lang.Void print(java.lang.Boolean parameter1) ;
	public java.lang.Void println(java.lang.Boolean parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void print(java.lang.Character[] parameter1) ;
	public java.lang.Void println(java.lang.Character[] parameter1) ;
	public java.lang.Void print(java.lang.Object parameter1) ;
	public java.lang.Void println(java.lang.Object parameter1) ;
	public java.lang.Void print(java.lang.String parameter1) ;
	public java.lang.Void println(java.lang.String parameter1) ;
}

package java.io;

interface DataInput
{
	public abstract java.lang.Byte readByte() ;
	public abstract java.lang.Character readChar() ;
	public abstract java.lang.Double readDouble() ;
	public abstract java.lang.Float readFloat() ;
	public abstract java.lang.Integer readInt() ;
	public abstract java.lang.Integer readUnsignedByte() ;
	public abstract java.lang.Integer readUnsignedShort() ;
	public abstract java.lang.Long readLong() ;
	public abstract java.lang.Short readShort() ;
	public abstract java.lang.Boolean readBoolean() ;
	public abstract java.lang.Integer skipBytes(java.lang.Integer parameter1) ;
	public abstract java.lang.Void readFully(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void readFully(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.String readLine() ;
	public abstract java.lang.String readUTF() ;
}

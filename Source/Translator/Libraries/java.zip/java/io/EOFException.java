package java.io;

abstract class EOFException extends java.io.IOException
{
	public EOFException() ;
	public EOFException(java.lang.String parameter1) ;
}

package java.io;

abstract class EOFException extends java.io.IOException
{
}

package java.io;

interface FilenameFilter
{
	public abstract java.lang.Boolean accept(java.io.File parameter1, java.lang.String parameter2) ;
}

package java.io;

abstract class StringWriter extends java.io.Writer
{
	public StringWriter() ;
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public StringWriter(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.String toString() ;
	public java.lang.Void write(java.lang.String parameter1) ;
	public java.lang.Void write(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.StringBuffer getBuffer() ;
}

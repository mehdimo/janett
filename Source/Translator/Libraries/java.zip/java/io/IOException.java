package java.io;

abstract class IOException extends java.lang.Exception
{
	public IOException() ;
	public IOException(java.lang.String parameter1) ;
}

package java.io;

abstract class IOException extends java.lang.Exception
{
}

package java.io;

abstract class FilterWriter extends java.io.Writer
{
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void write(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

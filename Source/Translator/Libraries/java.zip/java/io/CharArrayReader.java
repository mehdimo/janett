package java.io;

abstract class CharArrayReader extends java.io.Reader
{
	public java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Void reset() ;
	public java.lang.Boolean markSupported() ;
	public java.lang.Boolean ready() ;
	public java.lang.Void mark(java.lang.Integer parameter1) ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package java.io;

abstract class ByteArrayOutputStream extends java.io.OutputStream
{
	public java.lang.Integer size() ;
	public ByteArrayOutputStream() ;
	public java.lang.Void close() ;
	public java.lang.Void reset() ;
	public java.lang.Byte[] toByteArray() ;
	public ByteArrayOutputStream(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void writeTo(java.io.OutputStream parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Integer parameter1) ;
	public java.lang.String toString(java.lang.String parameter1) ;
}

package java.io;

interface DataOutput
{
	public abstract java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public abstract java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public abstract java.lang.Void write(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public abstract java.lang.Void writeLong(java.lang.Long parameter1) ;
	public abstract java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeBytes(java.lang.String parameter1) ;
	public abstract java.lang.Void writeChars(java.lang.String parameter1) ;
	public abstract java.lang.Void writeUTF(java.lang.String parameter1) ;
}

package java.io;

abstract class NotSerializableException extends java.io.ObjectStreamException
{
}

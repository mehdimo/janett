package java.io;

abstract class NotSerializableException extends java.io.ObjectStreamException
{
	public NotSerializableException() ;
	public NotSerializableException(java.lang.String parameter1) ;
}

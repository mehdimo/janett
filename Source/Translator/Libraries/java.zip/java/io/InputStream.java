package java.io;

abstract class InputStream
{
	public java.lang.Integer available() ;
	public abstract java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Void reset() ;
	public java.lang.Boolean markSupported() ;
	public java.lang.Void mark(java.lang.Integer parameter1) ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

package java.io;

abstract class FileReader extends java.io.InputStreamReader
{
}

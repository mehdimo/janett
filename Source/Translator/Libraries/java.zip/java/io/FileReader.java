package java.io;

abstract class FileReader extends java.io.InputStreamReader
{
	public FileReader(java.io.File parameter1) ;
	public FileReader(java.io.FileDescriptor parameter1) ;
	public FileReader(java.lang.String parameter1) ;
}

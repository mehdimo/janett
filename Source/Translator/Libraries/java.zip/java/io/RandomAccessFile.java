package java.io;

abstract class RandomAccessFile implements java.io.DataOutput, java.io.DataInput
{
	public java.lang.Byte readByte() ;
	public java.lang.Character readChar() ;
	public java.lang.Double readDouble() ;
	public java.lang.Float readFloat() ;
	public java.lang.Integer read() ;
	public java.lang.Integer readInt() ;
	public java.lang.Integer readUnsignedByte() ;
	public java.lang.Integer readUnsignedShort() ;
	public java.lang.Long getFilePointer() ;
	public java.lang.Long length() ;
	public java.lang.Long readLong() ;
	public java.lang.Short readShort() ;
	public java.lang.Void close() ;
	public java.lang.Boolean readBoolean() ;
	public java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public java.lang.Integer skipBytes(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public java.lang.Void seek(java.lang.Long parameter1) ;
	public java.lang.Void setLength(java.lang.Long parameter1) ;
	public java.lang.Void writeLong(java.lang.Long parameter1) ;
	public java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.io.FileDescriptor getFD() ;
	public java.lang.String readLine() ;
	public java.lang.String readUTF() ;
	public java.lang.Void writeBytes(java.lang.String parameter1) ;
	public java.lang.Void writeChars(java.lang.String parameter1) ;
	public java.lang.Void writeUTF(java.lang.String parameter1) ;
	public java.nio.channels.FileChannel getChannel() ;
	public RandomAccessFile(java.io.File parameter1, java.lang.String parameter2) ;
	public RandomAccessFile(java.lang.String parameter1, java.lang.String parameter2) ;
}

package java.io;

interface ObjectInputValidation
{
	public abstract java.lang.Void validateObject() ;
}

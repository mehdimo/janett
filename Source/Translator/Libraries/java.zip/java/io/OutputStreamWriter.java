package java.io;

abstract class OutputStreamWriter extends java.io.Writer
{
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public OutputStreamWriter(java.io.OutputStream parameter1) ;
	public java.lang.String getEncoding() ;
	public java.lang.Void write(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public OutputStreamWriter(java.io.OutputStream parameter1, java.lang.String parameter2) ;
	public OutputStreamWriter(java.io.OutputStream parameter1, java.nio.charset.Charset parameter2) ;
	public OutputStreamWriter(java.io.OutputStream parameter1, java.nio.charset.CharsetEncoder parameter2) ;
}

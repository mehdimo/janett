package java.io;

abstract class FilterOutputStream extends java.io.OutputStream
{
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

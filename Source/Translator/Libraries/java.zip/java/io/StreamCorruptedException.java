package java.io;

abstract class StreamCorruptedException extends java.io.ObjectStreamException
{
}

package java.io;

abstract class StreamCorruptedException extends java.io.ObjectStreamException
{
	public StreamCorruptedException() ;
	public StreamCorruptedException(java.lang.String parameter1) ;
}

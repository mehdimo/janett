package java.io;

interface FileFilter
{
	public abstract java.lang.Boolean accept(java.io.File parameter1) ;
}

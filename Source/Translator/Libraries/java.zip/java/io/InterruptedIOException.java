package java.io;

abstract class InterruptedIOException extends java.io.IOException
{
	java.lang.Integer bytesTransferred;
}

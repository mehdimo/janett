package java.io;

abstract class InterruptedIOException extends java.io.IOException
{
	public InterruptedIOException() ;
	public InterruptedIOException(java.lang.String parameter1) ;
	java.lang.Integer bytesTransferred;
}

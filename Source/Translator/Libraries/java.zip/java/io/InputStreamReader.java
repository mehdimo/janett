package java.io;

abstract class InputStreamReader extends java.io.Reader
{
	public java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Boolean ready() ;
	public java.lang.Integer read(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public InputStreamReader(java.io.InputStream parameter1) ;
	public java.lang.String getEncoding() ;
	public InputStreamReader(java.io.InputStream parameter1, java.lang.String parameter2) ;
	public InputStreamReader(java.io.InputStream parameter1, java.nio.charset.Charset parameter2) ;
	public InputStreamReader(java.io.InputStream parameter1, java.nio.charset.CharsetDecoder parameter2) ;
}

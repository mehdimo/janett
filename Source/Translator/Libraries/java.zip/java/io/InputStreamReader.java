package java.io;

abstract class InputStreamReader extends java.io.Reader
{
	public java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Boolean ready() ;
	public java.lang.Integer read(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.String getEncoding() ;
}

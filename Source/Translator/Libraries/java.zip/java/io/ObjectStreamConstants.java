package java.io;

interface ObjectStreamConstants
{
	java.lang.Short STREAM_MAGIC;
	java.lang.Short STREAM_VERSION;
	java.lang.Byte TC_BASE;
	java.lang.Byte TC_NULL;
	java.lang.Byte TC_REFERENCE;
	java.lang.Byte TC_CLASSDESC;
	java.lang.Byte TC_OBJECT;
	java.lang.Byte TC_STRING;
	java.lang.Byte TC_ARRAY;
	java.lang.Byte TC_CLASS;
	java.lang.Byte TC_BLOCKDATA;
	java.lang.Byte TC_ENDBLOCKDATA;
	java.lang.Byte TC_RESET;
	java.lang.Byte TC_BLOCKDATALONG;
	java.lang.Byte TC_EXCEPTION;
	java.lang.Byte TC_LONGSTRING;
	java.lang.Byte TC_PROXYCLASSDESC;
	java.lang.Byte TC_MAX;
	java.lang.Integer baseWireHandle;
	java.lang.Byte SC_WRITE_METHOD;
	java.lang.Byte SC_BLOCK_DATA;
	java.lang.Byte SC_SERIALIZABLE;
	java.lang.Byte SC_EXTERNALIZABLE;
	java.io.SerializablePermission SUBSTITUTION_PERMISSION;
	java.io.SerializablePermission SUBCLASS_IMPLEMENTATION_PERMISSION;
	java.lang.Integer PROTOCOL_VERSION_1;
	java.lang.Integer PROTOCOL_VERSION_2;
}

package java.io;

abstract class FileInputStream extends java.io.InputStream
{
	public java.lang.Integer available() ;
	public java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Void finalize() ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public FileInputStream(java.io.File parameter1) ;
	public java.io.FileDescriptor getFD() ;
	public FileInputStream(java.io.FileDescriptor parameter1) ;
	public FileInputStream(java.lang.String parameter1) ;
	public java.nio.channels.FileChannel getChannel() ;
}

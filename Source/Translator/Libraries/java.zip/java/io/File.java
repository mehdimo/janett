package java.io;

abstract class File implements java.io.Serializable, java.lang.Comparable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Long lastModified() ;
	public java.lang.Long length() ;
	public java.lang.Void deleteOnExit() ;
	public java.lang.Boolean canRead() ;
	public java.lang.Boolean canWrite() ;
	public java.lang.Boolean createNewFile() ;
	public java.lang.Boolean delete() ;
	public java.lang.Boolean exists() ;
	public java.lang.Boolean isAbsolute() ;
	public java.lang.Boolean isDirectory() ;
	public java.lang.Boolean isFile() ;
	public java.lang.Boolean isHidden() ;
	public java.lang.Boolean mkdir() ;
	public java.lang.Boolean mkdirs() ;
	public java.lang.Boolean setReadOnly() ;
	public java.lang.Boolean setLastModified(java.lang.Long parameter1) ;
	public java.io.File getAbsoluteFile() ;
	public java.io.File getCanonicalFile() ;
	public java.io.File getParentFile() ;
	public java.io.File[] listFiles() ;
	public java.io.File[] listRoots() ;
	public java.lang.Integer compareTo(java.io.File parameter1) ;
	public java.lang.Boolean renameTo(java.io.File parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getAbsolutePath() ;
	public java.lang.String getCanonicalPath() ;
	public java.lang.String getName() ;
	public java.lang.String getParent() ;
	public java.lang.String getPath() ;
	public java.lang.String toString() ;
	public java.lang.String[] list() ;
	public java.net.URI toURI() ;
	public java.net.URL toURL() ;
	public java.io.File[] listFiles(java.io.FileFilter parameter1) ;
	public java.io.File[] listFiles(java.io.FilenameFilter parameter1) ;
	public java.lang.String[] list(java.io.FilenameFilter parameter1) ;
	public java.io.File createTempFile(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.io.File createTempFile(java.lang.String parameter1, java.lang.String parameter2, java.io.File parameter3) ;
	java.lang.Character separatorChar;
	java.lang.String separator;
	java.lang.Character pathSeparatorChar;
	java.lang.String pathSeparator;
}

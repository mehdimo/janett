package java.io;

abstract class PipedReader extends java.io.Reader
{
	public java.lang.Integer read() ;
	public PipedReader() ;
	public java.lang.Void close() ;
	public java.lang.Boolean ready() ;
	public java.lang.Integer read(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public PipedReader(java.io.PipedWriter parameter1) ;
	public java.lang.Void connect(java.io.PipedWriter parameter1) ;
}

package java.io;

abstract class StreamTokenizer
{
	public java.lang.Integer lineno() ;
	public java.lang.Integer nextToken() ;
	public java.lang.Void parseNumbers() ;
	public java.lang.Void pushBack() ;
	public java.lang.Void resetSyntax() ;
	public java.lang.Void commentChar(java.lang.Integer parameter1) ;
	public java.lang.Void ordinaryChar(java.lang.Integer parameter1) ;
	public java.lang.Void quoteChar(java.lang.Integer parameter1) ;
	public java.lang.Void ordinaryChars(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void whitespaceChars(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void wordChars(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void eolIsSignificant(java.lang.Boolean parameter1) ;
	public java.lang.Void lowerCaseMode(java.lang.Boolean parameter1) ;
	public java.lang.Void slashSlashComments(java.lang.Boolean parameter1) ;
	public java.lang.Void slashStarComments(java.lang.Boolean parameter1) ;
	public StreamTokenizer(java.io.InputStream parameter1) ;
	public StreamTokenizer(java.io.Reader parameter1) ;
	public java.lang.String toString() ;
	java.lang.Integer ttype;
	java.lang.Integer TT_EOF;
	java.lang.Integer TT_EOL;
	java.lang.Integer TT_NUMBER;
	java.lang.Integer TT_WORD;
	java.lang.String sval;
	java.lang.Double nval;
}

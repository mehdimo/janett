package java.io;

interface Serializable
{
}

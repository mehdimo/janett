package java.io;

abstract class OptionalDataException extends java.io.ObjectStreamException
{
	java.lang.Integer length;
	java.lang.Boolean eof;
}

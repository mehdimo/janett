package java.io;

abstract class NotActiveException extends java.io.ObjectStreamException
{
	public NotActiveException() ;
	public NotActiveException(java.lang.String parameter1) ;
}

package java.io;

abstract class NotActiveException extends java.io.ObjectStreamException
{
}

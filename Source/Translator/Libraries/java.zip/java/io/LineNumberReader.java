package java.io;

abstract class LineNumberReader extends java.io.BufferedReader
{
	public java.lang.Integer getLineNumber() ;
	public java.lang.Integer read() ;
	public java.lang.Void reset() ;
	public java.lang.Void mark(java.lang.Integer parameter1) ;
	public java.lang.Void setLineNumber(java.lang.Integer parameter1) ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public LineNumberReader(java.io.Reader parameter1) ;
	public LineNumberReader(java.io.Reader parameter1, java.lang.Integer parameter2) ;
	public java.lang.String readLine() ;
}

package java.io;

interface ObjectOutput implements java.io.DataOutput
{
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void flush() ;
	public abstract java.lang.Void write(java.lang.Integer parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1) ;
	public abstract java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public abstract java.lang.Void writeObject(java.lang.Object parameter1) ;
}

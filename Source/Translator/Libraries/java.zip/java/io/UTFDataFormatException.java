package java.io;

abstract class UTFDataFormatException extends java.io.IOException
{
}

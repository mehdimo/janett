package java.io;

abstract class UTFDataFormatException extends java.io.IOException
{
	public UTFDataFormatException() ;
	public UTFDataFormatException(java.lang.String parameter1) ;
}

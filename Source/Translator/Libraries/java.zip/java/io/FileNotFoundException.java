package java.io;

abstract class FileNotFoundException extends java.io.IOException
{
	public FileNotFoundException() ;
	public FileNotFoundException(java.lang.String parameter1) ;
}

package java.io;

abstract class FileNotFoundException extends java.io.IOException
{
}

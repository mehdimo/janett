package java.io;

abstract class FileDescriptor
{
	public java.lang.Void sync() ;
	public java.lang.Boolean valid() ;
	java.io.FileDescriptor in;
	java.io.FileDescriptor out;
	java.io.FileDescriptor err;
}

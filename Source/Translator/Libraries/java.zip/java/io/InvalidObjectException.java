package java.io;

abstract class InvalidObjectException extends java.io.ObjectStreamException
{
	public InvalidObjectException(java.lang.String parameter1) ;
}

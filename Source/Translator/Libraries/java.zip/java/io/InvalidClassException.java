package java.io;

abstract class InvalidClassException extends java.io.ObjectStreamException
{
	public java.lang.String getMessage() ;
	public InvalidClassException(java.lang.String parameter1) ;
	public InvalidClassException(java.lang.String parameter1, java.lang.String parameter2) ;
	java.lang.String classname;
}

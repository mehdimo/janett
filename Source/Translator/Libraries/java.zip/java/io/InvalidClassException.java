package java.io;

abstract class InvalidClassException extends java.io.ObjectStreamException
{
	public java.lang.String getMessage() ;
	java.lang.String classname;
}

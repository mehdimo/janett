package java.io;

abstract class DataInputStream extends java.io.FilterInputStream implements java.io.DataInput
{
	public java.lang.Byte readByte() ;
	public java.lang.Character readChar() ;
	public java.lang.Double readDouble() ;
	public java.lang.Float readFloat() ;
	public java.lang.Integer readInt() ;
	public java.lang.Integer readUnsignedByte() ;
	public java.lang.Integer readUnsignedShort() ;
	public java.lang.Long readLong() ;
	public java.lang.Short readShort() ;
	public java.lang.Boolean readBoolean() ;
	public java.lang.Integer skipBytes(java.lang.Integer parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataInputStream(java.io.InputStream parameter1) ;
	public java.lang.String readLine() ;
	public java.lang.String readUTF() ;
	public java.lang.String readUTF(java.io.DataInput parameter1) ;
}

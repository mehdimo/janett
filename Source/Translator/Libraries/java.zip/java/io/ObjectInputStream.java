package java.io;

abstract class ObjectInputStream extends java.io.InputStream implements java.io.ObjectInput, java.io.ObjectStreamConstants
{
	public java.lang.Byte readByte() ;
	public java.lang.Character readChar() ;
	public java.lang.Double readDouble() ;
	public java.lang.Float readFloat() ;
	public java.lang.Integer available() ;
	public java.lang.Integer read() ;
	public java.lang.Integer readInt() ;
	public java.lang.Integer readUnsignedByte() ;
	public java.lang.Integer readUnsignedShort() ;
	public java.lang.Long readLong() ;
	public java.lang.Short readShort() ;
	public ObjectInputStream() ;
	public java.lang.Void close() ;
	public java.lang.Void defaultReadObject() ;
	public java.lang.Void readStreamHeader() ;
	public java.lang.Boolean readBoolean() ;
	public java.lang.Integer skipBytes(java.lang.Integer parameter1) ;
	public java.lang.Boolean enableResolveObject(java.lang.Boolean parameter1) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void readFully(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public ObjectInputStream(java.io.InputStream parameter1) ;
	public java.io.ObjectInputStream.GetField readFields() ;
	public java.lang.Void registerValidation(java.io.ObjectInputValidation parameter1, java.lang.Integer parameter2) ;
	public java.io.ObjectStreamClass readClassDescriptor() ;
	public java.lang.Object readObject() ;
	public java.lang.Object readObjectOverride() ;
	public java.lang.Object readUnshared() ;
	public java.lang.String readLine() ;
	public java.lang.String readUTF() ;
	public java.lang.Class resolveClass(java.io.ObjectStreamClass parameter1) ;
	public java.lang.Class resolveProxyClass(java.lang.String[] parameter1) ;
	public java.lang.Object resolveObject(java.lang.Object parameter1) ;
	abstract class GetField
	{
		public GetField() ;
		public abstract java.io.ObjectStreamClass getObjectStreamClass() ;
		public abstract java.lang.Boolean defaulted(java.lang.String parameter1) ;
		public abstract java.lang.Byte get(java.lang.String parameter1, java.lang.Byte parameter2) ;
		public abstract java.lang.Character get(java.lang.String parameter1, java.lang.Character parameter2) ;
		public abstract java.lang.Double get(java.lang.String parameter1, java.lang.Double parameter2) ;
		public abstract java.lang.Float get(java.lang.String parameter1, java.lang.Float parameter2) ;
		public abstract java.lang.Integer get(java.lang.String parameter1, java.lang.Integer parameter2) ;
		public abstract java.lang.Long get(java.lang.String parameter1, java.lang.Long parameter2) ;
		public abstract java.lang.Short get(java.lang.String parameter1, java.lang.Short parameter2) ;
		public abstract java.lang.Boolean get(java.lang.String parameter1, java.lang.Boolean parameter2) ;
		public abstract java.lang.Object get(java.lang.String parameter1, java.lang.Object parameter2) ;
	}
}

package java.io;

abstract class PushbackInputStream extends java.io.FilterInputStream
{
	public java.lang.Integer available() ;
	public java.lang.Integer read() ;
	public java.lang.Void close() ;
	public java.lang.Boolean markSupported() ;
	public java.lang.Void unread(java.lang.Integer parameter1) ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Void unread(java.lang.Byte[] parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void unread(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public PushbackInputStream(java.io.InputStream parameter1) ;
	public PushbackInputStream(java.io.InputStream parameter1, java.lang.Integer parameter2) ;
}

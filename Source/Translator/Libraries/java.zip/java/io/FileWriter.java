package java.io;

abstract class FileWriter extends java.io.OutputStreamWriter
{
}

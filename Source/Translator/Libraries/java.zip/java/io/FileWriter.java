package java.io;

abstract class FileWriter extends java.io.OutputStreamWriter
{
	public FileWriter(java.io.File parameter1) ;
	public FileWriter(java.io.File parameter1, java.lang.Boolean parameter2) ;
	public FileWriter(java.io.FileDescriptor parameter1) ;
	public FileWriter(java.lang.String parameter1) ;
	public FileWriter(java.lang.String parameter1, java.lang.Boolean parameter2) ;
}

package java.io;

abstract class DataOutputStream extends java.io.FilterOutputStream implements java.io.DataOutput
{
	public java.lang.Integer size() ;
	public java.lang.Void flush() ;
	public java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public java.lang.Void writeLong(java.lang.Long parameter1) ;
	public java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public DataOutputStream(java.io.OutputStream parameter1) ;
	public java.lang.Void writeBytes(java.lang.String parameter1) ;
	public java.lang.Void writeChars(java.lang.String parameter1) ;
	public java.lang.Void writeUTF(java.lang.String parameter1) ;
}

package java.io;

abstract class FileOutputStream extends java.io.OutputStream
{
	public java.lang.Void close() ;
	public java.lang.Void finalize() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public FileOutputStream(java.io.File parameter1) ;
	public FileOutputStream(java.io.File parameter1, java.lang.Boolean parameter2) ;
	public java.io.FileDescriptor getFD() ;
	public FileOutputStream(java.io.FileDescriptor parameter1) ;
	public FileOutputStream(java.lang.String parameter1) ;
	public FileOutputStream(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.nio.channels.FileChannel getChannel() ;
}

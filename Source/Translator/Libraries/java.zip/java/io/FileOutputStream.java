package java.io;

abstract class FileOutputStream extends java.io.OutputStream
{
	public java.lang.Void close() ;
	public java.lang.Void finalize() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.io.FileDescriptor getFD() ;
	public java.nio.channels.FileChannel getChannel() ;
}

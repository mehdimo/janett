package java.io;

abstract class ObjectOutputStream extends java.io.OutputStream implements java.io.ObjectOutput, java.io.ObjectStreamConstants
{
	public ObjectOutputStream() ;
	public java.lang.Void close() ;
	public java.lang.Void defaultWriteObject() ;
	public java.lang.Void drain() ;
	public java.lang.Void flush() ;
	public java.lang.Void reset() ;
	public java.lang.Void writeFields() ;
	public java.lang.Void writeStreamHeader() ;
	public java.lang.Void writeDouble(java.lang.Double parameter1) ;
	public java.lang.Void writeFloat(java.lang.Float parameter1) ;
	public java.lang.Void useProtocolVersion(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void writeByte(java.lang.Integer parameter1) ;
	public java.lang.Void writeChar(java.lang.Integer parameter1) ;
	public java.lang.Void writeInt(java.lang.Integer parameter1) ;
	public java.lang.Void writeShort(java.lang.Integer parameter1) ;
	public java.lang.Void writeLong(java.lang.Long parameter1) ;
	public java.lang.Void writeBoolean(java.lang.Boolean parameter1) ;
	public java.lang.Boolean enableReplaceObject(java.lang.Boolean parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.io.ObjectOutputStream.PutField putFields() ;
	public java.lang.Void writeClassDescriptor(java.io.ObjectStreamClass parameter1) ;
	public ObjectOutputStream(java.io.OutputStream parameter1) ;
	public java.lang.Void annotateClass(java.lang.Class parameter1) ;
	public java.lang.Void annotateProxyClass(java.lang.Class parameter1) ;
	public java.lang.Void writeObject(java.lang.Object parameter1) ;
	public java.lang.Void writeObjectOverride(java.lang.Object parameter1) ;
	public java.lang.Void writeUnshared(java.lang.Object parameter1) ;
	public java.lang.Void writeBytes(java.lang.String parameter1) ;
	public java.lang.Void writeChars(java.lang.String parameter1) ;
	public java.lang.Void writeUTF(java.lang.String parameter1) ;
	public java.lang.Object replaceObject(java.lang.Object parameter1) ;
	abstract class PutField
	{
		public PutField() ;
		public abstract java.lang.Void write(java.io.ObjectOutput parameter1) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Byte parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Character parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Double parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Float parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Integer parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Long parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Short parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Boolean parameter2) ;
		public abstract java.lang.Void put(java.lang.String parameter1, java.lang.Object parameter2) ;
	}
}

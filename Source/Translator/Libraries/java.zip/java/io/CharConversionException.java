package java.io;

abstract class CharConversionException extends java.io.IOException
{
}

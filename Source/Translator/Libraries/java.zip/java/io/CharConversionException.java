package java.io;

abstract class CharConversionException extends java.io.IOException
{
	public CharConversionException() ;
	public CharConversionException(java.lang.String parameter1) ;
}

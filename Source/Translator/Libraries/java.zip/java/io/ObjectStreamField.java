package java.io;

abstract class ObjectStreamField implements java.lang.Comparable
{
	public java.lang.Character getTypeCode() ;
	public java.lang.Integer getOffset() ;
	public java.lang.Boolean isPrimitive() ;
	public java.lang.Boolean isUnshared() ;
	public java.lang.Void setOffset(java.lang.Integer parameter1) ;
	public java.lang.Class getType() ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String getTypeString() ;
	public java.lang.String toString() ;
	public ObjectStreamField(java.lang.String parameter1, java.lang.Class parameter2) ;
	public ObjectStreamField(java.lang.String parameter1, java.lang.Class parameter2, java.lang.Boolean parameter3) ;
}

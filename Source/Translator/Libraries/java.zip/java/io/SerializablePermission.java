package java.io;

abstract class SerializablePermission extends java.security.BasicPermission
{
	public SerializablePermission(java.lang.String parameter1) ;
	public SerializablePermission(java.lang.String parameter1, java.lang.String parameter2) ;
}

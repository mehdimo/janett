package java.io;

abstract class SerializablePermission extends java.security.BasicPermission
{
}

package java.io;

abstract class SyncFailedException extends java.io.IOException
{
	public SyncFailedException(java.lang.String parameter1) ;
}

package java.io;

abstract class SyncFailedException extends java.io.IOException
{
}

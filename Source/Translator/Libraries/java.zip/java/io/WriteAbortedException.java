package java.io;

abstract class WriteAbortedException extends java.io.ObjectStreamException
{
	public java.lang.String getMessage() ;
	public java.lang.Throwable getCause() ;
	public WriteAbortedException(java.lang.String parameter1, java.lang.Exception parameter2) ;
	java.lang.Exception detail;
}

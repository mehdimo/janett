package java.io;

abstract class WriteAbortedException extends java.io.ObjectStreamException
{
	public java.lang.String getMessage() ;
	public java.lang.Throwable getCause() ;
	java.lang.Exception detail;
}

package java.io;

interface Externalizable implements java.io.Serializable
{
	public abstract java.lang.Void readExternal(java.io.ObjectInput parameter1) ;
	public abstract java.lang.Void writeExternal(java.io.ObjectOutput parameter1) ;
}

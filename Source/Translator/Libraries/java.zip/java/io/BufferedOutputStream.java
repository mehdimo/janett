package java.io;

abstract class BufferedOutputStream extends java.io.FilterOutputStream
{
	public java.lang.Void flush() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public BufferedOutputStream(java.io.OutputStream parameter1) ;
	public BufferedOutputStream(java.io.OutputStream parameter1, java.lang.Integer parameter2) ;
}

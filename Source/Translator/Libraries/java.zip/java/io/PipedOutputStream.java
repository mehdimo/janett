package java.io;

abstract class PipedOutputStream extends java.io.OutputStream
{
	public PipedOutputStream() ;
	public java.lang.Void close() ;
	public java.lang.Void flush() ;
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public PipedOutputStream(java.io.PipedInputStream parameter1) ;
	public java.lang.Void connect(java.io.PipedInputStream parameter1) ;
}

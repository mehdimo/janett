package java.io;

abstract class ObjectStreamException extends java.io.IOException
{
}

package java.io;

abstract class ObjectStreamException extends java.io.IOException
{
	public ObjectStreamException() ;
	public ObjectStreamException(java.lang.String parameter1) ;
}

package java.io;

abstract class LineNumberInputStream extends java.io.FilterInputStream
{
	public java.lang.Integer available() ;
	public java.lang.Integer getLineNumber() ;
	public java.lang.Integer read() ;
	public java.lang.Void reset() ;
	public java.lang.Void mark(java.lang.Integer parameter1) ;
	public java.lang.Void setLineNumber(java.lang.Integer parameter1) ;
	public java.lang.Long skip(java.lang.Long parameter1) ;
	public java.lang.Integer read(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
}

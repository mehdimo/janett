package java.io;

abstract class ObjectStreamClass implements java.io.Serializable
{
	public java.lang.Long getSerialVersionUID() ;
	public java.io.ObjectStreamField[] getFields() ;
	public java.lang.Class forClass() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.io.ObjectStreamClass lookup(java.lang.Class parameter1) ;
	public java.io.ObjectStreamField getField(java.lang.String parameter1) ;
	java.io.ObjectStreamField[] NO_FIELDS;
}

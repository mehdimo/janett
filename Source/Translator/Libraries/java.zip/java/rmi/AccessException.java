package java.rmi;

abstract class AccessException extends java.rmi.RemoteException
{
}

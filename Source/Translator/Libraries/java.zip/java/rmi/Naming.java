package java.rmi;

abstract class Naming
{
	public java.lang.Void unbind(java.lang.String parameter1) ;
	public java.lang.String[] list(java.lang.String parameter1) ;
	public java.rmi.Remote lookup(java.lang.String parameter1) ;
	public java.lang.Void bind(java.lang.String parameter1, java.rmi.Remote parameter2) ;
	public java.lang.Void rebind(java.lang.String parameter1, java.rmi.Remote parameter2) ;
}

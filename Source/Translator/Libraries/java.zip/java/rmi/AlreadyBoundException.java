package java.rmi;

abstract class AlreadyBoundException extends java.lang.Exception
{
}

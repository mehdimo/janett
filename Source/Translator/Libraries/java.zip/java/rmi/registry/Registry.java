package java.rmi.registry;

interface Registry implements java.rmi.Remote
{
	public abstract java.lang.String[] list() ;
	public abstract java.lang.Void unbind(java.lang.String parameter1) ;
	public abstract java.rmi.Remote lookup(java.lang.String parameter1) ;
	public abstract java.lang.Void bind(java.lang.String parameter1, java.rmi.Remote parameter2) ;
	public abstract java.lang.Void rebind(java.lang.String parameter1, java.rmi.Remote parameter2) ;
	java.lang.Integer REGISTRY_PORT;
}

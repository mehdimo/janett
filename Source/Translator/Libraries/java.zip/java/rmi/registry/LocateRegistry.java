package java.rmi.registry;

abstract class LocateRegistry
{
	public java.rmi.registry.Registry getRegistry() ;
	public java.rmi.registry.Registry createRegistry(java.lang.Integer parameter1) ;
	public java.rmi.registry.Registry getRegistry(java.lang.Integer parameter1) ;
	public java.rmi.registry.Registry getRegistry(java.lang.String parameter1) ;
	public java.rmi.registry.Registry getRegistry(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.rmi.registry.Registry getRegistry(java.lang.String parameter1, java.lang.Integer parameter2, java.rmi.server.RMIClientSocketFactory parameter3) ;
	public java.rmi.registry.Registry createRegistry(java.lang.Integer parameter1, java.rmi.server.RMIClientSocketFactory parameter2, java.rmi.server.RMIServerSocketFactory parameter3) ;
}

package java.rmi.registry;

interface RegistryHandler
{
	public abstract java.rmi.registry.Registry registryImpl(java.lang.Integer parameter1) ;
	public abstract java.rmi.registry.Registry registryStub(java.lang.String parameter1, java.lang.Integer parameter2) ;
}

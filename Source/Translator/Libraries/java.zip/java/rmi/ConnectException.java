package java.rmi;

abstract class ConnectException extends java.rmi.RemoteException
{
}

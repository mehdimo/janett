package java.rmi;

abstract class ConnectIOException extends java.rmi.RemoteException
{
}

package java.rmi;

abstract class ServerException extends java.rmi.RemoteException
{
}

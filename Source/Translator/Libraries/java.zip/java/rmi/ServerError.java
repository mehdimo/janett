package java.rmi;

abstract class ServerError extends java.rmi.RemoteException
{
}

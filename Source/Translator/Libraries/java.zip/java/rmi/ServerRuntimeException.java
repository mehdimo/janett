package java.rmi;

abstract class ServerRuntimeException extends java.rmi.RemoteException
{
}

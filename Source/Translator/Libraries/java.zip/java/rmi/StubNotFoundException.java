package java.rmi;

abstract class StubNotFoundException extends java.rmi.RemoteException
{
}

package java.rmi;

abstract class MarshalException extends java.rmi.RemoteException
{
}

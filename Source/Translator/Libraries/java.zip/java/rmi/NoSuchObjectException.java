package java.rmi;

abstract class NoSuchObjectException extends java.rmi.RemoteException
{
}

package java.rmi;

abstract class NotBoundException extends java.lang.Exception
{
}

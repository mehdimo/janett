package java.rmi;

interface Remote
{
}

package java.rmi;

abstract class RMISecurityManager extends java.lang.SecurityManager
{
}

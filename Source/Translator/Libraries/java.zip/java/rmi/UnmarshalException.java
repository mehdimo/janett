package java.rmi;

abstract class UnmarshalException extends java.rmi.RemoteException
{
}

package java.rmi;

abstract class RemoteException extends java.io.IOException
{
	public java.lang.String getMessage() ;
	public java.lang.Throwable getCause() ;
	java.lang.Throwable detail;
}

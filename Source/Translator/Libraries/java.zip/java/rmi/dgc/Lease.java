package java.rmi.dgc;

abstract class Lease implements java.io.Serializable
{
	public java.lang.Long getValue() ;
	public java.rmi.dgc.VMID getVMID() ;
}

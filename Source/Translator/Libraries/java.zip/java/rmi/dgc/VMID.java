package java.rmi.dgc;

abstract class VMID implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isUnique() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

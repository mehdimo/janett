package java.rmi.dgc;

interface DGC implements java.rmi.Remote
{
	public abstract java.lang.Void clean(java.rmi.server.ObjID[] parameter1, java.lang.Long parameter2, java.rmi.dgc.VMID parameter3, java.lang.Boolean parameter4) ;
	public abstract java.rmi.dgc.Lease dirty(java.rmi.server.ObjID[] parameter1, java.lang.Long parameter2, java.rmi.dgc.Lease parameter3) ;
}

package java.rmi;

abstract class UnknownHostException extends java.rmi.RemoteException
{
}

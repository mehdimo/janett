package java.rmi;

abstract class RMISecurityException extends java.lang.SecurityException
{
}

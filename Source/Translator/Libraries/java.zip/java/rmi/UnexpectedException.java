package java.rmi;

abstract class UnexpectedException extends java.rmi.RemoteException
{
}

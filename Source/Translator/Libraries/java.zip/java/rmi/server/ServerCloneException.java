package java.rmi.server;

abstract class ServerCloneException extends java.lang.CloneNotSupportedException
{
	public java.lang.String getMessage() ;
	public java.lang.Throwable getCause() ;
	java.lang.Exception detail;
}

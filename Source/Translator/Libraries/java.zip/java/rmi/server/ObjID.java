package java.rmi.server;

abstract class ObjID implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Void write(java.io.ObjectOutput parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.rmi.server.ObjID read(java.io.ObjectInput parameter1) ;
	java.lang.Integer REGISTRY_ID;
	java.lang.Integer ACTIVATOR_ID;
	java.lang.Integer DGC_ID;
}

package java.rmi.server;

abstract class ExportException extends java.rmi.RemoteException
{
}

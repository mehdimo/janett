package java.rmi.server;

interface Unreferenced
{
	public abstract java.lang.Void unreferenced() ;
}

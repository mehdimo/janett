package java.rmi.server;

interface Skeleton
{
	public abstract java.rmi.server.Operation[] getOperations() ;
	public abstract java.lang.Void dispatch(java.rmi.Remote parameter1, java.rmi.server.RemoteCall parameter2, java.lang.Integer parameter3, java.lang.Long parameter4) ;
}

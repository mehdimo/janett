package java.rmi.server;

abstract class UnicastRemoteObject extends java.rmi.server.RemoteServer
{
	public java.lang.Object clone() ;
	public java.lang.Boolean unexportObject(java.rmi.Remote parameter1, java.lang.Boolean parameter2) ;
	public java.rmi.Remote exportObject(java.rmi.Remote parameter1, java.lang.Integer parameter2) ;
	public java.rmi.server.RemoteStub exportObject(java.rmi.Remote parameter1) ;
	public java.rmi.Remote exportObject(java.rmi.Remote parameter1, java.lang.Integer parameter2, java.rmi.server.RMIClientSocketFactory parameter3, java.rmi.server.RMIServerSocketFactory parameter4) ;
}

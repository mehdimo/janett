package java.rmi.server;

interface LoaderHandler
{
	public abstract java.lang.Class loadClass(java.lang.String parameter1) ;
	public abstract java.lang.Object getSecurityContext(java.lang.ClassLoader parameter1) ;
	public abstract java.lang.Class loadClass(java.net.URL parameter1, java.lang.String parameter2) ;
	java.lang.String packagePrefix;
}

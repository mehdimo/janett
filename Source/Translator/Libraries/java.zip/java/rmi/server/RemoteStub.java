package java.rmi.server;

abstract class RemoteStub extends java.rmi.server.RemoteObject
{
	public java.lang.Void setRef(java.rmi.server.RemoteStub parameter1, java.rmi.server.RemoteRef parameter2) ;
}

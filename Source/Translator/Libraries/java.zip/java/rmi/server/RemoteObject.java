package java.rmi.server;

abstract class RemoteObject implements java.rmi.Remote, java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.rmi.server.RemoteRef getRef() ;
	public java.rmi.Remote toStub(java.rmi.Remote parameter1) ;
}

package java.rmi.server;

abstract class RemoteServer extends java.rmi.server.RemoteObject
{
	public java.lang.Void setLog(java.io.OutputStream parameter1) ;
	public java.io.PrintStream getLog() ;
	public java.lang.String getClientHost() ;
}

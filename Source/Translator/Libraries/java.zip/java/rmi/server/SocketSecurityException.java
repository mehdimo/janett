package java.rmi.server;

abstract class SocketSecurityException extends java.rmi.server.ExportException
{
}

package java.rmi.server;

interface RMIServerSocketFactory
{
	public abstract java.net.ServerSocket createServerSocket(java.lang.Integer parameter1) ;
}

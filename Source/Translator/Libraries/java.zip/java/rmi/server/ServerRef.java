package java.rmi.server;

interface ServerRef implements java.rmi.server.RemoteRef
{
	public abstract java.lang.String getClientHost() ;
	public abstract java.rmi.server.RemoteStub exportObject(java.rmi.Remote parameter1, java.lang.Object parameter2) ;
	java.lang.Long serialVersionUID;
}

package java.rmi.server;

abstract class LogStream extends java.io.PrintStream
{
	public java.lang.Void write(java.lang.Integer parameter1) ;
	public java.lang.Void write(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.io.OutputStream getOutputStream() ;
	public java.lang.Void setOutputStream(java.io.OutputStream parameter1) ;
	public java.io.PrintStream getDefaultStream() ;
	public java.lang.Void setDefaultStream(java.io.PrintStream parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Integer parseLevel(java.lang.String parameter1) ;
	public java.rmi.server.LogStream log(java.lang.String parameter1) ;
	java.lang.Integer SILENT;
	java.lang.Integer BRIEF;
	java.lang.Integer VERBOSE;
}

package java.rmi.server;

abstract class Operation
{
	public java.lang.String getOperation() ;
	public java.lang.String toString() ;
}

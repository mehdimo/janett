package java.rmi.server;

abstract class RMISocketFactory implements java.rmi.server.RMIClientSocketFactory, java.rmi.server.RMIServerSocketFactory
{
	public abstract java.net.ServerSocket createServerSocket(java.lang.Integer parameter1) ;
	public java.rmi.server.RMIFailureHandler getFailureHandler() ;
	public java.lang.Void setFailureHandler(java.rmi.server.RMIFailureHandler parameter1) ;
	public java.rmi.server.RMISocketFactory getDefaultSocketFactory() ;
	public java.rmi.server.RMISocketFactory getSocketFactory() ;
	public java.lang.Void setSocketFactory(java.rmi.server.RMISocketFactory parameter1) ;
	public abstract java.net.Socket createSocket(java.lang.String parameter1, java.lang.Integer parameter2) ;
}

package java.rmi.server;

abstract class RMIClassLoaderSpi
{
	public abstract java.lang.ClassLoader getClassLoader(java.lang.String parameter1) ;
	public abstract java.lang.String getClassAnnotation(java.lang.Class parameter1) ;
	public abstract java.lang.Class loadClass(java.lang.String parameter1, java.lang.String parameter2, java.lang.ClassLoader parameter3) ;
	public abstract java.lang.Class loadProxyClass(java.lang.String parameter1, java.lang.String[] parameter2, java.lang.ClassLoader parameter3) ;
}

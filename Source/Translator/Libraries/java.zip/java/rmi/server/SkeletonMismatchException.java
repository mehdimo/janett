package java.rmi.server;

abstract class SkeletonMismatchException extends java.rmi.RemoteException
{
}

package java.rmi.server;

interface RMIFailureHandler
{
	public abstract java.lang.Boolean failure(java.lang.Exception parameter1) ;
}

package java.rmi.server;

interface RMIClientSocketFactory
{
	public abstract java.net.Socket createSocket(java.lang.String parameter1, java.lang.Integer parameter2) ;
}

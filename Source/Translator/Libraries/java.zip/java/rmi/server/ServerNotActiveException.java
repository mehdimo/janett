package java.rmi.server;

abstract class ServerNotActiveException extends java.lang.Exception
{
}

package java.rmi.server;

interface RemoteCall
{
	public abstract java.lang.Void done() ;
	public abstract java.lang.Void executeCall() ;
	public abstract java.lang.Void releaseInputStream() ;
	public abstract java.lang.Void releaseOutputStream() ;
	public abstract java.io.ObjectInput getInputStream() ;
	public abstract java.io.ObjectOutput getOutputStream() ;
	public abstract java.io.ObjectOutput getResultStream(java.lang.Boolean parameter1) ;
}

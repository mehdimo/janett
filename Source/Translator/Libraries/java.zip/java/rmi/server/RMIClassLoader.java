package java.rmi.server;

abstract class RMIClassLoader
{
	public java.rmi.server.RMIClassLoaderSpi getDefaultProviderInstance() ;
	public java.lang.Class loadClass(java.lang.String parameter1) ;
	public java.lang.ClassLoader getClassLoader(java.lang.String parameter1) ;
	public java.lang.Object getSecurityContext(java.lang.ClassLoader parameter1) ;
	public java.lang.String getClassAnnotation(java.lang.Class parameter1) ;
	public java.lang.Class loadClass(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.Class loadClass(java.net.URL parameter1, java.lang.String parameter2) ;
	public java.lang.Class loadClass(java.lang.String parameter1, java.lang.String parameter2, java.lang.ClassLoader parameter3) ;
	public java.lang.Class loadProxyClass(java.lang.String parameter1, java.lang.String[] parameter2, java.lang.ClassLoader parameter3) ;
}

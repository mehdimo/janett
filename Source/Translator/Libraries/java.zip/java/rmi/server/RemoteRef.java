package java.rmi.server;

interface RemoteRef implements java.io.Externalizable
{
	public abstract java.lang.Integer remoteHashCode() ;
	public abstract java.lang.String remoteToString() ;
	public abstract java.lang.Void done(java.rmi.server.RemoteCall parameter1) ;
	public abstract java.lang.Void invoke(java.rmi.server.RemoteCall parameter1) ;
	public abstract java.lang.Boolean remoteEquals(java.rmi.server.RemoteRef parameter1) ;
	public abstract java.lang.String getRefClass(java.io.ObjectOutput parameter1) ;
	public abstract java.rmi.server.RemoteCall newCall(java.rmi.server.RemoteObject parameter1, java.rmi.server.Operation[] parameter2, java.lang.Integer parameter3, java.lang.Long parameter4) ;
	public abstract java.lang.Object invoke(java.rmi.Remote parameter1, java.lang.reflect.Method parameter2, java.lang.Object[] parameter3, java.lang.Long parameter4) ;
	java.lang.Long serialVersionUID;
	java.lang.String packagePrefix;
}

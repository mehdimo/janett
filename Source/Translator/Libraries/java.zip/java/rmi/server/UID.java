package java.rmi.server;

abstract class UID implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Void write(java.io.DataOutput parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.rmi.server.UID read(java.io.DataInput parameter1) ;
}

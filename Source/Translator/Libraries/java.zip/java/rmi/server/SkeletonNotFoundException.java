package java.rmi.server;

abstract class SkeletonNotFoundException extends java.rmi.RemoteException
{
}

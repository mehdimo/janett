package java.rmi.activation;

interface ActivationMonitor implements java.rmi.Remote
{
	public abstract java.lang.Void inactiveGroup(java.rmi.activation.ActivationGroupID parameter1, java.lang.Long parameter2) ;
	public abstract java.lang.Void inactiveObject(java.rmi.activation.ActivationID parameter1) ;
	public abstract java.lang.Void activeObject(java.rmi.activation.ActivationID parameter1, java.rmi.MarshalledObject parameter2) ;
}

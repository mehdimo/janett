package java.rmi.activation;

interface ActivationInstantiator implements java.rmi.Remote
{
	public abstract java.rmi.MarshalledObject newInstance(java.rmi.activation.ActivationID parameter1, java.rmi.activation.ActivationDesc parameter2) ;
}

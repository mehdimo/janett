package java.rmi.activation;

interface ActivationSystem implements java.rmi.Remote
{
	public abstract java.lang.Void shutdown() ;
	public abstract java.lang.Void unregisterGroup(java.rmi.activation.ActivationGroupID parameter1) ;
	public abstract java.lang.Void unregisterObject(java.rmi.activation.ActivationID parameter1) ;
	public abstract java.rmi.activation.ActivationDesc getActivationDesc(java.rmi.activation.ActivationID parameter1) ;
	public abstract java.rmi.activation.ActivationGroupDesc getActivationGroupDesc(java.rmi.activation.ActivationGroupID parameter1) ;
	public abstract java.rmi.activation.ActivationGroupID registerGroup(java.rmi.activation.ActivationGroupDesc parameter1) ;
	public abstract java.rmi.activation.ActivationID registerObject(java.rmi.activation.ActivationDesc parameter1) ;
	public abstract java.rmi.activation.ActivationDesc setActivationDesc(java.rmi.activation.ActivationID parameter1, java.rmi.activation.ActivationDesc parameter2) ;
	public abstract java.rmi.activation.ActivationGroupDesc setActivationGroupDesc(java.rmi.activation.ActivationGroupID parameter1, java.rmi.activation.ActivationGroupDesc parameter2) ;
	public abstract java.rmi.activation.ActivationMonitor activeGroup(java.rmi.activation.ActivationGroupID parameter1, java.rmi.activation.ActivationInstantiator parameter2, java.lang.Long parameter3) ;
	java.lang.Integer SYSTEM_PORT;
}

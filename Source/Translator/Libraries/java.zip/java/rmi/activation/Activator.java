package java.rmi.activation;

interface Activator implements java.rmi.Remote
{
	public abstract java.rmi.MarshalledObject activate(java.rmi.activation.ActivationID parameter1, java.lang.Boolean parameter2) ;
}

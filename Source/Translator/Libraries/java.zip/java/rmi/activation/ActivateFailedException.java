package java.rmi.activation;

abstract class ActivateFailedException extends java.rmi.RemoteException
{
}

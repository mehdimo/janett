package java.rmi.activation;

abstract class ActivationID implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.rmi.Remote activate(java.lang.Boolean parameter1) ;
}

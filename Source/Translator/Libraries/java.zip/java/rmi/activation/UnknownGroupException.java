package java.rmi.activation;

abstract class UnknownGroupException extends java.rmi.activation.ActivationException
{
}

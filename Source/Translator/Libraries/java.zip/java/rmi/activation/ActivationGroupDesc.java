package java.rmi.activation;

abstract class ActivationGroupDesc implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String getLocation() ;
	public java.rmi.MarshalledObject getData() ;
	public java.rmi.activation.ActivationGroupDesc.CommandEnvironment getCommandEnvironment() ;
	public java.util.Properties getPropertyOverrides() ;
	abstract class CommandEnvironment implements java.io.Serializable
	{
		public java.lang.Integer hashCode() ;
		public java.lang.Boolean equals(java.lang.Object parameter1) ;
		public java.lang.String getCommandPath() ;
		public java.lang.String[] getCommandOptions() ;
	}
}

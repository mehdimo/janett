package java.rmi.activation;

abstract class ActivationDesc implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean getRestartMode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String getLocation() ;
	public java.rmi.MarshalledObject getData() ;
	public java.rmi.activation.ActivationGroupID getGroupID() ;
}

package java.rmi.activation;

abstract class ActivationGroup_Stub extends java.rmi.server.RemoteStub implements java.rmi.activation.ActivationInstantiator, java.rmi.Remote
{
	public java.rmi.MarshalledObject newInstance(java.rmi.activation.ActivationID parameter1, java.rmi.activation.ActivationDesc parameter2) ;
}

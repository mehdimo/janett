package java.rmi.activation;

abstract class ActivationGroup extends java.rmi.server.UnicastRemoteObject implements java.rmi.activation.ActivationInstantiator
{
	public java.lang.Void inactiveGroup() ;
	public java.rmi.activation.ActivationGroupID currentGroupID() ;
	public java.lang.Boolean inactiveObject(java.rmi.activation.ActivationID parameter1) ;
	public java.rmi.activation.ActivationSystem getSystem() ;
	public java.lang.Void setSystem(java.rmi.activation.ActivationSystem parameter1) ;
	public java.lang.Void activeObject(java.rmi.activation.ActivationID parameter1, java.rmi.MarshalledObject parameter2) ;
	public abstract java.lang.Void activeObject(java.rmi.activation.ActivationID parameter1, java.rmi.Remote parameter2) ;
	public java.rmi.activation.ActivationGroup createGroup(java.rmi.activation.ActivationGroupID parameter1, java.rmi.activation.ActivationGroupDesc parameter2, java.lang.Long parameter3) ;
}

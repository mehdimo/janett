package java.rmi.activation;

abstract class ActivationException extends java.lang.Exception
{
	public java.lang.String getMessage() ;
	public java.lang.Throwable getCause() ;
	java.lang.Throwable detail;
}

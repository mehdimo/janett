package java.rmi.activation;

abstract class UnknownObjectException extends java.rmi.activation.ActivationException
{
}

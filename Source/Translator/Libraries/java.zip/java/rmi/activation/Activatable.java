package java.rmi.activation;

abstract class Activatable extends java.rmi.server.RemoteServer
{
	public java.lang.Boolean unexportObject(java.rmi.Remote parameter1, java.lang.Boolean parameter2) ;
	public java.rmi.activation.ActivationID getID() ;
	public java.lang.Void unregister(java.rmi.activation.ActivationID parameter1) ;
	public java.lang.Boolean inactive(java.rmi.activation.ActivationID parameter1) ;
	public java.rmi.Remote register(java.rmi.activation.ActivationDesc parameter1) ;
	public java.rmi.Remote exportObject(java.rmi.Remote parameter1, java.rmi.activation.ActivationID parameter2, java.lang.Integer parameter3) ;
	public java.rmi.activation.ActivationID exportObject(java.rmi.Remote parameter1, java.lang.String parameter2, java.rmi.MarshalledObject parameter3, java.lang.Boolean parameter4, java.lang.Integer parameter5) ;
	public java.rmi.Remote exportObject(java.rmi.Remote parameter1, java.rmi.activation.ActivationID parameter2, java.lang.Integer parameter3, java.rmi.server.RMIClientSocketFactory parameter4, java.rmi.server.RMIServerSocketFactory parameter5) ;
	public java.rmi.activation.ActivationID exportObject(java.rmi.Remote parameter1, java.lang.String parameter2, java.rmi.MarshalledObject parameter3, java.lang.Boolean parameter4, java.lang.Integer parameter5, java.rmi.server.RMIClientSocketFactory parameter6, java.rmi.server.RMIServerSocketFactory parameter7) ;
}

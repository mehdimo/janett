package java.rmi;

abstract class MarshalledObject implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Object get() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
}

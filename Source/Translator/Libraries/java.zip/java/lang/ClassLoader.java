package java.lang;

abstract class ClassLoader
{
	public java.lang.Void clearAssertionStatus() ;
	public java.lang.Void setDefaultAssertionStatus(java.lang.Boolean parameter1) ;
	public java.lang.Void resolveClass(java.lang.Class parameter1) ;
	public java.lang.Class defineClass(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.ClassLoader getParent() ;
	public java.lang.ClassLoader getSystemClassLoader() ;
	public java.lang.Package[] getPackages() ;
	public java.lang.Void setClassAssertionStatus(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void setPackageAssertionStatus(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.io.InputStream getResourceAsStream(java.lang.String parameter1) ;
	public java.io.InputStream getSystemResourceAsStream(java.lang.String parameter1) ;
	public java.lang.Class findClass(java.lang.String parameter1) ;
	public java.lang.Class findLoadedClass(java.lang.String parameter1) ;
	public java.lang.Class findSystemClass(java.lang.String parameter1) ;
	public java.lang.Class loadClass(java.lang.String parameter1) ;
	public java.lang.Class loadClass(java.lang.String parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Class defineClass(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.Void setSigners(java.lang.Class parameter1, java.lang.Object[] parameter2) ;
	public java.lang.Package getPackage(java.lang.String parameter1) ;
	public java.lang.String findLibrary(java.lang.String parameter1) ;
	public java.net.URL findResource(java.lang.String parameter1) ;
	public java.net.URL getResource(java.lang.String parameter1) ;
	public java.net.URL getSystemResource(java.lang.String parameter1) ;
	public java.util.Enumeration findResources(java.lang.String parameter1) ;
	public java.util.Enumeration getResources(java.lang.String parameter1) ;
	public java.util.Enumeration getSystemResources(java.lang.String parameter1) ;
	public java.lang.Class defineClass(java.lang.String parameter1, java.lang.Byte[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4, java.security.ProtectionDomain parameter5) ;
	public java.lang.Package definePackage(java.lang.String parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5, java.lang.String parameter6, java.lang.String parameter7, java.net.URL parameter8) ;
}

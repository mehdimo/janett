package java.lang.ref;

abstract class WeakReference extends java.lang.ref.Reference
{
}

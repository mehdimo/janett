package java.lang.ref;

abstract class PhantomReference extends java.lang.ref.Reference
{
	public java.lang.Object get() ;
}

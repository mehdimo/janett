package java.lang.ref;

abstract class ReferenceQueue
{
	public java.lang.ref.Reference poll() ;
	public java.lang.ref.Reference remove() ;
	public java.lang.ref.Reference remove(java.lang.Long parameter1) ;
}

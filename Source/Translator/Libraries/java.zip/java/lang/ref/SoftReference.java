package java.lang.ref;

abstract class SoftReference extends java.lang.ref.Reference
{
	public java.lang.Object get() ;
}

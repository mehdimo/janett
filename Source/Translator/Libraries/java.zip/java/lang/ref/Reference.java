package java.lang.ref;

abstract class Reference
{
	public java.lang.Void clear() ;
	public java.lang.Boolean enqueue() ;
	public java.lang.Boolean isEnqueued() ;
	public java.lang.Object get() ;
}

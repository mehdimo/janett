package java.lang;

abstract class Class implements java.io.Serializable
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Boolean desiredAssertionStatus() ;
	public java.lang.Boolean isArray() ;
	public java.lang.Boolean isInterface() ;
	public java.lang.Boolean isPrimitive() ;
	public java.lang.Class getComponentType() ;
	public java.lang.Class getDeclaringClass() ;
	public java.lang.Class getSuperclass() ;
	public java.lang.Class[] getClasses() ;
	public java.lang.Class[] getDeclaredClasses() ;
	public java.lang.Class[] getInterfaces() ;
	public java.lang.Boolean isAssignableFrom(java.lang.Class parameter1) ;
	public java.lang.ClassLoader getClassLoader() ;
	public java.lang.Object newInstance() ;
	public java.lang.Object[] getSigners() ;
	public java.lang.Boolean isInstance(java.lang.Object parameter1) ;
	public java.lang.Package getPackage() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.reflect.Constructor[] getConstructors() ;
	public java.lang.reflect.Constructor[] getDeclaredConstructors() ;
	public java.lang.reflect.Field[] getDeclaredFields() ;
	public java.lang.reflect.Field[] getFields() ;
	public java.lang.reflect.Method[] getDeclaredMethods() ;
	public java.lang.reflect.Method[] getMethods() ;
	public java.security.ProtectionDomain getProtectionDomain() ;
	public java.io.InputStream getResourceAsStream(java.lang.String parameter1) ;
	public java.lang.Class forName(java.lang.String parameter1) ;
	public java.lang.reflect.Constructor getConstructor(java.lang.Class[] parameter1) ;
	public java.lang.reflect.Constructor getDeclaredConstructor(java.lang.Class[] parameter1) ;
	public java.lang.reflect.Field getDeclaredField(java.lang.String parameter1) ;
	public java.lang.reflect.Field getField(java.lang.String parameter1) ;
	public java.net.URL getResource(java.lang.String parameter1) ;
	public java.lang.Class forName(java.lang.String parameter1, java.lang.Boolean parameter2, java.lang.ClassLoader parameter3) ;
	public java.lang.reflect.Method getDeclaredMethod(java.lang.String parameter1, java.lang.Class[] parameter2) ;
	public java.lang.reflect.Method getMethod(java.lang.String parameter1, java.lang.Class[] parameter2) ;
}

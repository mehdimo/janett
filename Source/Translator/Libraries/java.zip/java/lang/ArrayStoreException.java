package java.lang;

abstract class ArrayStoreException extends java.lang.RuntimeException
{
}

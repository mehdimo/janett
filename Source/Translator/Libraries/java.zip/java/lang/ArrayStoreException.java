package java.lang;

abstract class ArrayStoreException extends java.lang.RuntimeException
{
	public ArrayStoreException() ;
	public ArrayStoreException(java.lang.String parameter1) ;
}

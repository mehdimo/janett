package java.lang;

abstract class ThreadLocal
{
	public java.lang.Object get() ;
	public java.lang.Object initialValue() ;
	public java.lang.Void set(java.lang.Object parameter1) ;
}

package java.lang;

abstract class Exception extends java.lang.Throwable
{
}

package java.lang;

abstract class Exception extends java.lang.Throwable
{
	public Exception() ;
	public Exception(java.lang.String parameter1) ;
	public Exception(java.lang.Throwable parameter1) ;
	public Exception(java.lang.String parameter1, java.lang.Throwable parameter2) ;
}

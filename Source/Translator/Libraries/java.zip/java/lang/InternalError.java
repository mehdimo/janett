package java.lang;

abstract class InternalError extends java.lang.VirtualMachineError
{
}

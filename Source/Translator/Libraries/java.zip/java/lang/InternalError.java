package java.lang;

abstract class InternalError extends java.lang.VirtualMachineError
{
	public InternalError() ;
	public InternalError(java.lang.String parameter1) ;
}

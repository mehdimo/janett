package java.lang;

interface Runnable
{
	public abstract java.lang.Void run() ;
}

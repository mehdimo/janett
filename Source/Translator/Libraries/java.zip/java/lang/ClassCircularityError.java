package java.lang;

abstract class ClassCircularityError extends java.lang.LinkageError
{
	public ClassCircularityError() ;
	public ClassCircularityError(java.lang.String parameter1) ;
}

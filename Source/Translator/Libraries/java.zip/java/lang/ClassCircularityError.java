package java.lang;

abstract class ClassCircularityError extends java.lang.LinkageError
{
}

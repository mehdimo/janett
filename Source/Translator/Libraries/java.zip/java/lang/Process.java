package java.lang;

abstract class Process
{
	public abstract java.lang.Integer exitValue() ;
	public abstract java.lang.Integer waitFor() ;
	public abstract java.lang.Void destroy() ;
	public abstract java.io.InputStream getErrorStream() ;
	public abstract java.io.InputStream getInputStream() ;
	public abstract java.io.OutputStream getOutputStream() ;
}

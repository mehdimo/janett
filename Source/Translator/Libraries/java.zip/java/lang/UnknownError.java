package java.lang;

abstract class UnknownError extends java.lang.VirtualMachineError
{
}

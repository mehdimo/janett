package java.lang;

interface CharSequence
{
	public abstract java.lang.Integer length() ;
	public abstract java.lang.Character charAt(java.lang.Integer parameter1) ;
	public abstract java.lang.CharSequence subSequence(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.String toString() ;
}

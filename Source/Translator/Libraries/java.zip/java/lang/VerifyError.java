package java.lang;

abstract class VerifyError extends java.lang.LinkageError
{
}

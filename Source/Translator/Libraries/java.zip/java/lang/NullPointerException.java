package java.lang;

abstract class NullPointerException extends java.lang.RuntimeException
{
}

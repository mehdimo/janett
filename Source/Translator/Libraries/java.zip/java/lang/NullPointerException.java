package java.lang;

abstract class NullPointerException extends java.lang.RuntimeException
{
	public NullPointerException() ;
	public NullPointerException(java.lang.String parameter1) ;
}

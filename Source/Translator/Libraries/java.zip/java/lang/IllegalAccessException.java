package java.lang;

abstract class IllegalAccessException extends java.lang.Exception
{
	public IllegalAccessException() ;
	public IllegalAccessException(java.lang.String parameter1) ;
}

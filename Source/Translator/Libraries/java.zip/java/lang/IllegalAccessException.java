package java.lang;

abstract class IllegalAccessException extends java.lang.Exception
{
}

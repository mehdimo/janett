package java.lang;

abstract class InterruptedException extends java.lang.Exception
{
	public InterruptedException() ;
	public InterruptedException(java.lang.String parameter1) ;
}

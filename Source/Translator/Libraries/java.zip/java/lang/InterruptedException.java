package java.lang;

abstract class InterruptedException extends java.lang.Exception
{
}

package java.lang;

abstract class NoSuchFieldException extends java.lang.Exception
{
	public NoSuchFieldException() ;
	public NoSuchFieldException(java.lang.String parameter1) ;
}

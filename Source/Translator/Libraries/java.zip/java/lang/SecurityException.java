package java.lang;

abstract class SecurityException extends java.lang.RuntimeException
{
}

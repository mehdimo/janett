package java.lang;

abstract class InheritableThreadLocal extends java.lang.ThreadLocal
{
	public InheritableThreadLocal() ;
	public java.lang.Object childValue(java.lang.Object parameter1) ;
}

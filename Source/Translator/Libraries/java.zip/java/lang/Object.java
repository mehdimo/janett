package java.lang;

abstract class Object
{
	public java.lang.Integer hashCode() ;
	public java.lang.Void finalize() ;
	public java.lang.Void notify() ;
	public java.lang.Void notifyAll() ;
	public java.lang.Void wait() ;
	public java.lang.Void wait(java.lang.Long parameter1) ;
	public java.lang.Void wait(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Class getClass() ;
	public java.lang.Object clone() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
}

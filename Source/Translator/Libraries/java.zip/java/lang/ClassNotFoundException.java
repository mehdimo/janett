package java.lang;

abstract class ClassNotFoundException extends java.lang.Exception
{
	public ClassNotFoundException() ;
	public ClassNotFoundException(java.lang.String parameter1) ;
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getException() ;
	public ClassNotFoundException(java.lang.String parameter1, java.lang.Throwable parameter2) ;
}

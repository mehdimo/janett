package java.lang;

abstract class ClassNotFoundException extends java.lang.Exception
{
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getException() ;
}

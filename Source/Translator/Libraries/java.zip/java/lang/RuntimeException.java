package java.lang;

abstract class RuntimeException extends java.lang.Exception
{
}

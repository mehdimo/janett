package java.lang;

abstract class Byte extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public java.lang.Integer compareTo(java.lang.Byte parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Byte parameter1) ;
	public java.lang.Byte parseByte(java.lang.String parameter1) ;
	public java.lang.Byte parseByte(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Byte decode(java.lang.String parameter1) ;
	public java.lang.Byte valueOf(java.lang.String parameter1) ;
	public java.lang.Byte valueOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	java.lang.Byte MIN_VALUE;
	java.lang.Byte MAX_VALUE;
	java.lang.Class TYPE;
}

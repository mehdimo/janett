package java.lang;

abstract class IllegalMonitorStateException extends java.lang.RuntimeException
{
}

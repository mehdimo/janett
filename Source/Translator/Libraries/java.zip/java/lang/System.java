package java.lang;

abstract class System
{
	public java.lang.Long currentTimeMillis() ;
	public java.lang.Void gc() ;
	public java.lang.Void runFinalization() ;
	public java.lang.Void exit(java.lang.Integer parameter1) ;
	public java.lang.Void runFinalizersOnExit(java.lang.Boolean parameter1) ;
	public java.lang.Void setIn(java.io.InputStream parameter1) ;
	public java.lang.Void setErr(java.io.PrintStream parameter1) ;
	public java.lang.Void setOut(java.io.PrintStream parameter1) ;
	public java.lang.Integer identityHashCode(java.lang.Object parameter1) ;
	public java.lang.SecurityManager getSecurityManager() ;
	public java.lang.Void setSecurityManager(java.lang.SecurityManager parameter1) ;
	public java.lang.Void load(java.lang.String parameter1) ;
	public java.lang.Void loadLibrary(java.lang.String parameter1) ;
	public java.util.Properties getProperties() ;
	public java.lang.Void setProperties(java.util.Properties parameter1) ;
	public java.lang.Void arraycopy(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Object parameter3, java.lang.Integer parameter4, java.lang.Integer parameter5) ;
	public java.lang.String getProperty(java.lang.String parameter1) ;
	public java.lang.String getenv(java.lang.String parameter1) ;
	public java.lang.String mapLibraryName(java.lang.String parameter1) ;
	public java.lang.String getProperty(java.lang.String parameter1, java.lang.String parameter2) ;
	public java.lang.String setProperty(java.lang.String parameter1, java.lang.String parameter2) ;
	java.io.InputStream in;
	java.io.PrintStream out;
	java.io.PrintStream err;
}

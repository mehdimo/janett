package java.lang;

interface Cloneable
{
}

package java.lang;

abstract class InstantiationError extends java.lang.IncompatibleClassChangeError
{
	public InstantiationError() ;
	public InstantiationError(java.lang.String parameter1) ;
}

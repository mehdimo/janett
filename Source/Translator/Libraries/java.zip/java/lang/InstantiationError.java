package java.lang;

abstract class InstantiationError extends java.lang.IncompatibleClassChangeError
{
}

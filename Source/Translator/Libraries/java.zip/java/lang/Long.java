package java.lang;

abstract class Long extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public Long(java.lang.Long parameter1) ;
	public java.lang.Integer compareTo(java.lang.Long parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toBinaryString(java.lang.Long parameter1) ;
	public java.lang.String toHexString(java.lang.Long parameter1) ;
	public java.lang.String toOctalString(java.lang.Long parameter1) ;
	public java.lang.String toString(java.lang.Long parameter1) ;
	public java.lang.String toString(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Long parseLong(java.lang.String parameter1) ;
	public Long(java.lang.String parameter1) ;
	public java.lang.Long parseLong(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Long decode(java.lang.String parameter1) ;
	public java.lang.Long getLong(java.lang.String parameter1) ;
	public java.lang.Long valueOf(java.lang.String parameter1) ;
	public java.lang.Long valueOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Long getLong(java.lang.String parameter1, java.lang.Long parameter2) ;
	public java.lang.Long getLong(java.lang.String parameter1, java.lang.Long parameter2) ;
	java.lang.Long MIN_VALUE;
	java.lang.Long MAX_VALUE;
	java.lang.Class TYPE;
}

package java.lang;

abstract class IllegalAccessError extends java.lang.IncompatibleClassChangeError
{
	public IllegalAccessError() ;
	public IllegalAccessError(java.lang.String parameter1) ;
}

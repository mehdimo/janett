package java.lang;

abstract class IllegalAccessError extends java.lang.IncompatibleClassChangeError
{
}

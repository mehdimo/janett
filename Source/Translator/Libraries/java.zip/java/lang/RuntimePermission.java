package java.lang;

abstract class RuntimePermission extends java.security.BasicPermission
{
}

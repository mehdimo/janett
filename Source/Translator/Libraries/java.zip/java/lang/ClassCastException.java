package java.lang;

abstract class ClassCastException extends java.lang.RuntimeException
{
}

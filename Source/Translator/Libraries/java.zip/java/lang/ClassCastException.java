package java.lang;

abstract class ClassCastException extends java.lang.RuntimeException
{
	public ClassCastException() ;
	public ClassCastException(java.lang.String parameter1) ;
}

package java.lang;

abstract class ClassFormatError extends java.lang.LinkageError
{
	public ClassFormatError() ;
	public ClassFormatError(java.lang.String parameter1) ;
}

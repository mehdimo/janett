package java.lang;

abstract class ClassFormatError extends java.lang.LinkageError
{
}

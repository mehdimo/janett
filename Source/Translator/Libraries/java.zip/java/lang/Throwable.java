package java.lang;

abstract class Throwable implements java.io.Serializable
{
	public java.lang.Void printStackTrace() ;
	public java.lang.Void printStackTrace(java.io.PrintStream parameter1) ;
	public java.lang.Void printStackTrace(java.io.PrintWriter parameter1) ;
	public java.lang.StackTraceElement[] getStackTrace() ;
	public java.lang.Void setStackTrace(java.lang.StackTraceElement[] parameter1) ;
	public java.lang.String getLocalizedMessage() ;
	public java.lang.String getMessage() ;
	public java.lang.String toString() ;
	public java.lang.Throwable fillInStackTrace() ;
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable initCause(java.lang.Throwable parameter1) ;
}

package java.lang;

abstract class StringIndexOutOfBoundsException extends java.lang.IndexOutOfBoundsException
{
}

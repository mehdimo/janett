package java.lang;

abstract class VirtualMachineError extends java.lang.Error
{
}

package java.lang;

abstract class Short extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.Integer compareTo(java.lang.Short parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Short parseShort(java.lang.String parameter1) ;
	public java.lang.Short parseShort(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.String toString(java.lang.Short parameter1) ;
	public java.lang.Short decode(java.lang.String parameter1) ;
	public java.lang.Short valueOf(java.lang.String parameter1) ;
	public java.lang.Short valueOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	java.lang.Short MIN_VALUE;
	java.lang.Short MAX_VALUE;
	java.lang.Class TYPE;
}

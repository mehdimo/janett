package java.lang;

abstract class Error extends java.lang.Throwable
{
}

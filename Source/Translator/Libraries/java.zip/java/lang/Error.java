package java.lang;

abstract class Error extends java.lang.Throwable
{
	public Error() ;
	public Error(java.lang.String parameter1) ;
	public Error(java.lang.Throwable parameter1) ;
	public Error(java.lang.String parameter1, java.lang.Throwable parameter2) ;
}

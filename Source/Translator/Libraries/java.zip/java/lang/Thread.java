package java.lang;

abstract class Thread implements java.lang.Runnable
{
	public java.lang.Integer activeCount() ;
	public java.lang.Integer countStackFrames() ;
	public java.lang.Integer getPriority() ;
	public java.lang.Void checkAccess() ;
	public java.lang.Void destroy() ;
	public java.lang.Void dumpStack() ;
	public java.lang.Void interrupt() ;
	public java.lang.Void join() ;
	public java.lang.Void resume() ;
	public java.lang.Void run() ;
	public java.lang.Void start() ;
	public java.lang.Void stop() ;
	public java.lang.Void suspend() ;
	public java.lang.Void yield() ;
	public java.lang.Boolean interrupted() ;
	public java.lang.Boolean isAlive() ;
	public java.lang.Boolean isDaemon() ;
	public java.lang.Boolean isInterrupted() ;
	public java.lang.Void setPriority(java.lang.Integer parameter1) ;
	public java.lang.Void join(java.lang.Long parameter1) ;
	public java.lang.Void sleep(java.lang.Long parameter1) ;
	public java.lang.Void join(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void sleep(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setDaemon(java.lang.Boolean parameter1) ;
	public java.lang.ClassLoader getContextClassLoader() ;
	public java.lang.Void setContextClassLoader(java.lang.ClassLoader parameter1) ;
	public java.lang.Boolean holdsLock(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Void setName(java.lang.String parameter1) ;
	public java.lang.Thread currentThread() ;
	public java.lang.Integer enumerate(java.lang.Thread[] parameter1) ;
	public java.lang.ThreadGroup getThreadGroup() ;
	public java.lang.Void stop(java.lang.Throwable parameter1) ;
	java.lang.Integer MIN_PRIORITY;
	java.lang.Integer NORM_PRIORITY;
	java.lang.Integer MAX_PRIORITY;
}

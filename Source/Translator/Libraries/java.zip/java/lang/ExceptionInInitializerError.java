package java.lang;

abstract class ExceptionInInitializerError extends java.lang.LinkageError
{
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getException() ;
}

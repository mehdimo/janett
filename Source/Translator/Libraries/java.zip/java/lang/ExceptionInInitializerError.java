package java.lang;

abstract class ExceptionInInitializerError extends java.lang.LinkageError
{
	public ExceptionInInitializerError() ;
	public ExceptionInInitializerError(java.lang.String parameter1) ;
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getException() ;
	public ExceptionInInitializerError(java.lang.Throwable parameter1) ;
}

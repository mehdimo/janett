package java.lang;

abstract class StackTraceElement implements java.io.Serializable
{
	public java.lang.Integer getLineNumber() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isNativeMethod() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getClassName() ;
	public java.lang.String getFileName() ;
	public java.lang.String getMethodName() ;
	public java.lang.String toString() ;
}

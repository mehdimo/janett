package java.lang;

abstract class UnsupportedClassVersionError extends java.lang.ClassFormatError
{
}

package java.lang;

abstract class Double extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public java.lang.Boolean isInfinite() ;
	public java.lang.Boolean isNaN() ;
	public java.lang.Long doubleToLongBits(java.lang.Double parameter1) ;
	public java.lang.Long doubleToRawLongBits(java.lang.Double parameter1) ;
	public Double(java.lang.Double parameter1) ;
	public java.lang.Boolean isInfinite(java.lang.Double parameter1) ;
	public java.lang.Boolean isNaN(java.lang.Double parameter1) ;
	public java.lang.Integer compare(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double longBitsToDouble(java.lang.Long parameter1) ;
	public java.lang.Integer compareTo(java.lang.Double parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Double parameter1) ;
	public java.lang.Double parseDouble(java.lang.String parameter1) ;
	public Double(java.lang.String parameter1) ;
	public java.lang.Double valueOf(java.lang.String parameter1) ;
	java.lang.Double POSITIVE_INFINITY;
	java.lang.Double NEGATIVE_INFINITY;
	java.lang.Double NaN;
	java.lang.Double MAX_VALUE;
	java.lang.Double MIN_VALUE;
	java.lang.Class TYPE;
}

package java.lang;

abstract class IllegalArgumentException extends java.lang.RuntimeException
{
}

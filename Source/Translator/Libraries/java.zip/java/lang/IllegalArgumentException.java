package java.lang;

abstract class IllegalArgumentException extends java.lang.RuntimeException
{
	public IllegalArgumentException() ;
	public IllegalArgumentException(java.lang.String parameter1) ;
}

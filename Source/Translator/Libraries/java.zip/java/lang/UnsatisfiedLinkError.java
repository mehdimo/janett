package java.lang;

abstract class UnsatisfiedLinkError extends java.lang.LinkageError
{
}

package java.lang;

abstract class IncompatibleClassChangeError extends java.lang.LinkageError
{
}

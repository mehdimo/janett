package java.lang;

abstract class IncompatibleClassChangeError extends java.lang.LinkageError
{
	public IncompatibleClassChangeError() ;
	public IncompatibleClassChangeError(java.lang.String parameter1) ;
}

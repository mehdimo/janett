package java.lang;

abstract class Runtime
{
	public java.lang.Integer availableProcessors() ;
	public java.lang.Long freeMemory() ;
	public java.lang.Long maxMemory() ;
	public java.lang.Long totalMemory() ;
	public java.lang.Void gc() ;
	public java.lang.Void runFinalization() ;
	public java.lang.Void exit(java.lang.Integer parameter1) ;
	public java.lang.Void halt(java.lang.Integer parameter1) ;
	public java.lang.Void runFinalizersOnExit(java.lang.Boolean parameter1) ;
	public java.lang.Void traceInstructions(java.lang.Boolean parameter1) ;
	public java.lang.Void traceMethodCalls(java.lang.Boolean parameter1) ;
	public java.lang.Runtime getRuntime() ;
	public java.lang.Void load(java.lang.String parameter1) ;
	public java.lang.Void loadLibrary(java.lang.String parameter1) ;
	public java.lang.Void addShutdownHook(java.lang.Thread parameter1) ;
	public java.lang.Boolean removeShutdownHook(java.lang.Thread parameter1) ;
	public java.io.InputStream getLocalizedInputStream(java.io.InputStream parameter1) ;
	public java.io.OutputStream getLocalizedOutputStream(java.io.OutputStream parameter1) ;
	public java.lang.Process exec(java.lang.String parameter1) ;
	public java.lang.Process exec(java.lang.String[] parameter1) ;
	public java.lang.Process exec(java.lang.String parameter1, java.lang.String[] parameter2) ;
	public java.lang.Process exec(java.lang.String[] parameter1, java.lang.String[] parameter2) ;
	public java.lang.Process exec(java.lang.String parameter1, java.lang.String[] parameter2, java.io.File parameter3) ;
	public java.lang.Process exec(java.lang.String[] parameter1, java.lang.String[] parameter2, java.io.File parameter3) ;
}

package java.lang;

abstract class NoSuchFieldError extends java.lang.IncompatibleClassChangeError
{
}

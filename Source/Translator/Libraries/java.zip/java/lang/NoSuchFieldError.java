package java.lang;

abstract class NoSuchFieldError extends java.lang.IncompatibleClassChangeError
{
	public NoSuchFieldError() ;
	public NoSuchFieldError(java.lang.String parameter1) ;
}

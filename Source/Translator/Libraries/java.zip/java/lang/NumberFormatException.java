package java.lang;

abstract class NumberFormatException extends java.lang.IllegalArgumentException
{
}

package java.lang;

abstract class Float extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public java.lang.Boolean isInfinite() ;
	public java.lang.Boolean isNaN() ;
	public java.lang.Integer floatToIntBits(java.lang.Float parameter1) ;
	public java.lang.Integer floatToRawIntBits(java.lang.Float parameter1) ;
	public java.lang.Boolean isInfinite(java.lang.Float parameter1) ;
	public java.lang.Boolean isNaN(java.lang.Float parameter1) ;
	public java.lang.Integer compare(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.lang.Float intBitsToFloat(java.lang.Integer parameter1) ;
	public java.lang.Integer compareTo(java.lang.Float parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toString(java.lang.Float parameter1) ;
	public java.lang.Float parseFloat(java.lang.String parameter1) ;
	public java.lang.Float valueOf(java.lang.String parameter1) ;
	java.lang.Float POSITIVE_INFINITY;
	java.lang.Float NEGATIVE_INFINITY;
	java.lang.Float NaN;
	java.lang.Float MAX_VALUE;
	java.lang.Float MIN_VALUE;
	java.lang.Class TYPE;
}

package java.lang;

interface Comparable
{
	public abstract java.lang.Integer compareTo(java.lang.Object parameter1) ;
}

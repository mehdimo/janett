package java.lang;

abstract class Compiler
{
	public java.lang.Void disable() ;
	public java.lang.Void enable() ;
	public java.lang.Boolean compileClass(java.lang.Class parameter1) ;
	public java.lang.Boolean compileClasses(java.lang.String parameter1) ;
	public java.lang.Object command(java.lang.Object parameter1) ;
}

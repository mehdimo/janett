package java.lang;

abstract class StrictMath
{
	public java.lang.Double random() ;
	public java.lang.Double abs(java.lang.Double parameter1) ;
	public java.lang.Double acos(java.lang.Double parameter1) ;
	public java.lang.Double asin(java.lang.Double parameter1) ;
	public java.lang.Double atan(java.lang.Double parameter1) ;
	public java.lang.Double ceil(java.lang.Double parameter1) ;
	public java.lang.Double cos(java.lang.Double parameter1) ;
	public java.lang.Double exp(java.lang.Double parameter1) ;
	public java.lang.Double floor(java.lang.Double parameter1) ;
	public java.lang.Double log(java.lang.Double parameter1) ;
	public java.lang.Double rint(java.lang.Double parameter1) ;
	public java.lang.Double sin(java.lang.Double parameter1) ;
	public java.lang.Double sqrt(java.lang.Double parameter1) ;
	public java.lang.Double tan(java.lang.Double parameter1) ;
	public java.lang.Double toDegrees(java.lang.Double parameter1) ;
	public java.lang.Double toRadians(java.lang.Double parameter1) ;
	public java.lang.Long round(java.lang.Double parameter1) ;
	public java.lang.Double IEEEremainder(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double atan2(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double max(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double min(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Double pow(java.lang.Double parameter1, java.lang.Double parameter2) ;
	public java.lang.Float abs(java.lang.Float parameter1) ;
	public java.lang.Integer round(java.lang.Float parameter1) ;
	public java.lang.Float max(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.lang.Float min(java.lang.Float parameter1, java.lang.Float parameter2) ;
	public java.lang.Integer abs(java.lang.Integer parameter1) ;
	public java.lang.Integer max(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer min(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Long abs(java.lang.Long parameter1) ;
	public java.lang.Long max(java.lang.Long parameter1, java.lang.Long parameter2) ;
	public java.lang.Long min(java.lang.Long parameter1, java.lang.Long parameter2) ;
	java.lang.Double E;
	java.lang.Double PI;
}

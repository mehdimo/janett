package java.lang;

abstract class AbstractMethodError extends java.lang.IncompatibleClassChangeError
{
	public AbstractMethodError() ;
	public AbstractMethodError(java.lang.String parameter1) ;
}

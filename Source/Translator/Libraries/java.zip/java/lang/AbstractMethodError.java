package java.lang;

abstract class AbstractMethodError extends java.lang.IncompatibleClassChangeError
{
}

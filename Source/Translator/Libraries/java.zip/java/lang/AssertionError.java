package java.lang;

abstract class AssertionError extends java.lang.Error
{
}

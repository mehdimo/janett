package java.lang;

abstract class AssertionError extends java.lang.Error
{
	public AssertionError() ;
	public AssertionError(java.lang.Character parameter1) ;
	public AssertionError(java.lang.Double parameter1) ;
	public AssertionError(java.lang.Float parameter1) ;
	public AssertionError(java.lang.Integer parameter1) ;
	public AssertionError(java.lang.Long parameter1) ;
	public AssertionError(java.lang.Boolean parameter1) ;
	public AssertionError(java.lang.Object parameter1) ;
}

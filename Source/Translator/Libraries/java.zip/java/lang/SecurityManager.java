package java.lang;

abstract class SecurityManager
{
	public java.lang.Integer classLoaderDepth() ;
	public java.lang.Void checkAwtEventQueueAccess() ;
	public java.lang.Void checkCreateClassLoader() ;
	public java.lang.Void checkPrintJobAccess() ;
	public java.lang.Void checkPropertiesAccess() ;
	public java.lang.Void checkSetFactory() ;
	public java.lang.Void checkSystemClipboardAccess() ;
	public java.lang.Boolean getInCheck() ;
	public java.lang.Boolean inClassLoader() ;
	public java.lang.Void checkExit(java.lang.Integer parameter1) ;
	public java.lang.Void checkListen(java.lang.Integer parameter1) ;
	public java.lang.Void checkRead(java.io.FileDescriptor parameter1) ;
	public java.lang.Void checkWrite(java.io.FileDescriptor parameter1) ;
	public java.lang.Class currentLoadedClass() ;
	public java.lang.Class[] getClassContext() ;
	public java.lang.Void checkMemberAccess(java.lang.Class parameter1, java.lang.Integer parameter2) ;
	public java.lang.ClassLoader currentClassLoader() ;
	public java.lang.Object getSecurityContext() ;
	public java.lang.Boolean checkTopLevelWindow(java.lang.Object parameter1) ;
	public java.lang.Integer classDepth(java.lang.String parameter1) ;
	public java.lang.Void checkDelete(java.lang.String parameter1) ;
	public java.lang.Void checkExec(java.lang.String parameter1) ;
	public java.lang.Void checkLink(java.lang.String parameter1) ;
	public java.lang.Void checkPackageAccess(java.lang.String parameter1) ;
	public java.lang.Void checkPackageDefinition(java.lang.String parameter1) ;
	public java.lang.Void checkPropertyAccess(java.lang.String parameter1) ;
	public java.lang.Void checkRead(java.lang.String parameter1) ;
	public java.lang.Void checkSecurityAccess(java.lang.String parameter1) ;
	public java.lang.Void checkWrite(java.lang.String parameter1) ;
	public java.lang.Boolean inClass(java.lang.String parameter1) ;
	public java.lang.Void checkAccept(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void checkConnect(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void checkAccess(java.lang.Thread parameter1) ;
	public java.lang.ThreadGroup getThreadGroup() ;
	public java.lang.Void checkAccess(java.lang.ThreadGroup parameter1) ;
	public java.lang.Void checkMulticast(java.net.InetAddress parameter1) ;
	public java.lang.Void checkMulticast(java.net.InetAddress parameter1, java.lang.Byte parameter2) ;
	public java.lang.Void checkPermission(java.security.Permission parameter1) ;
	public java.lang.Void checkConnect(java.lang.String parameter1, java.lang.Integer parameter2, java.lang.Object parameter3) ;
	public java.lang.Void checkRead(java.lang.String parameter1, java.lang.Object parameter2) ;
	public java.lang.Void checkPermission(java.security.Permission parameter1, java.lang.Object parameter2) ;
}

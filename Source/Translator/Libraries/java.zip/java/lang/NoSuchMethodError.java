package java.lang;

abstract class NoSuchMethodError extends java.lang.IncompatibleClassChangeError
{
}

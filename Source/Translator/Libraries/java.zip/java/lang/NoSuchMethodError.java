package java.lang;

abstract class NoSuchMethodError extends java.lang.IncompatibleClassChangeError
{
	public NoSuchMethodError() ;
	public NoSuchMethodError(java.lang.String parameter1) ;
}

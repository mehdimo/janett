package java.lang;

abstract class StringBuffer implements java.io.Serializable, java.lang.CharSequence
{
	public java.lang.Integer capacity() ;
	public java.lang.Integer length() ;
	public java.lang.Character charAt(java.lang.Integer parameter1) ;
	public java.lang.Void ensureCapacity(java.lang.Integer parameter1) ;
	public java.lang.Void setLength(java.lang.Integer parameter1) ;
	public java.lang.Void setCharAt(java.lang.Integer parameter1, java.lang.Character parameter2) ;
	public java.lang.Void getChars(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.Character[] parameter3, java.lang.Integer parameter4) ;
	public java.lang.CharSequence subSequence(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.String toString() ;
	public java.lang.String substring(java.lang.Integer parameter1) ;
	public java.lang.String substring(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer indexOf(java.lang.String parameter1) ;
	public java.lang.Integer lastIndexOf(java.lang.String parameter1) ;
	public java.lang.Integer indexOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer lastIndexOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.StringBuffer reverse() ;
	public java.lang.StringBuffer append(java.lang.Character parameter1) ;
	public java.lang.StringBuffer append(java.lang.Double parameter1) ;
	public java.lang.StringBuffer append(java.lang.Float parameter1) ;
	public java.lang.StringBuffer append(java.lang.Integer parameter1) ;
	public java.lang.StringBuffer deleteCharAt(java.lang.Integer parameter1) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Character parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Double parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Float parameter2) ;
	public java.lang.StringBuffer delete(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Long parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Boolean parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Character[] parameter2) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Character[] parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.lang.StringBuffer append(java.lang.Long parameter1) ;
	public java.lang.StringBuffer append(java.lang.Boolean parameter1) ;
	public java.lang.StringBuffer append(java.lang.Character[] parameter1) ;
	public java.lang.StringBuffer append(java.lang.Character[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	public java.lang.StringBuffer append(java.lang.Object parameter1) ;
	public java.lang.StringBuffer replace(java.lang.Integer parameter1, java.lang.Integer parameter2, java.lang.String parameter3) ;
	public java.lang.StringBuffer insert(java.lang.Integer parameter1, java.lang.String parameter2) ;
	public java.lang.StringBuffer append(java.lang.String parameter1) ;
	public java.lang.StringBuffer append(java.lang.StringBuffer parameter1) ;
}

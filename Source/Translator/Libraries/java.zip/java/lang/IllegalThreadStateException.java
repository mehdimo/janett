package java.lang;

abstract class IllegalThreadStateException extends java.lang.IllegalArgumentException
{
	public IllegalThreadStateException() ;
	public IllegalThreadStateException(java.lang.String parameter1) ;
}

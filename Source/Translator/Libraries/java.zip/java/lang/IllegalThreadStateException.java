package java.lang;

abstract class IllegalThreadStateException extends java.lang.IllegalArgumentException
{
}

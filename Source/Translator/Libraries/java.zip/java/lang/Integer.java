package java.lang;

abstract class Integer extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Byte byteValue() ;
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public java.lang.Integer compareTo(java.lang.Integer parameter1) ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.String toBinaryString(java.lang.Integer parameter1) ;
	public java.lang.String toHexString(java.lang.Integer parameter1) ;
	public java.lang.String toOctalString(java.lang.Integer parameter1) ;
	public java.lang.String toString(java.lang.Integer parameter1) ;
	public java.lang.String toString(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer parseInt(java.lang.String parameter1) ;
	public java.lang.Integer parseInt(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer decode(java.lang.String parameter1) ;
	public java.lang.Integer getInteger(java.lang.String parameter1) ;
	public java.lang.Integer valueOf(java.lang.String parameter1) ;
	public java.lang.Integer getInteger(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer valueOf(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer getInteger(java.lang.String parameter1, java.lang.Integer parameter2) ;
	java.lang.Integer MIN_VALUE;
	java.lang.Integer MAX_VALUE;
	java.lang.Class TYPE;
}

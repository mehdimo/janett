package java.lang;

abstract class OutOfMemoryError extends java.lang.VirtualMachineError
{
}

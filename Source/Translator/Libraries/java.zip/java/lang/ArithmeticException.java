package java.lang;

abstract class ArithmeticException extends java.lang.RuntimeException
{
	public ArithmeticException() ;
	public ArithmeticException(java.lang.String parameter1) ;
}

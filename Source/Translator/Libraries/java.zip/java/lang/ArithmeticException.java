package java.lang;

abstract class ArithmeticException extends java.lang.RuntimeException
{
}

package java.lang;

abstract class NoSuchMethodException extends java.lang.Exception
{
	public NoSuchMethodException() ;
	public NoSuchMethodException(java.lang.String parameter1) ;
}

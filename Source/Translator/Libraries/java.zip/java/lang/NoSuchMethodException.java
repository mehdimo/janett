package java.lang;

abstract class NoSuchMethodException extends java.lang.Exception
{
}

package java.lang;

abstract class InstantiationException extends java.lang.Exception
{
}

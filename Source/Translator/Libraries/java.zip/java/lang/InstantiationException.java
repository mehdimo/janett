package java.lang;

abstract class InstantiationException extends java.lang.Exception
{
	public InstantiationException() ;
	public InstantiationException(java.lang.String parameter1) ;
}

package java.lang.reflect;

interface Member
{
	public abstract java.lang.Integer getModifiers() ;
	public abstract java.lang.Class getDeclaringClass() ;
	public abstract java.lang.String getName() ;
	java.lang.Integer PUBLIC;
	java.lang.Integer DECLARED;
}

package java.lang.reflect;

abstract class InvocationTargetException extends java.lang.Exception
{
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getTargetException() ;
}

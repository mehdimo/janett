package java.lang.reflect;

abstract class Field extends java.lang.reflect.AccessibleObject implements java.lang.reflect.Member
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Class getDeclaringClass() ;
	public java.lang.Class getType() ;
	public java.lang.Byte getByte(java.lang.Object parameter1) ;
	public java.lang.Character getChar(java.lang.Object parameter1) ;
	public java.lang.Double getDouble(java.lang.Object parameter1) ;
	public java.lang.Float getFloat(java.lang.Object parameter1) ;
	public java.lang.Integer getInt(java.lang.Object parameter1) ;
	public java.lang.Long getLong(java.lang.Object parameter1) ;
	public java.lang.Short getShort(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.Boolean getBoolean(java.lang.Object parameter1) ;
	public java.lang.Void setByte(java.lang.Object parameter1, java.lang.Byte parameter2) ;
	public java.lang.Void setChar(java.lang.Object parameter1, java.lang.Character parameter2) ;
	public java.lang.Void setDouble(java.lang.Object parameter1, java.lang.Double parameter2) ;
	public java.lang.Void setFloat(java.lang.Object parameter1, java.lang.Float parameter2) ;
	public java.lang.Void setInt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setLong(java.lang.Object parameter1, java.lang.Long parameter2) ;
	public java.lang.Void setShort(java.lang.Object parameter1, java.lang.Short parameter2) ;
	public java.lang.Void setBoolean(java.lang.Object parameter1, java.lang.Boolean parameter2) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Object get(java.lang.Object parameter1) ;
	public java.lang.Void set(java.lang.Object parameter1, java.lang.Object parameter2) ;
}

package java.lang.reflect;

abstract class Proxy implements java.io.Serializable
{
	public java.lang.Boolean isProxyClass(java.lang.Class parameter1) ;
	public java.lang.reflect.InvocationHandler getInvocationHandler(java.lang.Object parameter1) ;
	public java.lang.Class getProxyClass(java.lang.ClassLoader parameter1, java.lang.Class[] parameter2) ;
	public java.lang.Object newProxyInstance(java.lang.ClassLoader parameter1, java.lang.Class[] parameter2, java.lang.reflect.InvocationHandler parameter3) ;
}

package java.lang.reflect;

abstract class Constructor extends java.lang.reflect.AccessibleObject implements java.lang.reflect.Member
{
	public java.lang.Integer getModifiers() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Class getDeclaringClass() ;
	public java.lang.Class[] getExceptionTypes() ;
	public java.lang.Class[] getParameterTypes() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Object newInstance(java.lang.Object[] parameter1) ;
}

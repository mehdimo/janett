package java.lang.reflect;

abstract class UndeclaredThrowableException extends java.lang.RuntimeException
{
	public java.lang.Throwable getCause() ;
	public java.lang.Throwable getUndeclaredThrowable() ;
}

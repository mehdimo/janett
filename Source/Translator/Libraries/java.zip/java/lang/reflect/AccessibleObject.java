package java.lang.reflect;

abstract class AccessibleObject
{
	public java.lang.Boolean isAccessible() ;
	public java.lang.Void setAccessible(java.lang.Boolean parameter1) ;
	public java.lang.Void setAccessible(java.lang.reflect.AccessibleObject[] parameter1, java.lang.Boolean parameter2) ;
}

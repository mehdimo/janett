package java.lang.reflect;

abstract class Modifier
{
	public java.lang.Boolean isAbstract(java.lang.Integer parameter1) ;
	public java.lang.Boolean isFinal(java.lang.Integer parameter1) ;
	public java.lang.Boolean isInterface(java.lang.Integer parameter1) ;
	public java.lang.Boolean isNative(java.lang.Integer parameter1) ;
	public java.lang.Boolean isPrivate(java.lang.Integer parameter1) ;
	public java.lang.Boolean isProtected(java.lang.Integer parameter1) ;
	public java.lang.Boolean isPublic(java.lang.Integer parameter1) ;
	public java.lang.Boolean isStatic(java.lang.Integer parameter1) ;
	public java.lang.Boolean isStrict(java.lang.Integer parameter1) ;
	public java.lang.Boolean isSynchronized(java.lang.Integer parameter1) ;
	public java.lang.Boolean isTransient(java.lang.Integer parameter1) ;
	public java.lang.Boolean isVolatile(java.lang.Integer parameter1) ;
	public java.lang.String toString(java.lang.Integer parameter1) ;
	java.lang.Integer PUBLIC;
	java.lang.Integer PRIVATE;
	java.lang.Integer PROTECTED;
	java.lang.Integer STATIC;
	java.lang.Integer FINAL;
	java.lang.Integer SYNCHRONIZED;
	java.lang.Integer VOLATILE;
	java.lang.Integer TRANSIENT;
	java.lang.Integer NATIVE;
	java.lang.Integer INTERFACE;
	java.lang.Integer ABSTRACT;
	java.lang.Integer STRICT;
}

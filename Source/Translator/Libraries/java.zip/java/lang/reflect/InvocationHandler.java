package java.lang.reflect;

interface InvocationHandler
{
	public abstract java.lang.Object invoke(java.lang.Object parameter1, java.lang.reflect.Method parameter2, java.lang.Object[] parameter3) ;
}

package java.lang.reflect;

abstract class ReflectPermission extends java.security.BasicPermission
{
}

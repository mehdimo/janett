package java.lang.reflect;

abstract class Array
{
	public java.lang.Integer getLength(java.lang.Object parameter1) ;
	public java.lang.Byte getByte(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Character getChar(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Double getDouble(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Float getFloat(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer getInt(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Long getLong(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Short getShort(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Boolean getBoolean(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setByte(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Byte parameter3) ;
	public java.lang.Void setChar(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Character parameter3) ;
	public java.lang.Void setDouble(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Double parameter3) ;
	public java.lang.Void setFloat(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Float parameter3) ;
	public java.lang.Void setInt(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.lang.Void setLong(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Long parameter3) ;
	public java.lang.Void setShort(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Short parameter3) ;
	public java.lang.Void setBoolean(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Boolean parameter3) ;
	public java.lang.Object newInstance(java.lang.Class parameter1, java.lang.Integer parameter2) ;
	public java.lang.Object newInstance(java.lang.Class parameter1, java.lang.Integer[] parameter2) ;
	public java.lang.Object get(java.lang.Object parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void set(java.lang.Object parameter1, java.lang.Integer parameter2, java.lang.Object parameter3) ;
}

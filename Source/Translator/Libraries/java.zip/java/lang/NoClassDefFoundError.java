package java.lang;

abstract class NoClassDefFoundError extends java.lang.LinkageError
{
}

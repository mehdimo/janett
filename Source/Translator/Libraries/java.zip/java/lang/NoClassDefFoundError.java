package java.lang;

abstract class NoClassDefFoundError extends java.lang.LinkageError
{
	public NoClassDefFoundError() ;
	public NoClassDefFoundError(java.lang.String parameter1) ;
}

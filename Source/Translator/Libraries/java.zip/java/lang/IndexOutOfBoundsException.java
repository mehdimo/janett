package java.lang;

abstract class IndexOutOfBoundsException extends java.lang.RuntimeException
{
}

package java.lang;

abstract class IndexOutOfBoundsException extends java.lang.RuntimeException
{
	public IndexOutOfBoundsException() ;
	public IndexOutOfBoundsException(java.lang.String parameter1) ;
}

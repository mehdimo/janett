package java.lang;

abstract class LinkageError extends java.lang.Error
{
}

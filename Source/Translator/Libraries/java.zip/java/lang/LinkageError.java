package java.lang;

abstract class LinkageError extends java.lang.Error
{
	public LinkageError() ;
	public LinkageError(java.lang.String parameter1) ;
}

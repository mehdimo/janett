package java.lang;

abstract class Number implements java.io.Serializable
{
	public java.lang.Byte byteValue() ;
	public abstract java.lang.Double doubleValue() ;
	public abstract java.lang.Float floatValue() ;
	public abstract java.lang.Integer intValue() ;
	public abstract java.lang.Long longValue() ;
	public java.lang.Short shortValue() ;
	public Number() ;
}

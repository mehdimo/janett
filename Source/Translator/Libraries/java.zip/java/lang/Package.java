package java.lang;

abstract class Package
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isSealed() ;
	public java.lang.Package[] getPackages() ;
	public java.lang.String getImplementationTitle() ;
	public java.lang.String getImplementationVendor() ;
	public java.lang.String getImplementationVersion() ;
	public java.lang.String getName() ;
	public java.lang.String getSpecificationTitle() ;
	public java.lang.String getSpecificationVendor() ;
	public java.lang.String getSpecificationVersion() ;
	public java.lang.String toString() ;
	public java.lang.Boolean isCompatibleWith(java.lang.String parameter1) ;
	public java.lang.Boolean isSealed(java.net.URL parameter1) ;
	public java.lang.Package getPackage(java.lang.String parameter1) ;
}

package java.lang;

abstract class UnsupportedOperationException extends java.lang.RuntimeException
{
}

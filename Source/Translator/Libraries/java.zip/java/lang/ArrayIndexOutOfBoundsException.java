package java.lang;

abstract class ArrayIndexOutOfBoundsException extends java.lang.IndexOutOfBoundsException
{
}

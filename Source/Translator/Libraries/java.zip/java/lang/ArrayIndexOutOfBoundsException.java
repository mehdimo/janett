package java.lang;

abstract class ArrayIndexOutOfBoundsException extends java.lang.IndexOutOfBoundsException
{
	public ArrayIndexOutOfBoundsException() ;
	public ArrayIndexOutOfBoundsException(java.lang.Integer parameter1) ;
	public ArrayIndexOutOfBoundsException(java.lang.String parameter1) ;
}

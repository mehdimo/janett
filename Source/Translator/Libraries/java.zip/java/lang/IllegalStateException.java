package java.lang;

abstract class IllegalStateException extends java.lang.RuntimeException
{
	public IllegalStateException() ;
	public IllegalStateException(java.lang.String parameter1) ;
}

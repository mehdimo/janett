package java.lang;

abstract class ThreadGroup
{
	public java.lang.Integer activeCount() ;
	public java.lang.Integer activeGroupCount() ;
	public java.lang.Integer getMaxPriority() ;
	public java.lang.Void checkAccess() ;
	public java.lang.Void destroy() ;
	public java.lang.Void interrupt() ;
	public java.lang.Void list() ;
	public java.lang.Void resume() ;
	public java.lang.Void stop() ;
	public java.lang.Void suspend() ;
	public java.lang.Boolean isDaemon() ;
	public java.lang.Boolean isDestroyed() ;
	public java.lang.Void setMaxPriority(java.lang.Integer parameter1) ;
	public java.lang.Void setDaemon(java.lang.Boolean parameter1) ;
	public java.lang.Boolean allowThreadSuspension(java.lang.Boolean parameter1) ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.lang.Integer enumerate(java.lang.Thread[] parameter1) ;
	public java.lang.Integer enumerate(java.lang.Thread[] parameter1, java.lang.Boolean parameter2) ;
	public java.lang.ThreadGroup getParent() ;
	public java.lang.Boolean parentOf(java.lang.ThreadGroup parameter1) ;
	public java.lang.Integer enumerate(java.lang.ThreadGroup[] parameter1) ;
	public java.lang.Integer enumerate(java.lang.ThreadGroup[] parameter1, java.lang.Boolean parameter2) ;
	public java.lang.Void uncaughtException(java.lang.Thread parameter1, java.lang.Throwable parameter2) ;
}

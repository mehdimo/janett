package java.lang;

abstract class ThreadDeath extends java.lang.Error
{
}

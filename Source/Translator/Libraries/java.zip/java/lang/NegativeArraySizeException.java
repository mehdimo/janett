package java.lang;

abstract class NegativeArraySizeException extends java.lang.RuntimeException
{
}

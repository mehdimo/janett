package java.lang;

abstract class NegativeArraySizeException extends java.lang.RuntimeException
{
	public NegativeArraySizeException() ;
	public NegativeArraySizeException(java.lang.String parameter1) ;
}

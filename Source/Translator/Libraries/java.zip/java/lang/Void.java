package java.lang;

abstract class Void
{
	java.lang.Class TYPE;
}

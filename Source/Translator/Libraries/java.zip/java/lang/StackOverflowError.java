package java.lang;

abstract class StackOverflowError extends java.lang.VirtualMachineError
{
}

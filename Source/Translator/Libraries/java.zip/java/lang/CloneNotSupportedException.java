package java.lang;

abstract class CloneNotSupportedException extends java.lang.Exception
{
}

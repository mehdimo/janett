package java.lang;

abstract class CloneNotSupportedException extends java.lang.Exception
{
	public CloneNotSupportedException() ;
	public CloneNotSupportedException(java.lang.String parameter1) ;
}

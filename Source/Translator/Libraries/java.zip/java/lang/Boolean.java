package java.lang;

abstract class Boolean implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean booleanValue() ;
	public java.lang.Boolean valueOf(java.lang.Boolean parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.lang.Boolean getBoolean(java.lang.String parameter1) ;
	public java.lang.String toString(java.lang.Boolean parameter1) ;
	public java.lang.Boolean valueOf(java.lang.String parameter1) ;
	java.lang.Boolean TRUE;
	java.lang.Boolean FALSE;
	java.lang.Class TYPE;
}

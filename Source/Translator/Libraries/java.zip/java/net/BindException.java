package java.net;

abstract class BindException extends java.net.SocketException
{
}

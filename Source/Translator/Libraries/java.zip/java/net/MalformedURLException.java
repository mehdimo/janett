package java.net;

abstract class MalformedURLException extends java.io.IOException
{
}

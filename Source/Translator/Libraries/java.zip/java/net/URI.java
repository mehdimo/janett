package java.net;

abstract class URI implements java.lang.Comparable, java.io.Serializable
{
	public java.lang.Integer getPort() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isAbsolute() ;
	public java.lang.Boolean isOpaque() ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getAuthority() ;
	public java.lang.String getFragment() ;
	public java.lang.String getHost() ;
	public java.lang.String getPath() ;
	public java.lang.String getQuery() ;
	public java.lang.String getRawAuthority() ;
	public java.lang.String getRawFragment() ;
	public java.lang.String getRawPath() ;
	public java.lang.String getRawQuery() ;
	public java.lang.String getRawSchemeSpecificPart() ;
	public java.lang.String getRawUserInfo() ;
	public java.lang.String getScheme() ;
	public java.lang.String getSchemeSpecificPart() ;
	public java.lang.String getUserInfo() ;
	public java.lang.String toASCIIString() ;
	public java.lang.String toString() ;
	public java.net.URI normalize() ;
	public java.net.URI parseServerAuthority() ;
	public java.net.URL toURL() ;
	public java.net.URI create(java.lang.String parameter1) ;
	public java.net.URI resolve(java.lang.String parameter1) ;
	public java.net.URI relativize(java.net.URI parameter1) ;
	public java.net.URI resolve(java.net.URI parameter1) ;
}

package java.net;

abstract class URLStreamHandler
{
	public java.lang.Integer getDefaultPort() ;
	public java.lang.Integer hashCode(java.net.URL parameter1) ;
	public java.lang.String toExternalForm(java.net.URL parameter1) ;
	public java.lang.Void parseURL(java.net.URL parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.Integer parameter4) ;
	public java.net.InetAddress getHostAddress(java.net.URL parameter1) ;
	public java.lang.Boolean equals(java.net.URL parameter1, java.net.URL parameter2) ;
	public java.lang.Boolean hostsEqual(java.net.URL parameter1, java.net.URL parameter2) ;
	public java.lang.Boolean sameFile(java.net.URL parameter1, java.net.URL parameter2) ;
	public abstract java.net.URLConnection openConnection(java.net.URL parameter1) ;
	public java.lang.Void setURL(java.net.URL parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.Integer parameter4, java.lang.String parameter5, java.lang.String parameter6) ;
	public java.lang.Void setURL(java.net.URL parameter1, java.lang.String parameter2, java.lang.String parameter3, java.lang.Integer parameter4, java.lang.String parameter5, java.lang.String parameter6, java.lang.String parameter7, java.lang.String parameter8, java.lang.String parameter9) ;
}

package java.net;

abstract class ProtocolException extends java.io.IOException
{
}

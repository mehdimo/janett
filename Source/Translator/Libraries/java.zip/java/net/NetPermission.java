package java.net;

abstract class NetPermission extends java.security.BasicPermission
{
}

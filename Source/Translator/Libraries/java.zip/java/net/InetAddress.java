package java.net;

abstract class InetAddress implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isAnyLocalAddress() ;
	public java.lang.Boolean isLinkLocalAddress() ;
	public java.lang.Boolean isLoopbackAddress() ;
	public java.lang.Boolean isMCGlobal() ;
	public java.lang.Boolean isMCLinkLocal() ;
	public java.lang.Boolean isMCNodeLocal() ;
	public java.lang.Boolean isMCOrgLocal() ;
	public java.lang.Boolean isMCSiteLocal() ;
	public java.lang.Boolean isMulticastAddress() ;
	public java.lang.Boolean isSiteLocalAddress() ;
	public java.lang.Byte[] getAddress() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getCanonicalHostName() ;
	public java.lang.String getHostAddress() ;
	public java.lang.String getHostName() ;
	public java.lang.String toString() ;
	public java.net.InetAddress getLocalHost() ;
	public java.net.InetAddress getByAddress(java.lang.Byte[] parameter1) ;
	public java.net.InetAddress getByName(java.lang.String parameter1) ;
	public java.net.InetAddress[] getAllByName(java.lang.String parameter1) ;
	public java.net.InetAddress getByAddress(java.lang.String parameter1, java.lang.Byte[] parameter2) ;
}

package java.net;

abstract class ConnectException extends java.net.SocketException
{
}

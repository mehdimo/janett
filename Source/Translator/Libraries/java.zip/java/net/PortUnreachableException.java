package java.net;

abstract class PortUnreachableException extends java.net.SocketException
{
}

package java.net;

abstract class SocketTimeoutException extends java.io.InterruptedIOException
{
}

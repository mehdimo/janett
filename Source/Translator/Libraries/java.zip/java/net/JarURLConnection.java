package java.net;

abstract class JarURLConnection extends java.net.URLConnection
{
	public java.lang.String getEntryName() ;
	public java.net.URL getJarFileURL() ;
	public java.security.cert.Certificate[] getCertificates() ;
	public java.util.jar.Attributes getAttributes() ;
	public java.util.jar.Attributes getMainAttributes() ;
	public java.util.jar.JarEntry getJarEntry() ;
	public abstract java.util.jar.JarFile getJarFile() ;
	public java.util.jar.Manifest getManifest() ;
}

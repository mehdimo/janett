package java.net;

abstract class NoRouteToHostException extends java.net.SocketException
{
}

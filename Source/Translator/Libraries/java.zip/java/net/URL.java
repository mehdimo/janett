package java.net;

abstract class URL implements java.io.Serializable
{
	public java.lang.Integer getDefaultPort() ;
	public java.lang.Integer getPort() ;
	public java.lang.Integer hashCode() ;
	public java.io.InputStream openStream() ;
	public java.lang.Object getContent() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getAuthority() ;
	public java.lang.String getFile() ;
	public java.lang.String getHost() ;
	public java.lang.String getPath() ;
	public java.lang.String getProtocol() ;
	public java.lang.String getQuery() ;
	public java.lang.String getRef() ;
	public java.lang.String getUserInfo() ;
	public java.lang.String toExternalForm() ;
	public java.lang.String toString() ;
	public java.lang.Boolean sameFile(java.net.URL parameter1) ;
	public java.net.URLConnection openConnection() ;
	public java.lang.Void setURLStreamHandlerFactory(java.net.URLStreamHandlerFactory parameter1) ;
	public java.lang.Object getContent(java.lang.Class[] parameter1) ;
	public java.lang.Void set(java.lang.String parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.String parameter4, java.lang.String parameter5) ;
	public java.lang.Void set(java.lang.String parameter1, java.lang.String parameter2, java.lang.Integer parameter3, java.lang.String parameter4, java.lang.String parameter5, java.lang.String parameter6, java.lang.String parameter7, java.lang.String parameter8) ;
}

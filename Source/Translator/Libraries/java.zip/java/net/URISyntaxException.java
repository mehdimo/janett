package java.net;

abstract class URISyntaxException extends java.lang.Exception
{
	public java.lang.Integer getIndex() ;
	public java.lang.String getInput() ;
	public java.lang.String getMessage() ;
	public java.lang.String getReason() ;
}

package java.net;

abstract class SocketAddress implements java.io.Serializable
{
}

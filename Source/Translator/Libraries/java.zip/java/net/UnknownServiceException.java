package java.net;

abstract class UnknownServiceException extends java.io.IOException
{
}

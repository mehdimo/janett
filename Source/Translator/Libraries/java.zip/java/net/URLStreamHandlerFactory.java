package java.net;

interface URLStreamHandlerFactory
{
	public abstract java.net.URLStreamHandler createURLStreamHandler(java.lang.String parameter1) ;
}

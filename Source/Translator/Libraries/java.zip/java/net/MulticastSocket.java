package java.net;

abstract class MulticastSocket extends java.net.DatagramSocket
{
	public java.lang.Byte getTTL() ;
	public java.lang.Integer getTimeToLive() ;
	public java.lang.Boolean getLoopbackMode() ;
	public java.lang.Void setTTL(java.lang.Byte parameter1) ;
	public java.lang.Void setTimeToLive(java.lang.Integer parameter1) ;
	public java.lang.Void setLoopbackMode(java.lang.Boolean parameter1) ;
	public java.lang.Void send(java.net.DatagramPacket parameter1, java.lang.Byte parameter2) ;
	public java.net.InetAddress getInterface() ;
	public java.lang.Void joinGroup(java.net.InetAddress parameter1) ;
	public java.lang.Void leaveGroup(java.net.InetAddress parameter1) ;
	public java.lang.Void setInterface(java.net.InetAddress parameter1) ;
	public java.net.NetworkInterface getNetworkInterface() ;
	public java.lang.Void setNetworkInterface(java.net.NetworkInterface parameter1) ;
	public java.lang.Void joinGroup(java.net.SocketAddress parameter1, java.net.NetworkInterface parameter2) ;
	public java.lang.Void leaveGroup(java.net.SocketAddress parameter1, java.net.NetworkInterface parameter2) ;
}

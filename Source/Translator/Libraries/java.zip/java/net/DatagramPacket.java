package java.net;

abstract class DatagramPacket
{
	public java.lang.Integer getLength() ;
	public java.lang.Integer getOffset() ;
	public java.lang.Integer getPort() ;
	public java.lang.Byte[] getData() ;
	public java.lang.Void setLength(java.lang.Integer parameter1) ;
	public java.lang.Void setPort(java.lang.Integer parameter1) ;
	public java.lang.Void setData(java.lang.Byte[] parameter1) ;
	public java.lang.Void setData(java.lang.Byte[] parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	public java.net.InetAddress getAddress() ;
	public java.lang.Void setAddress(java.net.InetAddress parameter1) ;
	public java.net.SocketAddress getSocketAddress() ;
	public java.lang.Void setSocketAddress(java.net.SocketAddress parameter1) ;
}

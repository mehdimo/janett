package java.net;

abstract class SocketException extends java.io.IOException
{
}

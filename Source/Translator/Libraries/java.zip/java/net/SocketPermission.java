package java.net;

abstract class SocketPermission extends java.security.Permission implements java.io.Serializable
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getActions() ;
	public java.lang.Boolean implies(java.security.Permission parameter1) ;
	public java.security.PermissionCollection newPermissionCollection() ;
}

package java.net;

abstract class Authenticator
{
	public java.lang.Integer getRequestingPort() ;
	public java.lang.String getRequestingHost() ;
	public java.lang.String getRequestingPrompt() ;
	public java.lang.String getRequestingProtocol() ;
	public java.lang.String getRequestingScheme() ;
	public java.lang.Void setDefault(java.net.Authenticator parameter1) ;
	public java.net.InetAddress getRequestingSite() ;
	public java.net.PasswordAuthentication getPasswordAuthentication() ;
	public java.net.PasswordAuthentication requestPasswordAuthentication(java.net.InetAddress parameter1, java.lang.Integer parameter2, java.lang.String parameter3, java.lang.String parameter4, java.lang.String parameter5) ;
	public java.net.PasswordAuthentication requestPasswordAuthentication(java.lang.String parameter1, java.net.InetAddress parameter2, java.lang.Integer parameter3, java.lang.String parameter4, java.lang.String parameter5, java.lang.String parameter6) ;
}

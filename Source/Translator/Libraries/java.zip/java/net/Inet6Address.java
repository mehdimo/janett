package java.net;

abstract class Inet6Address extends java.net.InetAddress
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isAnyLocalAddress() ;
	public java.lang.Boolean isIPv4CompatibleAddress() ;
	public java.lang.Boolean isLinkLocalAddress() ;
	public java.lang.Boolean isLoopbackAddress() ;
	public java.lang.Boolean isMCGlobal() ;
	public java.lang.Boolean isMCLinkLocal() ;
	public java.lang.Boolean isMCNodeLocal() ;
	public java.lang.Boolean isMCOrgLocal() ;
	public java.lang.Boolean isMCSiteLocal() ;
	public java.lang.Boolean isMulticastAddress() ;
	public java.lang.Boolean isSiteLocalAddress() ;
	public java.lang.Byte[] getAddress() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getHostAddress() ;
}

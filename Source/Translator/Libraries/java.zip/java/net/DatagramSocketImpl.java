package java.net;

abstract class DatagramSocketImpl implements java.net.SocketOptions
{
	public abstract java.lang.Byte getTTL() ;
	public java.lang.Integer getLocalPort() ;
	public abstract java.lang.Integer getTimeToLive() ;
	public abstract java.lang.Void close() ;
	public abstract java.lang.Void create() ;
	public java.lang.Void disconnect() ;
	public abstract java.lang.Void setTTL(java.lang.Byte parameter1) ;
	public abstract java.lang.Void setTimeToLive(java.lang.Integer parameter1) ;
	public java.io.FileDescriptor getFileDescriptor() ;
	public abstract java.lang.Integer peekData(java.net.DatagramPacket parameter1) ;
	public abstract java.lang.Void receive(java.net.DatagramPacket parameter1) ;
	public abstract java.lang.Void send(java.net.DatagramPacket parameter1) ;
	public abstract java.lang.Void bind(java.lang.Integer parameter1, java.net.InetAddress parameter2) ;
	public abstract java.lang.Integer peek(java.net.InetAddress parameter1) ;
	public abstract java.lang.Void join(java.net.InetAddress parameter1) ;
	public abstract java.lang.Void leave(java.net.InetAddress parameter1) ;
	public java.lang.Void connect(java.net.InetAddress parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void joinGroup(java.net.SocketAddress parameter1, java.net.NetworkInterface parameter2) ;
	public abstract java.lang.Void leaveGroup(java.net.SocketAddress parameter1, java.net.NetworkInterface parameter2) ;
}

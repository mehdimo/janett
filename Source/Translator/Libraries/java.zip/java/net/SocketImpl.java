package java.net;

abstract class SocketImpl implements java.net.SocketOptions
{
	public abstract java.lang.Integer available() ;
	public java.lang.Integer getLocalPort() ;
	public java.lang.Integer getPort() ;
	public abstract java.lang.Void close() ;
	public java.lang.Void shutdownInput() ;
	public java.lang.Void shutdownOutput() ;
	public java.lang.Boolean supportsUrgentData() ;
	public abstract java.lang.Void listen(java.lang.Integer parameter1) ;
	public abstract java.lang.Void sendUrgentData(java.lang.Integer parameter1) ;
	public abstract java.lang.Void create(java.lang.Boolean parameter1) ;
	public java.io.FileDescriptor getFileDescriptor() ;
	public abstract java.io.InputStream getInputStream() ;
	public abstract java.io.OutputStream getOutputStream() ;
	public java.lang.String toString() ;
	public abstract java.lang.Void connect(java.lang.String parameter1, java.lang.Integer parameter2) ;
	public java.net.InetAddress getInetAddress() ;
	public abstract java.lang.Void bind(java.net.InetAddress parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void connect(java.net.InetAddress parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void connect(java.net.SocketAddress parameter1, java.lang.Integer parameter2) ;
	public abstract java.lang.Void accept(java.net.SocketImpl parameter1) ;
}

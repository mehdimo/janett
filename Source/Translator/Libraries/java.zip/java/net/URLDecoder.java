package java.net;

abstract class URLDecoder
{
	public java.lang.String decode(java.lang.String parameter1) ;
	public java.lang.String decode(java.lang.String parameter1, java.lang.String parameter2) ;
}

package java.net;

abstract class Socket
{
	public java.lang.Integer getLocalPort() ;
	public java.lang.Integer getPort() ;
	public java.lang.Integer getReceiveBufferSize() ;
	public java.lang.Integer getSendBufferSize() ;
	public java.lang.Integer getSoLinger() ;
	public java.lang.Integer getSoTimeout() ;
	public java.lang.Integer getTrafficClass() ;
	public java.lang.Void close() ;
	public java.lang.Void shutdownInput() ;
	public java.lang.Void shutdownOutput() ;
	public java.lang.Boolean getKeepAlive() ;
	public java.lang.Boolean getOOBInline() ;
	public java.lang.Boolean getReuseAddress() ;
	public java.lang.Boolean getTcpNoDelay() ;
	public java.lang.Boolean isBound() ;
	public java.lang.Boolean isClosed() ;
	public java.lang.Boolean isConnected() ;
	public java.lang.Boolean isInputShutdown() ;
	public java.lang.Boolean isOutputShutdown() ;
	public java.lang.Void sendUrgentData(java.lang.Integer parameter1) ;
	public java.lang.Void setReceiveBufferSize(java.lang.Integer parameter1) ;
	public java.lang.Void setSendBufferSize(java.lang.Integer parameter1) ;
	public java.lang.Void setSoTimeout(java.lang.Integer parameter1) ;
	public java.lang.Void setTrafficClass(java.lang.Integer parameter1) ;
	public java.lang.Void setKeepAlive(java.lang.Boolean parameter1) ;
	public java.lang.Void setOOBInline(java.lang.Boolean parameter1) ;
	public java.lang.Void setReuseAddress(java.lang.Boolean parameter1) ;
	public java.lang.Void setTcpNoDelay(java.lang.Boolean parameter1) ;
	public java.lang.Void setSoLinger(java.lang.Boolean parameter1, java.lang.Integer parameter2) ;
	public java.io.InputStream getInputStream() ;
	public java.io.OutputStream getOutputStream() ;
	public java.lang.String toString() ;
	public java.net.InetAddress getInetAddress() ;
	public java.net.InetAddress getLocalAddress() ;
	public java.net.SocketAddress getLocalSocketAddress() ;
	public java.net.SocketAddress getRemoteSocketAddress() ;
	public java.lang.Void bind(java.net.SocketAddress parameter1) ;
	public java.lang.Void connect(java.net.SocketAddress parameter1) ;
	public java.lang.Void connect(java.net.SocketAddress parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setSocketImplFactory(java.net.SocketImplFactory parameter1) ;
	public java.nio.channels.SocketChannel getChannel() ;
}

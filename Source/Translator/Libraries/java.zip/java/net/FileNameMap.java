package java.net;

interface FileNameMap
{
	public abstract java.lang.String getContentTypeFor(java.lang.String parameter1) ;
}

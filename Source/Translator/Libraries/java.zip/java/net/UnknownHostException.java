package java.net;

abstract class UnknownHostException extends java.io.IOException
{
}

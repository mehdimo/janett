package java.net;

abstract class ContentHandler
{
	public abstract java.lang.Object getContent(java.net.URLConnection parameter1) ;
	public java.lang.Object getContent(java.net.URLConnection parameter1, java.lang.Class[] parameter2) ;
}

package java.net;

interface SocketImplFactory
{
	public abstract java.net.SocketImpl createSocketImpl() ;
}

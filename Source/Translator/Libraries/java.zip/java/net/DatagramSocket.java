package java.net;

abstract class DatagramSocket
{
	public java.lang.Integer getLocalPort() ;
	public java.lang.Integer getPort() ;
	public java.lang.Integer getReceiveBufferSize() ;
	public java.lang.Integer getSendBufferSize() ;
	public java.lang.Integer getSoTimeout() ;
	public java.lang.Integer getTrafficClass() ;
	public java.lang.Void close() ;
	public java.lang.Void disconnect() ;
	public java.lang.Boolean getBroadcast() ;
	public java.lang.Boolean getReuseAddress() ;
	public java.lang.Boolean isBound() ;
	public java.lang.Boolean isClosed() ;
	public java.lang.Boolean isConnected() ;
	public java.lang.Void setReceiveBufferSize(java.lang.Integer parameter1) ;
	public java.lang.Void setSendBufferSize(java.lang.Integer parameter1) ;
	public java.lang.Void setSoTimeout(java.lang.Integer parameter1) ;
	public java.lang.Void setTrafficClass(java.lang.Integer parameter1) ;
	public java.lang.Void setBroadcast(java.lang.Boolean parameter1) ;
	public java.lang.Void setReuseAddress(java.lang.Boolean parameter1) ;
	public java.lang.Void receive(java.net.DatagramPacket parameter1) ;
	public java.lang.Void send(java.net.DatagramPacket parameter1) ;
	public java.lang.Void setDatagramSocketImplFactory(java.net.DatagramSocketImplFactory parameter1) ;
	public java.net.InetAddress getInetAddress() ;
	public java.net.InetAddress getLocalAddress() ;
	public java.lang.Void connect(java.net.InetAddress parameter1, java.lang.Integer parameter2) ;
	public java.net.SocketAddress getLocalSocketAddress() ;
	public java.net.SocketAddress getRemoteSocketAddress() ;
	public java.lang.Void bind(java.net.SocketAddress parameter1) ;
	public java.lang.Void connect(java.net.SocketAddress parameter1) ;
	public java.nio.channels.DatagramChannel getChannel() ;
}

package java.net;

abstract class URLClassLoader extends java.security.SecureClassLoader
{
	public java.net.URL[] getURLs() ;
	public java.lang.Void addURL(java.net.URL parameter1) ;
	public java.lang.Class findClass(java.lang.String parameter1) ;
	public java.net.URL findResource(java.lang.String parameter1) ;
	public java.net.URLClassLoader newInstance(java.net.URL[] parameter1) ;
	public java.security.PermissionCollection getPermissions(java.security.CodeSource parameter1) ;
	public java.util.Enumeration findResources(java.lang.String parameter1) ;
	public java.net.URLClassLoader newInstance(java.net.URL[] parameter1, java.lang.ClassLoader parameter2) ;
	public java.lang.Package definePackage(java.lang.String parameter1, java.util.jar.Manifest parameter2, java.net.URL parameter3) ;
}

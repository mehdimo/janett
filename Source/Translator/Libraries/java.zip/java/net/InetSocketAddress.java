package java.net;

abstract class InetSocketAddress extends java.net.SocketAddress
{
	public java.lang.Integer getPort() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean isUnresolved() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getHostName() ;
	public java.lang.String toString() ;
	public java.net.InetAddress getAddress() ;
}

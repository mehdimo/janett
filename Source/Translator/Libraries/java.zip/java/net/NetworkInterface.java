package java.net;

abstract class NetworkInterface
{
	public java.lang.Integer hashCode() ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String getDisplayName() ;
	public java.lang.String getName() ;
	public java.lang.String toString() ;
	public java.util.Enumeration getInetAddresses() ;
	public java.util.Enumeration getNetworkInterfaces() ;
	public java.net.NetworkInterface getByName(java.lang.String parameter1) ;
	public java.net.NetworkInterface getByInetAddress(java.net.InetAddress parameter1) ;
}

package java.net;

interface DatagramSocketImplFactory
{
	public abstract java.net.DatagramSocketImpl createDatagramSocketImpl() ;
}

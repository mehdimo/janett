package java.net;

abstract class URLEncoder
{
	public java.lang.String encode(java.lang.String parameter1) ;
	public java.lang.String encode(java.lang.String parameter1, java.lang.String parameter2) ;
}

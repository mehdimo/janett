package java.net;

abstract class PasswordAuthentication
{
	public java.lang.Character[] getPassword() ;
	public java.lang.String getUserName() ;
}

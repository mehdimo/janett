package java.net;

interface SocketOptions
{
	public abstract java.lang.Object getOption(java.lang.Integer parameter1) ;
	public abstract java.lang.Void setOption(java.lang.Integer parameter1, java.lang.Object parameter2) ;
	java.lang.Integer TCP_NODELAY;
	java.lang.Integer SO_BINDADDR;
	java.lang.Integer SO_REUSEADDR;
	java.lang.Integer SO_BROADCAST;
	java.lang.Integer IP_MULTICAST_IF;
	java.lang.Integer IP_MULTICAST_IF2;
	java.lang.Integer IP_MULTICAST_LOOP;
	java.lang.Integer IP_TOS;
	java.lang.Integer SO_LINGER;
	java.lang.Integer SO_TIMEOUT;
	java.lang.Integer SO_SNDBUF;
	java.lang.Integer SO_RCVBUF;
	java.lang.Integer SO_KEEPALIVE;
	java.lang.Integer SO_OOBINLINE;
}

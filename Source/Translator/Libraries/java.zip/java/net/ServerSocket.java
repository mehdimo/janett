package java.net;

abstract class ServerSocket
{
	public java.lang.Integer getLocalPort() ;
	public java.lang.Integer getReceiveBufferSize() ;
	public java.lang.Integer getSoTimeout() ;
	public java.lang.Void close() ;
	public java.lang.Boolean getReuseAddress() ;
	public java.lang.Boolean isBound() ;
	public java.lang.Boolean isClosed() ;
	public java.lang.Void setReceiveBufferSize(java.lang.Integer parameter1) ;
	public java.lang.Void setSoTimeout(java.lang.Integer parameter1) ;
	public java.lang.Void setReuseAddress(java.lang.Boolean parameter1) ;
	public java.lang.String toString() ;
	public java.net.InetAddress getInetAddress() ;
	public java.net.Socket accept() ;
	public java.lang.Void implAccept(java.net.Socket parameter1) ;
	public java.net.SocketAddress getLocalSocketAddress() ;
	public java.lang.Void bind(java.net.SocketAddress parameter1) ;
	public java.lang.Void bind(java.net.SocketAddress parameter1, java.lang.Integer parameter2) ;
	public java.lang.Void setSocketFactory(java.net.SocketImplFactory parameter1) ;
	public java.nio.channels.ServerSocketChannel getChannel() ;
}

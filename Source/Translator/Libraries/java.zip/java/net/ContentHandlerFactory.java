package java.net;

interface ContentHandlerFactory
{
	public abstract java.net.ContentHandler createContentHandler(java.lang.String parameter1) ;
}

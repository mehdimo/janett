package java.applet;

interface AudioClip
{
	public abstract java.lang.Void loop() ;
	public abstract java.lang.Void play() ;
	public abstract java.lang.Void stop() ;
}

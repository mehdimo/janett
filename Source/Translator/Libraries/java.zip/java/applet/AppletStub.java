package java.applet;

interface AppletStub
{
	public abstract java.lang.Boolean isActive() ;
	public abstract java.lang.Void appletResize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public abstract java.applet.AppletContext getAppletContext() ;
	public abstract java.net.URL getCodeBase() ;
	public abstract java.net.URL getDocumentBase() ;
	public abstract java.lang.String getParameter(java.lang.String parameter1) ;
}

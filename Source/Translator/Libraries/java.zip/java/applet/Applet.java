package java.applet;

abstract class Applet extends java.awt.Panel
{
	public java.lang.Void destroy() ;
	public java.lang.Void init() ;
	public java.lang.Void start() ;
	public java.lang.Void stop() ;
	public java.lang.Boolean isActive() ;
	public java.lang.Void resize(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.applet.AppletContext getAppletContext() ;
	public java.lang.Void setStub(java.applet.AppletStub parameter1) ;
	public java.lang.Void resize(java.awt.Dimension parameter1) ;
	public java.lang.String getAppletInfo() ;
	public void getParameterInfo() ;
	public java.lang.Void showStatus(java.lang.String parameter1) ;
	public java.net.URL getCodeBase() ;
	public java.net.URL getDocumentBase() ;
	public java.lang.Void play(java.net.URL parameter1) ;
	public java.util.Locale getLocale() ;
	public javax.accessibility.AccessibleContext getAccessibleContext() ;
	public java.applet.AudioClip getAudioClip(java.net.URL parameter1) ;
	public java.applet.AudioClip newAudioClip(java.net.URL parameter1) ;
	public java.awt.Image getImage(java.net.URL parameter1) ;
	public java.lang.String getParameter(java.lang.String parameter1) ;
	public java.lang.Void play(java.net.URL parameter1, java.lang.String parameter2) ;
	public java.applet.AudioClip getAudioClip(java.net.URL parameter1, java.lang.String parameter2) ;
	public java.awt.Image getImage(java.net.URL parameter1, java.lang.String parameter2) ;
	abstract class AccessibleApplet extends java.awt.Panel.AccessibleAWTPanel
	{
		public javax.accessibility.AccessibleRole getAccessibleRole() ;
		public javax.accessibility.AccessibleStateSet getAccessibleStateSet() ;
	}
}

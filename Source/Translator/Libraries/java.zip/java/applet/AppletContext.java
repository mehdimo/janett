package java.applet;

interface AppletContext
{
	public abstract java.lang.Void showStatus(java.lang.String parameter1) ;
	public abstract java.lang.Void showDocument(java.net.URL parameter1) ;
	public abstract java.util.Enumeration getApplets() ;
	public abstract java.util.Iterator getStreamKeys() ;
	public abstract java.applet.Applet getApplet(java.lang.String parameter1) ;
	public abstract java.applet.AudioClip getAudioClip(java.net.URL parameter1) ;
	public abstract java.awt.Image getImage(java.net.URL parameter1) ;
	public abstract java.io.InputStream getStream(java.lang.String parameter1) ;
	public abstract java.lang.Void setStream(java.lang.String parameter1, java.io.InputStream parameter2) ;
	public abstract java.lang.Void showDocument(java.net.URL parameter1, java.lang.String parameter2) ;
}

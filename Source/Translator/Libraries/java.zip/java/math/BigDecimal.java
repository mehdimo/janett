package java.math;

abstract class BigDecimal extends java.lang.Number implements java.lang.Comparable
{
	public java.lang.Double doubleValue() ;
	public java.lang.Float floatValue() ;
	public java.lang.Integer hashCode() ;
	public java.lang.Integer intValue() ;
	public java.lang.Integer scale() ;
	public java.lang.Integer signum() ;
	public java.lang.Long longValue() ;
	public java.lang.Integer compareTo(java.lang.Object parameter1) ;
	public java.lang.Boolean equals(java.lang.Object parameter1) ;
	public java.lang.String toString() ;
	public java.math.BigDecimal abs() ;
	public java.math.BigDecimal negate() ;
	public java.math.BigDecimal movePointLeft(java.lang.Integer parameter1) ;
	public java.math.BigDecimal movePointRight(java.lang.Integer parameter1) ;
	public java.math.BigDecimal setScale(java.lang.Integer parameter1) ;
	public java.math.BigDecimal setScale(java.lang.Integer parameter1, java.lang.Integer parameter2) ;
	public java.math.BigDecimal valueOf(java.lang.Long parameter1) ;
	public java.math.BigDecimal valueOf(java.lang.Long parameter1, java.lang.Integer parameter2) ;
	public java.lang.Integer compareTo(java.math.BigDecimal parameter1) ;
	public java.math.BigInteger toBigInteger() ;
	public java.math.BigInteger unscaledValue() ;
	public java.math.BigDecimal add(java.math.BigDecimal parameter1) ;
	public java.math.BigDecimal max(java.math.BigDecimal parameter1) ;
	public java.math.BigDecimal min(java.math.BigDecimal parameter1) ;
	public java.math.BigDecimal multiply(java.math.BigDecimal parameter1) ;
	public java.math.BigDecimal subtract(java.math.BigDecimal parameter1) ;
	public java.math.BigDecimal divide(java.math.BigDecimal parameter1, java.lang.Integer parameter2) ;
	public java.math.BigDecimal divide(java.math.BigDecimal parameter1, java.lang.Integer parameter2, java.lang.Integer parameter3) ;
	java.lang.Integer ROUND_UP;
	java.lang.Integer ROUND_DOWN;
	java.lang.Integer ROUND_CEILING;
	java.lang.Integer ROUND_FLOOR;
	java.lang.Integer ROUND_HALF_UP;
	java.lang.Integer ROUND_HALF_DOWN;
	java.lang.Integer ROUND_HALF_EVEN;
	java.lang.Integer ROUND_UNNECESSARY;
}
